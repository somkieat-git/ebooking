<?
	
	ob_start();
	session_start();
	if(isset($_REQUEST['s'])){
		$_SESSION["site"]=$_REQUEST['s'];
		$site=$_SESSION["site"];
	}else{
		$_SESSION["site"]="no";
		$site="no";
	}
?>
<script>
window.location='./ql/index_tspc2.php?s=<?=$site;?>';
//window.location='http://nccubuntu.qsncc.co.th/app/nccgroup/thebook1.7/ql/index_tspc2.php';
//window.location='http://nccubuntu.qsncc.co.th/app/nccgroup/thebook1.7/ql/index_tspc2.php?s=<?=$nccSite?>';
//window.location='http://nccubuntu.qsncc.co.th/app/nccgroup/tsp-cc/thebook1.6/index.php';
</script>
