<?
	ob_start(); 
	session_start();
?>

<html>
<head>
<script>
<!--

/*By JavaScript Kit
http://javascriptkit.com
Credit MUST stay intact for use
*/

function show2(){
if (!document.all&&!document.getElementById)
return
thelement=document.getElementById? document.getElementById("tick2"): document.all.tick2
var Digital=new Date()

var year=Digital.getYear()
if (year < 1000)
year+=1900
var day=Digital.getDay()
var month=Digital.getMonth()
var daym=Digital.getDate()
if (daym<10)
daym="0"+daym
var dayarray=new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday")
var montharray=new Array("January","February","March","April","May","June","July","August","September","October","November","December")


var hours=Digital.getHours()
var minutes=Digital.getMinutes()
var seconds=Digital.getSeconds()
var dn="PM"
if (hours<12)
dn="AM"
if (hours>12)
hours=hours-12
if (hours==0)
hours=12
if (minutes<=9)
minutes="0"+minutes
if (seconds<=9)
seconds="0"+seconds
var cdate = dayarray[day]+", "+daym+" - "+ montharray[month]+" - "+ year
var ctime=hours+":"+minutes+":"+seconds+" "+dn
thelement.innerHTML="<b style='font-size:9;color:#339900;'>"+ " [ "+cdate + "  : "+ctime+" ] </b>"
setTimeout("show2()",1000)
}
window.onload=show2
//-->
</script>


	<title></title>	
	<link rel="stylesheet" href="css/format.css.css" type="text/css">
</head>

<body bgcolor="#FFFFFF" style="margin-left:11px;">
<br >
<table width="100%"  bgcolor="#FFFFFF">
	<tr style="color:#339900; font-weight:bold;">
		<td width="5%" rowspan="2"><div align="center">
		  </div></td>
		<td height="20" colspan="3" align="center"><font size="+2"><?=$_SESSION["progname"] ;?></font></td>
		<td colspan="2" align="right">Version <?=$_SESSION["version"] ;?></td>
    </tr>
	<tr style="color:#339900; font-weight:bold;">
		<td width="69%" height="26" align="left" valign="bottom">user : <?=$_SESSION["usr_name"];?>		<span  id=tick2></span></td>
		<td width="5%" align="right" valign="bottom"><a href="fra_booking.php" target="main_Frame"><img src="images/icon-booking.gif" width="80" height="24" border="0"></a></td>
		<td width="7%" align="right" valign="bottom"><img src="images/icon-calendar.gif" width="80" height="24"></td>
		<td width="7%" align="right" valign="bottom"><a href="fra_maintenance.php" target="main_Frame"><img src="images/icon-master.gif" width="80" height="24" border="0"></a> </td>
		<td width="7%" align="right" valign="bottom"><a href="signout.php" target="_parent"><img src="images/icon-logout.gif" width="80" height="24" border="0"></a></td>
	</tr>
</table>
<hr width="100%" noshade  color="#339900">
<br>
</body>
</html>