<?
	ob_start();
	session_start();	
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");	
	
	$eckl_follow_date = $_REQUEST["eckl_follow_date"];
	if($eckl_follow_date) $eckl_follow_date = chgDateToDb($_REQUEST["eckl_follow_date"]);
	$eckl_item = $_REQUEST["eckl_item"];
	$eckl_fperson = $_REQUEST["eckl_fperson"];
	$eckl_complete_date = $_REQUEST["eckl_complete_date"];
	$eckl_cperson = $_REQUEST["eckl_cperson"];
	if($eckl_complete_date) {
		$eckl_complete_date = chgDateToDb($_REQUEST["eckl_complete_date"]);
		if(empty($eckl_cperson))
			$eckl_cperson = $_SESSION["usr_name"];
	}

	$id = $_REQUEST["id"];
	$id2 = $_REQUEST["id2"];
	$action = $_REQUEST["a"];
	$Submit = $_REQUEST["Submit"];
	$cap_name = array();
	$cap_name = array("#","Event id","Follow Date","Item","Follow Person","Complete Date","By Whom");

			   
	define("viewForm","eckl_viewForm.php?id=$id");
	define("prevForm","ecmt_updForm.php?id=$id");
	define("nextForm","dpd_viewForm.php?id=$id");
	define("updSave","eckl_updForm.php");
	define("tableName","ev_checklist");
	define("menuName","eChecklist");
	define("field_id","eckl_id");
	define("id",$id);	
	define("id2",$id2);	
	define("action",$action);
	define("beg_id",2);	
	define("end_id",6);	
	include_once("func/ev_updForm.func.php");	
	
	function duplicate($field,$value){
		global $dup;
		
		$sql = "select $field 
				from tableName 
				where $field = '$value' ";
		echo $sql;
		
		$table = mysql_query($sql) or die ("Connect Err.");
		$row=mysql_fetch_array($table);
		if($row[$field]== $value){
			$dup[$field] = $value;
		}//if($row[$field]== $value){
	}//	function duplicate($field,$value){	
				
	function checklist($var,$name){
		global $data;
		global $flag;
		/*
		if(empty($var)){
			if(ereg("usr_login|usr_pass|usr_sec|usr_name",$name))
				$flag = 1;
		}  //if(empty($var)){
		*/
		$data[$name] = $var;
	} //function checklist($var,$name){
	
	if(!empty($Submit)){
		checklist($eckl_follow_date,"eckl_follow_date");
		checklist($eckl_item,"eckl_item");
		checklist($eckl_fperson,"eckl_fperson");
		checklist($eckl_complete_date,"eckl_complete_date"); 
		checklist($eckl_cperson,"eckl_cperson"); 
		/*
		if($flag){
			$mesg = "Please input data in ";
			while(list($key,$value) = each($data)){
				if(empty($value)){
				if(!ereg("usr_login|usr_pass|usr_sec|usr_name",$name))
						$str .= "$key,";
				}  //if(empty($value)){
				//$str = substr( $str, strlen($str)-1, 1 );
			}
			echo errmesg ("$mesg $str");			
		}	//if($flag){
		else
		*/
		{
			if ($action=="a"){
			
				$data["eckl_id"] = "";
				$data["evn_id"] = "$id";
				$data["usr_cre"] = $_SESSION["usr_name"];
				$data["date_cre"] = date("Y/m/d  H:i:s");
				/*
				duplicate("usr_login",$usr_login);
				duplicate("usr_pass",$usr_pass);
				duplicate("usr_name",$usr_name);
				if(count($dup)>0) {
					while(list($key,$value)= each($dup)){
						//echo "$key<br>";
						if(ereg("usr_login|usr_pass|usr_name",$key))
							$str .= $key.",";
					} // while(list($key,$value)= each($dup)){				
					echo errmesg("Duplicate $str");
					exit();
				}//if(count($dup)>0) {
				*/
		
				$query = create_insert_query($table_name,$data);				
				//echo "$query<br>";
				mysql_query($query) or die("Insert error");	
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");	
				//Show alert by javascript
				echo "<script>
						alert ('Insert complete');
						window.location = '$updSave?a=a&id=$id';
					  </script>";
				exit();
			} //if ($action=="a"){
			
			if ($action=="e"){				
				$data["usr_upd"] = $_SESSION["usr_name"];
				$data["date_upd"] = date("Y/m/d  H:i:s");				
				/*
				duplicate("usr_login",$usr_login);
				duplicate("usr_pass",$usr_pass);
				duplicate("usr_name",$usr_name);
				if(count($dup)>0) {
					while(list($key,$value)= each($dup)){
						//echo "$key<br>";
						if(ereg("usr_login|usr_pass|usr_name",$key))
							$str .= $key.",";
					} // while(list($key,$value)= each($dup)){				
					echo errmesg("Duplicate $str");
					exit();
				}//if(count($dup)>0) {
				*/
				$query = create_update_evquery($table_name, $data, $id2, $field_id ,$id ,'evn_id');		
				//echo "$query<br>";
				//exit();
				mysql_query($query) or die("Update error");		
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");
				//Show alert by javascript
				echo "<script>
						alert ('Update complete');
						window.location = '$viewForm';
					  </script>";
				exit();
			}  //if ($action=="e"){
			
			if ($action=="d"){
				$query = "DELETE FROM $table_name WHERE $field_id = $id2 " ;
				$query .= " AND evn_id = '$id' ";
				//echo "$query<br>";
				//exit();
				
				mysql_query($query) or die("Delete error");		
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");
				//Show alert by javascript
				echo "<script>
						alert ('Delete complete');
						window.location = '$viewForm';
					  </script>";
				exit();
			}  //if ($action=="e"){
						
		}  //else{ of if($flag){
	}  //if(!empty($Submit)){
	
?>
<script language="javascript">
	function validate() 
	{
		if(frm.eckl_follow_date.value=="")
		{
			alert('Please input data in Follow Date');
			frm.eckl_follow_date.focus();
			return false;
		}
		
		if(frm.eckl_item.value=="")
		{
			alert('Please input data in Checklist Item Name');
			frm.eckl_item.focus();
			return false;
		}
		
		if(frm.eckl_fperson.value=="Not Assign")
		{
			alert('Please input data in Checklist Follow Person');
			frm.eckl_fperson.focus();
			return false;
		}		
	}
</script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</body>
</html>
