<?php 
	ob_start(); 
	session_start();
		
	include_once("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	include "./cfg/config.cfg.php";
	$prefix = strtoupper(prefix);	

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Gen Script Import</title>
<link href="css/format.css.css" rel="stylesheet" type="text/css">
<script type="text/javascript">
function Conf(){
		if(confirm("Are You Sure!!")== true){			
			window.location =  "gen_script.php";
			return true;
		}
		return false;
}

</script>
</head>

<body style="margin-left:11px;margin-top:15px;">

<form id="frm" name="frm" method="post" action="gen_script.php">
<table border="0" class="BorderGreen" width="530">
     <tr class="BorderSilver">
      <td width="474" colspan="4" style="background-color:#339900;font-weight:bold;color:White;">
	  	<div align="center"><strong >Script Import</strong></div>
	  </td>
    </tr>   
	 <tr>
      <td><div align="center">Insert Nameinfo to Profile : </div></td>
      <td>
		  <div align="center">
			<input type="submit" name="Submit" id="Submit" value="Run Script" />
		  </div>
	  </td>
    </tr>
  </table>
</form>
<?php 
$Submit = $_REQUEST["Submit"];

if( !empty($Submit) ){
	
	$sql = "SELECT * FROM nameinfo ";
			//$result = getData($sql);
			$result = mysql_query($sql);
			$info_data = array();
			
			while( $row = mysql_fetch_array( $result ) ){
				
				$f_nameinfo = get_table_fieldname("nameinfo");
				foreach( $f_nameinfo as $key => $val ){
					//$row = mysql_fetch_array( $result ) ;
					$info_data[$val] = $row[$val];					
				}
				
				$arrData[] = $info_data;
				
			}
			
			//echo "<pre>"; print_r($arrData); echo "<hr>";
			
			$arrProfile = array();
			for($i=0; $i<sizeof($arrData); $i++){
				foreach( $arrData[$i] as $inField => $inVal ){ //$arrData[0][id]
					$f_name = get_table_fieldname("profile");
					foreach( $f_name as $fKey => $fVal ){
						if( ( $fVal == "pro_etitle" ) && ( $inField == "nif_title" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_efname" ) && ( $inField == "nif_firstname" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_elname" ) && ( $inField == "nif_lastname" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_ecname" ) && ( $inField == "nif_company" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_eaddress1" ) && ( $inField == "nif_no" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_esoi" ) && ( $inField == "nif_soi" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_eroad" ) && ( $inField == "nif_road" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_etambol" ) && ( $inField == "nif_tumbol" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_edistrict" ) && ( $inField == "nif_amphur" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_eprovince" ) && ( $inField == "nif_province" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_epostcode" ) && ( $inField == "nif_zipcode" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_etel" ) && ( $inField == "nif_tel" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_efax" ) && ( $inField == "nif_fax" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_mobile" ) && ( $inField == "nif_mobile" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_email1" ) && ( $inField == "nif_email" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_website" ) && ( $inField == "nif_website" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_remark" ) && ( $inField == "nif_remark" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "usr_cre" ) && ( $inField == "usr_cre" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "date_cre" ) && ( $inField == "date_cre" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "usr_upd" ) && ( $inField == "usr_upd" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "date_upd" ) && ( $inField == "date_upd" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
					}// foreach( $f_name as $fKey => $fVal ){
				}// foreach( $arrData[$i] as $inField => $inVal ){	
			}// for($i=0; $i<sizeof($arrData); $i++){
			
			//echo "<pre>"; print_r($arrProfile); exit();
			
			
			
			/*## New concept insert code this area
			$run = "insert into run1 value('','1')";
			$updRun = mysql_query($run) or die("Insert table run1 error");	
			//echo "\$connect=$connect";
			$getID = mysql_insert_id($connect);
			$number = '000000'.$getID;
			$year = date("y");
			$number = $prefix.'/'.$year.'-'.substr($number,-6);
			
			//echo "\$number= $number"; echo "<br/>";*/
			
			$value = array();
			for($i=0; $i<sizeof($arrProfile); $i++){
			
				## New concept insert code this area
				$run = "insert into run1 value('','1')";
				$updRun = mysql_query($run) or die("Insert table run1 error");	
				//echo "\$connect=$connect";
				$getID = mysql_insert_id($connect);
				$number = '000000'.$getID;
				$year = date("y");
				$number = $prefix.'/'.$year.'-'.substr($number,-6);
				
				//echo "\$number= $number"; echo "<br/>";
			
				$f_name = get_table_fieldname("profile");
				foreach( $f_name as $fKey => $fVal ){
					$value[$fVal] = "";
					foreach( $arrProfile[$i] as $pField => $pVal ){
					
						$pVal = str_replace( "'" , "\'" , $pVal );
					
						if( $fVal == "pro_code" ){
							$value[$fVal] = $number ;
						}
						if( ( $fVal == "pro_default" ) || ( $fVal == "pro_sex" ) 
							|| ( $fVal == "pro_occupation" ) || ( $fVal == "pro_industry" ) 
							|| ( $fVal == "pro_education" ) || ( $fVal == "pro_reject" ) )
						{
							$value[$fVal] = "0" ;
						}
						if( $fVal == "pro_lang" ){
							$value[$fVal] = "th" ;
						}
						if( $fVal == "pro_show" ){
							$value[$fVal] = "1" ;
						}
						if( $fVal == "pro_source" ){
							$value[$fVal] = $prefix ;
						}
						if( $fVal == $pField ){
							$value[$fVal] = $pVal ;
						}
					}// foreach( $arrProfile[$i] as $pField => $pVal ){
					
				}//foreach( $f_name as $fKey => $fVal ){
				
				//echo "<pre>"; print_r($value); 
				$query = create_insert_query("profile" , $value);
				//echo "\$query= $query";  
				$result = mysql_query($query) or die("<script>alert ('Insert table profile error');</script>");
				
			} // for($i=0; $i<sizeof($arrProfile); $i++){
			//exit();
			if($result){
				echo "<script>
						alert ('Run Script Import complete');
					  </script>";
				exit();
			}
	
}

?>
</body>
</html>
