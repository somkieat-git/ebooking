<?
//ob_start();
//session_save_path('./session');
session_start();

$_SESSION["site"]="tspc";

$xxx="tspc";
session_register("xxx");
	
	//$nccSite=$_REQUEST['s'];
	echo "xxx=",$_SESSION["xxx"],"<br>";
	echo "site=",$_SESSION["site"],"<br>";
	session_id();
	echo "session_id=",session_id();
?>
<br>
<a href="ql/index_tspc2.php?ncc=tspc"> tsp-cc </a>
<br>
<a href="./ql/index_tspc2.php?ncc=psu"> psuicc </a>
<br>
<a href="index_tspc4.php?ncc=tspc"> next </a>
<br>
<a href="index_tspc5.php"> destroy </a>
<script>
//window.location='index_tspc4.php';
//window.location='http://nccubuntu.qsncc.co.th/app/nccgroup/thebook1.7/ql/index_tspc2.php';
//window.location='http://nccubuntu.qsncc.co.th/app/nccgroup/thebook1.7/ql/index_tspc2.php?s=<?=$nccSite?>';
//window.location='http://nccubuntu.qsncc.co.th/app/nccgroup/tsp-cc/thebook1.6/index.php';
</script>
