<?
	$QMonth =$_REQUEST["month"];
	$QYear =$_REQUEST["year"];
	/*
	$QMonth =$_REQUEST["Month"];
	if(empty($QMonth)) 
	{
		$QMonth = '02';
	}
	$QYear =$_REQUEST["Year"];
	if(empty($QYear)) 
	{
		$QYear = '2006';
	}
	*/
############################################	
set_time_limit(10);

require_once "class.writeexcel_workbook.inc.php";
require_once "class.writeexcel_worksheet.inc.php";

$fname = tempnam("", "demo1.xls");
$workbook =& new writeexcel_workbook($fname);
$worksheet =& $workbook->addworksheet('Monthly');

############################################	

// �ҡ⨷���ͧ������͡�����ŵ����͹��лշ���˹� 
//	$QMonth = '03';  //   'mm'
//	$QYear = '2006';  //  'yyyy'
// Connect to database from MySql Server
//include('connect.php');
include_once("db/connect.db.php");
//sql : Location
	$sql = "select * from location order by loc_seq";
	$table = mysql_query($sql) or die("sql error");

		$LocationCount = 0;
		while ($row = mysql_fetch_array($table)) 
		{
		$Location[$LocationCount] = $row['loc_shortname'];
		$LocationCount = $LocationCount + 1;
		}
		$Location[$LocationCount] = "Total";
		// �ӹǹ�ѹ�٧�ش�������͹ + �Ѻ Total Column = 31 + 1 = 32
		$DayPerMonth = 32;
		for($i=0;$i<$DayPerMonth;$i++)
		{
			for($j=0;$j<=$LocationCount;$j++)
			{
				$MonthTable[$i][$j] = 0;
			}
		}
//  
//sql : ev_revenue, location
	$sql = "SELECT right( rev_date, 2 ) AS 
		DAY , location.loc_shortname as locname, sum( rev_total ) AS net
		FROM ev_revenue, location
		WHERE left(rev_type,5) = 'space' 
		AND rev_total > 0 
		AND left( rev_date, 4 )  = $QYear 
		AND left( right( rev_date, 4 ) , 2 ) = $QMonth 
		AND ev_revenue.loc_id = location.loc_id
		GROUP BY 1 , 2";
	//echo "$sql<hr>";
	//exit();
	$table = mysql_query($sql) or die("sql error");
	if(mysql_num_rows($table)<=0) 
	{
		
//		exit();
			$worksheet->write('A1','����բ����ŷ���ͧ�������Ѻ ��͹='.$QMonth." ��=".$QYear );
	} 
	else
	{
	// Show result from Query
		while ($row = mysql_fetch_array($table)) 
		{
	// Search in Location array
			$LocationDay = 0;
			for($x=0;$x<=$LocationCount;$x++)
			{
				if ($row['locname']==$Location[$x])
				{
					$LocationDay = $x;
					break;
				}
			}

	// Transfer value into Array
			$PositionDay = $row['DAY']-1;
			$MonthTable[$PositionDay][$LocationDay] = $row['net'];
	// Total in Column
			$MonthTable[$DayPerMonth-1][$LocationDay] += $row['net'];
	// Total in Row
			$MonthTable[$PositionDay][$LocationCount] += $row['net'];

		}
	// Summary of GrandTotal
			for($x=0;$x<$LocationCount;$x++)
			{
				$MonthTable[$DayPerMonth-1][$LocationCount] += $MonthTable[$DayPerMonth-1][$x];
			}
	
	// Generating report form
	// Variable for Check Month of Year
		$M1  = $QMonth;
		$D1 = $M1."/01/".$QYear;

	// Location of Excel => chr(65) = 'A' , chr(1) = '1' => A1
	$RowNo = 49; //=> '1'
	$ColNo = 65;  //=> 'A'
	$RowChr = chr($RowNo);
	$ColChr = chr($ColNo);
	//
	$ShowText = "Monthly Report (Space Revenue) [" . date(' F ', strtotime($D1))." of ".$QYear."]";
	//
	$worksheet->write($ColChr.$RowChr,$ShowText);
	//
	// Show Location name from Array
	$RowNo = 51; //=> '3'
	$ColNo = 65;  //=> 'A'
	$RowChr = chr($RowNo);
	$ColChr = chr($ColNo);
	//
	$ShowText = "Day/Location";
	$worksheet->write($ColChr.$RowChr,$ShowText);
	//
			for($x=0;$x<=$LocationCount;$x++)
			{
					$ColNo = $ColNo + 1;
					$ColChr = chr($ColNo);
					$ShowText = $Location[$x];
					$worksheet->write($ColChr.$RowChr,$ShowText);
			}
	// Check number of day in the month
	$DayInMonth = date(' t ', strtotime($D1));
	//

	// Show Month Table again
	$ColNo = 64; 
	$RowNo = 3; 

		for($i=0;$i<$DayInMonth;$i++)
		{
			$Day = $i+1;
			if($Day == $DayPerMonth) {$Day="Total ";}
					$ShowText = $Day;
					
					$RowNo = $RowNo + 1;
					$RowChr = number_format($RowNo);
					
					$ColNo = 65;
					$ColChr = chr($ColNo);
					$Cell = $ColChr.$RowChr;

					$worksheet->write($Cell,$ShowText);
					
					for($j=0;$j<=$LocationCount;$j++)
					{
							$ShowText = $MonthTable[$i][$j];

							$ColNo = $ColNo + 1;
							$ColChr = chr($ColNo);

							$worksheet->write($ColChr.$RowChr,$ShowText);

					}
		}

	
	// Total in Last Row
	//
	//
					$ShowText  = "Total";

					$RowNo = $RowNo + 1;
					$RowChr = number_format($RowNo);
					
					$ColNo = 65;
					$ColChr = chr($ColNo);
					$Cell = $ColChr.$RowChr;

					$worksheet->write($Cell,$ShowText);
					for($j=0;$j<=$LocationCount;$j++)
					{
							$ShowText = $MonthTable[$DayPerMonth-1][$j];

							$ColNo = $ColNo + 1;
							$ColChr = chr($ColNo);
							$worksheet->write($ColChr.$RowChr,$ShowText);
					}
	//
	}
//
include('db/disconnect.db.php');


#######################################################################

$workbook->close();

header("Content-Type: application/x-msexcel; name=\"demo1.xls\"");
header("Content-Disposition: inline; filename=\"demo1.xls\"");
$fh=fopen($fname, "rb");
fpassthru($fh);
unlink($fname);

?>