<?
error_reporting(E_ALL ^E_NOTICE ^E_WARNING ^ E_DEPRECATED);
	ob_start();
	session_start();	
	
	$nif_id = $_REQUEST["nif_id"];
	$nif_type = $_REQUEST["nif_type"];
	//$nif_type = "client";
	$nif_initial = $_REQUEST["nif_initial"];
	$nif_firstname = $_REQUEST["nif_firstname"];
	$nif_lastname = $_REQUEST["nif_lastname"];
	$nif_title = $_REQUEST["nif_title"];
	$nif_company = $_REQUEST["nif_company"];
	$nif_no = $_REQUEST["nif_no"];
	$nif_soi = $_REQUEST["nif_soi"];
	$nif_road = $_REQUEST["nif_road"];
	$nif_tumbol = $_REQUEST["nif_tumbol"];
	$nif_amphur = $_REQUEST["nif_amphur"];
	$nif_province = $_REQUEST["nif_province"];
	$nif_zipcode = $_REQUEST["nif_zipcode"];
	$nif_tel = $_REQUEST["nif_tel"];
	$nif_fax = $_REQUEST["nif_fax"];
	$nif_mobile = $_REQUEST["nif_mobile"];
	$nif_email = $_REQUEST["nif_email"];
	$nif_website = $_REQUEST["nif_website"];
	$nif_remark = $_REQUEST["nif_remark"];
	$nif_used = $_REQUEST["nif_used"];

	$id = $_REQUEST["id"];
	$action = $_REQUEST["a"];
	$Submit = $_REQUEST["Submit"];
	$cap_name = array();
	$cap_name = array("#","Type","Initial","*First Name","*Last Name","Title","Company","Address No.","Soi","Road",
		"Tumbol","District","Province","Zip Code","Telephone","Fax","Mobile","email","website","remark",
		"used","used create","date create","user upd","date upd");
	
			   
	define("viewForm","flexigrid/cus_vfrm.php");
	define("updSave","cus_updForm.php");
	define("tableName","nameinfo");
	define("menuName","Customer");
	define("field_id","nif_id");
	define("action",$action);
	define("id",$id);	
	define("beg_id",1);	
	define("end_id",19);	
	include_once("func/updForm.func.php");	
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");	
	
	function duplicate($field,$value){
		global $dup;
			$sql = "select $field 
						from nameinfo
						where $field = '$value' ";
		//cho $sql;
			$table = mysql_query($sql) or die ("Connect Err.");
			$row=mysql_fetch_array($table);
			if($row[$field]== $value){
				$dup[$field] = $value;
			}//if($row[$field]== $value){
	}//	function duplicate($field,$value){	
	
	function checklist($var,$name){
		global $data;global $flag;
		/*
		if(empty($var)){
			if(ereg("nif_firstname|nif_lastname",$name))
				$flag = 1;
		}  //if(empty($var)){
		*/
		$data[$name] = $var;
	} //function checklist($var,$name){
	
	if(!empty($Submit)){
		checklist($nif_type,"nif_type");
		checklist($nif_initial,"nif_initial");
		checklist($nif_firstname,"nif_firstname");
		checklist($nif_lastname,"nif_lastname");
		checklist($nif_title,"nif_title");
		checklist($nif_company,"nif_company");
		checklist($nif_no,"nif_no");
		checklist($nif_soi,"nif_soi");
		checklist($nif_road,"nif_road");
		checklist($nif_tumbol,"nif_tumbol");
		checklist($nif_amphur,"nif_amphur");
		checklist($nif_province,"nif_province");
		checklist($nif_zipcode,"nif_zipcode");
		checklist($nif_tel,"nif_tel");
		checklist($nif_fax,"nif_fax");
		checklist($nif_mobile,"nif_mobile");
		checklist($nif_email,"nif_email");
		checklist($nif_website,"nif_website");
		checklist($nif_remark,"nif_remark");
		
		if($flag){
			$mesg = "Please input data in ";
			while(list($key,$value) = each($data)){
				if(empty($value)){
					if(!ereg("nif_firstname|nif_lastname",$name))
						$str .= "$key,";						
				}  //if(empty($value)){
				//$str = substr( $str, strlen($str)-1, 1 );
			}
			echo errmesg ("$mesg $str");			
		}	//if($flag){
		
		else{
			if ($action=="a"){
				$data["nif_id"] = "";
				if($nif_type==""){
					$data["nif_type"] = "client";
				}
				$data["usr_cre"] = $_SESSION["usr_name"];
				$data["date_cre"] = date("Y/m/d  H:i:s");		
				/*
				duplicate("nif_firstname",$nif_firstname);
				duplicate("nif_lastname",$nif_lastname);
				if(count($dup)>0) {
					while(list($key,$value)= each($dup)){
						//echo "$key<br>";
						if(ereg("nif_firstname|nif_lastname",$key))
							$str .= $key.",";
					} // while(list($key,$value)= each($dup)){				
					echo errmesg("Duplicate $str");
					exit();
				}//if(count($dup)>0) {				
				*/
				$query = create_insert_query($table_name,$data);				
				//echo "$query<br>";
				//exit();
				mysql_query($query) or die("Insert error");		
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");			
				//Show alert by javascript
				echo "<script>
						alert ('Insert complete');
						window.location = 'cus_updForm.php?a=a';
					  </script>";
				exit();
			} //if ($action=="a"){
			
			if ($action=="e"){
				$data["usr_upd"] = $_SESSION["usr_name"];
				$data["date_upd"] = date("Y/m/d  H:i:s");	
				/*
				duplicate("nif_firstname",$nif_firstname);
				duplicate("nif_lastname",$nif_lastname);
				if(count($dup)>0) {
					while(list($key,$value)= each($dup)){
						//echo "$key<br>";
						if(ereg("nif_firstname|nif_lastname",$key))
							$str .= $key.",";
					} // while(list($key,$value)= each($dup)){				
					echo errmesg("Duplicate $str");
					exit();
				}//if(count($dup)>0) {				
				*/
				$query = create_update_query($table_name, $data, $id, $field_id);				
				//echo "$query<br>";
				//exit();
				mysql_query($query) or die("Update error");	
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");				
				//Show alert by javascript
				echo "<script>
						alert ('Update complete');
						window.location = '".viewForm."';
					  </script>";
				exit();
			}  //if ($action=="e"){
			
			if ($action=="d"){
				$query = "DELETE FROM $table_name WHERE $field_id = $id " ;
				//echo "$query<br>";
				//exit();
				
				mysql_query($query) or die("Delete error");		
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");			
				//Show alert by javascript
				echo "<script>
						alert ('Delete complete');
						window.location = '".viewForm."';
					  </script>";
				exit();
			}  //if ($action=="e"){
						
		}  //else{ of if($flag){
	}  //if(!empty($Submit)){
	
?>
<script language="javascript">
	function validate() 
	{
		if(frm.nif_firstname.value=="")
		{
			alert('Please input data in First Name');
			frm.nif_firstname.focus()
			return false;
		}

		if(frm.nif_lastname.value=="")
		{
			alert('Please input data in Last Name');
			frm.nif_lastname.focus()
			return false;
		}
	}
</script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</body>
</html>
