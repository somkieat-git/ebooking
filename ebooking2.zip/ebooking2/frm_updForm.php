<?
error_reporting(E_ALL ^E_NOTICE ^E_WARNING ^ E_DEPRECATED);
	//จุดที่ต้องแก้ไข 1.รับค่าข้อมูลที่จะ Write ลง DB
	ob_start();
	session_start();	
	
	$frm_id = $_REQUEST["frm_id"];
	$frm_name = $_REQUEST["frm_name"];
	$frm_menu = $_REQUEST["frm_menu"];
	$frm_status = $_REQUEST["frm_status"];
	$frm_used = $_REQUEST["frm_used"];
	$id = $_REQUEST["id"];
	$action = $_REQUEST["a"];
	$Submit = $_REQUEST["Submit"];
	$cap_name = array();
	$cap_name = array("#","Form Name","Form Menu","Form Status","Used");
			   
	define("viewForm","flexigrid/frm_vfrm.php");
	define("updSave","frm_updForm.php");
	define("tableName","formname");
	define("menuName","Form Name");
	define("field_id","frm_id");
	define("action",$action);
	define("id",$id);	
	define("beg_id",1);	
	define("end_id",4);	
	include_once("func/updForm.func.php");	
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");	
	function duplicate($field,$value){
		global $dup;
				$sql = "select $field 
							from formname
							where $field = '$value' ";
		//cho $sql;
				$table = mysql_query($sql) or die ("Connect Err.");
				$row=mysql_fetch_array($table);
				if($row[$field]== $value){
					$dup[$field] = $value;
				}//if($row[$field]== $value){
	}//	function duplicate($field,$value){	
	
	//จุดที่ต้องแก้ไข 2.รับค่าข้อมูลที่จะ Write ลง DB
	function checklist($var,$name){
		global $data;
		global $flag;
		if(empty($var)){
			//จุดที่ต้องแก้ไข 3.บันทึกรายชื่อ Field ที่ต้องกรอกให้ครบ
			if(ereg("frm_name|frm_status|frm_menu",$name))
				$flag = 1;
		}  //if(empty($var)){
		$data[$name] = $var;
	} //function checklist($var,$name){
	
	if(!empty($Submit)){
		//จุดที่ต้องแก้ไข 4.เช็คข้อมูลที่จำเป็นต้องกรอกให้ครบถ้วน Write ลง DB
		checklist($frm_name,"frm_name");
		checklist($frm_status,"frm_status");
		checklist($frm_menu,"frm_menu");
		checklist($frm_used,"frm_used");
		if($flag){
			$mesg = "Please input data in ";
			while(list($key,$value) = each($data)){
				if(empty($value)){
					//จุดที่ต้องแก้ไข 5.copy ในจุดที่ 3 มาไว้บรรทัดนี้ด้วย
				if(!ereg("frm_name|frm_status|frm_menu",$name))
						$str .= "$key,";
				}  //if(empty($value)){
				//$str = substr( $str, strlen($str)-1, 1 );
			}
			echo errmesg ("$mesg $str");			
		}	//if($flag){
		else{
			//จุดที่ต้องแก้ไข 6 เตรียมWrite ลง DB ตามเงื่อนไข Action		
			if ($action=="a"){
				$data["frm_id"] = "";
				$data["usr_cre"] = $_SESSION["usr_name"];
				$data["date_cre"] = date("Y/m/d  H:i:s");	
				/*	
				duplicate("frm_name",$frm_name);
				duplicate("frm_menu",$frm_menu);
				if(count($dup)>0) {
					while(list($key,$value)= each($dup)){
						//echo "$key<br>";
						if(ereg("frm_name|frm_menu",$key))
							$str .= $key.",";
					} // while(list($key,$value)= each($dup)){				
					echo errmesg("Duplicate $str");
					exit();
				}//if(count($dup)>0) {		
				*/
				$query = create_insert_query($table_name,$data);				
				//echo "$query<br>";
				mysql_query($query) or die("Insert error");					
				
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");			
				//Show alert by javascript
				echo "<script>
						alert ('Insert complete');
						window.location = 'frm_updForm.php?a=a';
					  </script>";
				exit();
			} //if ($action=="a"){
			
			if ($action=="e"){
				$data["usr_upd"] = $_SESSION["usr_name"];
				$data["date_upd"] = date("Y/m/d  H:i:s");			
				/*
				duplicate("frm_name",$frm_name);
				duplicate("frm_menu",$frm_menu);
				if(count($dup)>0) {
					while(list($key,$value)= each($dup)){
						//echo "$key<br>";
						if(ereg("frm_name|frm_menu",$key))
							$str .= $key.",";
					} // while(list($key,$value)= each($dup)){				
					echo errmesg("Duplicate $str");
					exit();
				}//if(count($dup)>0) {			
				*/
				$query = create_update_query($table_name, $data, $id, $field_id);				
				//echo "$query<br>";
				mysql_query($query) or die("Update error");	
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");
				//Show alert by javascript
				echo "<script>
						alert ('Update complete');
						window.location = '".viewForm."';
					  </script>";
				exit();
			}  //if ($action=="e"){
			
			if ($action=="d"){
				$query = "DELETE FROM $table_name WHERE $field_id = $id " ;
				//echo "$query<br>";
				//exit();
				
				mysql_query($query) or die("Delete error");		
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");
				//Show alert by javascript
				echo "<script>
						alert ('Delete complete');
						window.location = '".viewForm."';
					  </script>";					 
				exit();
			}  //if ($action=="e"){/
						
		}  //else{ of if($flag){
	}  //if(!empty($Submit)){
	
?>
<script language="javascript">
	function validate() 
	{
		if(frm.frm_name.value=="")
		{
			alert('Please input data in Form Name');
			frm.frm_name.focus()
			return false;
		}

		if(frm.frm_menu.value=="")
		{
			alert('Please input data in Form Menu');
			frm.frm_menu.focus()
			return false;
		}
		
		if(frm.frm_status.value=="")
		{
			alert('Please input data in Form Status');
			frm.frm_status.focus()
			return false;
		}	
	}
</script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</body>
</html>
