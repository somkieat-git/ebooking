<?
	ob_start();
	session_start();
	$_SESSION["site"]="gjc";
?>
<script>
window.location='ql/index.php';
</script>
