<?	
	ob_start();
	session_start();
	include_once("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	//define("updSave","esch_updForm.php");
	$viewForm = "esch_viewForm.php";
	$updSave = "esch_updForm.php";
	$table_name = "ev_schedule";
	$field_id = "esch_id";
	$action = $_REQUEST["a"];
	$evn_id = $_REQUEST["id"];
	$id2 = $_REQUEST["id2"];
	$sd_ed = $_REQUEST["id3"];
	if ($sd_ed) 	list($stDate,$enDate,$atten) = explode(",",$sd_ed);
	if ($stDate) $stDate = chgDate($stDate);
	if ($enDate) $enDate = chgDate($enDate);
	if (empty($atten)) $atten = 0;
	//echo "\$stDate =$stDate<br>\$enDate = $enDate<br>";
	/*
	echo "
		\$action = $action<br> 
		\$viewForm  = $viewForm <br>
		\$updSave = $updSave<br>
		\$table_name = $table_name<br>
		\$field_id = $field_id<br>
		\$id2 = $id2<br>
	";
	*/
	if ($action == "a"){
		$caption = "Insert  "  ;
		$button = "Save";
	}
	if ($action == "e"){
		$caption = "Edit  "  ;
		$button = "Update";
	}
	if ($action == "d"){
		$caption = "Delete  "  ;
		$button = "Delete";
	}

	//======================Begin prepare standard data======================================
		
	if(!empty($evn_id)){
		$sql = "SELECT * FROM eventname WHERE evn_id = '$evn_id'  ";
		//echo "$sql<br>";
		//exit();
		$result = getData($sql);
		$row = mysql_fetch_array($result);
		$disabled = "";
		if($row[3] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;
		$evn_name = $row[1];
	} //if(!empty($ev_id)){	
		
		$sql = "SELECT loc.loc_id, loc.loc_shortname, loc.loc_fullname,
					eloc.eloc_event_date, eloc.eloc_event_time, eloc.eloc_end_date, eloc.eloc_end_time
					FROM location loc, ev_location eloc 
					WHERE loc.loc_id = eloc.loc_id
					AND eloc.evn_id = '$evn_id'  					
					ORDER BY loc.loc_id
					";
		//echo "$sql<br>";
		
		$rs_loc_id= getData($sql);	
		
	//======================End prepare stand data========================================


	//======================Begin select data from ev_statistics===============================
	if (!empty($evn_id) && !empty($id2)){
		$sql = "SELECT * FROM $table_name WHERE evn_id = '$evn_id'  
		AND $field_id = $id2 ";
		//echo "$sql<br>";
		//exit();
		$result = getData($sql);
		$numrow = mysql_num_rows($result);
		$rs_esch = mysql_fetch_array($result);	
		
		$esch_beg_date = $rs_esch[2];
		$esch_end_date = $rs_esch[3];
		$esch_beg_time = $rs_esch[4];
		$esch_end_time = $rs_esch[5];
		$esch_loc_id = $rs_esch[6];
		$esch_atten = $rs_esch[8];
		$esch_desc = $rs_esch[7];
		//echo "$rs_esta[2]<br>";
	} //if (!empty($evn_id)){
	
	
	
?>
<html>
<script language="javascript">
	function validate() 
	{
		if(frm.esch_beg_date.value=="")
		{
			alert('Please input data in Begin Date');
			frm.esch_beg_date.focus()
			return false;
		}
		
		if(frm.esch_end_date.value=="")
		{
			alert('Please input data in End Date');
			frm.esch_end_date.focus()
			return false;
		}
		if(frm.esch_beg_time.value=="")
		{
			alert('Please input data in Start Time');
			frm.esch_beg_time.focus()
			return false;
		}
		if(frm.esch_end_time.value=="")
		{
			alert('Please input data in End Time');
			frm.esch_end_time.focus()
			return false;
		}
		if(frm.esch_loc_id.value=="")
		{
			alert('Please input data in Location');
			frm.esch_loc_id.focus()
			return false;
		}
		if(frm.esch_atten.value=="")
		{
			alert('Please input data in Attendance');
			frm.esch_atten.focus()
			return false; 
		}
		var chkdesc = frm.esch_desc.value;
		if(trimAll(chkdesc)=="" )
		{
			alert('Please input data in Description');
			frm.esch_desc.focus();
			return false;
		}			
	}
	
	function trimAll( strValue ) {
	 var objRegExp = /^(\s*)$/;
		//check for all spaces
		if(objRegExp.test(strValue)) {
		   strValue = strValue.replace(objRegExp, '');
		   if( strValue.length == 0)
			  return strValue;
		}
	
	   //check for leading & trailing spaces
	   objRegExp = /^(\s*)([\W\w]*)(\b\s*$)/;
	   if(objRegExp.test(strValue)) {
		   //remove leading and trailing whitespace characters
		   strValue = strValue.replace(objRegExp, '$2');
		}
	  return strValue;
	}
	function chkDateTime() {
		if(document.frm.esch_beg_date.value == ""){
			var Digital=new Date() ;			
			var yyyy = Digital.getYear() ;
			var mm = Digital.getMonth()+1;
			var dd= Digital.getDate();
			document.frm.esch_beg_date.value = dd + "/" + mm + "/" + yyyy ;			
			return false;
		}		
		
		if(document.frm.esch_end_date.value == ""){
			var Digital=new Date() ;			
			var yyyy = Digital.getYear() ;
			var mm = Digital.getMonth()+1;
			var dd= Digital.getDate();
			document.frm.esch_end_date.value = dd + "/" + mm + "/" + yyyy ;			
			return false;
		}		
		/*
		if(document.frm.esch_beg_time.value == ""){
			document.frm.esch_beg_time.value = "08:00";			
			return false;
		}		
		
		if(document.frm.esch_end_time.value == ""){
			document.frm.esch_end_time.value = "18:00";
			return false;
		}				
		*/	
	}
	function cancel(val) 
	{
		window.open(val,"frame_details");
	}
	
</script>

<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">
<script language="javascript" type="text/javascript" src="datetimepicker.js"></script>

</head>
	
<body >
<form action="<?=$updSave ?>?a=<?=$action ;?>&id=<?=$evn_id?>&id2=<?=$id2?>" method="post" name="frm"  id="frm"  onSubmit="return validate();">
  <table border="0" class="BorderGreen">
    <tr class="BorderSilver">
      <td colspan="4" style="background-color:#339900;font-weight:bold;color:White;">
	  	<div align="center"><strong ><?=$caption ;?>Schedule Event   - <?=$evn_id." - " .$evn_name ?></strong></div>
	  </td>
    </tr>
	<tr>
	  <td height="27" colspan="4"><div align="center">
        <input name="esch_id" type="hidden" id="esch_id" value="<?=$evn_id ?>">
</div></td>
    </tr>		
		<tr>
		  <td width="213" ><div align="right">Start Date : </div></td>
		  <td width="339" colspan="2"><div align="left">
		    <input name="esch_beg_date" type="text" id="esch_beg_date"  onBlur="chkDateTime();"
			value="<? if($esch_beg_date) echo chgDate($esch_beg_date); else echo $stDate ;?>" size="10" maxlength="10">		    
		    <a href="javascript:NewCal('esch_beg_date','ddmmyyyy',false,12)">
		  <img src="images/cal.gif" width="16" height="16" border="0" alt="Pick a date"></a></div></td>
    </tr>
		<tr>
		  <td height="21" ><div align="right">End Date : </div></td>
		  <td colspan="2" ><input name="esch_end_date" type="text" id="esch_end_date"  onBlur="chkDateTime();"
		  value="<? if($esch_end_date) echo chgDate($esch_end_date); else echo $enDate ;?>" size="10" maxlength="10">
	      <a href="javascript:NewCal('esch_end_date','ddmmyyyy',false,12)">
		  <img src="images/cal.gif" width="16" height="16" border="0" alt="Pick a date"></a></td>
    </tr>
		<tr>
		  <td ><div align="right">Start Time : </div></td>
		  <td colspan="2" ><div align="left">
		    <input name="esch_beg_time" type="text" id="esch_beg_time"  
			value="<? if($esch_beg_time) echo chgTime($esch_beg_time);  ?>" size="5" maxlength="5"></div></td>
    </tr>
		<tr>
		  <td ><div align="right">End Time : </div></td>
		  <td colspan="2" >
		  <input name="esch_end_time" type="text" id="esch_end_time"  
		  value="<? if($esch_end_time) echo chgTime($esch_end_time);  ?>" size="5" maxlength="5"></td>
    </tr>
		<tr>
		  <td ><div align="right">Location : </div></td>
		  <td colspan="2" ><div align="left">
		    <select name="esch_loc_id" id="esch_loc_id">
			  <?
			  	$data = $esch_loc_id;
			  	while($res  =  mysql_fetch_array($rs_loc_id)){
					$val_loc_id = "$res[1] - $res[2]"; ?>
					<option value='<?=$res[0]?>' <?  if($res[0]==$data) echo "selected" ?> 
				><?=$val_loc_id ?></option>										 
			 <?	
				}
			  ?>
	        </select>
		  </div></td>
    </tr>
		<tr>
		  <td ><div align="right">Attendance : </div></td>
		  <td colspan="2" ><input name="esch_atten" type="text" id="esch_atten" 
		  value="<? if($esch_atten) echo $esch_atten; else echo $atten ;?>"></td>
    </tr>
		<tr>
		  <td height="27" ><div align="right">Description :
	      </div>		    
		    <div align="right"></div></td>
		  <td colspan="2" ><div align="left">
		    <textarea name="esch_desc" cols="65" rows="5" id="esch_desc" value="<?=($esch_desc);?>"><?=$esch_desc;?>
		    </textarea>
		 </div></td>
    </tr>
		<tr>
		  <td ><div align="right"></div></td>
		  <td colspan="2" ><div align="left"></div></td>
    </tr>
    <tr align="center" >
      <td colspan="3">	  	
  	    <div align="center">
			<input name="Submit2" type="button" class="Button" value="&lt;= Back " onClick="window.location = 'dpd_viewForm.php?id=<?=$evn_id?>'" >
			<input name="Submit" type="submit" class="Button" value="<?=$button?>" <?=$disabled ;?> >
			<input name="Button" type="button" class="Button" id="Button"  onClick="cancel('esch_viewForm.php?id=<?=$evn_id ;?>');" value="Cancel" >
			<input name="Submit22" type="button" class="Button" value="Next =&gt;" onClick="window.location = 'eset_viewForm.php?id=<?=$evn_id?>'" >		  
		  </div></td>
    </tr>
  </table>
</form>
<?

	//======================Begin Save Data==============================================
	//request data into varible
	$Submit = $_REQUEST["Submit"];
	if(!empty($Submit)){
		$a_esch_beg_date = chgDateToDb($_REQUEST["esch_beg_date"]);
		$a_esch_end_date = chgDateToDb($_REQUEST["esch_end_date"]);
		$a_esch_beg_time = chgTimeToDb($_REQUEST["esch_beg_time"]);
		$a_esch_end_time = chgTimeToDb($_REQUEST["esch_end_time"]);
		$a_esch_loc_id = $_REQUEST["esch_loc_id"];
		$a_esch_atten = $_REQUEST["esch_atten"];
		$a_esch_desc = $_REQUEST["esch_desc"];
		
		/*echo "
		submit = $Submit<br>
		evn_id =  $evn_id<br>
		a_esch_beg_date = $a_esch_beg_date<br> 
		a_esch_end_date = $a_esch_end_date<br>
		a_esch_beg_time = $a_esch_beg_time <br> 
		a_esch_end_time = $a_esch_end_time<br>
		a_esch_loc_id = $a_esch_loc_id<br>
		a_esch_atten = $a_esch_atten<br>
		a_esch_desc = $a_esch_desc <br>
		";*/
		
		/*
		//check duplicate data in table ev_statistics
		$sql = "SELECT evn_id FROM ev_schedule WHERE evn_id = '$evn_id' AND  esch_id = '$esch_id'  ";
		//echo "$sql<br>";
		
		$result = getData($sql);
		$numrow = mysql_num_rows($result);
		$row = mysql_fetch_array($result);
		//echo "numrow = $numrow<br>";
		if ($numrow == 0 ){
				$action = "add";}
			else{
				$action = "edit";
		}
		//echo "action=$action<br>";
		*/
		
		function  checklist($value,$label,$field){
			global $resNull;	global $resData;global $flag; global $strPattern;
			$strPattern = "Start Date|End Date|Start Time|End Time|Location|Detail ";									  
			if(empty($value)){
				if(ereg($strPattern,$label)){
					$flag = 1;
					$resNull[$label] = $value;
				} //if(ereg($strPattern,$label)){			
			} //if(empty($var)){
			$resData[$field] = $value;
		} //function checklist($var,$name){
		
		//checklist($evn_id,"","evn_id");
		checklist($a_esch_beg_date,"Start Date","esch_beg_date");
		checklist($a_esch_end_date,"End Date","esch_end_date");
		checklist($a_esch_beg_time,"Start Time","esch_beg_time");
		checklist($a_esch_end_time,"End Time","esch_end_time");
		checklist($a_esch_loc_id,"Location","esch_loc_id");
		checklist($a_esch_atten,"Attendance","esch_atten");
		checklist($a_esch_desc,"Detail","esch_desc");

		/*
		//echo "flag = $flag<br>";		
		if($flag){
			$mesg = "Please input data in ";
			while(list($key,$value) = each($resNull)){
				if(empty($value)){
					if(!ereg($strPattern,$name))	
						$str .= "$key, ";
				}  //if(empty($value)){
			} //while(list($key,$value) = each($resNull)){
			$str = substr($str, 0, strlen($str) -2 ); 
			echo errmesg ("$mesg $str");			
			
		}	//if($flag){
		else
		*/
		{
			if($action=="a"){
				$resData["evn_id"] = $evn_id;
				$resData["usr_cre"] = $_SESSION["usr_name"];
				$resData["date_cre"] = date("Y/m/d  H:i:s");		
				
				$query = create_insert_query("$table_name",$resData);	
				//echo "$query<br>";
				//exit();
				mysql_query($query) or die("Insert error");						
				//Show alert by javascript
				echo "<script>
						alert ('Insert complete');
						window.location = '$updSave?a=a&id=$evn_id&id3=$a_esch_beg_date,$a_esch_end_date,$a_esch_atten';
					  </script>";
				exit();
			} //if($action=="a"){
			
			if($action=="e"){
				$resData["usr_upd"] = $_SESSION["usr_name"];
				$resData["date_upd"] = date("Y/m/d  H:i:s");		
				
				$query = create_update_query("$table_name", $resData, $evn_id, "evn_id");				
				$query .= " AND $field_id = $id2 ";
				//echo "$query<br>";
				//exit();
				mysql_query($query) or die("Update $table_name error");		
				//Show alert by javascript
				echo "<script>
						alert ('Update $table_name complete');
						window.location = '$viewForm?id=$evn_id' ;
					  </script>";
				exit();
			} //if($action=="e"){
			
			if ($action=="d"){
				$query = "DELETE FROM $table_name WHERE $field_id = $id2 " ;
				//echo "$query<br>";
				//exit();
				
				mysql_query($query) or die("Delete $table_name error");		
				//Show alert by javascript
				echo "<script>
						alert ('Delete $table_name complete');
						window.location = '$viewForm?id=$evn_id' ;
					  </script>";
				exit();
			}  //if ($action=="d"){
			
		} //else{
	} //if(!empty($Submit)){
	
	//======================End Save Data==============================================
?>
