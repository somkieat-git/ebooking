<?
	//�ش����ͧ��� 1.�Ѻ��Ң����ŷ��� Write ŧ DB
	ob_start();
	session_start();	
	
	$usr_id = $_REQUEST["usr_id"];
	$usr_login = $_REQUEST["usr_login"];
	$usr_pass = $_REQUEST["usr_pass"];
	$usr_sec = $_REQUEST["usr_sec"];
	$usr_name = $_REQUEST["usr_name"];
	$usr_used = $_REQUEST["usr_used"];

	$id = $_REQUEST["id"];
	$action = $_REQUEST["a"];
	$Submit = $_REQUEST["Submit"];
	$cap_name = array();
	$cap_name = array("#","login","Password","Security","User name","Used");
	
	/*echo "frm_id = $frm_id<br>
			   frm_name= $frm_name<br>
			   frm_status = $frm_status<br>
			   id = $id<br>
			   action = $action<br>
			   Submit = $Submit <hr>";*/
			   
	define("viewForm","usr_viewForm.php");
	define("updSave","usr_updForm.php");
	define("tableName","user");
	define("menuName","User");
	define("field_id","usr_id");
	define("action",$action);
	define("id",$id);	
	define("beg_id",1);	
	define("end_id",5);	
	include_once("func/updForm.func.php");	
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");	
	
		/*if($usr_login == $row['usr_login']){
			echo "<script> alert ('Login Have In DB');history.go(-1);</script>";
				exit();			
		} */
	function duplicate($field,$value){
		global $dup;
		
		$sql = "select $field 
				from user 
				where $field = '$value' ";
		//echo $sql;
		
		$table = mysql_query($sql) or die ("Connect Err.");
		$row=mysql_fetch_array($table);
		if($row[$field]== $value){
			$dup[$field] = $value;
		}//if($row[$field]== $value){
	}//	function duplicate($field,$value){	
				
	//�ش����ͧ��� 2.�Ѻ��Ң����ŷ��� Write ŧ DB
	function checklist($var,$name){
		global $data;
		global $flag;

		if(empty($var)){
			//�ش����ͧ��� 3.�ѹ�֡��ª��� Field ����ͧ��͡���ú
			if(ereg("usr_login|usr_pass|usr_sec|usr_name",$name))
				$flag = 1;
		}  //if(empty($var)){
		$data[$name] = $var;
	} //function checklist($var,$name){
	
	if(!empty($Submit)){
		//�ش����ͧ��� 4.�礢����ŷ����繵�ͧ��͡���ú��ǹ Write ŧ DB
		checklist($usr_login,"usr_login");
		checklist($usr_pass,"usr_pass");
		checklist($usr_sec,"usr_sec");
		checklist($usr_name,"usr_name"); 
		checklist($usr_used,"usr_used"); 
		if($flag){
			$mesg = "Please input data in ";
			while(list($key,$value) = each($data)){
				if(empty($value)){
					//�ش����ͧ��� 5.copy 㹨ش��� 3 ������÷Ѵ������
				if(!ereg("usr_login|usr_pass|usr_sec|usr_name",$name))
						$str .= "$key,";
				}  //if(empty($value)){
				//$str = substr( $str, strlen($str)-1, 1 );
			}
			echo errmesg ("$mesg $str");			
		}	//if($flag){
		else{
			//�ش����ͧ��� 6 �����Write ŧ DB ������͹� Action		
			if ($action=="a"){
	/*				// #3. Save data in Logfile
			$log_ip = $_SERVER["REMOTE_ADDR"];
					echo "$log_ip<br>";
					$username=$_SESSION["usr_name"];
					echo "$username<br>";
				
					$sql = "insert into logfile values(
								'',now(),'$username','$log_ip','user.php','begin use program'
								)";
						echo "$sql<br>";*/
						
						
				$data["usr_id"] = "";
				$data["usr_used"] = "Y";
				$data["usr_cre"] = $_SESSION["usr_name"];
				$data["date_cre"] = date("Y/m/d  H:i:s");
				duplicate("usr_login",$usr_login);
				duplicate("usr_pass",$usr_pass);
				duplicate("usr_name",$usr_name);
				if(count($dup)>0) {
					while(list($key,$value)= each($dup)){
						//echo "$key<br>";
						if(ereg("usr_login|usr_pass|usr_name",$key))
							$str .= $key.",";
					} // while(list($key,$value)= each($dup)){				
					echo errmesg("Duplicate $str");
					exit();
				}//if(count($dup)>0) {
				//if(count($dup)>0) 
				
			/*if($data["usr_login"] == $row['usr_login']){
				echo "<script> alert ('Login Have In DB');history.go(-1);</script>";
				exit();			
			} */
				$query = create_insert_query($table_name,$data);				
				//echo "$query<br>";
				mysql_query($query) or die("Insert error");		
				//Show alert by javascript
				echo "<script>
						alert ('Insert complete');
						window.location = 'usr_updForm.php?a=a';
					  </script>";
				exit();
			} //if ($action=="a"){
			
			if ($action=="e"){				
				$data["usr_upd"] = $_SESSION["usr_name"];
				$data["date_upd"] = date("Y/m/d  H:i:s");				
				/*
				duplicate("usr_login",$usr_login);
				duplicate("usr_pass",$usr_pass);
				duplicate("usr_name",$usr_name);
				if(count($dup)>0) {
					while(list($key,$value)= each($dup)){
						//echo "$key<br>";
						if(ereg("usr_login|usr_pass|usr_name",$key))
							$str .= $key.",";
					} // while(list($key,$value)= each($dup)){				
					echo errmesg("Duplicate $str");
					exit();
				}//if(count($dup)>0) {
				*/
				$query = create_update_query($table_name, $data, $id, $field_id);				
				//echo "$query<br>";
				mysql_query($query) or die("Update error");		
				//Show alert by javascript
				echo "<script>
						alert ('Update complete');
						window.location = 'usr_viewForm.php';
					  </script>";
				exit();
			}  //if ($action=="e"){
			
			if ($action=="d"){
				//$data["usr_upd"] = "tan";
				//$data["date_upd"] = date("Y/m/d  H:i:s");				
				//$query = create_update_query($table_name, $data, $id, $field_id);				
				//$query = "DELETE FROM $table_name WHERE $field_id = $id " ;
				echo "$query<br>";
				//exit();
				
				mysql_query($query) or die("Delete error");		
				//Show alert by javascript
				echo "<script>
						alert ('Delete complete');
						window.location = 'usr_viewForm.php';
					  </script>";
				exit();
			}  //if ($action=="e"){
						
		}  //else{ of if($flag){
	}  //if(!empty($Submit)){
	
?>
<script language="javascript">
	function validate() 
	{
		if(frm.usr_login.value=="")
		{
			alert('Please input data in Login');
			frm.usr_login.focus()
			return false;
		}

		if(frm.usr_pass.value=="")
		{
			alert('Please input data in Password');
			frm.usr_pass.focus()
			return false;
		}
		
		if(frm.usr_sec.value=="")
		{
			alert('Please input data in Security');
			frm.usr_sec.focus()
			return false;
		}	
		if(frm.usr_name.value=="")
		{
			alert('Please input data in User Name');
			frm.usr_name.focus()
			return false;
		}	

	}
</script>
</body>
</html>
