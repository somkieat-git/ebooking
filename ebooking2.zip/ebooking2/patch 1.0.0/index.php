<?   
	ob_start(); 
	//----------- result after run index.php --------------------------------------------------------------------------------
	// $_SESSION["progname"]
	// $_SESSION["version"]
	// $_SESSION["usr_name"]
	// $_SESSION["sec_view"]
	// $_SESSION["sec_add"]
	// $_SESSION["sec_edit"]
	// $_SESSION["sec_del"]
	// $_SESSION["admin"]
	//---------------------------------------------------------------------------------------------------------------------------------
	session_start();
	
    $_SESSION["progname"] = "Booking System";
    $_SESSION["version"] = "1.0.0";
	
    $usr_login = $_REQUEST["usr_login"];
	$usr_pass = $_REQUEST["usr_pass"];	
	//echo "usr_login =$usr_login<br>usr_pass=$usr_pass<br>";
	
	// #1.check usr_name & usr_pass  in user
	if(!empty($usr_login) && !empty($usr_pass)){	
		include_once("db/connect.db.php");
		include_once("func/sql.func.php");		
		
		$sql = "select usr.*, sec.* 
					from user usr, security sec 
					where usr.usr_sec = sec.sec_id
					and usr.usr_login = '$usr_login' ";
					
		//echo "$sql<br>";
		$result = mysql_query($sql) or die("Select error !");
		//echo "result = $result<br>";
		$count = mysql_num_rows($result);
		if ($count == 0) {	
			echo "<script> alert ('UserName Invalid');history.go(-1);</script>";
			exit();			
		}
		else{
			$row = mysql_fetch_array($result);
			if($usr_pass != $row['usr_pass']){
				echo "<script> alert ('Password Invalid');history.go(-1);</script>";
				exit();			
			}
			else{
				// #2.Save usr_name in $_SESSION["usr_name"]
				$_SESSION["usr_name"] = $row['usr_name'];
				
				// #3. Save data in Logfile
				$log_ip = $_SERVER["REMOTE_ADDR"];
				$sql = "insert into logfile values(
					'',now(),'$usr_login','$log_ip','index.php','begin use program'
					)";
				//echo $sql ; 
				mysql_query($sql) or die ("Save logfile error");
				
				// #4. check authorize save in $_SESSION["?"]
				//$arrView= array();
				//$arrViewn= array();
				$arrView = explode(",", $row["sec_view"]);				
				$arrViewn = getAuthor($arrView);				
				//print_r(array_keys($arrViewn));
				$_SESSION["sec_view"]  = $arrViewn ; 
				
				//echo "index.php.sec_add =  ".$row["sec_add"]."<br>";
				
				$arrAdd = explode(",", $row["sec_add"]);				
				$arrAddn = getAuthor($arrAdd);				
				//print_r(array_keys($arrAddn));
				$_SESSION["sec_add"] = $arrAddn;
				/*
				foreach($arrAdd as $key=>$val) 
				{
					$sql = "select frm_name from formname where frm_id = $val ";
					//echo "$sql<br>";
					$result = mysql_query($sql) ;
					$row = mysql_fetch_array($result);					
					if($result)			
					  //$res["$val"] = $row["frm_name"];
					  echo $row[0]."<br>";
				}	
				
				exit();
				*/
				$arrEdit = explode(",", $row["sec_edit"]);				
				$arrEditn = getAuthor($arrEdit);				
				//print_r(array_keys($arrEditn));
				$_SESSION["sec_edit"] = $arrEditn;
				
				$arrDel = explode(",", $row["sec_del"]);				
				$arrDeln = getAuthor($arrDel);				
				//print_r(array_keys($arrDeln));
				$_SESSION["sec_del"] = $arrDeln;
				
				//exit();
				/*
				echo "sec_view =".$_SESSION["sec_view"]."<br>";
				echo "sec_add =".$_SESSION["sec_add"]."<br>";
				echo "sec_edit =".$_SESSION["sec_edit"]."<br>";
				echo "sec_del =".$_SESSION["sec_del"]."<br>";
				*/
				
				// #5. check authorize admin & save in $_SESSION["admin"]			
				if ($row["sec_name"]=='admin')
					$_SESSION["admin"] = true;
				else
					$_SESSION["admin"] = false;					
					
					$_SESSION["id"]=$usr_login;
					
					echo "<script> window.location = 'fra_main.php' ;</script>";
//					fra_maintenance.php
			}	//else{  if($usr_pass != $row['usr_pass']){
		} // else{ if ($count == 0) {			
		include("db/disconnect.db.php");
	} //if(!empty($usr_name) && !empty($usr_pass)){	
?>
   
<html>
<head>
	<title>Thebook System</title>
	<link rel="stylesheet" href="css/format.css.css" type="text/css">
	<script src="pages/jsval.js" type="text/javascript" language="JavaScript"></script>
	
	<script language="JavaScript">
	<!--
		function setProps()
		{
			var objForm = document.forms["Login"];
			
			objForm.usr_pass.required = 1;
			objForm.usr_pass.err = "Please enter Password !";
			
			objForm.usr_login.required = 1;
			objForm.usr_login.err = "Please enter Userlogin !";			
		}
	//-->
	</script>
</head>

<body onLoad="setProps()">
	<br>
	<h2 style="text-align: center; font-weight: bold; color:#339900" ><?=$_SESSION["progname"]  ?></h2>
	<br>
	<br>	
	<br>
<div align="center">
		<strong>Login to <?=$_SESSION["progname"] ?></strong>
		<br>
		<br>
		<br>
		<table>
			<tr>
				<td valign="top">
					<img style="position:relative;top:-15px;left:35px" src="images/login.png" height="48" width="48" alt="login">
				</td>
				<td>
					<form id="Login"  name="frm" action="index.php" method="post" onsubmit="return jsVal(this);">
						<table border="0" class="note">
							<tr>
								<td colspan="2" style="background-color:#339900;font-weight:bold;color:White;"><strong style="padding-left:35px">Login</strong></td>
							</tr>
							<tr>
								<td colspan="2" height="15px"></td>
							</tr>
							<tr>
								<td>Userlogin :</td>
								<td><input name="usr_login" type="text" class="FormInput" id="usr_login"></td>
							</tr>
							<tr>
								<td>Password :</td>
								<td><input name="usr_pass" type="password" class="FormInput" id="usr_pass"></td>
							</tr>
							<tr>
				   				<td colspan="2" style="border-top: 1px solid #339900;padding: 6px 0px 4px 0px;" align="right">
									<input type="submit" value="Login" class="Button">
								</td>
				   			</tr>
						</table>
					</form>
				</td>
				<td width="48px">&nbsp;</td>
			</tr>
		</table>
	<br>
		<br>
		<strong style="font-size:8pt;font-weight:normal">powered by</strong><br>
		mis<br>
		<strong style="font-size:8pt;font-weight:normal"><?=$_SESSION["version"] ?></strong><br> 
		
</div>
</body>
</html>
<script language="JavaScript">
	document.frm.usr_login.focus();
</script>