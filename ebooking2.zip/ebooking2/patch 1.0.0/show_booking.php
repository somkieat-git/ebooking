<?
	include_once("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	$day_name_length = 2;	
	
	//======================Begin select data from default ===================================
	$sql = "SELECT * FROM `default`
				WHERE  type = 'booking' ";	
	//echo "$sql<br>";
	//exit();
	$arr_default = array('txtStartdate','txtEventday','txtScroll','txtStarttime','cboLocation',
	'cboLocf1','cboLocf2','txtEndtime','chkInout','chkEventday','chkShortdisplay','chkLocOnTop');
	$arr_val = array();
	$result = getData($sql);
	$i = 0;
	while($rs_default = mysql_fetch_array($result)){
		if ($rs_default[1]=="$arr_default[$i]") $arr_val[] = $rs_default[2];
		$i++ ;
	}
		$txtStartdate = $arr_val[0];
			if ($txtStartdate) 
				$txtStartdate = chgDate($arr_val[0]) ;
			else
				$txtStartdate = date("d/m/Y");
		$txtEventday = $arr_val[1] ;
		$txtScroll = $arr_val[2] ;
		$txtStarttime = $arr_val[3] ;
			if ($txtStarttime) $txtStarttime = chgTime($arr_val[3]) ;
		$cboLocation = $arr_val[4];	
		$cboLocf1 = $arr_val[5] ;
		$cboLocf2 = $arr_val[6] ;
		$txtEndtime =$arr_val[7] ;
			if($txtEndtime) $txtEndtime =chgTime($arr_val[7]) ;
		$chkInout = $arr_val[8];
		$chkEventday = $arr_val[9];	
		$chkShortdisplay = $arr_val[10];					
		$chkLocOnTop = $arr_val[11];					
	/*
	echo " begin<br>
		\$txtStartdate =$txtStartdate<br>
		\$txtEventday = $txtEventday<br>
		\$txtScroll = $txtScroll<br>
		\$txtStarttime = $txtStarttime<br>
		\$cboLocation = $cboLocation<br>
		\$cboLocf1 = $cboLocf1<br>
		\$cboLocf2 = $cboLocf2<br>
		\$txtEndtime =$txtEndtime<br>
		\$chkInout = $chkInout<br>
		\$chkEventday = $chkEventday<br>
		\$chkShortdisplay = $chkShortdisplay<br>
	";
	*/
	
	#Set value to $arr_hld
	$sql = " SELECT hld_date,  hld_desc, hld_color FROM holiday 
				ORDER BY hld_date
				";
	$res =  getData($sql);
	$arr_hld = array();
	while ($rs_hld = mysql_fetch_array($res)){
		$arr_hld[$rs_hld[0]] = array($rs_hld[0],$rs_hld[1],$rs_hld[2]);
	}
	
	/*
	#Set value to $arr_bks
	$sql = " SELECT bks_id,  bks_name, bks_color FROM bookingstatus 
				ORDER BY bks_id
				";
	$res =  getData($sql);
	$arr_bks = array();
	while ($rs_bks = mysql_fetch_array($res)){
		$arr_bks[$rs_bks[0]] = array($rs_bks[0],$rs_bks[1],$rs_bks[2]);
	}
	*/
	
	#Set value to $arr_loc
	$sql = " SELECT loc_id, loc_shortname FROM location 
				WHERE loc_seq >= $cboLocation
				ORDER BY loc_seq 
				";
	$res =  getData($sql);
	$arr_loc = array();
	$arr_sloc = array();
	while ($loc = mysql_fetch_array($res)){
		$arr_loc [] = $loc[0];
		$arr_sloc [] = array($loc[0],$loc[1]);
	}
	
	//$stTime = substr($txtStarttime,0,2).substr($txtStarttime,3,2);
	//$enTime = substr($txtEndtime,0,2).substr($txtEndtime,3,2);
	
	$stTime = chgTimeToDb($txtStarttime);
	$enTime = chgTimeToDb($txtEndtime);
		
	#Set value to $arr_date
		$arr_date = array();
		$arr_sdate = array();
		list($dd, $mm, $yy) = explode('/',$txtStartdate);
		
		for($date=$dd; $date<($dd+$txtScroll); $date++){ 		
			$valday = date("Ymd", mktime(0, 0, 0, $mm,$date,$yy));
			$showday = date("d/m/y", mktime(0, 0, 0, $mm,$date,$yy));
			$showweek = date("l", mktime(0, 0, 0, $mm,$date,$yy));
			
			$arr_date[] = $valday;
			$arr_sdate[] = array($showday,$showweek);
		} //for($date=$dd; $date<($dd+$txtScroll); $date++){ 		
		
		$x = count($arr_loc);
		$y = count($arr_date);
		$z = $txtEventday;		
		
		//print_r($arr_loc);
		//echo "<hr>";
		//print_r($arr_date);
		//echo "<hr>";
		//$arr_show = array();
		//$arr_show = array(array($arr_loc), array($arr_date));
		//echo "\$x = $x<br>\$y = $y<br>\$z = $z<br>";
		for ($ix = 0 ; $ix < $x; $ix++){
					for ($iy = 0 ; $iy < $y; $iy++){
						for ($iz = 0 ; $iz < $z; $iz++){
							$arr_show[$ix][$iy][$iz] = "";
						} //for ($iz = 0 ; $iz < count($z); $iz++){
					} //for ($iy = 0 ; $iy < count($y); $iy++){
		} //for ($ix = 0 ; $ix < count($x); $ix++){		
		/*
		//print_r($arr_show);
		//echo "<br>";
		for ($ix = 0 ; $ix < $x; $ix++){
					for ($iy = 0 ; $iy < $y; $iy++){
						for ($iz = 0 ; $iz < $z; $iz++){
							echo "[$ix][$iy][$iz] = " .$arr_show[$ix][$iy][$iz];
							echo "<br>";
						} //for ($iz = 0 ; $iz < count($z); $iz++){
						echo "<br>";
					} //for ($iy = 0 ; $iy < count($y); $iy++){
					echo "<br>";
		} //for ($ix = 0 ; $ix < count($x); $ix++){		
		echo "<hr>";
		//exit();
		*/
		
	#Select value from ev_location
	$sql = " 
	SELECT  
		eloc.loc_id, 
		eloc.eloc_in_date,
		eloc.eloc_in_time,
		eloc.eloc_event_date,
		eloc.eloc_event_time,
		eloc.eloc_end_date,
		eloc.eloc_end_time,
		eloc.eloc_out_date,
		eloc.eloc_out_time,
		eloc.bks_id,
		evn.evn_shortname,
		bks.bks_code,
		bks.bks_color,
		eloc.evn_id	
	FROM eventname evn, ev_location eloc, bookingstatus bks
	WHERE evn.evn_id = eloc.evn_id
		AND eloc.bks_id =  bks.bks_id
		AND ( eloc.eloc_in_time >= '$stTime' 
			OR eloc.eloc_event_time >= '$stTime' 
			OR eloc.eloc_event_time >= '$stTime' )
		AND ( eloc.eloc_out_time <= '$enTime'
			OR eloc.eloc_end_time <= '$enTime')
		AND bks.bks_id not in (1,2,5,6,7)
	ORDER BY eloc.eloc_in_date, eloc.eloc_in_time, eloc.evn_id	, eloc.loc_id ";
	//echo "$sql<hr>";	
	//exit();
	$res =  getData($sql);
	$arr_eloc = array();
	while ($eloc = mysql_fetch_array($res)){
		$arr_eloc [] = array($eloc[0],$eloc[1],$eloc[2],$eloc[3],$eloc[4],$eloc[5],$eloc[6],
		$eloc[7],$eloc[8],$eloc[9],$eloc[10],$eloc[11],$eloc[12],$eloc[13]);		
	}	
	
	# input value in $arr_show
	for($eloc=0; $eloc<count($arr_eloc); $eloc++){ 				
		list($loc_id, $eloc_in_date,	$eloc_in_time,
		$eloc_event_date, $eloc_event_time,	
		$eloc_end_date, $eloc_end_time,
		$eloc_out_date,$eloc_out_time,	
		$eloc_bk_status,	$evn_name,	
		$bks_code,$bks_color,$evn_id ) = $arr_eloc[$eloc];
		$ix = "";
		$ix = array_keys($arr_loc,$loc_id);
		
		# focus $eloc_in_date
		if ($eloc_in_date < $eloc_event_date ){
			for ($ymd = $eloc_in_date ; $ymd < $eloc_event_date ; $ymd++){
				$ochkval = "";
				//echo "\$ymd = $ymd<br>";
				$iy = array_keys($arr_date,$ymd);					
				for ($iz = 0 ; $iz < $z; $iz++){
					$pref = "[i]";
					$chkval  =  $arr_show[$ix[0]][$iy[0]][$iz];					
					//echo "\$chkva = $chkva<br>";
					//echo "\$ochkval = $ochkval<br>";
					if(empty($chkval)) {
						//echo "Loop1<br>";	
						$chkval  =  $bks_color.",".$evn_id.",".$bks_code.",".$pref.$evn_name ;
						if($ochkval <> $chkval)	{
							//echo "Loop2<br>";	
							$ochkval = $chkval;
							$arr_show[$ix[0]][$iy[0]][$iz] = $chkval;
						}				
					} //if($arr_show[$ix][$iy][$iz] = ""){
					else{
						//echo "Out loop<br>";
						continue;
					} //else{
				} //for ($iz = 0 ; $iz < count($z); $iz++){
			} //for ($ymd = $eloc_in_date ; $ymd <= $eloc_event_date ; $ymd++)
		} //if ($eloc_in_date <= $eloc_evnet_date )

		# focus $eloc_event_date
		if ($eloc_event_date <= $eloc_end_date ){
			for ($ymd = $eloc_event_date ; $ymd <= $eloc_end_date ; $ymd++){
				$ochkval = "";
				//echo "\$ymd = $ymd<br>";
				$iy = array_keys($arr_date,$ymd);					
				for ($iz = 0 ; $iz < $z; $iz++){
					$pref = "[s]";					
					$chkval  =  $arr_show[$ix[0]][$iy[0]][$iz];					
					//echo "\$chkva = $chkva<br>";
					//echo "\$ochkval = $ochkval<br>";
					if(empty($chkval)) {
						//echo "Loop1<br>";	
						//echo "[$ix[0]][$iy[0]][$iz] \$chkval = $chkval<br>";
						$chkval  =  $bks_color.",".$evn_id.",".$bks_code.",".$pref.$evn_name ;
						if($ochkval <> $chkval)	{
							//echo "Loop2<br>";	
							//echo "[$ix[0]][$iy[0]][$iz] \$chkval = $chkval<br>";
							$ochkval = $chkval;
							$arr_show[$ix[0]][$iy[0]][$iz] = $chkval;
						}				
					} //if($arr_show[$ix][$iy][$iz] = ""){
					else{
						//echo "Out loop<br>";
						//echo "[$ix[0]][$iy[0]][$iz] \$chkval = $chkval<br>";
						continue;
					} //else{
				} //for ($iz = 0 ; $iz < count($z); $iz++){
			} //for ($ymd = $eloc_in_date ; $ymd <= $eloc_event_date ; $ymd++)
		} //if ($eloc_in_date <= $eloc_evnet_date )

		# focus $eloc_out_date
		if ($eloc_out_date > $eloc_end_date ){
			for ($ymd = $eloc_end_date+1 ; $ymd <= $eloc_out_date ; $ymd++){
				$ochkval = "";
				//echo "\$ymd = $ymd<br>";
				$iy = array_keys($arr_date,$ymd);					
				for ($iz = 0 ; $iz < $z; $iz++){
					$pref = "[o]";
					$chkval  =  $arr_show[$ix[0]][$iy[0]][$iz];					
					//echo "\$chkva = $chkva<br>";
					//echo "\$ochkval = $ochkval<br>";
					if(empty($chkval)) {
						//echo "Loop1<br>";	
						$chkval  =  $bks_color.",".$evn_id.",".$bks_code.",".$pref.$evn_name ;
						if($ochkval <> $chkval)	{
							//echo "Loop2<br>";	
							$ochkval = $chkval;
							$arr_show[$ix[0]][$iy[0]][$iz] = $chkval;
						}				
					} //if($arr_show[$ix][$iy][$iz] = ""){
					else{
						//echo "Out loop<br>";
						continue;
					} //else{
				} //for ($iz = 0 ; $iz < count($z); $iz++){
			} //for ($ymd = $eloc_in_date ; $ymd <= $eloc_event_date ; $ymd++)
		} //if ($eloc_in_date <= $eloc_evnet_date )

	} //for($eloc=0; $eloc<count($arr_eloc); $eloc++){
	/*
	#show all value
	echo "<br>";	
	for ($ix = 0 ; $ix < $x; $ix++){
				for ($iy = 0 ; $iy < $y; $iy++){
					for ($iz = 0 ; $iz < $z; $iz++){
						echo "[$ix][$iy][$iz] = " .$arr_show[$ix][$iy][$iz];
						echo "<br>";
					} //for ($iz = 0 ; $iz < count($z); $iz++){
					echo "<br>";
				} //for ($iy = 0 ; $iy < count($y); $iy++){
				echo "<br>";
	} //for ($ix = 0 ; $ix < count($x); $ix++){		
	//echo "<hr>";
	//exit();
	*/

?>
<html>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">
<body>
<form name="form1" method="post" action="">
  <table width="100%"  border="1" cellpadding="1" cellspacing="1" bordercolor="#FFFFFF">      
  <?
	echo " <tr bgcolor='#FFFFFF'>";
	echo " <th  height='10%' bgcolor='#FFFFFF' scope='col'>__________</th>" ;	
	//exit();
			for ($x=0 ; $x<count($arr_loc) ; $x++ )
			{
				echo "<th  colspan=\"2\"  scope=\"col\">";
				echo str_repeat("_",8);
				echo "</th>";
			}
	echo "</tr>";
  ?>
    <tr style = "background-color:#339900;font-weight:bold;color:White;">
      <th width="50" bordercolor="#FFFFCC"  class="BorderSilver" scope="col"></th>
      <?
	//====================Show Header============================
	//if (chkLocOnTop){
		
	//}
	//else
	{
		for($loc=0; $loc<count($arr_loc); $loc++){ 
			if(isset($arr_sloc[$loc]) and is_array($arr_sloc[$loc])){ 
				list($id, $loc_name) = $arr_sloc[$loc]; 
				$show_head = $loc_name ;?>
	
      			<th colspan="2" bordercolor="#FFFFCC" class="BorderSilver" scope="col"><?=$show_head ;?></th>
      <?			
			}  //if(isset($arr_loc[$loc]) and is_array($arr_loc[$loc])){ 
		} //for($loc=0; $loc<count($arr_loc); $loc++){ 
	} //else{
	?>
    </tr>
    <?
		//=====begin Show Date====================			
		
		for ($i_date = 0; $i_date < count($arr_date) ; $i_date++){		
						
			$valday = $arr_date[$i_date];
			$hld_date = $arr_hld[$valday][0];
			$hld_desc = $arr_hld[$valday][1];
			$hld_color = $arr_hld[$valday][2];			
				//if(empty($hld_color)) $hld_color = "#ECE9D8";				
				//if(empty($hld_color)) $hld_color = "#FFFFFF";
			$showday = $arr_sdate[$i_date][0];
			$showweek = $arr_sdate[$i_date][1];
				if(substr($showweek ,0,1) == "S" )  $hld_color = "#FF0066";
			#control digit of day_name
			if($day_name_length){
				$showweek = substr($showweek,0,$day_name_length);
			}			
	?>
    <tr>
      <th width="10%"   rowspan="<?=$txtEventday ;?>" valign="top" border-bottom="#FFFFCC" 
			bgcolor="<?=$hld_color?>" class="showbooking" title="<?=$hld_desc ;?>" scope="row">
        <div align="Left"><?=$showday ." ". $showweek ;?></div></th>
      <?
			//=====end Show Date====================	
			
			//=====begin Show Value ==========
			//print_r($arr_eloc);
			//echo "<br>";
			//exit();
			
			for($i=0;$i<$txtEventday;$i++){			
				if ($i >0)	echo "<tr>";									
				for($i_loc=0; $i_loc<count($arr_loc); $i_loc++){ 					
					//echo "[$i_loc][$i_date][$i] = ".$result."<br>";
					$result = $arr_show[$i_loc][$i_date][$i]; 					
					if(empty($result)) {
						//$result = "'#ECE9D8','',&nbsp;,&nbsp;";
						$result = "'#FFFFFF','',&nbsp;,&nbsp;";
						list($color,$evn_id,$s_v1,$s_v2) = explode(',',$result);					
							echo '<a href = new_event.php?d='.$valday.' target="main_Frame">
							<td bgcolor =  ' .$color.  '  class="showbooking" ><div align="left">'.$s_v1 .'</div></td>
							<td bgcolor =  ' .$color.  '  class="showbooking" ><div align="left">'.$s_v2 .'</div></td>
							</a>';
					} //if(empty($result)) $result = "'#ECE9D8','',&nbsp;,&nbsp;";{
					else{
						list($color,$evn_id,$s_v1,$s_v2) = explode(',',$result);			
						if($chkShortdisplay=="Y")
							$s_v2 = substr($s_v2 ,0,13);					
						
	?>	
      
      <td width="2" bgcolor =<?=$color ;?> class="showbooking"  border-bottom="#FFFFCC" ><a href = fra_ev_maintenance.php?id=<?=$evn_id ;?> target='main_Frame'><div align="left"><?=$s_v1 ;?></div></a></td>
      <td nowrap bgcolor =<?=$color ;?> class="showbooking"   border-bottom="#FFFFCC"><a href = fra_ev_maintenance.php?id=<?=$evn_id ;?> target='main_Frame'><div align="right"><?=$s_v2;?></div></a></td>
      
      <?					
				} //else{
				} //for($i_loc=0; $i_loc<count($arr_loc); $i_loc++){ 					
				echo "</tr>";
			} //for($i=1;$i<=$txtEventday;$i++){
	?>
    </tr>
    <?		
		} //for ($i_date = 0; $i_date < count($arr_date) ; $i_date++){		
		include("db/disconnect.db.php");
	?>
  </table>
</form>
</body>
</html>
