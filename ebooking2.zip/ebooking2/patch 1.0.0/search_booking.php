<?	
	ob_start();
	session_start();
	include_once("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	define("updSave","search_booking.php");
	$Submit = $_REQUEST["Submit"];

	//======================Begin prepare standard data======================================
		
		$sql = "SELECT loc_id , loc_shortname, loc_fullname  FROM location 
					ORDER BY loc_seq, loc_shortname ";
		$res_location = getData($sql);	
			
		$loc_field1 = "loc_field1";
		$loc_field2 = "loc_field2";
		
		$sql = "SELECT * FROM miscode  WHERE mis_type in ( 'loc_field1','loc_field2')
					 ";
		$res_loc_field = getData($sql);
		
		$arr_loc_field1 = array();
		$arrloc_field2 = array();
		
		while( $row = mysql_fetch_array($res_loc_field)){
			if ($row["mis_type"] == $loc_field1 ){
				$arr_loc_field1[] = $row["mis_name"];
			} //if ($row["mis_type"] == $loc_field1 ){
			
			if ($row["mis_type"] == $loc_field2 ){
				$arr_loc_field2 [] = $row["mis_name"];
			} //if ($row["mis_type"] == $loc_field2 ){
			
		} //while( $row = mysql_fetch_array($res_loc_field)){
		
	//======================End prepare stand data========================================

	//======================Begin select data from default ===================================
	if(empty($Submit)){ 
		//echo "Empty<br>";
		$sql = "SELECT * FROM `default`
					WHERE  type = 'booking' ";	
		//echo "$sql<br>";
		//exit();
		$arr_default = array('txtStartdate','txtEventday','txtScroll','txtStarttime','cboLocation',
		'cboLocf1','cboLocf2','txtEndtime','chkInout','chkEventday','chkShortdisplay','chkLocOnTop');
		$arr_val = array();
		$result = getData($sql);
		$i = 0;
		while($rs_default = mysql_fetch_array($result)){
			if ($rs_default[1]=="$arr_default[$i]") $arr_val[] = $rs_default[2];
			$i++ ;
		}
			$txtStartdate = $arr_val[0];
				if ($txtStartdate) 
					$txtStartdate = chgDate($arr_val[0]) ;
				else
					$txtStartdate = date("d/m/Y");
			$txtEventday = $arr_val[1] ;
			$txtScroll = $arr_val[2] ;
			$txtStarttime = $arr_val[3] ;
				if ($txtStarttime) $txtStarttime = chgTime($arr_val[3]) ;
			$cboLocation = $arr_val[4];	
			$cboLocf1 = $arr_val[5] ;
			$cboLocf2 = $arr_val[6] ;
			$txtEndtime =$arr_val[7] ;
				if($txtEndtime) $txtEndtime =chgTime($arr_val[7]) ;
			$chkInout = $arr_val[8];
			$chkEventday = $arr_val[9];	
			$chkShortdisplay = $arr_val[10];					
			$chkLocOnTop = $arr_val[11];					
		/*
		echo " begin<br>
			\$txtStartdate =$txtStartdate<br>
			\$txtEventday = $txtEventday<br>
			\$txtScroll = $txtScroll<br>
			\$txtStarttime = $txtStarttime<br>
			\$cboLocation = $cboLocation<br>
			\$cboLocf1 = $cboLocf1<br>
			\$cboLocf2 = $cboLocf2<br>
			\$txtEndtime =$txtEndtime<br>
			\$chkInout = $chkInout<br>
			\$chkEventday = $chkEventday<br>
			\$chkShortdisplay = $chkShortdisplay<br>
		";
		*/
	}//if(empty($Submit)){
?>
<html>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">
<script language="javascript" type="text/javascript" src="datetimepicker.js"></script>
</head>
<script language="javascript">
	function Onblur() 
	{
		if(frm.txtEventday.value=="")
		{
			frm.txtEventday.value = "1";
		}
		
		if(frm.txtScroll.value=="")
		{
			frm.txtScroll.value = "30";
		}
		
		if(frm.txtStarttime.value=="")
		{
			frm.txtStarttime.value = "08:00";
		}
		
		if(frm.txtEndtime.value=="")
		{
			frm.txtEndtime.value = "18:00";
		}

	}
</script>
<body >
<form name="frm" method="post" action="<?=updSave?>" >
  <div align="center"></div>
  <div align="center"></div>
  <table width="90%"  border="0" cellpadding="0" cellspacing="1" class="BorderSilver">
	<tr class="BorderSilver">
      <td height="25" colspan="4" style="background-color:#339900;font-weight:bold;color:White;">
	  	<div align="center"><strong >Search Booking</strong></div>	  </td>
    </tr>    
	<tr>
	  <td height="20">&nbsp;</td>
	  <td>&nbsp;</td>
	  <td>&nbsp;</td>
	  <td>&nbsp;</td>
    </tr>
	<tr>
      <td width="26%"><div align="right">Start Date :</div></td>
      <td width="25%"><div align="left">
        <input name="txtStartdate" type="text" id="txtStartdate" value="<?=$txtStartdate ; ?>" size="10" maxlength="10">
	  <a href="javascript:NewCal('txtStartdate','ddmmyyyy',false,12)">
	  <img src="images/cal.gif" width="16" height="16" border="0" alt="Pick a date"></a>
	  </div></td>
      <td width="23%"><div align="right">Location : </div></td>
      <td width="26%"><div align="left">
        <select name="cboLocation" id="cboLocation"  >
		<?
				while( $row = mysql_fetch_array($res_location)){
					echo "<option value = ".$row[0] ; 
					if($row[0]==$cboLocation) echo ' selected' ;
					echo " >".$row[1] ."</option>";
				}
		?>
        </select>
      </div></td>
    </tr>
    <tr>
      <td><div align="right">Event Per Day : </div></td>
      <td><div align="left">
        <input name="txtEventday" type="text" id="txtEventday" value="<?=$txtEventday; ?>" onBlur="return Onblur();">
</div></td>
      <td><div align="right">Location Field 1 : </div></td>
      <td><div align="left">
        <select name="cboLocf1" id="cboLocf1" >
			  <?
			  	foreach($arr_loc_field1 as $key=>$val){ 
					 echo "<option value = '".$val."'" ;
					 if($val == $cboLocf1) echo ' selected' ;
					 echo " >".$val . "</option>";
				}
			  ?>
        </select>
      </div></td>
    </tr>
    <tr>
      <td><div align="right">Day to scroll : </div></td>
      <td><div align="left">
        <input name="txtScroll" type="text" id="txtScroll" value="<?=$txtScroll; ?>" onBlur="return Onblur();">
      </div></td>
      <td><div align="right">Location Field 2 : </div></td>
      <td><div align="left">
        <select name="cboLocf2" id="cboLocf2" >
			  <?
			  	foreach($arr_loc_field2 as $key=>$val){ 
					 echo "<option value = '".$val."'" ;
					  if($val == $cboLocf2) echo ' selected' ;
					 echo " >".$val . "</option>";
				}
			  ?>
        </select>
      </div></td>
    </tr>
    <tr>
      <td><div align="right">Start Time : </div></td>
      <td><div align="left">
        <input name="txtStarttime" type="text" id="txtStarttime" value="<?=$txtStarttime; ?>" onBlur="return Onblur();">
      </div></td>
      <td><div align="right">End Time : </div></td>
      <td><div align="left">
        <input name="txtEndtime" type="text" id="txtEndtime" value="<?=$txtEndtime; ?>" onBlur="return Onblur();">
      </div></td>
    </tr>
    <tr>
      <td height="23" colspan="4">
        <hr width="100%" noshade  color="#339900">      
	  </td>
    </tr>
    <tr>
      <td height="29">
        <div align="right">
          <input name="chkLocOnTop" type="checkbox" id="chkLocOnTop" value="Y"
		<?
			echo  "value = '" .$chkLocOnTop . "'" ;
			if($chkLocOnTop=="Y") echo ' checked';
		?>
		>
      Location on top </div></td>
      <td>
        <div align="center">
          <input name="chkInout" type="checkbox" id="chkInout" value="Y"
		<?
			echo  "value = '" .$chkInout . "'" ;
			if($chkInout=="Y") echo ' checked';
		?>
		>
      In/Out Days </div></td>
      <td>
        <div align="right">
          <input name="chkEventday" type="checkbox" id="chkEventday" value="Y" 
		<?
			echo  "value = '" .$chkEventday . "'" ;
			if($chkEventday == "Y") echo ' checked';
		?>
		>
      Event Days </div></td>
      <td>
        <div align="center">
          <input name="chkShortdisplay" type="checkbox" id="chkShortdisplay" value="Y"
		<?
			echo  "value = '" .$chkshortdisplay . "'" ;
			if($chkShortdisplay == "Y" ) echo ' checked';
		?>
		>
      Short Display </div></td></tr>
    <tr>
      <td height="42" colspan="2"><div align="right">
        <input name="Submit" type="submit" class="Button" value="   OK   ">
      </div></td>
      <td colspan="2"><div align="left">
        <input name="Button" type="button" class="Button" id="Button"  onClick="history.go(-1)" value="Cancel" >
      </div></td>
    </tr>
  </table>
</form>
</body>
</html>
<?
	#Begin Save Data
	if($Submit){ 
		//echo "OK";
		$txtStartdate = ($_REQUEST["txtStartdate"]);
		$txtEventday = $_REQUEST["txtEventday"];
		$txtScroll = $_REQUEST["txtScroll"];
		$txtStarttime = ($_REQUEST["txtStarttime"]);
		$cboLocation = $_REQUEST["cboLocation"];
		$cboLocf1 = $_REQUEST["cboLocf1"];
		$cboLocf2 = $_REQUEST["cboLocf2"];
		$txtEndtime = ($_REQUEST["txtEndtime"]);
		$chkInout = $_REQUEST["chkInout"];
		$chkEventday = $_REQUEST["chkEventday"];
		$chkShortdisplay = $_REQUEST["chkShortdisplay"];
		$chkLocOnTop = $_REQUEST["chkLocOnTop"];
		$day_name_length = 2;	
		if (empty($chkInout)) $chkInout = "N";
		if (empty($chkEventday)) $chkEventday = "N";
		if (empty($chkShortdisplay)) $chkShortdisplay = "N";
		/*
		echo " \$Submit = $Submit<br>
			txtStartdate = $txtStartdate<br>
			txtEventday = $txtEventday<br>
			txtScroll = $txtScroll<br>
			txtStarttime = $txtStarttime<br>
			cboLocation = $cboLocation<br>
			cboLocf1 = $cboLocf1<br>
			cboLocf2 = $cboLocf2<br>
			txtEndtime = $txtEndtime<br>
			chkInout = $chkInout<br>
			chkEventday = $chkEventday<br>
			chkShortdisplay = $chkShortdisplay<br>
			chkLocOnTop = $chkLocOnTop<hr>
			";
		*/
		
		#save selected in default
		$arr_default = array('txtStartdate','txtEventday','txtScroll','txtStarttime','cboLocation',
		'cboLocf1','cboLocf2','txtEndtime','chkInout','chkEventday','chkShortdisplay','chkLocOnTop');
		$arr_val = array(chgDateToDb($txtStartdate), $txtEventday, $txtScroll, chgTimeToDb($txtStarttime), $cboLocation,
		$cboLocf1,$cboLocf2,chgTimeToDb($txtEndtime),$chkInout,$chkEventday,$chkShortdisplay,$chkLocOnTop
		);	
		
		for($i=0;$i<count($arr_default);$i++){
			$sql = "UPDATE `default` SET `value` =  '$arr_val[$i]'	WHERE `type` = 'booking'  AND `fields` =  '$arr_default[$i]'	";
			//echo "$sql<br>";
			mysql_query($sql) or die("Update default error !");
		}
		echo "<script> window.open ('show_booking.php',target='main_Frame') ;</script>";
	}//if($Submit){
	
	include("db/disconnect.db.php");
?>
