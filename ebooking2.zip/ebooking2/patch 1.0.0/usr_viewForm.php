<?
	ob_start(); 
	session_start();	
	define("tableName","user");
	define("viewForm","usr_viewForm.php");
	define("updForm","usr_updForm.php");
	define("field_id","usr_id");
	define("beg_id",1);	
	define("end_id",3);	
	
	$sql = "SELECT usr.usr_id, usr.usr_login, usr.usr_pass, 
				sec.sec_name, usr.usr_name, usr.usr_used, usr.usr_cre, usr.date_cre,
				usr.usr_upd, usr.date_upd
				FROM user usr, security sec
				WHERE usr.usr_sec = sec.sec_id
				";
	//echo "$sql";
	//exit();
	define("query","$sql");
	
	$cap_name = array();
	$cap_name = array("#","login","pass","security","name","used","used create","date create","user upd","date upd");
	
	$key = array_keys($_SESSION["sec_add"], viewForm); 
	//print_r(array_keys($_SESSION["sec_add"], viewForm));
	if($key[0])
		define("insert",1);		
	else
		define("insert",0);			
	//echo "insert = ".insert."<br>";
		
	$key = array_keys($_SESSION["sec_edit"], viewForm); 
	//print_r(array_keys($_SESSION["sec_edit"], viewForm));
	if($key[0])
		define("edit",1);		
	else
		define("edit",0);			
	//echo "edit = ".edit."<br>";
	
	$key = array_keys($_SESSION["sec_del"], viewForm); 
	//print_r(array_keys($_SESSION["sec_del"], viewForm));
	if($key[0])
		define("del",1);		
	else
		define("del",0);			
	//echo "del = ".del."<hr>";
	
	include("func/viewForm.func.php");
?>
</body>
</html>
