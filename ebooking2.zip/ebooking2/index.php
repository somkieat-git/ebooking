<?
	ob_start();
	session_start();
	$_SESSION["site"]="ebooking";
?>
<script>
window.location='ql/index.php';
</script>
