<?

//include_once("func/misc.func.php");
error_reporting(E_ALL ^E_NOTICE ^E_WARNING);
function create_update_query($table_name, $data, $id, $id_field_name="ID") 
{
	$request = "UPDATE ".$table_name." SET ";
	foreach($data as $field_name=>$field_val) 
	{
		if( !is_int($field_val) ) 
		{
			$field_val = "'$field_val'";
		}
		$request .= " ".$field_name."=".$field_val.",";
	}
	$request = substr( $request, 0, 0 - strlen(",") );            	
	$request .= " WHERE $id_field_name=".$id;

	Return $request;
}

function create_update_evquery($table_name, $data, $id1, $id_field_name1, $id2, $id_field_name2) 
{
	$request = "UPDATE ".$table_name." SET ";
	foreach($data as $field_name=>$field_val) 
	{
		if( !is_int($field_val) ) 
		{
			$field_val = "'$field_val'";
		}
		$request .= " ".$field_name."=".$field_val.",";
	}
	$request = substr( $request, 0, 0 - strlen(",") );            	
	$request .= " WHERE $id_field_name1= ".$id1;
	$request .= " AND $id_field_name2= ".$id2;

	Return $request;
}

function create_insert_query($table_name, $data) 
{
	$request = "INSERT INTO ".$table_name." ( ";
	$request_values = "";

	foreach($data as $field_name=>$field_val) 
	{
		$field_name=strtoupper($field_name);
		$request.="$field_name ,";
		if(!is_int($field_valal)) 
		{
			$field_val = "'$field_val'";
		}
		$request_values .= $field_val.",";
	}
	$request = substr( $request, 0, 0 - strlen(",") );            	
	$request .= " ) VALUES (";
	$request_values = substr( $request_values, 0, 0 - strlen(",") );            	
	$request .= $request_values.")";

	Return $request;
}


function get_recordset_sql($s_table_name, $arr_data, $arr_selected_field) 
{
	//var_dump($arr_data);
	$s_selected_field = arr_val2str($arr_selected_field);
	//echo "<br>";
	//var_dump($s_selected_field);

	$myquery = "SELECT $s_selected_field FROM $s_table_name WHERE id>0 ";
	foreach($arr_data as $field_name=>$field_val) 
	{
		if(!is_int($field_val)) 
		{
			$field_val = "'$field_val'";
		}
		$myquery .= " and ".$field_name."=".$field_val;
	}

	$r = mysql_query($myquery);

	Return $r;
}


function get_viewForm($query,$pointer,$pagesize) 
{

	$myquery = "$query ";
	if (!empty($pointer) || !empty($pagesize) ){
		$myquery .= " limit $pointer,$pagesize";
	}
	//echo "$myquery<br>";
	$r = mysql_query($myquery);
	Return $r;
}

function get_updForm($table_name,$field_id,$field_val) 
{

	$myquery = "SELECT * FROM $table_name WHERE $field_id = $field_val ";
	$r = mysql_query($myquery);
	Return $r;
}

function get_ev_updForm($table_name,$field_id,$field_val,$evn_id) 
{

	$myquery = " SELECT * FROM $table_name WHERE $field_id = $field_val ";
	$myquery .= " AND evn_id = $evn_id";
	$r = mysql_query($myquery);
	Return $r;
}

function errmesg($str){
	//$mesg = "<center><font face=\"MS Sans Serif\" size=\"2\" color=\"red\">$str</font></center>";	
	//return $mesg;
	$mesg = "<script language='javascript'>alert('$str');window.history.go(-1)</script>";
	return $mesg;
}

function add_data($data,$table){
	$query = "insert into $table values(";
	list($key,$value) = each($data);
	$query = $query."'$value'";
	while(list($key,$value) = each($data))
		$query = $query.",'$value'";
	$query = $query.")";
	return $query;
}

function get_id_sql($s_table_name, $arr_data) 
{
	$result = get_recordset_sql($s_table_name, $arr_data, array(0=>"ID"));
	if($result) 
	{
		$f = mysql_fetch_assoc($result);
	}

	Return $f["ID"];
}


function get_instance_sql($s_table_name, $arr_data) 
{
	$result = get_recordset_sql($s_table_name, $arr_data, array(0=>"*"));
		
	Return $result;
}


function get_instance_sql_arr($s_table_name, $arr_data) 
{
	$result = get_instance_sql($s_table_name, $arr_data);
	if(mysql_num_rows($result)>0) 
	{
		$f = mysql_fetch_assoc($result);	
		Return $f;
	}

	Return 0;
}

function getAuthor($arr_data)
{
	$res = array();
	foreach($arr_data as $key=>$val) 
	{
		$sql = "select frm_name from formname  " ;
		$sql .= "where frm_id = $val ";
		$result = mysql_query($sql) ;
		$row = mysql_fetch_array($result);
		if($result)			
		  $res["$val"] = "$row[0]";
	}	
	Return $res;
}

function getMenu($arr_data,$status)
{
	$res = array();
	foreach($arr_data as $key=>$val) 
	{
		$sql = "select frm_menu,frm_name from formname where  frm_status = '$status' ";
		$sql .= "and frm_id = $key ";
		$result = mysql_query($sql) ;
		$row = mysql_fetch_array($result);
		$num = mysql_num_rows($result);		
		if($num==1)			
		  $res["$row[0]"] = "$row[1]";
	}	
	Return $res;
}

function getData($query)
{
	$res = mysql_query($query) or die(errmesg('Query error'));
	Return $res;
}

function getResult($query,$item)
{
	$res = mysql_query($query) or die(errmesg('Query error'));
	$fetch = mysql_fetch_array($res);
	if($item)
		$res = $fetch[$item];
	else 
		$res = $fetch;
	Return $res;
}

function getNumRow($query)
{
	$res = mysql_query($query) or die(errmesg('Query error'));
	$numrow = mysql_num_rows($res);
	Return $numrow;
}

function getRate($arr_data,$rtc_id,$evn_id)
{
	$res = array();
	foreach($arr_data as $key=>$val) 
	{
		$sql = "select srtc.loc_id, srtc.show_amt, srtc.inout_amt, srtc.out_amt , rtc.rtc_status,
					esta.esta_ini_atten
					from sub_ratecode srtc, ratecode rtc, ev_statistics esta
					where   srtc.rtc_id = rtc.rtc_id
					and srtc.rtc_id = esta.rtc_id
					and rtc.rtc_id = esta.rtc_id
					and srtc.rtc_id = $rtc_id 
					and esta.evn_id = '$evn_id'
					and srtc.loc_id = $val					
					";
		//echo "$sql<br>";
		//exit();
		$result = mysql_query($sql) ;
		$row = mysql_fetch_array($result);
		$num = mysql_num_rows($result);		
		if($num==1)			
		  $res["$row[0]"] = array($row[1],$row[2],$row[3],$row[4],$row[5]);
	}	
	Return $res;
}


function chgDate($strDate)
{
	$res = substr($strDate,6,2)."/".substr($strDate,4,2)."/".substr($strDate,0,4);
	Return $res;
}

function chgDateToDb($strDate)
{
	$false   = array("/", '.');	
	$true = array("/", "/");
	$res = str_replace($false, $true, $strDate);	
	list($dd, $mm, $yyyy) = explode('/',$res);
	if(strlen($dd) < 2) $dd = '0' . $dd;
	if(strlen($mm) < 2) $mm = '0' . $mm;
	if(strlen($yyyy) < 2) $yyyy = '200' . $yyyy;
	if(strlen($yyyy) < 3) $yyyy = '20' . $yyyy;	
	$res = $yyyy.$mm.$dd;
	Return $res;
}
function chgTime($strTime)
{
	$res = substr($strTime,0,2).":".substr($strTime,-2); 
	Return $res;
}
function chgTimeToDb($strTime)
{
	$false   = array(":", '.');	
	$true = array(":", ":");
	$res = str_replace($false, $true, $strTime);	
	list($hh, $mm) = explode(':',$res);
	if(strlen($hh) < 2) $hh = '0' . $hh;
	if(strlen($mm) < 2) $mm = $mm. '0';
	$res = $hh.$mm;
	Return $res;
	
}

function chgNumber($strNumber)
{	
	$res = number_format($strNumber,2);
	Return $res;
}

function chgNumberToDb($strNumber)
{
	$false   = array(",", '.00');	
	$true = array("", "");
	$res = str_replace($false, $true, $strNumber);
	Return $res;
}

function updRevenue($action,$table_name,$field_id,$id)
{
	$vatrate = 7 ;
	$inc_yn = "Y";
	$resData = array();
	$user_name = $_SESSION["usr_name"];
	$date_name = date("Y/m/d  H:i:s");		
	
	//if($action == "a" || $action == "e"){
		if($table_name == "ev_location"){
			$sql = "
						SELECT eloc_id, evn_id, loc_id, eloc_in_date, eloc_event_date,
						eloc_end_date, eloc_out_date, rtc_status, eloc_show_qty,
						eloc_show_net, eloc_inout_qty, eloc_inout_net,
						eloc_out_qty, eloc_out_net
						FROM ev_location eloc, ratecode rtc 
						WHERE  $field_id = $id
						AND eloc.rtc_id = rtc.rtc_id						
						";
			//echo "$sql<br>"; //exit();
			$result = mysql_query($sql);
			$rs = mysql_fetch_array($result);
			#get value from $rs
			$eloc_id = $rs[0];
			$evn_id = $rs[1];
			$loc_id = $rs[2];
			$eloc_in_date = $rs[3];
			$eloc_event_date = $rs[4];
			$eloc_end_date = $rs[5];
			$eloc_out_date = $rs[6];
			$rtc_status = $rs[7];
			if($rtc_status=="L") $rev_type = "space_L";
			if($rtc_status=="P") $rev_type = "space_P";			
			$eloc_show_qty = $rs[8];
			$eloc_show_total = $rs[9];
			$eloc_inout_qty = $rs[10];
			$eloc_inout_total = $rs[11];
			$eloc_out_qty = $rs[12];
			$eloc_out_total = $rs[13];
			
			if( $action == "e"){
				$del = delRevenue($rev_type,$eloc_id);
			}
			
			if( $action == "d"){
				$del = delRevenue($rev_type,$eloc_id);
				exit();
			}
			
			#chk eloc_in_date
			$arr_date = array();
			if($eloc_inout_qty){
				//echo "\$eloc_out_qty";
				$intMM = substr($eloc_in_date,4,2);
				$intDD = substr($eloc_in_date,6,2);
				$intYY = substr($eloc_in_date,0,4);
				$stDate = gregoriantojd($intMM, $intDD, $intYY);
				
				$intMM = substr($eloc_event_date,4,2);
				$intDD = substr($eloc_event_date,6,2);
				$intYY = substr($eloc_event_date,0,4);
				$enDate = gregoriantojd($intMM, $intDD, $intYY);
				//for($i = $eloc_event_date ; $i <= $eloc_end_date ; $i++){
				for($i = $stDate ; $i <= $enDate ; $i++){
					$convDate = jdtogregorian ($i);
					//echo "<br>\$convDate=$convDate<br>";
					list($intMM,$intDD,$intYY) = explode("/",$convDate);
					$convDate = chgDateToDb("$intDD/$intMM/$intYY");													
				
				//for($i = $eloc_in_date ; $i < $eloc_event_date ; $i++){
					$total = $eloc_inout_total;
					$qty = round($total / $eloc_inout_qty,2) ;
					if($inc_yn == "Y"){
						$vat = round(($qty / (100 + $vatrate )) * $vatrate,2);
						$b4vat = round($qty - $vat,2) ;
					}
					else {
						$vat = round(($qty / (100 )) * $vatrate,2);
						$b4vat = $qty ;
					}
					$incvat  =  round($b4vat + $vat ,2);
					$arr_date[] =  $convDate.",".$qty.",".$b4vat.",".$vat.",".$incvat ;
				} // for($i = $eloc_in_date ; $i <= $eloc_event_date ; $i++){
			} // if($eloc_inout_qty){
			
			foreach($arr_date as $key=>$val) {
				list($rev_date, $rev_total, $rev_b4vat, $rev_vat, $rev_incvat) = explode(',',$val);
				$resData["evn_id"] = $evn_id;
				$resData["loc_id"] = $loc_id;
				$resData["rev_date"] = $rev_date;
				$resData["rev_source"] = "in";
				$resData["rev_type"] = $rev_type;
				$resData["rev_total"] = $rev_total;
				$resData["rev_b4vat"] = $rev_b4vat;
				$resData["rev_vat"] = $rev_vat;
				$resData["rev_incvat"] = $rev_incvat;
				$resData["rev_link"] = $eloc_id;
				$resData["usr_cre"] = $user_name ;
				$resData["date_cre"] = $date_name ;
				
				$query = create_insert_query("ev_revenue",$resData);	
				//echo "$query<hr>";
				//exit();
				mysql_query($query) or die("Insert ev_location error");						
			} // foreach($arr_in_date as $key=>$val) {
			//exit();
			
			#chk eloc_event_date
			$arr_date = array();
			if($eloc_show_qty){
				//echo "\$eloc_show_qty";
				$intMM = substr($eloc_event_date,4,2);
				$intDD = substr($eloc_event_date,6,2);
				$intYY = substr($eloc_event_date,0,4);
				$stDate = gregoriantojd($intMM, $intDD, $intYY);
				
				$intMM = substr($eloc_end_date,4,2);
				$intDD = substr($eloc_end_date,6,2);
				$intYY = substr($eloc_end_date,0,4);
				$enDate = gregoriantojd($intMM, $intDD, $intYY);
				//for($i = $eloc_event_date ; $i <= $eloc_end_date ; $i++){
				for($i = $stDate ; $i <= $enDate ; $i++){
					$convDate = jdtogregorian ($i);
					//echo "<br>\$convDate=$convDate<br>";
					list($intMM,$intDD,$intYY) = explode("/",$convDate);
					$convDate = chgDateToDb("$intDD/$intMM/$intYY");									
					$total = $eloc_show_total;
					$qty = round($total / $eloc_show_qty,2) ;
					if($inc_yn == "Y"){
						$vat = round(($qty / (100 + $vatrate )) * $vatrate,2);
						$b4vat = round($qty - $vat,2) ;
					}
					else {
						$vat = round(($qty / (100 )) * $vatrate,2);
						$b4vat = $qty ;
					}
					$incvat  =  round($b4vat + $vat,2) ;
					$arr_date[] =  $convDate.",".$qty.",".$b4vat.",".$vat.",".$incvat ;
				} // for($i = $eloc_in_date ; $i <= $eloc_event_date ; $i++){
			} // if($eloc_inout_qty){
			
			foreach($arr_date as $key=>$val) {
				list($rev_date, $rev_total, $rev_b4vat, $rev_vat, $rev_incvat) = explode(',',$val);
				$resData["evn_id"] = $evn_id;
				$resData["loc_id"] = $loc_id;
				$resData["rev_date"] = $rev_date;
				$resData["rev_source"] = "show";
				$resData["rev_type"] = $rev_type;
				$resData["rev_total"] = $rev_total;
				$resData["rev_b4vat"] = $rev_b4vat;
				$resData["rev_vat"] = $rev_vat;
				$resData["rev_incvat"] = $rev_incvat;
				$resData["rev_link"] = $eloc_id;
				$resData["usr_cre"] = $user_name ;
				$resData["date_cre"] = $date_name ;
				
				$query = create_insert_query("ev_revenue",$resData);	
				//echo "$query<hr>";
				//exit();
				mysql_query($query) or die("Insert ev_location error");						
			} // foreach($arr_in_date as $key=>$val) {
			//exit();
			
			#chk eloc_out_date
			$arr_date = array();
			if($eloc_out_qty){
				//echo "\$eloc_out_qty";
				$intMM = substr($eloc_end_date,4,2);
				$intDD = substr($eloc_end_date,6,2);
				$intYY = substr($eloc_end_date,0,4);
				$stDate = gregoriantojd($intMM, $intDD, $intYY);
				
				$intMM = substr($eloc_out_date,4,2);
				$intDD = substr($eloc_out_date,6,2);
				$intYY = substr($eloc_out_date,0,4);
				$enDate = gregoriantojd($intMM, $intDD, $intYY);
				//for($i = $eloc_event_date ; $i <= $eloc_end_date ; $i++){
				for($i = $stDate ; $i <= $enDate ; $i++){
					$convDate = jdtogregorian ($i);
					//echo "<br>\$convDate=$convDate<br>";
					list($intMM,$intDD,$intYY) = explode("/",$convDate);
					$convDate = chgDateToDb("$intDD/$intMM/$intYY");									
								
				//for($i > $eloc_end_date ; $i <= $eloc_out_date ; $i++){
					$total = $eloc_out_total;
					$qty = round($total / $eloc_out_qty,2) ;
					if($inc_yn == "Y"){
						$vat = round(($qty / (100 + $vatrate )) * $vatrate,2);
						$b4vat = round($qty - $vat,2) ;
					}
					else {
						$vat = round(($qty / (100 )) * $vatrate,2);
						$b4vat = $qty ;
					}
					$incvat  =  round($b4vat + $vat,2) ;
					$arr_date[] =  $convDate.",".$qty.",".$b4vat.",".$vat.",".$incvat ;
				} // for($i = $eloc_in_date ; $i <= $eloc_event_date ; $i++){
			} // if($eloc_inout_qty){
			
			foreach($arr_date as $key=>$val) {
				list($rev_date, $rev_total, $rev_b4vat, $rev_vat, $rev_incvat) = explode(',',$val);
				$resData["evn_id"] = $evn_id;
				$resData["loc_id"] = $loc_id;
				$resData["rev_date"] = $rev_date;
				$resData["rev_source"] = "out";
				$resData["rev_type"] = $rev_type;
				$resData["rev_total"] = $rev_total;
				$resData["rev_b4vat"] = $rev_b4vat;
				$resData["rev_vat"] = $rev_vat;
				$resData["rev_incvat"] = $rev_incvat;
				$resData["rev_link"] = $eloc_id;
				$resData["usr_cre"] = $user_name ;
				$resData["date_cre"] = $date_name ;
				
				$query = create_insert_query("ev_revenue",$resData);	
				//echo "$query<hr>";
				//exit();
				mysql_query($query) or die("Insert ev_location error");						
			} // foreach($arr_in_date as $key=>$val) {
			//exit();
		} // if($table_name == "ev_location"){
		
		if($table_name == "ev_equip_serv" || $table_name == "ev_food_serv"){
			$sql = "
						SELECT eesv_id, evn_id, loc_id, esv_id, eesv_beg_date,
						eesv_end_date, eesv_day, eesv_net, eesv_chk_vat
						FROM $table_name 
						WHERE  $field_id = $id
						";
			//echo "$sql<br>";
			$result = mysql_query($sql);
			$rs = mysql_fetch_array($result);
			#get value from $rs
			$eesv_id = $rs["eesv_id"];
			$evn_id = $rs["evn_id"];
			$loc_id = $rs["loc_id"];
			$esv_id = $rs["esv_id"];
			$eesv_beg_date = $rs["eesv_beg_date"];
			$eesv_end_date = $rs["eesv_end_date"];
			$eesv_day = $rs["eesv_day"];
			$eesv_total = $rs[7];			
			$eesv_chk_vat = $rs["eesv_chk_vat"];
			if($table_name=="ev_equip_serv") $rev_type = "equip";
			if($table_name=="ev_food_serv") $rev_type = "food";			

			if( $action == "e"){
				$del = delRevenue($rev_type,$eesv_id);
			}
			
			if( $action == "d"){
				$del = delRevenue($rev_type,$eesv_id);
				exit();
			}
			
			#chk eloc_in_date
			$arr_date = array();
			if($eesv_day){
				for($i = $eesv_beg_date ; $i <= $eesv_end_date ; $i++){
					$total = $eesv_total;
					$qty = round($total / $eesv_day,2) ;
					if($eesv_chk_vat == "Y"){
						$vat = round(($qty / (100 + $vatrate )) * $vatrate,2);
						$b4vat = round($qty - $vat,2) ;
					}
					else {
						$vat = round(($qty / (100 )) * $vatrate,2);
						$b4vat = $qty ;
					}
					$incvat  =  round($b4vat + $vat ,2);
					$arr_date[] =  $i.",".$qty.",".$b4vat.",".$vat.",".$incvat ;
				} // for($i = $eloc_in_date ; $i <= $eloc_event_date ; $i++){
			} // if($eloc_inout_qty){
			
			foreach($arr_date as $key=>$val) {
				list($rev_date, $rev_total, $rev_b4vat, $rev_vat, $rev_incvat) = explode(',',$val);
				$resData["evn_id"] = $evn_id;
				$resData["loc_id"] = $loc_id;
				$resData["esv_id"] = $esv_id;
				$resData["rev_date"] = $rev_date;
				$resData["rev_source"] = "equip_food";
				$resData["rev_type"] = $rev_type;
				$resData["rev_total"] = $rev_total;
				$resData["rev_b4vat"] = $rev_b4vat;
				$resData["rev_vat"] = $rev_vat;
				$resData["rev_incvat"] = $rev_incvat;
				$resData["rev_link"] = $eesv_id;
				$resData["usr_cre"] = $user_name ;
				$resData["date_cre"] = $date_name ;
				
				$query = create_insert_query("ev_revenue",$resData);	
				//echo "$query<hr>";
				//exit();
				mysql_query($query) or die("Insert ev_revenue error");						
			} // foreach($arr_in_date as $key=>$val) {
			//exit();
		} //if($table_name == "ev_equip_serv" || $table_name == "ev_food_serv"){			
		
	//} // if($action = "a" || $action = "e"){	
				
}

function delRevenue($rev_type,$rev_link)
{
	$sql = "
				DELETE FROM ev_revenue
				WHERE rev_type in ( '$rev_type' )
				AND rev_link in ( $rev_link )
				";
				//echo "$sql<br>";
	$res = mysql_query($sql) or die("Delete ev_revenue Error !");
	Return $res;
}

function delRevenue2($evn_id,$str_del,$type)	
{
	//echo "delRevenue2";
	$sql = "
				DELETE FROM ev_revenue
				WHERE evn_id = '$evn_id' ";								
				if ($type == "space"){
					$sql .= "AND loc_id in ( $str_del )
								  AND rev_type like ( 's%' )
					";
				}
				else{
					$sql .= "AND esv_id in ( $str_del )
								  AND rev_type = '$type'
					";				
				}
				//echo "$sql<br>";
				//exit();
	$res = mysql_query($sql) or die("Delete ev_revenue Error !");
	Return $res;
}

function calcDays($date1,$date2){
	$arrSDate = explode ("/", $date1);
	$arrEDate = explode ("/", $date2);	
	$intSDD = $arrSDate[0];	$intSMM = $arrSDate[1];	$intSYY = $arrSDate[2];	
	$intEDD = $arrEDate[0];	$intEMM = $arrEDate[1];	$intEYY = $arrEDate[2];	
	$intDate1Jul = gregoriantojd($intSMM, $intSDD, $intSYY);
	$intDate2Jul = gregoriantojd($intEMM, $intEDD, $intEYY);	
	//echo "\$intDate1Jul = $intDate1Jul , \$intDate2Jul=$intDate2Jul <br>";
	$result = $intDate2Jul - $intDate1Jul   ;
	//echo "\$result =$result <br>";
	return $result;
} // end function calcDays


function createRandomPassword() {

    $chars = "abcdefghijkmnopqrstuvwxyz023456789";
    srand((double)microtime()*1000000);
    $i = 1;
    $pass = '' ;

    while ($i <= 5) {
        $num = rand() % 33;
        $tmp = substr($chars, $num, 1);
        $pass = $pass . $tmp;
        $i++;
    }

    return $pass;

}// end function createRandomPassword()

function str2arr($strValue){
	if($strValue){
		$arrTmp=explode(",",$strValue);		
		foreach($arrTmp as $key=>$val){
			$arrValue[$val]=$val;
		} //foreach($arrTmp as $key=>$val){
		return $arrValue;		
	}//if($strValue){	
}//function str2arr(){

function multiID2str($strID,$arrData){
	$arrTmp=explode(",",$strID);
	foreach($arrTmp as $key=>$val){
		$arrResult[]=$arrData[$val];
	}
	$strResult=implode(", ",$arrResult);
	return $strResult;
} //function multiID2str($id,$data){

function getLocation($evnID){
	if($evnID){
		$sql=" select loc_id from ev_location ";
		$sql.=" where evn_id = $evnID";
		$sql.=" group by loc_id ";
		//echo "getLocation1=$sql<br>";
		$result = mysql_query($sql);
		while($rs = mysql_fetch_array($result)) {
			$arrResult[$rs[loc_id]]=$rs[loc_id];
		}
		$strTemp=implode(",",$arrResult);
		
		$sql=" select loc_id, loc_shortname from location ";
		$sql.=" where loc_id in( $strTemp )";		
		//echo "getLocation2=$sql<br>";
		$result = mysql_query($sql);
		while($rs = mysql_fetch_array($result)){
			$arrResult[$rs[loc_id]]=$rs[loc_shortname];
		}
		$strResult=implode(", ",$arrResult);
		return $strResult;		
	} //if($evnID){
} //function getLocation($evnID){

function updLog($usrLogin, $form, $msg){
	$log_ip = $_SERVER["REMOTE_ADDR"];
	//$msg=str_replace("'","",$msg);
	$sql = "insert into logfile values(
		'',now(),
		'$usrLogin',
		'$log_ip',
		'$form',
		\"$msg\"
		)";
	//echo "<br>updLog=$sql<br>" ; //exit();
	mysql_query($sql) or die ("Save logfile error");
}

?>