<?

//include_once("func/misc.func.php");
error_reporting(E_ALL ^E_NOTICE ^E_WARNING);
function create_update_query($table_name, $data, $id, $id_field_name="ID") 
{
	$request = "UPDATE ".$table_name." SET ";
	foreach($data as $field_name=>$field_val) 
	{
		if( !is_int($field_val) ) 
		{
			$field_val = "'$field_val'";
		}
		$request .= " ".$field_name."=".$field_val.",";
	}
	$request = substr( $request, 0, 0 - strlen(",") );            	
	$request .= " WHERE $id_field_name=".$id;

	Return $request;
}

function create_update_evquery($table_name, $data, $id1, $id_field_name1, $id2, $id_field_name2) 
{
	$request = "UPDATE ".$table_name." SET ";
	foreach($data as $field_name=>$field_val) 
	{
		if( !is_int($field_val) ) 
		{
			$field_val = "'$field_val'";
		}
		$request .= " ".$field_name."=".$field_val.",";
	}
	$request = substr( $request, 0, 0 - strlen(",") );            	
	$request .= " WHERE $id_field_name1= ".$id1;
	$request .= " AND $id_field_name2= ".$id2;

	Return $request;
}

function create_insert_query($table_name, $data) 
{
	$request = "INSERT INTO ".$table_name." ( ";
	$request_values = "";

	foreach($data as $field_name=>$field_val) 
	{
		$field_name=strtoupper($field_name);
		$request.="$field_name ,";
		if(!is_int($field_valal)) 
		{
			$field_val = "'$field_val'";
		}
		$request_values .= $field_val.",";
	}
	$request = substr( $request, 0, 0 - strlen(",") );            	
	$request .= " ) VALUES (";
	$request_values = substr( $request_values, 0, 0 - strlen(",") );            	
	$request .= $request_values.");";

	Return $request;
}


function get_recordset_sql($s_table_name, $arr_data, $arr_selected_field) 
{
	//var_dump($arr_data);
	$s_selected_field = arr_val2str($arr_selected_field);
	//echo "<br>";
	//var_dump($s_selected_field);

	$myquery = "SELECT $s_selected_field FROM $s_table_name WHERE id>0 ";
	foreach($arr_data as $field_name=>$field_val) 
	{
		if(!is_int($field_val)) 
		{
			$field_val = "'$field_val'";
		}
		$myquery .= " and ".$field_name."=".$field_val;
	}

	$r = mysql_query($myquery);

	Return $r;
}


function get_viewForm($query,$pointer,$pagesize) 
{

	$myquery = "$query ";
	if (!empty($pointer) || !empty($pagesize) ){
		$myquery .= " limit $pointer,$pagesize";
	}
	//echo "$myquery<br>";
	$r = mysql_query($myquery);
	Return $r;
}

function get_updForm($table_name,$field_id,$field_val) 
{

	$myquery = "SELECT * FROM $table_name WHERE $field_id = $field_val ";
	$r = mysql_query($myquery);
	Return $r;
}

function get_ev_updForm($table_name,$field_id,$field_val,$evn_id) 
{

	$myquery = " SELECT * FROM $table_name WHERE $field_id = $field_val ";
	$myquery .= " AND evn_id = $evn_id";
	$r = mysql_query($myquery);
	Return $r;
}

function errmesg($str)
{
	//$mesg = "<center><font face=\"MS Sans Serif\" size=\"2\" color=\"red\">$str</font></center>";	
	//return $mesg;
	$mesg = "<script language='javascript'>alert('$str');window.history.go(-1)</script>";
	return $mesg;
}

function add_data($data,$table)
{
	$query = "insert into $table values(";
	list($key,$value) = each($data);
	$query = $query."'$value'";
	while(list($key,$value) = each($data))
		$query = $query.",'$value'";
	$query = $query.")";
	return $query;
}

function get_id_sql($s_table_name, $arr_data) 
{
	$result = get_recordset_sql($s_table_name, $arr_data, array(0=>"ID"));
	if($result) 
	{
		$f = mysql_fetch_assoc($result);
	}

	Return $f["ID"];
}


function get_instance_sql($s_table_name, $arr_data) 
{
	$result = get_recordset_sql($s_table_name, $arr_data, array(0=>"*"));
		
	Return $result;
}


function get_instance_sql_arr($s_table_name, $arr_data) 
{
	$result = get_instance_sql($s_table_name, $arr_data);
	if(mysql_num_rows($result)>0) 
	{
		$f = mysql_fetch_assoc($result);	
		Return $f;
	}

	Return 0;
}

function getAuthor($arr_data)
{
	$res = array();
	foreach($arr_data as $key=>$val) 
	{
		$sql = "select frm_name from formname  " ;
		$sql .= "where frm_id = $val ";
		$result = mysql_query($sql) ;
		$row = mysql_fetch_array($result);
		if($result)			
		  $res["$val"] = "$row[0]";
	}	
	Return $res;
}

function getMenu($arr_data,$status)
{
	$res = array();
	foreach($arr_data as $key=>$val) 
	{
		$sql = "select frm_menu,frm_name from formname where  frm_status = '$status' ";
		$sql .= "and frm_id = $key ";
		$result = mysql_query($sql) ;
		$row = mysql_fetch_array($result);
		$num = mysql_num_rows($result);		
		if($num==1)			
		  $res["$row[0]"] = "$row[1]";
	}	
	Return $res;
}

function getData($query)
{
	$res = mysql_query($query) or die(errmesg('Query error'));
	Return $res;
}

function getResult($query,$item)
{
	$res = mysql_query($query) or die(errmesg('Query error'));
	$fetch = mysql_fetch_array($res);
	if($item)
		$res = $fetch[$item];
	else 
		$res = $fetch;
	Return $res;
}

function getNumRow($query)
{
	$res = mysql_query($query) or die(errmesg('Query error'));
	$numrow = mysql_num_rows($res);
	Return $numrow;
}

function getRate($arr_data,$rtc_id,$evn_id)
{
	$res = array();
	foreach($arr_data as $key=>$val) 
	{
		$sql = "select srtc.loc_id, srtc.show_amt, srtc.inout_amt, srtc.out_amt , rtc.rtc_status,
					esta.esta_ini_atten
					from sub_ratecode srtc, ratecode rtc, ev_statistics esta
					where   srtc.rtc_id = rtc.rtc_id
					and srtc.rtc_id = esta.rtc_id
					and rtc.rtc_id = esta.rtc_id
					and srtc.rtc_id = $rtc_id 
					and esta.evn_id = '$evn_id'
					and srtc.loc_id = $val					
					";
		//echo "$sql<br>";
		//exit();
		$result = mysql_query($sql) ;
		$row = mysql_fetch_array($result);
		$num = mysql_num_rows($result);		
		if($num==1)			
		  $res["$row[0]"] = array($row[1],$row[2],$row[3],$row[4],$row[5]);
	}	
	Return $res;
}


function chgDate($strDate)
{
	$res = substr($strDate,6,2)."/".substr($strDate,4,2)."/".substr($strDate,0,4);
	Return $res;
}

function chgDateToDb($strDate)
{
	$false   = array("/", '.');	
	$true = array("/", "/");
	$res = str_replace($false, $true, $strDate);	
	list($dd, $mm, $yyyy) = explode('/',$res);
	if(strlen($dd) < 2) $dd = '0' . $dd;
	if(strlen($mm) < 2) $mm = '0' . $mm;
	if(strlen($yyyy) < 2) $yyyy = '200' . $yyyy;
	if(strlen($yyyy) < 3) $yyyy = '20' . $yyyy;	
	$res = $yyyy.$mm.$dd;
	Return $res;
}

function chgAndUpdateDate($strDate)
{
	$false   = array("/", '.');	
	$true = array("/", "/");
	$res = str_replace($false, $true, $strDate);	
	list($dd, $mm, $yyyy) = explode('/',$res);
	//$yyyy +=1;
	$cur_year = date("Y");
	if(strlen($dd) < 2) $dd = '0' . $dd;
	if(strlen($mm) < 2) $mm = '0' . $mm;
	if($yyyy < $cur_year) $yyyy = $cur_year ;
	if(strlen($yyyy) < 2) $yyyy = '200' . $yyyy;
	if(strlen($yyyy) < 3) $yyyy = '20' . $yyyy;	
	$res = $yyyy.$mm.$dd;
	Return $res;
}



function chgTime($strTime)
{
	$res = substr($strTime,0,2).":".substr($strTime,-2); 
	Return $res;
}


function chgTimeToDb($strTime)
{
	$false   = array(":", '.');	
	$true = array(":", ":");
	$res = str_replace($false, $true, $strTime);	
	list($hh, $mm) = explode(':',$res);
	if(strlen($hh) < 2) $hh = '0' . $hh;
	if(strlen($mm) < 2) $mm = $mm. '0';
	$res = $hh.$mm;
	Return $res;
	
}

function chgNumber($strNumber)
{	
	$res = number_format($strNumber,2);
	Return $res;
}

function chgNumberToDb($strNumber)
{
	$false   = array(",", '.00');	
	$true = array("", "");
	$res = str_replace($false, $true, $strNumber);
	Return $res;
}

function updRevenue($action,$table_name,$field_id,$id)
{
	if($table_name == "ev_location"){
		$sql="SELECT eloc_id ,evn_id ,loc_id";
		$sql.=" ,eloc_in_date ,eloc_event_date ,eloc_end_date ,eloc_out_date ,rtc_status";
		$sql.=" ,eloc_inout_qty ,eloc_inout_total ,eloc_inout_adj ,eloc_inout_net";
		$sql.=" ,eloc_show_qty ,eloc_show_total ,eloc_show_adj ,eloc_show_net";
		$sql.=" ,eloc_out_qty ,eloc_out_total ,eloc_out_adj ,eloc_out_net";
		$sql.=" FROM ev_location eloc, ratecode rtc ";
		$sql.="	WHERE  $field_id = $id";
		$sql.="	AND eloc.rtc_id = rtc.rtc_id";	
		//$sql.=" AND eloc_show_net > 0 ";	
		$sql.=" AND eloc_g_net > 0 ";			
		echo "$sql<hr>"; //exit();
		$result = mysql_query($sql);
		$rs = mysql_fetch_array($result);
		
		#get value from $rs
		$eloc_id = $rs["eloc_id"];
		$evn_id = $rs["evn_id"];
		$loc_id = $rs["loc_id"];
		$eloc_in_date = $rs["eloc_in_date"];
		$eloc_event_date = $rs["eloc_event_date"];
		$eloc_end_date = $rs["eloc_end_date"];
		$eloc_out_date = $rs["eloc_out_date"];
		$rtc_status = $rs["rtc_status"];
		if($rtc_status=="L") $rev_type = "space_L";
		if($rtc_status=="P") $rev_type = "space_P";	
		
		$eloc_inout_qty = $rs["eloc_inout_qty"];
		$eloc_inout_total = $rs["eloc_inout_total"];
		$eloc_inout_adj = $rs["eloc_inout_adj"];
		$eloc_inout_net = $rs["eloc_inout_net"];
				
		$eloc_show_qty = $rs["eloc_show_qty"];			
		$eloc_show_total = $rs["eloc_show_total"];
		$eloc_show_adj = $rs["eloc_show_adj"];
		$eloc_show_net = $rs["eloc_show_net"];
		
		$eloc_out_qty = $rs["eloc_out_qty"];
		$eloc_out_total = $rs["eloc_out_total"];
		$eloc_out_adj = $rs["eloc_out_adj"];
		$eloc_out_net = $rs["eloc_out_net"];
		
		if($rev_type){
			if( $action == "e"){
				$del = delRevenue($rev_type,$eloc_id);
			}//if( $action == "e"){			
			if( $action == "d"){
				$del = delRevenue($rev_type,$eloc_id);
				exit();
			}//if( $action == "d"){			
		}//if($rev_type){
		
	
		$arrQuery=array();		
		#chk eloc_in_date
		$in_date = conToGregoriantojd($eloc_event_date)-1;
		$in_date = conToJdtogregorian($in_date);
		
		$arrQuery["in"]=genRevenue($evn_id,$loc_id,"in",$rev_type,$eloc_in_date,$in_date,$eloc_inout_qty,$eloc_inout_total,$eloc_inout_adj,$eloc_inout_net,"Y",$eloc_id);	
		
		#chk eloc_show_date
		$arrQuery["show"]=genRevenue($evn_id,$loc_id,"show",$rev_type,$eloc_event_date,$eloc_end_date,$eloc_show_qty ,$eloc_show_total ,$eloc_show_adj ,$eloc_show_net ,"Y",$eloc_id);	
		
		#chk eloc_out_date
		$out_date = conToGregoriantojd($eloc_end_date)+1;
		$out_date = conToJdtogregorian($out_date);
		
		$arrQuery["out"]=genRevenue($evn_id,$loc_id,"out",$rev_type,$out_date,$eloc_out_date,$eloc_out_qty,$eloc_out_total,$eloc_out_adj,$eloc_out_net,"Y",$eloc_id);
	
		/*echo "<br>\$arrQuery=<pre>";
		print_r($arrQuery); exit();	*/
		
	} //if($table_name == "ev_location"){			
	
	if($table_name == "ev_equip_serv" || $table_name == "ev_food_serv"){
		$sql="SELECT eesv_id ,evn_id ,loc_id ,esv_id ";
		$sql.=",eesv_beg_date ,eesv_end_date, eesv_day";
		$sql.=",eesv_total ,eesv_adj ,eesv_net ,eesv_chk_vat";
		$sql.="	FROM $table_name ";
		$sql.="	WHERE  $field_id = $id";
		$sql.=" AND eesv_include_vat > 0";
		//echo "$sql<hr>"; //exit();
		
		$result = mysql_query($sql);
		$rs = mysql_fetch_array($result);
		#get value from $rs
		$eesv_id = $rs["eesv_id"];
		$evn_id = $rs["evn_id"];
		$loc_id = $rs["loc_id"];
		$esv_id = $rs["esv_id"];
		$eesv_beg_date = $rs["eesv_beg_date"];
		$eesv_end_date = $rs["eesv_end_date"];
		$eesv_day = $rs["eesv_day"];
		$eesv_total = $rs["eesv_total"];	
		$eesv_adj = $rs["eesv_adj"];
		$eesv_net = $rs["eesv_net"];
		$eesv_chk_vat = $rs["eesv_chk_vat"];
		if($table_name=="ev_equip_serv") $rev_type = "equip";
		if($table_name=="ev_food_serv") $rev_type = "food";			
		
		if($rev_type){
			if( $action == "e"){
				$del = delRevenue($rev_type,$eesv_id);
			}		
			if( $action == "d"){
				$del = delRevenue($rev_type,$eesv_id);
				exit();
			}	
		}//if($rev_type){
		
		
		#equip & food
		$arrQuery["equip_food"]=genRevenue($evn_id,$loc_id,"equip_food",$rev_type,$eesv_beg_date,$eesv_end_date,$eesv_day,$eesv_total,$eesv_adj,$eesv_net,$eesv_chk_vat,$eesv_id);			
		
		//echo "<br>\$arrQuery=<pre>";
		//print_r($arrQuery); //exit();	
		
	} //if($table_name == "ev_equip_serv" || $table_name == "ev_food_serv"){
	
	//echo "<br>\$arrQuery=<pre>";
	//print_r($arrQuery); //exit();	
	
	foreach($arrQuery as $key=>$val) {
		foreach($val as $subKey=>$subVal) {			
			$strSQl=$subVal;
			//echo "\$strSQl=$strSQl<br>";	
			mysql_query($strSQl) or die("Insert ev_revenue error!");		
		}//foreach($val[$key] as $subKey=>$subVal) {
	}//foreach($arrQuery as $key=>$val) {
	//exit();							
					
}//function updRevenue($action,$table_name,$field_id,$id)

function delRevenue($rev_type,$rev_link)
{
	$sql = "
			DELETE FROM ev_revenue
			WHERE rev_type in ( '$rev_type' )
			AND rev_link in ( $rev_link )
			";
			echo "$sql<br>"; //exit();
	$res = mysql_query($sql) or die("Delete ev_revenue Error !");
	Return $res;
}

function delRevenue2($evn_id,$str_del,$type)	
{
	//echo "delRevenue2";
	$sql = "
		DELETE FROM ev_revenue
		WHERE evn_id = '$evn_id' ";								
		if ($type == "space"){
			$sql .= "AND loc_id in ( $str_del )
						  AND rev_type like ( 's%' )
			";
		}
		else{
			$sql .= "AND esv_id in ( $str_del )
						  AND rev_type = '$type'
			";				
		}
				//echo "$sql<br>";
				//exit();
	$res = mysql_query($sql) or die("Delete ev_revenue Error !");
	Return $res;
}

function calcDays($date1,$date2)
{
	//echo "<hr>\$date1= $date1  ,  \$date2= $date2";
	if (ereg("/" , $date1 )){
		$arrSDate = explode ("/", $date1);
		$intSDD = $arrSDate[0];	$intSMM = $arrSDate[1];	$intSYY = $arrSDate[2];	
	}else{
		$intSDD = substr($date1,6,2); $intSMM = substr($date1,4,2);	$intSYY = substr($date1,0,4);
	}
	
	if (ereg("/" , $date2 )){
		$arrEDate = explode ("/", $date2);	
		$intEDD = $arrEDate[0];	$intEMM = $arrEDate[1];	$intEYY = $arrEDate[2];		
	}else{
		$intEDD = substr($date2,6,2); $intEMM = substr($date2,4,2);	$intEYY = substr($date2,0,4);
	}
	
	/*$arrSDate = explode ("/", $date1);
	$arrEDate = explode ("/", $date2);	
	$intSDD = $arrSDate[0];	$intSMM = $arrSDate[1];	$intSYY = $arrSDate[2];	
	$intEDD = $arrEDate[0];	$intEMM = $arrEDate[1];	$intEYY = $arrEDate[2];	*/
	$intDate1Jul = gregoriantojd($intSMM, $intSDD, $intSYY);
	$intDate2Jul = gregoriantojd($intEMM, $intEDD, $intEYY);	
	//echo "<hr>\$intDate1Jul = $intDate1Jul , \$intDate2Jul=$intDate2Jul <br>";
	$result = $intDate2Jul - $intDate1Jul   ;
	//echo "\$result =$result <br>";
	return $result;
} // end function calcDays

function createRandomPassword() 
{

    $chars = "abcdefghijkmnopqrstuvwxyz023456789";
    srand((double)microtime()*1000000);
    $i = 1;
    $pass = '' ;

    while ($i <= 5) {
        $num = rand() % 33;
        $tmp = substr($chars, $num, 1);
        $pass = $pass . $tmp;
        $i++;
    }

    return $pass;

}// end function createRandomPassword()

function str2arr($strValue)
{
	if($strValue){
		$arrTmp=explode(",",$strValue);		
		foreach($arrTmp as $key=>$val){
			$arrValue[$val]=$val;
		} //foreach($arrTmp as $key=>$val){
		return $arrValue;		
	}//if($strValue){	
}//function str2arr(){

function multiID2str($strID,$arrData)
{
	$arrTmp=explode(",",$strID);
	foreach($arrTmp as $key=>$val){
		$arrResult[]=$arrData[$val];
	}
	$strResult=implode(", ",$arrResult);
	return $strResult;
} //function multiID2str($id,$data){

function getLocation($evnID)
{
	if($evnID){
		$sql=" select loc_id from ev_location ";
		$sql.=" where evn_id = $evnID";
		$sql.=" group by loc_id ";
		//echo "getLocation1=$sql<br>";
		$result = mysql_query($sql);
		while($rs = mysql_fetch_array($result)) {
			$arrResult[$rs[loc_id]]=$rs[loc_id];
		}
		$strTemp=implode(",",$arrResult);
		
		$sql=" select loc_id, loc_shortname from location ";
		$sql.=" where loc_id in( $strTemp )";		
		//echo "getLocation2=$sql<br>";
		$result = mysql_query($sql);
		while($rs = mysql_fetch_array($result)){
			$arrResult[$rs[loc_id]]=$rs[loc_shortname];
		}
		$strResult=implode(", ",$arrResult);
		return $strResult;		
	} //if($evnID){
} //function getLocation($evnID){

function updLog($usrLogin, $form, $msg)
{
	$log_ip = $_SERVER["REMOTE_ADDR"];
	//$msg=str_replace("'","",$msg);
	$sql = "insert into logfile values(
		'',now(),
		'$usrLogin',
		'$log_ip',
		'$form',
		\"$msg\"
		)";
	//echo "<br>updLog=$sql<br>" ; //exit();
	mysql_query($sql) or die ("Save logfile error");
}

function genRevenue($evnID,$locID,$revSource,$revType,$begDate,$endDate,$qtyDay,$amtTotal,$amtAdj,$amtNet,$VatInc,$eloc_id)
{
	//$resData=array();
	$query="";	
	$vatrate = 7 ;
	$user_name = $_SESSION["usr_name"];
	$date_name = date("Y/m/d  H:i:s");			
	
	$stDate=conToGregoriantojd($begDate);	
	$enDate=conToGregoriantojd($endDate);
	
	for($i = $stDate ; $i <= $enDate ; $i++){		
		$convDate = jdtogregorian ($i);	// 2011/01/27
		list($intMM,$intDD,$intYY) = explode("/",$convDate);		
		$convDate = chgDateToDb("$intDD/$intMM/$intYY");
					
		$totalPerDay=round($amtTotal / $qtyDay,2) ;
		$adjPerDay=round($amtAdj / $qtyDay,2) ;
		$netPerDay=round($amtNet / $qtyDay,2) ;		
			
		$amtVat=calVat($vatrate,$VatInc,$netPerDay);		
		list($b4vat,$vat,$incvat)=explode(",",implode(",",$amtVat));
		
		$resData["evn_id"] = $evnID;
		$resData["loc_id"] = $locID;
		$resData["rev_date"] = $convDate;
		$resData["rev_source"] = $revSource;
		$resData["rev_type"] = $revType;
		$resData["rev_total"] = $totalPerDay;
		$resData["rev_adj"] = $adjPerDay;
		$resData["rev_net"] = $netPerDay;
		$resData["rev_b4vat"] = $b4vat;
		$resData["rev_vat"] = $vat;
		$resData["rev_incvat"] = $incvat;
		$resData["rev_link"] = $eloc_id;
		$resData["usr_cre"] = $user_name ;
		$resData["date_cre"] = $date_name ;
		
		$query[]= create_insert_query("ev_revenue",$resData);			
		
	} // for($i = $stDate ; $i <= $enDate ; $i++){	
	
	//echo "query= <pre>"; print_r($query); exit();
	return $query;

}//genRevenue

function calVat($VatRate,$VatInc="Y",$amt)
{
	if($VatInc == "Y"){
		$vat = round(($amt / (100 + $VatRate )) * $VatRate,2);
		$b4vat = round($amt - $vat,2) ;
	}
	else {
		$vat = round(($amt / (100 )) * $VatRate,2);
		$b4vat = $amt ;
	}
	$incvat  =  round($b4vat + $vat ,2);	
	
	$arrVal=array($b4vat,$vat,$incvat);		
	return $arrVal;
	
}//function calVat(){

/*
 * Parameter => A julian day number as integer
 * Return => The julian day for the given gregorian date as an integer
 */
function conToGregoriantojd($YYYYMMDD)
{
	$intMM = substr($YYYYMMDD,4,2);
	$intDD = substr($YYYYMMDD,6,2);
	$intYY = substr($YYYYMMDD,0,4);
	$resDate = gregoriantojd($intMM, $intDD, $intYY);
	return $resDate; 
}//function conToGregoriantojd($YYYYMMDD){


/*
 * Parameter => A julian day number as integer
 * Return => The gregorian date as a string in the form "YYYYMMDD"
 */
function conToJdtogregorian($enCodeDate)
{
	$resDate = jdtogregorian($enCodeDate);
	list($intMM,$intDD,$intYY) = explode("/",$resDate);		
	$resDate = chgDateToDb("$intDD/$intMM/$intYY");	
	return $resDate; 
}//function conToJdtogregorian($enCodeDate){

function getMiscodeCus($mis_type)
{ // By Kae
	$sql = "SELECT mis_code , mis_type , mis_tname ";
	$sql .= "FROM miscode_cus ";
	$sql .= "WHERE mis_type = '$mis_type' ";
	$sql .= "ORDER BY mis_code asc  ";
	$result = getData($sql);
	return $result;
}

function db_query($dbtype, $dbname, $sql, $link)
{
	if($dbtype == "mysql"){
		$result=mysql_db_query($dbname,$sql,$link);
	}
	return $result ;
} // end function db_query(){

function fetch_array($dbtype, $result)
{
//echo "\$result=" . $result ;
	if($dbtype == "mysql"){
		$arrResult = mysql_fetch_array($result);
		//print_r($arrResult);
	}
return $arrResult ;
} // end function fetch_array(){

function chgDateToSh($strDate)
{
	//echo "\$strDate=$strDate";
	$false   = array("-", '.');	
	$true = array("/", "/");
	$res = str_replace($false, $true, $strDate);	
	//echo "\$res=$res";
	list($yyyy, $mm, $dd) = explode('/',$res);
	if(strlen($dd) < 2) $dd = '0' . $dd;
	if(strlen($mm) < 2) $mm = '0' . $mm;
	if(strlen($yyyy) < 2) $yyyy = '200' . $yyyy;
	if(strlen($yyyy) < 3) $yyyy = '20' . $yyyy;
    //if(strlen($dd) > 2) $dd = substr($dd , 0 , -(strlen($dd)-2)); // ??????????????????? $dd 
	$res = $yyyy.$mm.$dd;
	$res=$dd."/".$mm."/".$yyyy;
	//echo "\$res=$res";
	Return $res;
}//function chgDateToSh($strDate)


function genEventID($event_date)
{
	//echo "\$event_date= $event_date";
	if (ereg("/" , $event_date )){
		list($dd, $mm, $yyyy) = explode('/',$event_date);
	}else{
		$mm = substr($event_date,4,2);
		$dd = substr($event_date,6,2);
		$yyyy = substr($event_date,0,4);
	}
	
	if(strlen($mm) < 2) $mm = '0' . $mm;
	$yymm = substr($yyyy,2,2).$mm;
	
	$sql = "SELECT MAX(evn_id) as id FROM eventname
				 WHERE evn_id like '$yymm%' ";
	//echo "\$sql=$sql<br>";
	//exit();
	
	$result = getData($sql);
	$row = mysql_fetch_array($result);
	
	//echo $row[0]; echo "<hr>";
	//echo "\$yymm=$yymm<br>";

	if(is_null($row["id"])){
		$evn_id_new =  "$yymm"."0001";
	}else{
		//$evn_id = ($row[0]+1);
		$running = "99".substr($row["id"], 4)+1;
		$evn_id_new = "$yymm".substr($running, 2);
		//echo "runing=$running<br>"; 
	}
	
	return $evn_id_new ;

}

function genID( $field_id , $table_name )
{
	$sql = "SELECT MAX($field_id) as id FROM $table_name ";
	//echo "\$sql= $sql<hr>";
	$result = mysql_query($sql);
	$rs = mysql_fetch_array($result);
	$gen_id = $rs["id"]+1;
	
	return $gen_id ;
}

function updateYear($YYYYMMDD)
{
	$intMM = substr($YYYYMMDD,4,2);
	$intDD = substr($YYYYMMDD,6,2);
	$intYY = date("Y");
	$date = $intYY.$intMM.$intDD ;
	return $date ;
}




function setEvDateblock( $evn_id_new , $arrData )
{
	
	$usr_cre = $_SESSION["usr_name"];
	$date_cre = date("Y/m/d  H:i:s");	
	//$setAllValue = array();
	for( $i=0; $i<sizeof($arrData); $i++ ){
		
		$setValue = array();
		$setValue["evn_id"] = $evn_id_new ;
		$setValue["edbk_item"] = $arrData[$i]["edbk_item"]; ;
		$setValue["edbk_in_date"] = $arrData[$i]["edbk_in_date"];
		$setValue["edbk_in_time"] = $arrData[$i]["edbk_in_time"];
		$setValue["edbk_ev_begdate"] = $arrData[$i]["edbk_ev_begdate"];
		$setValue["edbk_ev_begtime"] = $arrData[$i]["edbk_ev_begtime"];
		$setValue["edbk_ev_enddate"] = $arrData[$i]["edbk_ev_enddate"];
		$setValue["edbk_ev_endtime"] = $arrData[$i]["edbk_ev_endtime"];
		$setValue["edbk_out_date"] = $arrData[$i]["edbk_out_date"]; 
		$setValue["edbk_out_time"] = $arrData[$i]["edbk_out_time"];
		$setValue["loc_id"] = $arrData[$i]["loc_id"];
		$setValue["usr_cre"] = $usr_cre;
		$setValue["date_cre"] = $date_cre ;
		$setValue["usr_upd"] = "";
		$setValue["date_upd"] = "" ;
						  
		
		$setAllValue[] = $setValue ;
	}
	//echo "<pre>"; print_r($setAllValue); echo "<hr>"; exit();
	return $setAllValue ;

}

/*function setEvLocation( $arrData , $loc_id , $fName )
{
	global $setValue;
	
	for( $i=0; $i<sizeof($arrData); $i++ ){
		$edbk_item = $arrData[$i]["edbk_item"];
		$edbk_in_date = $arrData[$i]["edbk_in_date"];
        $edbk_out_date = $arrData[$i]["edbk_out_date"];
        $edbk_ev_begdate = $arrData[$i]["edbk_ev_begdate"];
        $edbk_ev_enddate = $arrData[$i]["edbk_ev_enddate"];
        $edbk_in_time = $arrData[$i]["edbk_in_time"];
        $edbk_out_time = $arrData[$i]["edbk_out_time"];
        $edbk_ev_begtime = $arrData[$i]["edbk_ev_begtime"];
        $edbk_ev_endtime = $arrData[$i]["edbk_ev_endtime"];
        //$loc_id = $arrData[$i]["loc_id"];
		
		$show_qty = calcDays($edbk_ev_begdate,$edbk_ev_enddate)+1 ;
		$in_qty = calcDays($edbk_in_date,$edbk_ev_begdate) ;
		$out_qty = calcDays($edbk_ev_enddate,$edbk_out_date); 
		//$inout_qty = $in_qty + $out_qty ;
		
        $arrLocID = $arrData[$i]["arrLocID"];
		for( $j=0; $j<sizeof($arrLocID); $j++ ){
			if( ereg( $arrLocID[$j] , $loc_id ) ){
			
				switch($fName){
					case "eloc_id" :
						$setValue["eloc_id"] =  genID( "eloc_id" , "ev_location" ) + $i;
						//$setValue["eloc_id"] =  "AAA";
						break;
						
					case "eloc_show_qty" :
						$setValue["eloc_show_qty"] = $show_qty ;
						break;
						
					case "eloc_inout_qty" :
						$setValue["eloc_inout_qty"] = $in_qty ;
						break;
						
					case "eloc_out_qty" :
						$setValue["eloc_out_qty"] = $out_qty ;
						break;
						
					case "eloc_in_date" :
						$setValue["eloc_in_date"] = $edbk_in_date;
						break;
						
					case "eloc_in_time" :
						$setValue["eloc_in_time"] = $edbk_in_time;
						break;
						
					case "eloc_event_date" :
						$setValue["eloc_event_date"] = $edbk_ev_begdate;
						break;
						
					case "eloc_event_time" :
						$setValue["eloc_event_time"] = $edbk_ev_begtime;
						break;
						
					case "eloc_end_date" :
						$setValue["eloc_end_date"] = $edbk_ev_enddate;
						break;
						
					case "eloc_end_time" :
						$setValue["eloc_end_time"] = $edbk_ev_endtime;
						break;
					
					case "eloc_out_date" :
						$setValue["eloc_out_date"] = $edbk_out_date;
						break;
						
					case "eloc_out_time" :
						$setValue["eloc_out_time"] = $edbk_out_time;
						break;
				}
				
			}
		}
	}

}
*/


function getSubRatecodeByLocID( $rtc_id , $loc_id , $field ){
	//show_amt , inout_amt , out_amt
	$sql = "SELECT  $field FROM sub_ratecode ";
	$sql .= " WHERE rtc_id = " . $rtc_id ;
	$sql .= " AND loc_id = " . $loc_id;
	//echo "\$sql= $sql"; //exit();	
	$result = getData($sql);
	$rs = mysql_fetch_array($result);
	$$field = $rs[$field];
	
	return $$field;
}

function setEvLocation( $arrValue , $arrData , $loc_id )
{
	global $setValue;
	
	foreach( $arrValue as $fname => $data ){
		//$setValue[$fName] = $data;
		$rtc_id = $arrValue["rtc_id"];
		
		$show_amt = getSubRatecodeByLocID( $rtc_id , $loc_id , "show_amt" );
		$show_adj = $arrValue["eloc_show_adj"];
		
		$inout_amt = getSubRatecodeByLocID( $rtc_id , $loc_id , "inout_amt" );
		$inout_adj = $arrValue["eloc_inout_adj"];
		
		$out_amt = getSubRatecodeByLocID( $rtc_id , $loc_id , "out_amt" );
		$out_adj = $arrValue["eloc_out_adj"];
		
		
		for( $i=0; $i<sizeof($arrData); $i++ ){
			$edbk_item = $arrData[$i]["edbk_item"];
			$edbk_in_date = $arrData[$i]["edbk_in_date"];
			$edbk_out_date = $arrData[$i]["edbk_out_date"];
			$edbk_ev_begdate = $arrData[$i]["edbk_ev_begdate"];
			$edbk_ev_enddate = $arrData[$i]["edbk_ev_enddate"];
			$edbk_in_time = $arrData[$i]["edbk_in_time"];
			$edbk_out_time = $arrData[$i]["edbk_out_time"];
			$edbk_ev_begtime = $arrData[$i]["edbk_ev_begtime"];
			$edbk_ev_endtime = $arrData[$i]["edbk_ev_endtime"];
			//$loc_id = $arrData[$i]["loc_id"];
			
			$show_qty = calcDays($edbk_ev_begdate,$edbk_ev_enddate)+1 ;
			$in_qty = calcDays($edbk_in_date,$edbk_ev_begdate) ;
			$out_qty = calcDays($edbk_ev_enddate,$edbk_out_date); 
			
			$show_total = $show_qty * $show_amt ;
			$inout_total = $in_qty * $inout_amt ;		
			$out_total = $out_qty * $out_amt ;
			
			$show_net = ( $show_qty * $show_amt ) + $arrValue["eloc_show_adj"] ;
			$inout_net = ( $in_qty * $inout_amt ) + $arrValue["eloc_inout_adj"] ;
			$out_net = ( $out_qty * $out_amt ) + $arrValue["eloc_out_adj"] ;
			
			$g_total = $show_total + $inout_total + $out_total ;
			$g_adjust = $show_adj + $inout_adj + $out_adj ;
			$g_net = $show_net + $inout_net + $out_net ;
			
			//$inout_qty = $in_qty + $out_qty ;
			
			$arrLocID = $arrData[$i]["arrLocID"];
			for( $j=0; $j<sizeof($arrLocID); $j++ ){
				if( ereg( $arrLocID[$j] , $loc_id ) ){
				
				 $setValue["eloc_id"] =  genID( "eloc_id" , "ev_location" ) + $j;
				 $setValue["loc_id"] = $loc_id ;
				 $setValue["eloc_in_date"] = $edbk_in_date;
				 $setValue["eloc_in_time"] = $edbk_in_time;
				 $setValue["eloc_event_date"] = $edbk_ev_begdate;
				 $setValue["eloc_event_time"] = $edbk_ev_begtime;
				 $setValue["eloc_end_date"] =  $edbk_ev_enddate;
				 $setValue["eloc_end_time"] = $edbk_ev_endtime;
				 $setValue["eloc_out_date"] = $edbk_out_date;
				 $setValue["eloc_out_time"] = $edbk_out_time;
				 $setValue["rtc_id"] = $rtc_id ;
				 $setValue["eloc_show_qty"] = $show_qty ;
				 $setValue["eloc_show_amt"] = $show_amt ; 
				 $setValue["eloc_show_total"] = $show_total ;
				 $setValue["eloc_show_adj"] = $show_adj ;
				 $setValue["eloc_show_net"] = $show_net ;
				 $setValue["eloc_inout_qty"] = $in_qty ;
				 $setValue["eloc_inout_amt"] = $inout_amt ;
				 $setValue["eloc_inout_total"] = $inout_total ;
				 $setValue["eloc_inout_adj"] = $inout_adj ;
				 $setValue["eloc_inout_net"] = $inout_net ;
				 $setValue["eloc_out_qty"] = $out_qty ;
				 $setValue["eloc_out_amt"] = $out_amt;
				 $setValue["eloc_out_total"] = $out_total;
				 $setValue["eloc_out_adj"] = $out_adj ;
				 $setValue["eloc_out_net"] = $out_net ;
				 $setValue["eloc_g_total"] = $g_total ;
				 $setValue["eloc_g_adjust"] = $g_adjust ;
				 $setValue["eloc_g_net"] = $g_net;
				 $setValue["eloc_seat_type"] = $arrValue["eloc_seat_type"];
				 $setValue["eloc_room_code"] = $arrValue["eloc_room_code"];
				 $setValue["eloc_atten"] = $arrValue["eloc_atten"];
				 $setValue["eloc_num_session"] = $arrValue["eloc_num_session"];
				 $setValue["eloc_sqm"] = $arrValue["eloc_sqm"];
					
				} // if( ereg( $arrLocID[$j] , $loc_id ) ){
			}// for( $j=0; $j<sizeof($arrLocID); $j++ ){
		}// for( $i=0; $i<sizeof($arrData); $i++ ){
	}

}


function chkFollowDate()
{
	// TODO : แก้ Script Checklist
	#insert default checklist to ev_checklist
	$val_date_cre = date("d/m/Y");	
	list($dd, $mm, $yy) = explode('/',$val_date_cre);
	//$YYYYMMDD = $yy.$mm.$dd ;
	$start_date = date("Ymd", mktime(0, 0, 0, $mm,$dd,$yy));
	//echo "\$YYYYMMDD = $YYYYMMDD"; exit();
	
	$sql = "SELECT * FROM checklist  
				ORDER BY ckl_name
				";
	//echo "$sql<br>";				
	$result = getData($sql);
	$arr_ckl = array();
	$arr_tmp = array();
	while ($rs_ckl = mysql_fetch_array($result)){
		$ckl_id = $rs_ckl["ckl_id"];
		$ckl_name = $rs_ckl["ckl_name"];
		$ckl_val = $rs_ckl["ckl_val"];
		$ckl_cnt_fr  = $rs_ckl["ckl_cnt_fr"];
		
		if ($ckl_cnt_fr == 0 ) {
			$follow_date = date("Ymd", mktime(0, 0, 0, $mm,$dd,$yy)); 
			$d = date("d", mktime(0, 0, 0, $mm,$dd,$yy));
			
			/*echo "\$follow_date= $follow_date"; echo "<br />";
			echo "\$d= $d"; echo "<br />";*/
			
		}
		else {
			$dd = $arr_tmp[$ckl_cnt_fr] + $ckl_val ; 
			$follow_date = date("Ymd", mktime(0, 0, 0, $mm,$dd,$yy));
			$d = date("d", mktime(0, 0, 0, $mm,$dd,$yy));
			
			/*echo "\$dd= $dd"; echo "<br />";
			echo "\$follow_date= $follow_date"; echo "<br />";
			echo "\$d= $d"; echo "<br />";*/
		}  
		
		/*if ($ckl_cnt_fr == 0 ) {
			$follow_date = $YYYYMMDD // $mm,$dd,$yy => 02,03,2011			
			$d = $dd ;
		}
		else {
			$YYYYMMDD = conToGregoriantojd($YYYYMMDD);
	
			$dd = $arr_tmp[$ckl_cnt_fr] + $ckl_val ; 
			$follow_date = date("Ymd", mktime(0, 0, 0, $mm,$dd,$yy));
			$d = date("d", mktime(0, 0, 0, $mm,$dd,$yy));
		}*/  
		
		$arr_ckl[$ckl_id] = $follow_date.",".$ckl_name; 
		$arr_tmp[$ckl_id] = $d; 
		
	} //while ($rs_ckl = mysql_fetch_array($result)){
	for($i=2;$i <= count($arr_ckl);$i++){
		list($eckl_follow_date, $eckl_item) = explode(',',$arr_ckl[$i]);
			$arrFlDate[$eckl_item] = $eckl_follow_date;
	}
	//exit();
	return $arrFlDate;
	
}


function getEventNameAndEventMgr($evn_id , $firstDate="" , $lastDate=""){
	$arrData = array();
	if(!$evn_id) return $arrData;
	$sql = "SELECT evn.evn_id , evn.evn_shortname , "; 
	$sql .= " u.usr_id , u.usr_name , ";
	$sql .= " edbk.edbk_ev_begdate , edbk.edbk_ev_enddate ";
	$sql .= " FROM ev_staff estf , user u , eventname evn , ev_dateblock edbk";
	$sql .= " WHERE evn.evn_id = $evn_id ";
	$sql .= " AND estf.evn_id = evn.evn_id ";
	$sql .= " AND edbk.evn_id = evn.evn_id ";	
	$sql .= " AND u.usr_id = estf.usr_id ";
	$sql .= " AND estf.estf_item = 'Event Manager' ";
	$sql .= " AND edbk.edbk_item = 0 ";
	if($firstDate) $sql .= " AND edbk.edbk_ev_begdate = '$firstDate' ";
	if($firstDate) $sql .= " AND edbk.edbk_ev_enddate = '$lastDate' ";
	//$sql .= " ORDER BY edbk_ev_begdate ASC "  ;
	//echo "\$sql= $sql<br>"; // exit();
	$result = getData($sql);
	while($rs = mysql_fetch_array($result)){
		$arrData["evn_id"] = $rs["evn_id"];
		$arrData["edbk_ev_begdate"] = chgDate($rs["edbk_ev_begdate"]);
		$arrData["edbk_ev_enddate"] = chgDate($rs["edbk_ev_enddate"]);
		$arrData["evn_shortname"] = $rs["evn_shortname"];
		$arrData["usr_name"] = $rs["usr_name"];
	}
	//echo "\$arrData = <pre>" ; print_r($arrData); echo "<hr>";//exit();
	return $arrData;
}


function getCommentByEvnID($evn_id , $strEItem){
	$arrData = array();
	if(!$evn_id) return $arrData;
	$sql = "SELECT * FROM ev_comment WHERE 1=1 ";	
	$sql .= " AND evn_id = $evn_id ";
	if($strEItem <> "'all'" && $strEItem <> "") $sql .= " AND ecmt_item IN( $strEItem ) ";
	$sql .= " ORDER BY ecmt_item ASC ";
	//echo "\$sql= $sql"; exit();
	
	$result = getData($sql);
	$num_row = getNumRow($sql);	
	if($num_row > 0){
	 while($rs = mysql_fetch_array($result)){
		$data["evn_id"]  = $rs["evn_id"];
		$data["ecmt_item"] = $rs["ecmt_item"];
		$data["ecmt_desc"] = $rs["ecmt_desc"];
		$arrData[]= $data;
	 }
	}
	//echo "\$arrData = <pre>" ; print_r($arrData);  exit();
	return $arrData;
}


?>