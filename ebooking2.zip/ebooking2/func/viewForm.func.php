<?	
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	$query = query;
	$table_name = tableName;
	$viewForm = viewForm;
	$updForm = updForm;
	$cap_name = $cap_name;
	$field_id = field_id;
	$beg_id = beg_id;
	$end_id = end_id;	
	$insert = insert;
	$edit = edit;
	$del = del;
	//echo "insert = $insert<br>edit = $edit<br>del = $del<br>";
	
	//$result = getData($query);	
	$result = get_viewForm($query,"","");
	$cnt_fieldname = mysql_num_fields($result);	
	
	
	$totalrecord = mysql_num_rows($result);
	$pagesize = 10;
	$totalpage = ceil($totalrecord/$pagesize);  
	
	if (empty($_REQUEST["pageno"]))
		$pageno =0;
	else
		$pageno = $_REQUEST["pageno"];		
	$pointer = $pageno * $pagesize;
	
	$fieldname = get_table_fieldname($table_name); 
	
	$result = get_viewForm($query,$pointer,$pagesize);	
	$cnt_fieldname = count($fieldname);
	
	//$result = getData($query);	
	//$cnt_fieldname = mysql_num_fields($result);	

	
?>
	
<html>
<head>
<title><?=$viewForm?> </title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">

<style type="text/css">
<!--
.style1 {color: #FFFFFF}
-->
</style>
</head>
<body>
<form name="<?=$viewForm?>" method="post" action="">
  <table border="0" cellpadding="1" cellspacing="1" class="BorderGreen" >
    <tr>
      <td class="mandatory" colspan=<?=$cnt_fieldname + 1?>>	  
		<?
		if($insert==1) 
			echo "<a href=$updForm?a=a><img  src='images/addmaillist.png' width='16' height='16' border='0' alt='Insert'>Insert</a>	";
		?>
	  &nbsp;&nbsp;Result :: <?= $totalrecord ?> &nbsp;records 
	  </td>
    </tr>
    <tr style="background-color: #339900; color: White;">
	 		<td  font-weight:bold;><div align="center">Action</div></td>
	   <?
	 	if($_SESSION["admin"])
			for ($i = $beg_id; $i <$cnt_fieldname; $i++)  
	    {?>
				<td   font-weight:bold;><div align="center" ><?=$cap_name[$i] ?></div></td>			
		<? }		
		
		else
			for ($i = $beg_id; $i <= $end_id; $i++) {
		?>
			 <td  font-weight:bold;><div align="center" ><?=$cap_name[$i] ?></div></td>
		<?
			}
		?>	
		
		 
    </tr>
    <? 
	
	while($row=mysql_fetch_array($result)){ 
  	if ($color == "#F0F0F0")
		$color = "#FFFFFF" ;
	else
		$color = "#F0F0F0" ;
	?>		  
			<tr bgcolor="<?=$color ?>">
					  <td width="6%" > 
					<?
					if($edit==1) 
						echo "<a href=".$updForm."?a=e&id=".$row["$field_id"]."><img src='images/b_edit.png' alt='Edit' border='0'></a>";
						
					if($del==1) 
						echo "<a href=".$updForm."?a=d&id=".$row["$field_id"]."><img src='images/b_drop.png' alt='Delete' border='0'></a>";

				if($_SESSION["admin"]) {					
					for ($i = $beg_id; $i <$cnt_fieldname; $i++) {
						//$Val_len = strlen($row[$i]);
						if ($cap_name[$i]=="pass"){
							echo "<td width = '$Val_len'>".str_repeat("*", strlen($row[$i]))."</td>";											
						}						
						if ($cap_name[$i]=="date"){
							echo "<td width='$Val_len'>".chgDate($row[$i])."</td>";
						}
						if ($cap_name[$i] != "date" && $cap_name[$i] != "pass" ){
							echo "<td width='$Val_len'>" .$row[$i]."</td>";	
						}				
					 } //for ($i = 0; $i <$cnt_fieldname; $i++) {
				 } //if($_SESSION["admin"]) 
				else {
					for ($i = $beg_id; $i <= $end_id; $i++)  {								
						//$Val_len = strlen($row[$i]);
						if ($cap_name[$i]=="pass"){
							echo "<td width='$Val_len'>****</td>";											
						}						
						if ($cap_name[$i]=="date"){
							echo "<td width='$Val_len'>".chgDate($row[$i])."</td>";
						}
						if ($cap_name[$i] != "date" && $cap_name[$i] != "pass" ){
							echo "<td width='$Val_len'>" .$row[$i]."</td>";	
						}				
					} //for ($i = $beg_id; $i <= $end_id; $i++)  {								
				} //else{
				?>	
			</tr>
	
       <? } ?>	   
    <tr style="background-color: #339900; ">
      <td colspan=<?=$cnt_fieldname + 1?>" ><div align="left" class="mandatory style1"  >
        <?	
			//Control botton Prev
			$p =$pageno-1 ;
			if (($p) < 0 ) {
				echo "[".Prev."]";
				}
			else			
				echo "[<a href='$viewForm?pageno=$p&keyword=$keyword'> Prev </a>]";										
			
			for($i=0;$i<$totalpage;$i++)
				if ($i == $pageno)
					echo "[".($i+1)."]";
				else{
					echo "[<a href='$viewForm?pageno=$i&keyword=$keyword'>".($i+1)."</a>]";					
				}
				
			//Control botton Next
			$n = $pageno+1 ;
			if (($n) > $totalpage-1 ){
				$totalpage =  $totalpage - 1;
				echo "[".Next."]";				
			}
			else
				echo "[<a href='$viewForm?pageno=$n&keyword=$keyword'>Next</a>]";			
		  ?>
      </div></td>
    </tr>
  </table>
</form>
