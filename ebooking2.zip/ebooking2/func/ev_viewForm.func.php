<?	
	
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	$sysName = sysName;	 
	$query = query;
	$table_name = tableName;
	$viewForm = viewForm;
	$updForm = updForm;
	$cap_name = $cap_name;
	$field_id = field_id;
	$beg_id = beg_id;
	$end_id = end_id;	
	$insert = insert;
	$edit = edit;
	$del = del;
	//echo "insert = $insert<br>edit = $edit<br>del = $del<br>";
	
	//$result = get_viewForm($table_name,"","");
	//echo "$query<hr>";
	$result = getData($query);
	$cnt_fieldname = mysql_num_fields($result);	
	
	if(!empty($evn_id)){
		$sql = "SELECT * FROM eventname WHERE evn_id = '$evn_id'  ";
		$res = getData($sql);
		$rs = mysql_fetch_array($res);
		$evn_name = $rs[1];
	} //if(!empty($ev_id)){	
		
	
?>
	
<html>
<head>
<title><?=$viewForm?> </title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">

<style type="text/css">
<!--
.style1 {color: #FFFFFF}
-->
</style>
</head>
<body>
<form name="<?=$viewForm?>" method="post" action="">
  <table width="760px" border="0" cellpadding="1" cellspacing="1" class="BorderGreen" >
    <tr>
      <td class="mandatory" colspan=<?=$cnt_fieldname + 1?>><?=$sysName ." - ". $evn_id ." - ". $evn_name ;?>&nbsp;&nbsp;		
		<?
		if($insert==1) 
			echo "<a href=$updForm?a=a&id=".$evn_id."><img  src='images/addmaillist.png' width='16' height='16' border='0' alt='Insert'>Insert</a>
			<div align='right'></div></td>";
		//else
			//echo "Insert $table_name<div align='right'></div></td>";		
		?>
    </tr>
    <tr style="background-color: #339900; color: White;">
	   <?
	 	if($_SESSION["admin"])
			for ($i = 0; $i <$cnt_fieldname; $i++)  
	    {?>
				<td   font-weight:bold;><div align="left" ><?=$cap_name[$i] ?></div></td>			
		<? }		
		
		else
			for ($i = $beg_id; $i <= $end_id; $i++) {
		?>
			 <td  font-weight:bold;><div align="left" ><?=$cap_name[$i] ?></div></td>
		<?
			}
		?>	
		
		  <td  font-weight:bold;><div align="center">Action</div></td>
    </tr>
    <? 
	
	while($row=mysql_fetch_array($result)){ 
  	if ($color == "#F0F0F0")
		$color = "#FFFFFF" ;
	else
		$color = "#F0F0F0" ;
	?>		  
			<tr bgcolor="<?=$color ?>">
				 <?
				if($_SESSION["admin"]) 
					for ($i = 0; $i <$cnt_fieldname; $i++) 
				{?>
						<td ><?= $row[$i] ?></td>
				<? }
				else
					for ($i = $beg_id; $i <= $end_id; $i++)  {
				?>
						<td ><?= $row[$i] ?></td>
				<?
					}
				?>	
					  <td width="6%" > 
					<?

					if($edit==1) 
						echo "<a href=".$updForm."?a=e&id=".$evn_id."&id2=".$row["$field_id"]."><img src='images/b_edit.png' alt='Edit' border='0'></a>";
					//else
						//echo "<img src='images/b_edit.png' alt='' border='0'>";		
						
					if($del==1) 
						echo "<a href=".$updForm."?a=d&id=".$evn_id."&id2=".$row["$field_id"]."><img src='images/b_drop.png' alt='Delete' border='0'></a>";
					//else
						//echo "<img src='images/b_drop.png' alt='ź' border='0'>";		
					?>
			</tr>
	
       <? } ?>

  </table>
</form>
