<?
/******************************************************************

Module Name 	:
Purpose 	:
Description 	:
Author 		: Sergey Suzdalcew

(C) 2003 By Sergey Suzdalcew

********************************************************************/

/*
Function :
Purpose  :
Arguments:
Returns  :
Comments :
*/

function get_user_email()
{
	$user_id = $_SESSION["user_id"];
	$myquery = "SELECT email from T_ACCOUNT where user_id=$user_id";
	$r = mysql_query($myquery);
	if(mysql_num_rows($r)>0)
	{
		$f = mysql_fetch_array($r);
		Return $f["email"];
	}
	return "";
}



/*
Function :
Purpose  :
Arguments:
Returns  :
Comments :
*/

function arr2assoc($array)
{
	foreach($array as $key=>$val)
	{
		$result[$val] = $val;
	}

	Return $result;
}

/*
Function :
Purpose  :
Arguments:
Returns  :
Comments :
*/

function arr2str($array, $separator="&")
{
	foreach($array as $key=>$val)
	{
		$result .= $separator.$key."=".$val;
	}

	Return $result;
}

/*
Function :
Purpose  :
Arguments:
Returns  :
Comments :
*/

function weekday2int($weekday)
{
	$myquery = "select ID from T_WEEK where NAME='$weekday'";
	$r=mysql_query($myquery);
	$f = mysql_fetch_array($r);

	Return $f["ID"];
}

/*
Function :
Purpose  :
Arguments:
Returns  :
Comments :
*/

function get_dict_data($table_name, $id)
{
	$myquery = "SELECT NAME FROM $table_name WHERE id=$id";
	$r = mysql_query($myquery);
	$f = mysql_fetch_array($r);

	Return $f["NAME"];
}

/*
Function :
Purpose  :
Arguments:
Returns  :
Comments :
*/

function get_table_data($table_name, $field_name, $id)
{
	$myquery = "SELECT $field_name FROM $table_name WHERE id=$id";
	$r = mysql_query($myquery);
	$f = mysql_fetch_array($r);

	Return $f[$field_name];
}

/*
Function :	get_calendar_id
Purpose  :	���������� id ��������� ��� �������� ������������
Arguments:
Returns  :	int
Comments :
*/

function get_calendar_id()
{
	$myquery = "SELECT CALENDAR_ID FROM T_ACCOUNT WHERE USER_ID=".$_SESSION["user_id"];
	$r = mysql_query($myquery);
	if($r)
	{
		$f = mysql_fetch_assoc($r);
		if(!isset($f["CALENDAR_ID"]) || empty($f["CALENDAR_ID"])) {
			$f["CALENDAR_ID"] = 0;
		}
		Return $f["CALENDAR_ID"];
	}
}

/*
Function :	get_val_index
Purpose  :	���� value ���� � ������� �� ���������� ��� ������
Arguments:	$array, $value
Returns  :	integer
Comments :
*/

function get_val_index($array, $value)
{
	foreach($array as $key=>$val)
	{
		if($val == $value)
		{
			Return $key;
		}
	}

	Return -1;
}

/*
Function :	trunc_str
Purpose  :
Arguments:
Returns  :
Comments :
*/

function trunc_str($str, $len=1)
{
	$result = substr($str, 0, strlen($str) - $len);

	Return $result;
}

/*
Function :	arr_val2str
Purpose  :	��������� ������ �� �������� ������� � ��������� ��� ��������  �����������
Arguments:	$array = array
(
["key"] = val
),
$separator
Returns  :	string
Comments :
*/

function arr_val2str($array, $separator=",")
{
	$str = "";

	foreach($array as $key=>$val)
	{
		$str .= $val.$separator;
	}

	Return trunc_str($str);
}

function compare_time ($old, $new) {
	if($new == "") {return true; }
	$oldd = explode (":", $old);
	$neww = explode (":", $new);
	$olds = my_strtotime("2002-01-04 $old");
	$news = my_strtotime("2002-01-04 $new");
	if($olds <= $news) { return true;}
}

function id_event_in_day($date, $time = "00:00") {
	$ids = array();
	$date = strftime("%Y-%m-%d",strtotime($date));
	$user_id = $_SESSION["user_id"];
	$calendar_id = $_SESSION["calendar_id"];
	$myquery = "SELECT DISTINCT M.THEME, M.ID, M.DATE, M.TIME, R.END_DATE,R.END_TIME, R.INTERVAL_VAL, R.INTERVAL_TYPE
	FROM T_MEET M LEFT JOIN T_REPEAT R ON (M.REC = '1' AND M.ID = R.MEET_ID)
	WHERE M.USER_ID='$user_id' AND M.CALENDAR_ID='$calendar_id' AND DATE <= '$date' AND (R.END_DATE >='$date' OR R.END_DATE = '0000-00-00') ORDER BY M.TIME LIMIT 0,30";
	$r = mysql_query($myquery);
#	echo mysql_num_rows($r) . " $myquery <BR>";
	$minn = my_strtotime("$date $time");

	while($ff =  mysql_fetch_object($r)) {
#		echo "$date !";
		if ($minn < my_strtotime($ff->DATE)) { break;}
		$thistime = my_strtotime($ff->DATE . " " . $ff->TIME);
		switch ($ff->INTERVAL_TYPE) {
			case '2':	# HOUR	#3600
				if ( $date == $ff->DATE ) { $ids[] = $ff->ID; break;}
				if ( $date == $ff->END_DATE) { $ids[] = $ff->ID; break;}
				$newtime = $thistime + (3600 * $ff->INTERVAL_VAL * intval(($minn - $thistime) / (3600 * $ff->INTERVAL_VAL)));
				$newtime += 3600 * $ff->INTERVAL_VAL;
				if ( strftime("%Y-%m-%d",$newtime) == $date) { $ids[] = $ff->ID; break;}
				break;
			case '3':	# DAY	# 86400
				if ( $date == $ff->DATE ) { $ids[] = $ff->ID; break;}

				$newtime =  $thistime + (86400 * $ff->INTERVAL_VAL * intval(($minn - $thistime) / (86400 * $ff->INTERVAL_VAL)));
				if ( 
					my_d($newtime) == $date && 
					my_strtotime($ff->END_DATE) >= my_strtotime($date) && 
					my_d($newtime) != $ff->END_DATE

					) { $ids[] = $ff->ID; break; }
#				if ( $date == $ff->END_DATE && compare_time ($ff->END_TIME, $ff->TIME) && my_strtotime($ff->END_DATE) > my_strtotime($date)) { $ids[] = $ff->ID; break; }
				if ( $minn <= strtotime($ff->END_DATE) && $date == my_d($newtime) && compare_time ($ff->TIME, $ff->END_TIME) && my_strtotime($ff->END_DATE) >= my_strtotime($date)) { $ids[] = $ff->ID; break; }

				$newtime += 86400 * $ff->INTERVAL_VAL;
#				echo my_strtotime($ff->END_DATE)." >= ".my_strtotime($date)." <BR>";
				if ( 
					my_d($newtime) == $date && 
					my_strtotime($ff->END_DATE) >= my_strtotime($date) && 
					my_d($newtime) != $ff->END_DATE

					) { $ids[] = $ff->ID; break; }
#				if ( $date == $ff->END_DATE && compare_time ($ff->END_TIME, $ff->TIME) && my_strtotime($ff->END_DATE) > my_strtotime($date)) { $ids[] = $ff->ID; break; }
				if ( 
					$minn <= strtotime($ff->END_DATE) &&
					$date == my_d($newtime) && 
					compare_time ($ff->TIME, $ff->END_TIME) && 
					my_strtotime($ff->END_DATE) >= my_strtotime($date)

					) { $ids[] = $ff->ID; break; }

#				echo my_d($newtime) . " $date 2<BR>";
				break;
			case '6':	# WEEK	#604800
				if ( $date == $ff->DATE ) { $ids[] = $ff->ID; break;}

				$newtime =  $thistime + (86400 * 7 * $ff->INTERVAL_VAL * intval(($minn - $thistime) / (86400 * 7 * $ff->INTERVAL_VAL)));
				if ( my_d($newtime) == $date && my_strtotime($ff->END_DATE) >= my_strtotime($date) && my_d($newtime) != $ff->END_DATE) { $ids[] = $ff->ID; break; }
				if ( $minn <= strtotime($ff->END_DATE) && $date == my_d($newtime) && compare_time ($ff->TIME, $ff->END_TIME) && my_strtotime($ff->END_DATE) >= my_strtotime($date)) { $ids[] = $ff->ID; break; }

				$newtime += 86400 * 7 * $ff->INTERVAL_VAL;
				if ( my_d($newtime) == $date && my_strtotime($ff->END_DATE) >= my_strtotime($date) && my_d($newtime) != $ff->END_DATE) { $ids[] = $ff->ID; break; }
				if ( $minn <= strtotime($ff->END_DATE) && $date == my_d($newtime) && compare_time ($ff->TIME, $ff->END_TIME) && my_strtotime($ff->END_DATE) >= my_strtotime($date)) { $ids[] = $ff->ID; break; }

				break;
			case '4':	# MONTH	# fffffffffffff
				if(strftime("%d", $thistime) <= date("t") && my_d($thistime) == my_d($minn)) { $ids[] = $ff->ID; break; }
				
				for ($i = $ff->INTERVAL_VAL; $i > 0; ($i += $ff->INTERVAL_VAL)) {

					if(strftime("%d", $thistime) > 28) {
						$newtime = mktime ( date("G",$thistime), date("i",$thistime), date("s", $thistime) , (date("n", $thistime) + $i), date("j",$thistime) - 3 , date("Y",$thistime));
					} else {
						$newtime = mktime ( date("G",$thistime), date("i",$thistime), date("s", $thistime) , (date("n", $thistime) + $i), date("j",$thistime), date("Y",$thistime));
					}

#					echo my_d($newtime) . " " . my_d($minn) . "<BR>";
					if(my_d($newtime) == my_d($minn) && strftime("%d", $minn) == strftime("%d",$thistime)) { $ids[] = $ff->ID; break 2; }

					$lastday = date("t", $newtime);
					if ( 
						strftime("%Y-%m",$newtime) == strftime("%Y-%m",$minn) && 
						strftime("%d",$minn) >= $lastday &&
						strftime("%d",$thistime) == strftime("%d",$minn)) {
								
						$ids[]  = $ff->ID;
						break 2;
					} elseif (
						strftime("%Y-%m",$newtime) == strftime("%Y-%m",$minn) && 
						strftime("%d",$minn) == $lastday && strftime("%d", $thistime) > $lastday) {

						$ids[]  = $ff->ID;
						break 2;
					}
					if($minn < $newtime) { break;}
				}
				break;
			case '5':	# YEAR	#
				if(strftime("%d", $thistime) <= date("t") && my_d($thistime) == my_d($minn)) { $ids[] = $ff->ID; break; }
				for ($i = $ff->INTERVAL_VAL; $i > 0; ($i += $ff->INTERVAL_VAL)) {

					if(strftime("%d", $thistime) > 28) {
						$newtime = mktime ( date("G",$thistime), date("i",$thistime), date("s", $thistime) , date("n", $thistime), date("j",$thistime) - 3 , (date("Y",$thistime) + $i));
					} else {
						$newtime = mktime ( date("G",$thistime), date("i",$thistime), date("s", $thistime) , date("n", $thistime), date("j",$thistime), (date("Y",$thistime) + $i));
					}

					if(my_d($newtime) == my_d($minn) && strftime("%d", $minn) == strftime("%d",$thistime)) { $ids[] = $ff->ID; break 2; }

					$lastday = date("t", $newtime);
					if ( 
						strftime("%Y-%m",$newtime) == strftime("%Y-%m",$minn) && 
						strftime("%d",$minn) >= $lastday &&
						strftime("%d",$thistime) == strftime("%d",$minn)) {
								
						$ids[]  = $ff->ID;
						break 2;
					} elseif (
						strftime("%Y-%m",$newtime) == strftime("%Y-%m",$minn) && 
						strftime("%d",$minn) == $lastday && strftime("%d", $thistime) > $lastday) {

						$ids[]  = $ff->ID;
						break 2;
					}
					if($minn < $newtime) { break;}
				}
				break;
		}

	}
#	echo "<BR>$date<BR>"; print_r($ids);
	Return $ids;
}


?>