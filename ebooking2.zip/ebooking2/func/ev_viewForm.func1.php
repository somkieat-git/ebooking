<?	
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	$sysName = sysName;	 
	$query = query;
	$table_name = tableName;
	$viewForm = viewForm;
	$updForm = updForm;
	$addForm = addForm;
	$cap_name = $cap_name;
	$field_id = field_id;
	$beg_id = beg_id;
	$end_id = end_id;	
	$insert = insert;
	$edit = edit;
	$del = del;
	//echo "insert = $insert<br>edit = $edit<br>del = $del<br>";
	
	//echo "$query<hr>";
	//exit();
	$result = getData($query);	
	$cnt_fieldname = mysql_num_fields($result);	
	
	if(!empty($evn_id)){
		$sql = "SELECT * FROM eventname WHERE evn_id = '$evn_id'  ";
		$res = getData($sql);
		$rs = mysql_fetch_array($res);
		$evn_name = $rs["evn_shortname"];
	} //if(!empty($ev_id)){	
	//echo "\$evn_name=$evn_name<br>";
	
?>
	
<html>
<head>
<title><?=$viewForm?> </title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">

<style type="text/css">
<!--
.style1 {color: #FFFFFF}
-->
</style>
</head>
<body>
<form name="<?=$viewForm?>" method="post" action="">
  <table border="0" cellpadding="1" cellspacing="1" class="BorderGreen" >
    <tr>
	
      <td class="mandatory" colspan='1'>
	  
		<?
		if($insert==1) {
			if($addForm) {
				echo "<a href=$addForm?a=a&id=".$evn_id."><img  src='images/addmaillist.png' width='16' height='16' border='0' alt='Insert'>Insert</a></td>";
			}
			else{
				echo "<a href=$updForm?a=a&id=".$evn_id."><img  src='images/addmaillist.png' width='16' height='16' border='0' alt='Insert'>Insert</a></td>";
			}
		} //if($insert==1) {
		?>
	  <td class="mandatory" colspan=<?=$cnt_fieldname - 1?>><div align="center">
	  &nbsp;&nbsp;<?=$sysName ." - ". $evn_id ." - ". $evn_name ;?>
	  </div></td>
	  
    </tr>
    <tr style="background-color: #339900; color: White;">
	<td  font-weight:bold;><div align="center">Action</div></td>
	   <?
	   #show caption
	 	if($_SESSION["admin"]){
			for ($i = $beg_id; $i <$cnt_fieldname; $i++)  
			echo "<td font-weight:bold;><div align='left'>".$cap_name[$i]."</div></td>";
		}
		else{
			for ($i = $beg_id; $i <= $end_id; $i++)
			echo "<td font-weight:bold;><div align='left'>".$cap_name[$i]."</div></td>";
		}
		echo "</tr>";		
		
		while($row=mysql_fetch_array($result)){ 
		if ($color == "#F0F0F0")
			$color = "#FFFFFF" ;
		else
			$color = "#F0F0F0" ;			
				
			echo "<tr bgcolor=".$color."><td width='4%' ><div align='center'>";

			if($edit==1) 
				echo "<a href=".$updForm."?a=e&id=".$evn_id."&id2=".$row["$field_id"]."><img src='images/b_edit.png' alt='Edit' border='0'></a>";
				
			if($del==1)
				echo "<a href=".$updForm."?a=d&id=".$evn_id."&id2=".$row["$field_id"]."><img src='images/b_drop.png' alt='Delete' border='0'></a></div>";
		
			#show value
			if($_SESSION["admin"]) {
				for ($i = $beg_id; $i <$cnt_fieldname; $i++) {
					$field_name = mysql_field_name($result, $i );
					$showVal = $row[$i];
					if (substr($field_name,- 4)=="date"){
						if ($showVal)
							$showVal = chgDate($row[$i]); 
					}
					if (substr($field_name,- 4)=="time"){
						if ($showVal)
							$showVal = chgTime($row[$i]); 
					}													
					if (substr($field_name,-7) == "_loc_id"){
						if ($showVal){
							$sql = "SELECT loc.loc_shortname FROM location loc WHERE loc.loc_id = $showVal ";
							$rs_loc = getResult($sql,"");
							$showVal = $rs_loc["loc_shortname"]; 
						} //if ($showVal){
					}	//if (substr($field_name,-6) == "loc_id"){
					if (substr($field_name,-7) == "_dep_id"){
						if ($showVal){
							$sql = "SELECT dep_name FROM department WHERE dep_id = $showVal ";
							$rs_dep = getResult($sql,"");
							$showVal = $rs_dep["dep_name"]; 
						} //if ($showVal){
					}	//if (substr($field_name,-6) == "loc_id"){					
					if (substr($field_name,-6) == "_total" || substr($field_name,-7) == "_adjust" || 
						substr($field_name,-4) == "_net" || substr($field_name,-4) == "_qty" || 
						substr($field_name,-4) == "_day" || substr($field_name,-4) == "_amt" || 
						substr($field_name,-4) == "_adj" || substr($field_name,-3) == "vat"){
							$showVal = '<div align="right">'.chgNumber($showVal).'</div>'; 													
					}	
					echo "<td>".nl2br($showVal)."</td>";
				} //for ($i = 0; $i <$cnt_fieldname; $i++) {
			} //if($_SESSION["admin"]) {
			
			else{
				for ($i = $beg_id; $i <= $end_id; $i++)  {
					$field_name = mysql_field_name($result, $i);
					$showVal = $row[$i];
					if (substr($field_name,- 4)=="date"){
						if ($showVal)
							$showVal = chgDate($row[$i]); 
					}
					if (substr($field_name,- 4)=="time"){
						if ($showVal)
							$showVal = chgTime($row[$i]); 
					}					
					if (substr($field_name,-7) == "_loc_id"){
						if ($showVal){
							$sql = "SELECT loc.loc_shortname FROM location loc WHERE loc.loc_id = $showVal ";
							$rs_loc = getResult($sql,"");
							$showVal = $rs_loc["loc_shortname"]; 
						} //if ($showVal){
					}	//if (substr($field_name,-6) == "loc_id"){
					if (substr($field_name,-7) == "_dep_id"){
						if ($showVal){
							$sql = "SELECT dep_name FROM department WHERE dep_id = $showVal ";
							$rs_dep = getResult($sql,"");
							$showVal = $rs_dep["dep_name"]; 
						} //if ($showVal){
					}	//if (substr($field_name,-6) == "loc_id"){
					if (substr($field_name,-6) == "_total" || substr($field_name,-7) == "_adjust" || 
						substr($field_name,-4) == "_net" || substr($field_name,-4) == "_qty" || 
						substr($field_name,-4) == "_day" || substr($field_name,-4) == "_amt" || 
						substr($field_name,-4) == "_adj" || substr($field_name,-3) == "vat"){
							$showVal = '<div align="right">'.chgNumber($showVal).'</div>'; 													
					}						
					echo "<td>".nl2br($showVal)."</td>";
				} //for ($i = $beg_id; $i <= $end_id; $i++)  {
			} //else{
			echo "</tr>";
   		 }  //while($row=mysql_fetch_array($result)){  
		 ?>
  </table>
</form>
