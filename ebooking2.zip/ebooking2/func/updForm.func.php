<?	
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	$viewForm = viewForm;
	$updSave = updSave;	
	$table_name = tableName;
	$menuName = menuName;
	$field_id = field_id;	
	$action = action;
	$id = id;
	$beg_id = beg_id;
	$end_id = end_id;
//	echo "table_name = $table_name<br>field_id = $field_id<br> action = $action<br>id = $id<br>beg_id = $beg_id<br>end_id = $end_id<br>";
	
	if ($action == "a"){
		$caption = "Insert  "  ;
		$button = "Save";
	}
	if ($action == "e"){
		$caption = "Edit  "  ;
		$button = "Update";
	}
	if ($action == "d"){
		$caption = "Delete  "  ;
		$button = "Delete";
	}
	if(!empty($id)){
		$result = get_updForm($table_name,$field_id,$id);	
		$row=mysql_fetch_array($result);
	}
		$fieldname = get_table_fieldname($table_name); 
		$cnt_fieldname = count($fieldname);
		
?>
<html>
<head>
<title>updForm => <?=$table_name?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">
<!--<script language="javascript" type="text/javascript" src="datetimepicker.js"></script>-->

<!--------------  jQuery Datepick (Popup Calendra)  ---------------------->
	
	<link href="./css/jquery.datepick.css" type="text/css" rel="stylesheet" />
	<script type="text/javascript" src="lib/jquery.min.js"></script>	
	<script type="text/javascript" src="js/jquery.datepick.js"></script>
	<script type="text/javascript">
	$(function() {
		jQuery('#beg_date').datepick({showOnFocus: false,  yearRange: 'c-10:c+10' , showTrigger: '#calImg'});
		jQuery('#end_date').datepick({showOnFocus: false,  yearRange: 'c-10:c+10' , showTrigger: '#calImg'});
	});
	</script>



</head>
	
<body>
<form action="<?=$updSave ?>?id=<?=$id?>" method="post" name="frm"  id="frm"  onSubmit="return validate() ;">
  <table border="0" class="BorderGreen">
    <tr class="BorderSilver">
      <td colspan="2" style="background-color:#339900;font-weight:bold;color:White;"><div align="center"><strong ><?=$caption.$menuName ?></strong></div></td>
    </tr>
	<tr><td colspan="2" >&nbsp;</td></tr>
	<?	for ($i = $beg_id; $i <= $end_id; $i++) {?>	
		<tr>
		  <td ><div align="right"><span >
	      <?=$cap_name[$i] ?> : 
	      </span></div></td>
		  <td>
		  <?
		  	if ($fieldname[$i]=="usr_sec" ){
				$sql = "SELECT sec_id, sec_name FROM security ORDER BY sec_name ";
				//echo "$sql";
				$res = getData($sql);
				echo "<select name=".$fieldname[$i] ." id=". $fieldname[$i] .">";
			 	while($rs_sec = mysql_fetch_array($res)){
					echo "<option value = '".$rs_sec[0] ."'" ; 
					if ($row[$i] == $rs_sec[0] ) echo " selected " ;
					echo " > ". $rs_sec[1]." </option>";
				}
				echo "</select>";
			} //if ($fieldname[$i]=="usr_sec" ){
			
		  	if ($fieldname[$i]=="esv_dept" ){
				$sql = "SELECT dep_id, dep_name FROM department ORDER BY dep_name ";
				//echo "$sql";
				$res = getData($sql);
				echo "<select name=".$fieldname[$i] ." id=". $fieldname[$i] .">";
			 	while($rs_dep = mysql_fetch_array($res)){
					echo "<option value = '".$rs_dep["dep_id"] ."'" ; 
					if ($row[$i] == $rs_dep["dep_id"] ) echo " selected " ;
					echo " > ". $rs_dep["dep_name"]." </option>";
				} //while($rs_dep = mysql_fetch_array($res)){
				echo "</select>";
			} //if ($fieldname[$i]=="esv_dept" ){
			
		  	if ($fieldname[$i]=="stt_id" ){
				$sql = "SELECT stt_id, stt_name FROM settle_cat ORDER BY stt_name ";
				//echo "$sql";
				$res = getData($sql);
				echo "<select name=".$fieldname[$i] ." id=". $fieldname[$i] .">";
			 	while($rs_stt = mysql_fetch_array($res)){
					echo "<option value = '".$rs_stt["stt_id"] ."'" ; 
					if ($row[$i] == $rs_stt["stt_id"] ) echo " selected " ;
					echo " > ". $rs_stt["stt_name"]." </option>";
				} //while($rs_stt = mysql_fetch_array($res)){
				echo "</select>";
			} //if ($fieldname[$i]=="stt_id" ){
			
		  	if ($fieldname[$i]=="esv_status" ){
				echo "<select name=".$fieldname[$i] ." id=". $fieldname[$i] .">";
					echo "<option value = 'E' " ; 
					if ($row[$i] == "E" ) echo " selected " ;
					echo " > E  </option>";
					echo "<option value = 'F' " ; 
					if ($row[$i] == "F" ) echo " selected " ;
					echo " > F  </option>";
					echo "</select>";
				} //if ($fieldname[$i]=="esv_status" ){				
		  	
		  	if ($fieldname[$i]=="esv_include_vat" ){
				echo "<select name=".$fieldname[$i] ." id=". $fieldname[$i] .">";
					echo "<option value = 'Y' " ; 
					if ($row[$i] == "Y" ) echo " selected " ;
					echo " > Y  </option>";
					echo "<option value = 'N' " ; 
					if ($row[$i] == "N" ) echo " selected " ;
					echo " > N  </option>";
					echo "</select>";
				} //if ($fieldname[$i]=="esv_include_vat" ){
			
		  	if ($fieldname[$i]=="lgp_id" ){
				$sql = "SELECT lgp_id, lgp_name FROM location_group ORDER BY lgp_name ";
				//echo "$sql";
				$res = getData($sql);
				echo "<select name=".$fieldname[$i] ." id=". $fieldname[$i] .">";
			 	while($rs_lgp = mysql_fetch_array($res)){
					echo "<option value = '".$rs_lgp["lgp_id"] ."'" ; 
					if ($row[$i] == $rs_lgp["lgp_id"] ) echo " selected " ;
					echo " > ". $rs_lgp["lgp_name"]." </option>";
				} //while($rs_stt = mysql_fetch_array($res)){
				echo "</select>";
			} //if ($fieldname[$i]=="lgp_id" ){
			
		  	if ($fieldname[$i]=="ckl_cnt_fr" ){
				$sql = "SELECT ckl_id, ckl_name FROM checklist ORDER BY ckl_name ";
				//echo "$sql";
				$res = getData($sql);
				echo "<select name=".$fieldname[$i] ." id=". $fieldname[$i] .">";
			 	while($rs_lgp = mysql_fetch_array($res)){
					echo "<option value = '".$rs_lgp["ckl_id"] ."'" ; 
					if ($row[$i] == $rs_lgp["ckl_id"] ) echo " selected " ;
					echo " > ". $rs_lgp["ckl_name"]." </option>";
				} //while($rs_stt = mysql_fetch_array($res)){
				echo "</select>";
			} //if ($fieldname[$i]=="lgp_id" ){
			
			if($fieldname[$i] != "usr_sec" && $fieldname[$i] != "esv_dept" && $fieldname[$i] != "stt_id" &&  $fieldname[$i] != "esv_status"  && $fieldname[$i] !="esv_include_vat" && $fieldname[$i] != "lgp_id" && $fieldname[$i] != "ckl_cnt_fr" ){			
					$showVal = $row[$i] ;
					$link = "";
					if (substr($fieldname[$i],- 4) == "date"){
						?>
						<script type="text/javascript">
						   $(function() {
							jQuery('#<?=$fieldname[$i]?>').datepick({showOnFocus: false,  yearRange: 'c-10:c+10' , showTrigger: '#calImg'});
						   });
						  </script>
						<?php
						if($showVal)
							$showVal = chgDate($row[$i]) ; 							
						$link = " <div style=\"display: none;\"> ";
						$link .= "<img id=\"calImg\" src=\"images/calendar.gif\" alt=\"Pick a date\" class=\"trigger\">";
						$link .= "</div>";
					}
					if (substr($fieldname[$i],- 4)=="time"){
						$showVal = chgTime($row[$i]); 
					}			
		  ?>		  
		  <input name = <?=$fieldname[$i] ?>  size = "<?=strlen($showVal) ?>" 
			type = <? if($fieldname[$i] == "usr_pass") echo "password" ; else echo "text" 	?> 		
			id = <?=$fieldname[$i]?> value="<?=$showVal?>">
			<? if($link) echo $link ?>
		  </td>  			
		</tr>
	<?
	} //if($fieldname[$i] != "usr_sec" && $fieldname[$i] != "esv_dept" && $fieldname[$i] != "stt_id" &&  $fieldname[$i] != "esv_status"  ){			
		} //for ($i = 1; $i < $cnt_fieldname; $i++)
	?>	
	
	
    <tr align="center" >
      <td colspan="2">
	  <?
	  if($action=="e"  ){
	  ?>
	  <a href="javascript:del('<?=$updSave?>?a=d&id=<?=$id ?>');"><img src='images/b_drop.png' alt='Delete' border='0'></a>	  	
	  <?
	   } //if($action!="e"  ){
	  ?>
	  	<input name="Submit" type="submit" class="Button" value="<?=$button?>" >
		<input name="Button" type="button" class="Button"  
		onClick= "return cancel('<?=$viewForm?>') ;" 
		value="Cancel" >      
		<input name="<?= $field_id ?>" type="hidden" id="<?=$field_id ?>" value="<? if (!empty($id)) echo $row["$field_id"]?>">
	   <input name="a" type="hidden" id="action" value="<?=$action ?>">
</td>
    </tr>
  </table>
</form>
<script language="javascript">
	function cancel(val) 
	{
		//alert(val);
		window.open(val,"frame_details");
	}
	
	function del(val) 
	{
		window.open(val,"frame_details");		
	}
</script>
