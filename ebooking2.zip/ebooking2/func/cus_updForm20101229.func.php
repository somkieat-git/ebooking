<?
ob_start();
session_start();
/*include_once("db/connect.db.php");
include_once("func/sql.func.php");*/

//$usr_id = usr_id;
//$usr_login = usr_login ;
$user_login = user_login;
$viewForm = viewForm;
$updSave = updSave;
$table_name = tableName;
$menuName = menuName;
$field_id = field_id;
$action = action;
$id = id;
$beg_id = beg_id;
$end_id = end_id;
$add_size = 10 ;
$limitSize = 20;
$pro_source =  strtoupper(prefix) ;
$lang = $_SESSION["lang"] ;


//echo "table_name = $table_name<br>field_id = $field_id<br> action = $action<br>id = $id<br>beg_id = $beg_id<br>end_id = $end_id<br>";




// Query Question  //
$arrQuestion = array();
$sql = " SELECT que_id, que_tname, que_ename ";
$sql .= " FROM question ";
$sql .= " WHERE que_show = 1 ";
if($ugrp_view != "*") {
    $sql .= " AND que_type = 'default' ";
    $sql .= " OR que_type = 'public'";
}
if($ugrp_view && $ugrp_view != "*") {
    $arrTemp = explode(",",$ugrp_view);
    foreach($arrTemp as $key => $val) {
        $sql .=" OR que_type =  '$val' " ;
    } //foreach($arrTemp as $key => $val){
}  //if($ugrp_view){
$sql .= " ORDER BY que_seq, que_id ";
//echo "$sql<hr>";
$rstQue = mysql_query($sql) or die(mysql_error()) ;
while($rsQue = mysql_fetch_array($rstQue)) {
    $que_id = $rsQue["que_id"];
    $lang == 'th' ? $name = $rsQue["que_tname"] : $name = $rsQue["que_ename"];
    $arrQuestion[$que_id] = $name;
} //while($rsQue = fetch_array($dbtype, $rstQue)){
//echo "\$arrQuestion=";print_r($arrQuestion);echo "<hr>";



// Query Choice  //
$arrChoice = array();
$sql = " SELECT que_id, cho_id, cho_tname, cho_ename ";
$sql .= " FROM choice ";
$sql .= " WHERE cho_show = 1 ";
$sql .= " ORDER BY que_id, cho_seq, cho_id ";
//echo "$sql<hr>";
$rstCho = mysql_query($sql) or die(mysql_error()) ;
while($rsCho = mysql_fetch_array($rstCho)) {
    $que_id = $rsCho["que_id"];
    $cho_id = $rsCho["cho_id"];
    $lang == 'th' ? $name = $rsCho["cho_tname"] : $rsCho["cho_ename"];
    $arrChoice[$que_id][$cho_id] = $name;
} //while($rsQue = fetch_array($dbtype, $rstQue)){
//echo "\$arrChoice=<br>";print_r($arrChoice);echo "<hr>";



$action == "d" ? $disabled = "disabled" : $disabled = "" ;
//echo "\$action=$action";
//echo "\$disabled=$disabled";

if ($action == "a") {
    $caption = "Insert  "  ;
    $button = "Save";
    $pro_country = 'ประเทศไทย';
}
if ($action == "e") {
    $caption = "Edit  "  ;
    $button = "Update";
}
if ($action == "d") {
    $caption = "Delete  "  ;
    $button = "Delete";
}


if(!empty($id)) {
    $result = get_updForm($table_name,$field_id,$id);
    $row=mysql_fetch_array($result);
    //$pro_code = $row["pro_code"];
    $create = "Create by : ".$row["usr_cre"]." date : ".($row["date_cre"]);
    $update = "Update by : ".$row["usr_upd"]." date : ".($row["date_upd"]);
}
$fieldname = get_table_fieldname($table_name);
$cnt_fieldname = count($fieldname);





//echo $pro_source;
//echo $result;
//echo "<pre>";
//print_r($fieldname);
//echo "</pre>";
//echo $row["pro_code"];
//echo "<pre>";
//print_r($fieldname);
//echo "</pre>";
//echo $fieldname[2];
//echo strlen($row["pro_code"]);


//exit();


?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" >
    <head>
        <title>updForm => <?=$table_name?></title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <!--<meta name="keywords" content="jquery, form, sliding, usability, css3, validation, javascript"/>-->


        <!---------------------------  jQuery Library  --------------------------->

        <script type="text/javascript" src="lib/jquery.min.js"></script>
        <script type="text/javascript" src="lib/jquery-1.4.4.js"></script>
		<script type="text/javascript" src="lib/encode.url.js"></script>



        <!---------------------------  jQuery Tab Slide  --------------------------->
        <link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
        <script type="text/javascript" src="js/sliding.form.js"></script>



        <!-----------------  jQuery Datepick (Popup Calendra)  ----------------------->

        <link href="css/jquery.datepick.css" type="text/css" rel="stylesheet" />
        <script type="text/javascript" src="js/jquery.datepick.js"></script>
        <script type="text/javascript" src="js/datepick.js"></script>


        <!-----------------  Javascript In page  ----------------------->
        <script type="text/javascript" src="js/cus_updfrm.chk.js"></script>
		
  </head>
    <style>
        span.reference{
            position:fixed;
            left:5px;
            top:5px;
            font-size:10px;
            text-shadow:1px 1px 1px #fff;
        }
        span.reference a{
            color:#555;
            text-decoration:none;
            text-transform:uppercase;
        }
        span.reference a:hover{
            color:#000;

        }
        h1{
            color:#ccc;
            font-size:36px;
            text-shadow:1px 1px 1px #fff;
            padding:20px;
        }
    </style>
    <body>
	<div id="div_body">
        <div id="content">
            <h2><?php echo $caption.$menuName; ?></h2>
            <div id="wrapper">
                <div id="navigation" style="display:none;">
                    <ul>
                        <li class="selected">
                            <a href="#">ข้อมูลบริษัท</a>
                        </li>
                        <li>
                            <a href="#">Company Profile</a>
                        </li>
                        <li>
                            <a href="#">ข้อมูลลูกค้า / Contact Profile</a>
                        </li>
                        <li>
                            <a href="#">รายละเอียดเพิ่มเติม</a>
                        </li>
                    </ul>
                </div>
                <div id="steps">
                    <form action="<?=$updSave ?>?id=<?=$id?>" method="post" name="frm"  id="frm"  onSubmit="return validate() ;">
                        <fieldset class="step">
                            <legend>ข้อมูลบริษัท</legend>
                            <input name="hddAction" type="hidden" id="hddAction" value="<?=$action;?>">

                            <p>
                                <label for="pro_code">หมายเลข : </label>
                                <?php
                                //$size_code = strlen($pro_code)+ $add_size;
                                $action != "a" ? $pro_code = $row["pro_code"] : $pro_code = '*** New ***';
                                ?>
                                <input type="text" name="pro_code" id="pro_code" size="15" value="<?php echo $pro_code; ?>" disabled/>
                                <input type="hidden" id="pro_code" name="pro_code" value="<?php echo $row["pro_code"]; ?>" />
                                <input name="pro_lang" type="hidden" id="pro_lang" value="<?php echo $row["pro_lang"]; ?>" >
                            </p>
                            <p>
                                <label for="pro_default">ที่อยู่หลัก : </label>
                                <?php
                                if( $row["pro_default"] == 0 ) {
                                    $checked1 = "checked";
                                    $checked2 = "";
                                }else {
                                    $checked1 = "";
                                    $checked2 = "checked";
                                }

                                //echo "\$row[\"pro_default\"] = " . $row["pro_default"];
                                //echo "$checked1 = " . $checked1 ;
                                //echo "$checked2 = " . $checked2 ;
                                ?>

                                <input name="pro_default" id="pro_default" type="radio" value="0" <?php echo $checked1; ?> <?php echo $disabled ; ?>>
                                <span class="text_detail">ภาษาไทย</span>
                                <input name="pro_default" id="pro_default" type="radio" value="1" <?php echo $checked2; ?> <?php echo $disabled ; ?>>
                                <span class="text_detail">English</span>
                            </p>
                            <p>
                                <label for="pro_mailAd">สถานที่ี่ติดต่อ : </label>
                                <?php
                                if( $row["pro_mailAd"] == 2 ) {
                                    $checked1 = "";
                                    $checked2 = "";
                                    $checked3 = "checked";
                                }else if( $row["pro_mailAd"] == 1 ) {
                                    $checked1 = "";
                                    $checked2 = "checked";
                                    $checked3 = "";
                                }else {
                                    $checked1 = "checked";
                                    $checked2 = "";
                                    $checked3 = "";
                                }
                                ?>
                                <input name="pro_mailAd" type="radio" value="0" <?php echo $checked1; ?> <?php echo $disabled ; ?>>
                                <span class="text_detail">ไม่ระบุ</span>
                                <input name="pro_mailAd" type="radio" value="1" <?php echo $checked2; ?> <?php echo $disabled ; ?>>
                                <span class="text_detail">ที่บ้าน</span>
                                <input name="pro_mailAd" type="radio" value="2" <?php echo $checked3; ?> <?php echo $disabled ; ?>>
                                <span class="text_detail">ที่ทำงาน</span>
                            </p>
                            <p>
                                <label for="pro_tprefix">คำนำหน้า - ชื่อบริษัท - คำลงท้าย : </label>
                                <?php
                                //$size_tprefix = strlen($row["pro_tprefix"])+ $add_size;
                                //$size_tcname = strlen($row["pro_tcname"])+ 2;
                                //$size_tsuffix = strlen($row["pro_tsuffix"])+ $add_size;
                                ?>
         <input type="text" name="pro_tprefix" id="pro_tprefix" size="10" value="<?php echo $row["pro_tprefix"]; ?>" <?php echo $disabled ; ?> /> - 
		 <input type="text" name="pro_tcname" id="pro_tcname" size="20" value="<?php echo $row["pro_tcname"]; ?>" <?php echo $disabled ; ?>/> - 
		 <input type="text" name="pro_tsuffix" id="pro_tsuffix" size="10" value="<?php echo $row["pro_tsuffix"]; ?>" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <label for="pro_com_regis">วันที่จัดตั้งบริษัท : </label>
                                <?
                                if ($action <> "a") {
                                    $ComRegis = $row["pro_com_regis"];
                                    $ComRegis <> "0000-00-00" ? $ComRegis = chgDateToSh($ComRegis) : $ComRegis = "" ;
                                } //if ($action <> "a"){
                                ?>
                                <?
                                if($action == "v") {
                                    $readonly = "readonly = 'true' ";
                                } //if($action == "v"){
                                //echo "\$ComRegis=$ComRegis";
                                ?>

                                <?php //echo "\$ComRegis=" . $ComRegis ; ?>
                                <input type="text" name="pro_com_regis" id="pro_com_regis_th" size="10" onFocus="javascript:frm.pro_com_regis_en.value=this.value;" value="<?php echo $ComRegis ; ?>" <?php echo $disabled ; ?>/>
							</p>
							
                            <p></p>
                            <legend>ที่อยู่บริษัท</legend>
                            <p>
                                <label for="pro_taddress1">เลขที่ : </label>
                                <?php
                                $size_taddress1 = strlen($row["pro_taddress1"])+ $add_size;
                                ?>
                                <input type="text" name="pro_taddress1" id="pro_taddress1" size="<?php echo $size_taddress1 ;?>" value="<?php echo $row["pro_taddress1"]?>" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <label for="pro_taddress2">อาคาร/หมู่บ้าน : <br /><span style="color:#FF0000;font-weight:bold;">( *ระบุ อาคาร/หมู่บ้าน )</span></label>
                                <?php
                                $size_taddress2 = strlen($row["pro_taddress2"])+ $add_size;
                                ?>
                                <input type="text" name="pro_taddress2" id="pro_taddress2" size="<?php echo $size_taddress2 ;?>" value="<?php echo $row["pro_taddress2"]?>" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <label for="pro_tsoi">ตรอก/ซอย : <br /><span style="color:#FF0000;font-weight:bold;">( *ระบุ ตรอก/ซอย )</span></label>
                                <?php
                                $size_tsoi = strlen($row["pro_tsoi"])+ $add_size;
                                ?>
                                <input type="text" name="pro_tsoi" id="pro_tsoi" size="<?php echo $size_tsoi ;?>" value="<?php echo $row["pro_tsoi"]?>" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <label for="pro_troad">ถนน : <br /><span style="color:#FF0000;font-weight:bold;">( *ระบุ ถนน )</span></label>
                                <?php
                                $size_troad = strlen($row["pro_troad"])+ $add_size;
                                ?>
                                <input type="text" name="pro_troad" id="pro_troad" size="<?php echo $size_troad ;?>" value="<?php echo $row["pro_troad"]?>" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <label for="pro_ttambol">แขวง/ตำบล : </label>
                                <?php
                                $size_ttambol = strlen($row["pro_ttambol"]) + $addSize ;
                                $size_ttambol < $limitSize ? $size_ttambol = $limitSize : 0 ;
                                ?>
								<input name="pro_ttambol" type="text" id="pro_ttambol"  size="<?php echo $size_ttambol;?>" value="<?php echo $row["pro_ttambol"]; ?>" onKeyPress="btnEnable()" <?php echo $disabled ; ?>/>
                                <?php if($action != "d"): ?>
                                <input type="button" value="..." onClick="javascript:BrowseAddress('pro_ttambol','add_ttambol','th');btnEnable();" />
                                <?php endif; ?>
                            </p>
                            <p>
                                <label for="pro_tdistrict">เขต/อำเภอ : </label>
                                <?php
                                $size_tdistrict = strlen($row["pro_tdistrict"]) + $addSize ;
                                $size_tdistrict < $limitSize ? $size_tdistrict = $limitSize : 0 ;
                                ?>
                                <input name="pro_tdistrict" type="text" id="pro_tdistrict"  size="<?php echo $size_tdistrict;?>" value="<?php echo $row["pro_tdistrict"]; ?>" onKeyPress="btnEnable()" <?php echo $disabled ; ?>/>
                                <?php if($action != "d"): ?>
                                <input type="button" value="..." onClick="javascript:BrowseAddress('pro_tdistrict','add_tdistrict','th');btnEnable();" />
                                <?php endif; ?>
                            </p>
                            <p>
                                <label for="pro_tprovince">จังหวัด : </label>
                                <?php
                                $size_tprovince = strlen($row["pro_tprovince"]) + $addSize ;
                                ?>
                                <input type="text" name="pro_tprovince" id="pro_tprovince" size="<?php echo $size_tprovince; ?>" value="<?php echo $row["pro_tprovince"]; ?>" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <label for="pro_tcountry">ประเทศ : </label>
                                <?php
                                $size_tcountry = strlen($row["pro_tcountry"]) + $addSize ;
                                ?>
                                <input type="text" name="pro_tcountry" id="pro_tcountry" size="<?php echo $size_tcountry; ?>" value="<?php echo $row["pro_tcountry"]; ?>" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <label for="pro_tpostcode">รหัสไปรษณีย์ : </label>
                                <?php
                                $size_tpostcode = strlen($row["pro_tpostcode"]) + $addSize ;
                                ?>
                                <input type="text" name="pro_tpostcode" id="pro_tpostcode" size="<?php echo $size_tpostcode; ?>" value="<?php echo $row["pro_tpostcode"]; ?>" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <label for="pro_ttel">โทรศัพท์</label>
                                <?php
                                $size_ttel = strlen($row["pro_ttel"]) + $addSize ;
                                ?>
                                <input type="text" name="pro_ttel" id="pro_ttel" size="<?php echo $size_ttel; ?>" value="<?php echo $row["pro_ttel"]; ?>" onFocus="javascript:getIt(this,'t')" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <label for="pro_tfax">โทรสาร</label>
                                <?php
                                $size_tfax = strlen($row["pro_tfax"]) + $addSize ;
                                ?>
                                <input type="text" name="pro_tfax" id="pro_tfax" size="<?php echo $size_tfax; ?>" value="<?php echo $row["pro_tfax"]; ?>" onFocus="javascript:getIt(this,'t')" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <?php
                                $row["pro_reject"] == "1" ? $checked = "checked" : $checked = "";
                                ?>
                                <label for="">   </label>
                                <input name="pro_reject" id="pro_reject" type="checkbox" value="1" <?php echo $checked; ?> <?php echo $disabled ; ?>/>
                                <span style="color:#FF0000; font-weight:bold;" >ยกเลิกการส่งไปรษณีย์ (Reject mail)</span>
                            </p>
                        </fieldset>
                        <fieldset class="step">
                            <legend>Company Profile</legend>
                            <p>
                                <label for="pro_eprefix">Prefix - Company : </label>
                                <?php
                                $size_eprefix = strlen($row["pro_eprefix"])+ $add_size;
                                //$size_tcname = strlen($row["pro_tcname"])+ 2;
                                ?>
                                <input type="text" name="pro_eprefix" id="pro_eprefix" size="<?php echo $size_eprefix; ?>" value="<?php echo $row["pro_eprefix"]; ?>" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <label for="pro_tcname">Company Name : </label>
                                <input type="text" name="pro_ecname" id="proetcname" size="40" value="<?php echo $row["pro_ecname"]; ?>" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <label for="pro_tsuffix">Suffix - Company : </label>
                                <?php
                                $size_esuffix = strlen($row["pro_esuffix"])+ $add_size;
                                ?>
                                <input type="text" name="pro_esuffix" id="pro_esuffix" size="<?php echo $size_esuffix; ?>" value="<?php echo $row["pro_esuffix"]; ?>" <?php echo $disabled ; ?>/>
                            </p>
							<p>
								<label for="pro_com_regis">Registration Date : </label>
								
								 <input type="text" name="pro_com_regis" id="pro_com_regis_en" size="10" onFocus="javascript:frm.pro_com_regis_th.value=this.value;" value="<?php echo $ComRegis ; ?>" <?php echo $disabled ; ?>/>
								 
                            </p>
                            <p></p>
                            <legend>Company Address</legend>
                            <p>
                                <label for="pro_eaddress1">No. : </label>
                                <?php
                                $size_eaddress1 = strlen($row["pro_eaddress1"])+ $add_size;
                                ?>
                                <input type="text" name="pro_eaddress1" id="pro_eaddress1" size="<?php echo $size_eaddress1 ;?>" value="<?php echo $row["pro_eaddress1"]?>" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <label for="pro_eaddress2">Tower/Village : <br /><span style="color:#FF0000; font-weight:bold;">( *Specific Tower/Village )</span></label>
                                <?php
                                $size_eaddress2 = strlen($row["pro_eaddress2"])+ $add_size;
                                ?>
                                <input type="text" name="pro_eaddress2" id="pro_eaddress2" size="<?php echo $size_eaddress2 ;?>" value="<?php echo $row["pro_eaddress2"]?>" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <label for="pro_esoi">Soi : <br /><span style="color:#FF0000; font-weight:bold;">( *Specific Soi )</span></label>
                                <?php
                                $size_esoi = strlen($row["pro_esoi"])+ $add_size;
                                ?>
                                <input type="text" name="pro_esoi" id="pro_esoi" size="<?php echo $size_esoi ;?>" value="<?php echo $row["pro_esoi"]?>" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <label for="pro_eroad">Road : <br /><span style="color:#FF0000; font-weight:bold;">( *Specific Road )</span></label>
                                <?php
                                $size_eroad = strlen($row["pro_eroad"])+ $add_size;
                                ?>
                                <input type="text" name="pro_eroad" id="pro_eroad" size="<?php echo $size_eroad ;?>" value="<?php echo $row["pro_eroad"]?>" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <label for="pro_etambol">Tambol : </label>
                                <?php
                                $size_etambol = strlen($row["pro_etambol"]) + $addSize ;
                                $size_etambol < $limitSize ? $size_etambol = $limitSize : 0 ;
                                ?>
                                <input name="pro_etambol" type="text" id="pro_etambol"  size="<?php echo $size_etambol;?>" value="<?php echo $row["pro_etambol"]; ?>" onKeyPress="btnEnable()" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <label for="pro_edistrict">District : </label>
                                <?php
                                $size_edistrict = strlen($row["pro_edistrict"]) + $addSize ;
                                $size_edistrict < $limitSize ? $size_edistrict = $limitSize : 0 ;
                                ?>
                                <input name="pro_edistrict" type="text" id="pro_edistrict"  size="<?php echo $size_edistrict;?>" value="<?php echo $row["pro_edistrict"]; ?>" onKeyPress="btnEnable()" <?php echo $disabled ; ?> />
                            </p>
                            <p>
                                <label for="pro_eprovince">Province : </label>
                                <?php
                                $size_eprovince = strlen($row["pro_eprovince"]) + $addSize ;
                                ?>
                                <input type="text" name="pro_eprovince" id="pro_eprovince" size="<?php echo $size_eprovince; ?>" value="<?php echo $row["pro_eprovince"]; ?>" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <label for="pro_ecountry">Country : </label>
                                <?php
                                $size_ecountry = strlen($row["pro_ecountry"]) + $addSize ;
                                ?>
                                <input type="text" name="pro_ecountry" id="pro_ecountry" size="<?php echo $size_ecountry; ?>" value="<?php echo $row["pro_ecountry"]; ?>" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <label for="pro_epostcode">Postcode : </label>
                                <?php
                                $size_epostcode = strlen($row["pro_epostcode"]) + $addSize ;
                                ?>
                                <input type="text" name="pro_epostcode" id="pro_epostcode" size="<?php echo $size_epostcode; ?>" value="<?php echo $row["pro_epostcode"]; ?>" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <label for="pro_etel">Telephone : </label>
                                <?php
                                $size_etel = strlen($row["pro_etel"]) + $addSize ;
                                ?>
                                <input type="text" name="pro_etel" id="pro_etel" size="<?php echo $size_etel; ?>" value="<?php echo $row["pro_etel"]; ?>" onFocus="javascript:getIt(this,'t')" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <label for="pro_efax">Fax : </label>
                                <?php
                                $size_efax = strlen($row["pro_efax"]) + $addSize ;
                                ?>
                                <input type="text" name="pro_efax" id="pro_efax" size="<?php echo $size_efax; ?>" value="<?php echo $row["pro_efax"]; ?>" onFocus="javascript:getIt(this,'t')" <?php echo $disabled ; ?>/>
                            </p>
                        </fieldset>
                        <fieldset class="step">
                            <legend>ข้อมูลลูกค้า / Contact Profile</legend>
                            <p>
                                <label for="pro_ttitle">คำนำหน้า - ชื่อ-นามสกุล : </label>
                                <?php
                                //$size_title = strlen($row["pro_ttitle"])+ $add_size;
                                //$size_tfname = strlen($row["pro_tfname"])+ $add_size;
                                //$size_tlname = strlen($row["pro_tlname"])+ $add_size;
                                ?>
                                <input type="text" name="pro_ttitle" id="pro_ttitle" size="10" value="<?php echo $row["pro_ttitle"]; ?>" <?php echo $disabled ; ?>/> - <input type="text" name="pro_tfname" id="pro_tfname" size="15" value="<?php echo $row["pro_tfname"]; ?>" <?php echo $disabled ; ?>/>-
                                <input type="text" name="pro_tlname" id="pro_tlname" size="15" value="<?php echo $row["pro_tlname"]; ?>" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <label for="pro_etitle">Title - First-Last Name : </label>
                                <?php
                                //$size_eitle = strlen($row["pro_etitle"])+ $add_size;
                                //$size_efname = strlen($row["pro_efname"])+ $add_size;
                                //$size_elname = strlen($row["pro_elname"])+ $add_size;
                                ?>
                                <input type="text" name="pro_etitle" id="pro_etitle" size="10" value="<?php echo $row["pro_etitle"]; ?>" <?php echo $disabled ; ?>/>-
                                <input type="text" name="pro_efname" id="pro_efname" size="15" value="<?php echo $row["pro_efname"]; ?>" <?php echo $disabled ; ?>/>-
                                <input type="text" name="pro_elname" id="pro_elname" size="15" value="<?php echo $row["pro_elname"]; ?>" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <label for="pro_tdept">แผนก : </label>
                                <?php
                                //$pro_tdept = $row["pro_tdept"];
                                //$size_tdept = strlen($pro_tdept) + $addSize ;
                                //$size_tdept < $limitSize ? $size_tdept = $limitSize : 0 ;
                                ?>
                                <input type="text" name="pro_tdept" id="pro_tdept" size="15" value="<?php echo $row["pro_tdept"]; ?>" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <label for="pro_edept">Division / Department : </label>
                                <?php
                                //$pro_edept = $row["pro_edept"];
                                //$size_edept = strlen($pro_edept) + $addSize ;
                                //$size_edept < $limitSize ? $size_edept = $limitSize : 0 ;
                                ?>
                                <input type="text" name="pro_edept" id="pro_edept" size="15" value="<?php echo $row["pro_edept"]; ?>" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <label for="pro_tposition">ตำแหน่ง : </label>
                                <?php
                                //$pro_tposition = $row["pro_tposition"];
                                //$size_tposition = strlen($pro_tposition) + $addSize ;
                                //$size_tposition < $limitSize ? $size_tposition = $limitSize : 0 ;
                                ?>
                                <input type="text" name="pro_tposition" id="pro_tposition" size="15" value="<?php echo $row["pro_tposition"]; ?>" <?php echo $disabled ; ?> />
                            </p>							 
                            <p>
                                <label for="pro_eposition">Position : </label>
                                <?php
                                //$pro_eposition = $row["pro_eposition"];
                                //$size_eposition = strlen($pro_eposition) + $addSize ;
                                //$size_eposition < $limitSize ? $size_eposition = $limitSize : 0 ;
                                ?>
                                <input type="text" name="pro_eposition" id="pro_eposition" size="15" value="<?php echo $row["pro_eposition"]; ?>" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <label for="pro_mobile">มือถือ : </label>
                                <input type="text" name="pro_mobile" id="pro_mobile" value="<?php echo $row["pro_mobile"] ; ?>" onFocus="javascript:getIt(this,'m')" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <label for="pro_website">Web Site : </label>
                                <?php
                                $size_website = strlen($row["pro_website"]) + $add_size;
                                ?>
                                <input type="text" name="pro_website" id="pro_website" size="<?php echo $size_website;?>" value="<?php echo $row["pro_website"] ; ?>" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <label for="pro_email1">E-Mail #1: </label>
                                <?php
                                $size_email1 = strlen($row["pro_email1"]) + $add_size;
                                ?>
                                <input type="text" name="pro_email1" id="pro_email1" size="<?php echo $size_email1;?>" value="<?php echo $row["pro_email1"] ; ?>" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <label for="pro_email2">E-Mail #2: </label>
                                <?php
                                $size_email2 = strlen($row["pro_email2"]) + $add_size;
                                ?>
                                <input type="text" name="pro_email2" id="pro_email2" size="<?php echo $size_email2;?>" value="<?php echo $row["pro_email2"] ; ?>" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <label for="pro_birthdate">วัน/เดือน/ปี เกิด : </label>
                                <?
                                if ($action <> "a") {
                                    $BirthDate = $row["pro_birthdate"];
                                    //$pro_lang =  $row["pro_lang"];
                                    list($y,$m,$d) = explode("-",$BirthDate);
									//echo "\$d=$d || \$m=$m || \$y=$y" ;
                                    $yearNow = date("Y");
                                    $y <> 0 ? $Age = birthday($BirthDate) : $Age = "-";
                                    $BirthDate <> "0000-00-00" ? $BirthDate = chgDateToSh($BirthDate) : $BirthDate = "" ;
                                } //if ($action <> "a"){
                                ?>
                                <?
                                if($action == "d") {
                                    $readonly = "readonly = 'true' ";
                                } //if($action == "v"){
                                ?>
                                <input type="text" name="pro_birthdate" id="pro_birthdate" value="<?php echo $BirthDate ; ?>" <?php echo $disabled ; ?> <?php echo $readonly ; ?>/>
                            </p>
                            <p>
                                <label for="txtAge">อายุ : </label>
                                <input name="txtAge" id="txtAge"  type="text" value="<?=$Age; ?>" size="2" <?php echo $disabled ; ?> readonly >&nbsp; ปี
                            </p>
                            <p>
                                <label for="pro_sex">เพศ : </label>
                                <?php
                                if( $row["pro_sex"] == 2 ) {
                                    $checked1 = "";
                                    $checked2 = "";
                                    $checked3 = "checked";
                                }else if( $row["pro_sex"] == 1 ) {
                                    $checked1 = "";
                                    $checked2 = "checked";
                                    $checked3 = "";
                                }else {
                                    $checked1 = "checked";
                                    $checked2 = "";
                                    $checked3 = "";
                                }
                                ?>
                                <input name="pro_sex" id="pro_sex" type="radio" value="0" <?php echo $checked1; ?> <?php echo $disabled ; ?> />
                                <span class="text_detail">ไม่ระบุ</span>
                                <input name="pro_sex" id="pro_sex" type="radio" value="1" <?php echo $checked2; ?> <?php echo $disabled ; ?> />
                                <span class="text_detail">ชาย</span>
                                <input name="pro_sex" id="pro_sex" type="radio" value="2" <?php echo $checked3; ?> <?php echo $disabled ; ?> />
                                <span class="text_detail">หญิง</span>
                            </p>
                            <p>
                                <label for="pro_national">สัญชาติ : </label>
                                <?php
                                $size_national = strlen($row["pro_national"]) + $add_size;
                                ?>
                                <input type="text" name="pro_national" id="pro_national" size="<?php echo $size_national;?>" value="<?php echo $row["pro_national"] ; ?>" <?php echo $disabled ; ?>/>
                            </p>
                            <p>
                                <label for="pro_marital">สถานภาพสมรส : </label>
                                <?php $result_mis = getMiscodeCus('marital'); ?>
                                <select name="pro_marital" id="pro_marital" onClick="btnEnable()" <?php echo $disabled ; ?>>
                                    <?php while( $rw = mysql_fetch_array($result_mis) ):?>
                                        <?php $row["pro_marital"] == $rw["mis_code"] ? $selected = "selected" : $selected = ""; ?>
                                    <option value="<?php echo $rw["mis_code"]; ?>" <?php echo $selected ; ?>><?php echo $rw["mis_tname"]; ?></option>
                                    <?php endwhile;?>
                                </select>
                            </p>
                            <p>
                                <label for="">หมายเหตุ : </label>
                                <textarea name="pro_remark"  id="pro_remark" cols="60" rows="5" onKeyPress="btnEnable()" <?php echo $disabled ; ?>><?php echo $row["pro_remark"];?></textarea>
                            </p>
                        </fieldset>
                        <fieldset class="step">
                            <legend>รายละเอียดเพิ่มเติม</legend>
                            <p>
                                <label for="">อาชีพ : </label>
                                <?php $result_mis = getMiscodeCus('occupation'); ?>
                                <select name="pro_occupation" id="pro_occupation" onClick="btnEnable()" onChange="javascript:displayOccCm(this.value , '<?php echo $row["pro_occupatCm"]; ?>');" <?php echo $disabled ; ?>>
                                    <?php while( $rw = mysql_fetch_array($result_mis) ):?>
                                        <?php $row["pro_occupation"] == $rw["mis_code"] ? $selected = "selected" : $selected = ""; ?>
                                    <option value="<?php echo $rw["mis_code"]; ?>" <?php echo $selected ; ?>><?php echo $rw["mis_tname"]; ?></option>
                                    <?php endwhile;?>
                                </select> 
                                <span id="div_occ_cm" style="display:none;">
								<input type="text" name="pro_occupatCm" id="pro_occupatCm" value="<?php echo $row["pro_occupatCm"]; ?>" <?php echo $disabled ; ?> />
								</span>
                        	</p>
                            <p>
                                <label for="">การศึกษา : </label>
                                <?php $result_mis = getMiscodeCus('education'); ?>
                                <select name="pro_education" id="pro_education" onClick="btnEnable()" <?php echo $disabled ; ?> >
                                    <?php while( $rw = mysql_fetch_array($result_mis) ):?>
                                        <?php $row["pro_education"] == $rw["mis_code"] ? $selected = "selected" : $selected = ""; ?>
                                    <option value="<?php echo $rw["mis_code"]; ?>" <?php echo $selected ; ?>><?php echo $rw["mis_tname"]; ?></option>
                                    <?php endwhile;?>
                                </select>
                            </p>
                            <p>
                                <label for="name">แหล่งที่มา :</label>
                                <?php
                                $size_source = strlen($row["pro_source"]);
                                //$action != "a" ? $pro_source = $row["pro_source"] : $pro_source = $ugrp_add ;
                                //echo $pro_source ;
                                ?>
                                <input type="text" name="pro_source" id="pro_source" size="<?php echo $size_source ; ?>" value="<?php echo $pro_source; ?>" disabled />
                                <input type="hidden" name="pro_source" id="pro_source" value="<?php echo $pro_source; ?>" />
                                <?php //echo "<br />".$create."&nbsp;&nbsp;&nbsp;".$update ?>
                            </p>
                            <?php
							$arrQKey = array();
							$arrComment = array();
                            $pro_id = $row["pro_id"];
                            $arrAnswer = array();
                            $sql = " SELECT ans_id, pro_id, que_id, cho_id, ans_comment ";
                            $sql .= " FROM answer ";
                            $pro_id ? $sql .= " WHERE pro_id = $pro_id": $sql .= " WHERE 1 = 0 ";
                            $sql .= " ORDER BY que_id, cho_id ";
                            //echo "$sql<hr>";
                            $rstAns = db_query($dbtype, $dbname, $sql, $link);
                            while($rsAns = fetch_array($dbtype, $rstAns)) {
                                $ans_id = $rsAns["ans_id"];
                                $que_id = $rsAns["que_id"];
                                $cho_id = $rsAns["cho_id"];
                                $ans_comment = $rsAns["ans_comment"];
                                $arrAnswer[$que_id] = array($ans_id,$cho_id,$ans_comment);
                            }
                            ?>
                            <?php  foreach( $arrQuestion as $qKey => $qVal ): ?>
                                <?php  if( $qKey <> 1 ): ?>
                                    <?php	$ans_id = $arrAnswer[$qKey][0];	?>
									<?php	$ans_comment = $arrAnswer[$qKey][2];	?>
                            <p>
                                <label for="name" style="font-size:11px;"><?php echo $qVal ;?> : </label>

                                        <?php $fieldName = $ans_id."_".$pro_id."_".$qKey ; ?>
                                <select name="<?php echo $fieldName; ?>" id="<?php echo $fieldName; ?>" <?php echo $disabled ; ?> onChange="javascript:displayChoice(this.value , '<?php echo $qKey; ?>' , '<?php echo $ans_comment ; ?>' );">

                                            <?php foreach($arrChoice[$qKey] as $cKey => $cVal): ?>
                                                <?php $ans_cho_id = $arrAnswer[$qKey][1]; ?>
                                                <?php $cKey == $ans_cho_id ? $selected = "selected" : $selected = ""; ?>
                                    <option value="<?php echo $cKey; ?>" <?php echo $selected ;?>><?php echo $cVal ;?></option>
                                            <?php endforeach; //foreach($arrChoice[$qKey] as $cKey => $cVal){?>
                                </select>
					
							<span id="txt<?php echo $qKey; ?>" style="display:none;" >								
								<input type="text" name="ans_comments[<?php echo $qKey; ?>]" id="ans_comments[<?php echo $qKey; ?>]" value="<?php echo $ans_comment ; ?>" <?php echo $disabled ; ?> />
							</span>
								<?php $arrQKey[] = $qKey ;
								      $arrComment[] = $ans_comment ; 
								?>
								<input name="hddFieldsName2[]" type="hidden" id="hddFieldsName2[]" value="<?php echo $fieldName; ?>" />
                            </p>
							
                                <?php endif; //if( $qKey <> 1 ):?>
                            <?php  endforeach; //foreach( $arrQuestion as $qKey => $qVal ): ?>
							<?php 
								$hddqKey = implode("|" , $arrQKey);
								$hddComment = implode("|" , $arrComment);
							?>
					<input name="hddqKey" type="hidden" id="hddqKey" value="<?php echo $hddqKey; ?>" />
					<input name="hddComment" type="hidden" id="hddComment" value="<?php echo $hddComment; ?>" />
					         <p class="submit">
							<?php $action == "d" ? $onclick = "onClick=\"return Conf(this);\"" : $onclick = "" ;?>
							<table align="center" border="0">
								<tr>
									<td>
							    <input name="Submit" id="btnSubmit" type="submit" class="Button" <?php echo $onclick ; ?> value="<?=$button?>" >
								<input name="<?= $field_id ?>" type="hidden" id="<?=$field_id ?>" value="<? if (!empty($id)) echo $row["$field_id"]?>">
                    <input name="a" type="hidden" id="action" value="<?=$action ?>">
					<input name="usr_cre" type="hidden" id="usr_cre" value="<?php echo $row["usr_cre"]; ?>">
					<input name="date_cre" type="hidden" id="date_cre" value="<?php echo $row["date_cre"]; ?>">
									</td>
									<td>
									<input id="back" type="button" class="Button" onClick="javascript:window.location.href='flexigrid/cus_vfrm.php';" value="Cancel" />
									</td>
								</tr>
							</table>
						    </p>
                        </fieldset>
                    </form>
                </div>                
            </div>
        </div>
	</div>
