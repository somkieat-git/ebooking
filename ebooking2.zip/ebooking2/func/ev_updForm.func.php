<?	
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	$viewForm = viewForm;
	$prevForm = prevForm;
	$nextForm = nextForm;
	$updSave = updSave;	
	$table_name = tableName;
	$menuName = menuName;
	$field_id = field_id;	
	$id = id;
	$id2 = id2;
	$action = action;
	$beg_id = beg_id;
	$end_id = end_id;
//	echo "table_name = $table_name<br>field_id = $field_id<br> action = $action<br>id = $id<br>beg_id = $beg_id<br>end_id = $end_id<br>";
	
	if ($action == "a"){
		$caption = "Insert  "  ;
		$button = "Save";
	}
	if ($action == "e"){
		$caption = "Edit  "  ;
		$button = "Update";
	}
	if ($action == "d"){
		$caption = "Delete  "  ;
		$button = "Delete";
	}
	if(!empty($id2)){	
		$result = get_ev_updForm($table_name,$field_id,$id2,$id);	
		$row=mysql_fetch_array($result);
	}
		$fieldname = get_table_fieldname($table_name); 
		$cnt_fieldname = count($fieldname);
		
		$sql = "SELECT * FROM eventname WHERE evn_id = '$id'  ";
		//echo "\$sql=$sql<br>";
		$res_evn = getData($sql);
		$rs_evn = mysql_fetch_array($res_evn);
		$disabled = "";
		//if($rs_evn[3] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;		
		if($rs_evn["evn_used"] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;			
		$evn_name = $rs_evn["evn_thainame"];		
		//echo "\$disabled =$disabled<br>";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>updForm => <?=$table_name?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">
<script language="javascript" type="text/javascript" src="datetimepicker.js"></script>
<!--------------  jQuery Datepick (Popup Calendra)  ---------------------->
	
	<link href="./css/jquery.datepick.css" type="text/css" rel="stylesheet" />
	<script type="text/javascript" src="lib/jquery.min.js"></script>	
	<script type="text/javascript" src="js/jquery.datepick.js"></script>
	<script type="text/javascript">
	$(function() {
		//jQuery('#txtFrdate').datepick();
		jQuery('#eckl_follow_date').datepick({showOnFocus: false , yearRange: 'c-10:c+10' , showTrigger: '#calImg'});
		jQuery('#eckl_complete_date').datepick({showOnFocus: false , yearRange: 'c-10:c+10' , showTrigger: '#calImg'});

	});
	</script>

</head>
	
<body>
<form action="<?=$updSave ?>?id=<?=$id?>&id2=<?=$id2?>" method="post" name="frm"  id="frm"  onSubmit="return validate() ;">
  <table border="0" class="BorderGreen">
    <tr class="BorderSilver">
      <td colspan="2" style="background-color:#339900;font-weight:bold;color:White;"><div align="center"><strong ><?=$caption.$menuName ?></strong></div></td>
    </tr>
	<tr><td colspan="2" >&nbsp;</td></tr>
	<?	for ($i = $beg_id; $i <= $end_id; $i++) {?>	
		<tr>
		  <td ><div align="right"><span >
	      <?=$cap_name[$i] ?> : 
	      </span></div></td>
		  <td>
		  <?
		  	if ($fieldname[$i]=="usr_sec" ){
				$sql = "SELECT sec_id, sec_name FROM security ORDER BY sec_name ";
				echo "$sql";
				$res = getData($sql);
				echo "<select name=".$fieldname[$i] ." id=". $fieldname[$i] .">";
			 	while($rs_sec = mysql_fetch_array($res)){
					echo "<option value = '".$rs_sec["sec_id"] ."'" ; 
					if ($row[$i] == $rs_sec["sec_id"] ) echo " selected " ;
					echo " > ". $rs_sec["sec_name"]." </option>";
				}
				echo "</select>";
			} //if ($fieldname[$i]=="usr_sec" ){
			
		  	if ($fieldname[$i]=="esv_dept" ){
				$sql = "SELECT dep_id, dep_name FROM department ORDER BY dep_name ";
				//echo "$sql";
				$res = getData($sql);
				echo "<select name=".$fieldname[$i] ." id=". $fieldname[$i] .">";
			 	while($rs_dep = mysql_fetch_array($res)){
					echo "<option value = '".$rs_dep["dep_id"] ."'" ; 
					if ($row[$i] == $rs_dep["dep_id"] ) echo " selected " ;
					echo " > ". $rs_dep["dep_name"]." </option>";
				} //while($rs_dep = mysql_fetch_array($res)){
				echo "</select>";
			} //if ($fieldname[$i]=="esv_dept" ){
			
		  	if ($fieldname[$i]=="stt_id" ){
				$sql = "SELECT stt_id, stt_name FROM settle_cat ORDER BY stt_name ";
				//echo "$sql";
				$res = getData($sql);
				echo "<select name=".$fieldname[$i] ." id=". $fieldname[$i] .">";
			 	while($rs_stt = mysql_fetch_array($res)){
					echo "<option value = '".$rs_stt["stt_id"] ."'" ; 
					if ($row[$i] == $rs_stt["stt_id"] ) echo " selected " ;
					echo " > ". $rs_stt["stt_name"]." </option>";
				} //while($rs_stt = mysql_fetch_array($res)){
				echo "</select>";
			} //if ($fieldname[$i]=="stt_id" ){
			
		  	if ($fieldname[$i]=="esv_status" ){
				echo "<select name=".$fieldname[$i] ." id=". $fieldname[$i] .">";
					echo "<option value = 'E' " ; 
					if ($row[$i] == "E" ) echo " selected " ;
					echo " > E  </option>";
					echo "<option value = 'F' " ; 
					if ($row[$i] == "F" ) echo " selected " ;
					echo " > F  </option>";
					echo "</select>";
				} //if ($fieldname[$i]=="esv_status" ){				
		  	
		  	if ($fieldname[$i]=="lgp_id" ){
				$sql = "SELECT lgp_id, lgp_name FROM location_group ORDER BY lgp_name ";
				//echo "$sql";
				$res = getData($sql);
				echo "<select name=".$fieldname[$i] ." id=". $fieldname[$i] .">";
			 	while($rs_lgp = mysql_fetch_array($res)){
					echo "<option value = '".$rs_lgp["lgp_id"] ."'" ; 
					if ($row[$i] == $rs_lgp["lgp_id"] ) echo " selected " ;
					echo " > ". $rs_lgp["lgp_name"]." </option>";
				} //while($rs_stt = mysql_fetch_array($res)){
				echo "</select>";
			} //if ($fieldname[$i]=="lgp_id" ){
			
		  	if ($fieldname[$i]=="eckl_fperson" ){
				$sql = "SELECT usr_id, usr_name FROM user 
				WHERE usr_used = 'Y'
				ORDER BY usr_name ";
				//echo "$sql";
				$res = getData($sql);
				echo "<select name=".$fieldname[$i] ." id=". $fieldname[$i] .">";
			 	while($rs_loc = mysql_fetch_array($res)){
					echo "<option value = '".$rs_loc["usr_name"] ."'" ; 
					if ($row[$i] == $rs_loc["usr_name"] ) echo " selected " ; if($action == "a" && $rs_loc["usr_name"] == "Not Assign" ) echo " selected" ;
					echo " > ". $rs_loc["usr_name"]." </option>";
				} //while($rs_loc = mysql_fetch_array($res)){
				echo "</select>";
			} //if ($fieldname[$i]=="lgp_id" ){
			
			if($fieldname[$i] != "usr_sec" && $fieldname[$i] != "esv_dept" && $fieldname[$i] != "stt_id" &&  $fieldname[$i] != "esv_status"  && $fieldname[$i] != "lgp_id" && $fieldname[$i] != "eckl_fperson" ){			
					$showVal = $row[$i] ;
					$link = "";
					if (substr($fieldname[$i],- 4) == "date"){
						
						if($showVal)
							$showVal = chgDate($row[$i]) ; 
						/*$link = "<a href = \"javascript:NewCal('$fieldname[$i]' ,'ddmmyyyy' ,false, 12 ) \">";
						$link .= "<img src = 'images/cal.gif' width = '16' height = '16' border='0' alt = 'Pick a date' ></a> ";*/
						$link = "<div style=\"display: none;\">";
						$link .= "<img id=\"calImg\" src=\"images/calendar.gif\" alt=\"Pick a date\" class=\"trigger\">";
						$link .= "</div>";
					}
					if (substr($fieldname[$i],- 4)=="time"){
						$showVal = chgTime($row[$i]); 
					}			
		  ?>		  
	  	  <input name = <?=$fieldname[$i] ?>  size = "<?=strlen($showVal) ?>" 
			type = <? if($fieldname[$i] == "usr_pass") echo "password" ; else echo "text" 	?> 		
			id = <?=$fieldname[$i]?> value="<?=$showVal?>" <? if($fieldname[$i] == "eckl_cperson") echo "readonly" ;?> >
			<? if($link) echo $link ?>
		  </td>  			
		</tr>
	<?
	} //if($fieldname[$i] != "usr_sec" && $fieldname[$i] != "esv_dept" && $fieldname[$i] != "stt_id" &&  $fieldname[$i] != "esv_status"  ){			
		} //for ($i = 1; $i < $cnt_fieldname; $i++)
	?>	
	
    <tr align="center">
      <td colspan="2">	 
		<input name="Submit2" type="button" class="Button" value="&lt;= Back " onClick="window.location = '<?=$prevForm ;?>'" >
	  	<input name="Submit" type="submit" class="Button" value="<?=$button?>" <?=$disabled ;?> >
		<input name="Button" type="button" class="Button"  
		onClick= "return cancel('<?=$viewForm?>') ;" 
		value="Cancel" >  
        <input name="Submit22" type="button" class="Button" value="Next =&gt;" onClick="window.location = '<?=$nextForm ;?>'" >
		<input name="<?= $field_id ?>" type="hidden" id="<?=$field_id ?>" value="<? if (!empty($id)) echo $row["$field_id"]?>">
	   <input name="a" type="hidden" id="action" value="<?=$action ?>">
</td>
    </tr>
  </table>
</form>
<script language="javascript">
	function cancel(val) 
	{
		//alert(val);
		window.open(val,"frame_details");
	}
</script>
