<?
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	$updForm = updForm;
	$updSave = updSave;	
	$table_name = tableName;
	$field_id = field_id;
	$action = action;
	$id = id;
	$beg_id = beg_id;
	$end_id = end_id;
	
	/*echo "table_name = $table_name<br>field_id = $field_id<br> 
	            action = $action<br>id = $id<br>beg_id = $beg_id<br>end_id = $end_id<br>";*/
	
	if ($action == "a"){
		$caption = "Insert  "  ;
		$button = "Save";
	}
	if ($action == "e"){
		$caption = "Edit  "  ;
		$button = "Update";
	}
	if ($action == "d"){
		$caption = "Delete  "  ;
		$button = "Delete";
	}
	if(!empty($id)){
		$result = get_updForm($table_name,$field_id,$id);	
		$row=mysql_fetch_array($result);
	}
		$fieldname = get_table_fieldname($table_name); 
		$cnt_fieldname = count($fieldname);
?>
<html>
<head>
	<title></title>	
	<link rel="stylesheet" href="../css/format.css.css" type="text/css">
	<script language="JavaScript">
	<!--
		function validate(objForm)
		{
			var objForm = document.forms["EditField"];
			objForm.strName.required = 1;
			objForm.strName.err = "<?php echo $FIELD_NEW_ERROR_NAME;?>";
			
			bResult = jsVal(objForm);
			
			return bResult;
		}
	//-->
	</script>
	<script src="../js/jsval.js" type="text/javascript" language="JavaScript"></script>	
</head>
<?php
	$strName = "";
	$nType = 1;
	$strValue = "";
	$bReadOnly = 0;
	
	include ("file:///E|/CuteFlow/config/config.inc.php");

	if (-1 != $fieldid)
	{
    	//--- open database
    	$nConnection = mysql_connect($DATABASE_HOST, $DATABASE_UID, $DATABASE_PWD);
    	
    	if ($nConnection)
    	{
    		//--- get maximum count of users
    		if (mysql_select_db($DATABASE_DB, $nConnection))
    		{
    			//--- read the values of the user
				$strQuery = "SELECT * FROM cf_inputfield WHERE nID = ".$_REQUEST["fieldid"];
				$nResult = mysql_query($strQuery, $nConnection);
        
        		if ($nResult)
        		{
        			if (mysql_num_rows($nResult) > 0)
        			{
        				while (	$arrRow = mysql_fetch_array($nResult))
        				{
        					$strName = $arrRow["strName"];
							$nType = $arrRow["nType"];
							$strValue = $arrRow["strStandardValue"];
							$bReadOnly = $arrRow["bReadOnly"];
        				}		
        			}
        		}
    		}
    	}
	}	
?>
<body>
	<br/>
	<br/>
	<div align="center">
		<form action="file:///E|/CuteFlow/pages/writefield.php" id="EditField" name="EditField" onsubmit="return validate(this);">
    		<table class="note">
    			<tr>
    				<td colspan="2" bgcolor="Red" align="left" style="font-weight:bold;color:White;">
						<?php echo $FIELD_EDIT_HEADLINE;?>
					</td>
    			</tr>
                <tr>
    				<td class="mandatory"><?php echo $FIELD_EDIT_NAME;?></td>
    				<td><input id="strName" Name="strName" type="text" class="FormInput" style="width:250px;" value="<?php echo $strName;?>"></td>
    			</tr>
                <tr>
    				<td class="mandatory"><?php echo $FIELD_EDIT_TYPE;?></td>
    				<td>
					<select id="nType" name="nType" class="FormInput">
						<option value="1" <?php if ($nType == 1) echo "selected";?>><?php echo $FIELD_TYPE_TEXT;?></option>
						<option value="2" <?php if ($nType == 2) echo "selected";?>><?php echo $FIELD_TYPE_BOOLEAN;?></option>
						<option value="3" <?php if ($nType == 3) echo "selected";?>><?php echo $FIELD_TYPE_DOUBLE;?></option>
						<option value="4" <?php if ($nType == 4) echo "selected";?>><?php echo $FIELD_TYPE_DATE;?></option>
					</select>
    			</tr>
				<tr>
					<td colspan="2" height="10px"></td>
				</tr>
                <tr>
    				<td><?php echo $FIELD_EDIT_STDVALUE;?></td>
    				<td><input type="text" Name="StdValue" id="StdValue" class="FormInput" style="width:150px;" value="<?php echo $strValue;?>"></td>
    			</tr>
				<tr>
					<td colspan="2" height="10px"></td>
				</tr>
    	        <tr>
    				<td><?php echo $FIELD_EDIT_READONLY;?></td>
    				<td><input type="checkbox" id="ReadOnly" name="ReadOnly"  <?php echoCheckedReadOnly($bReadOnly);?>>&nbsp;</td>
    			</tr>
    			<tr>
    				<td colspan="2" style="border-top: 1px solid #B8B8B8;padding: 6px 0px 4px 0px;" align="right">
						<input type="button" class="Button" value="<?php echo $BTN_CANCEL;?>" onclick="history.go(-1)">&nbsp;&nbsp;<input type="submit" value="<?php echo $USER_EDIT_ACTION;?>" class="Button">
					</td>
    			</tr>
    		</table>
			<input type="hidden" value="<?php echo $_REQUEST["fieldid"];?>" id="fieldid" name="fieldid">
			<input type="hidden" value="<?php echo $_REQUEST["language"];?>" id="language" name="language">
			<input type="hidden" value="<?php echo $_REQUEST["sort"];?>" id="sort" name="sort">
			<input type="hidden" value="<?php echo $_REQUEST["start"];?>" id="start" name="start">
		</form>
	</div><table>
	<tr>
		<td></td>
	</tr>
	</table>
	
</body>
</html>

<?php
	function echoCheckedReadOnly($bReadOnly)
	{
		if ($bReadOnly == 1)
		{
			echo "CHECKED";	
		}	
	}
?>