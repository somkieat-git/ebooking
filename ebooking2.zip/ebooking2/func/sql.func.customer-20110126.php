<?php
	//ob_start();
	session_start();
	$hostname=hostname;
	$user=username;
	$pass=password;
	$dbname=dbname;
	$dbtype = dbtype;
	
	//$system="customer";
	//$_SESSION["lang"]==""?$_SESSION["lang"]="th":0;
	//include_once("../customer/func/sql.func.php");//function
	//$link = conn($dbtype, $dbname, $hostname, $user, $pass);


//error_reporting(E_ALL   ^E_NOTICE  ^E_WARNING);
set_time_limit(120);
function conn($dbtype, $dbname, $hostname, $user, $pass){
	if($dbtype == "mysql"){
		$link = mysql_connect($hostname,$user,$pass) or die(mysql_error());
		mysql_select_db($dbname,$link) or die(mysql_error());
		//mysql_query("SET NAMES 'tis620'",$link);
		//mysql_query("SET NAMES 'utf8'",$link);
		mysql_query("SET NAMES utf8",$link);
	}
	return $link ;
} // end function connect(){

function query($dbtype, $link, $sql){
	//echo "\$link=$link<br>";
	if($dbtype == "mysql"){
		$result=mysql_query($sql,$link);
	}
return $result ;
} // end function connect(){

function db_query($dbtype, $dbname, $sql, $link){
	if($dbtype == "mysql"){
		$result=mysql_db_query($dbname,$sql,$link);
	}
return $result ;
} // end function db_query(){

function fetch_array($dbtype, $result){
//echo "\$result=" . $result ;
	if($dbtype == "mysql"){
		$arrResult = mysql_fetch_array($result);
		//print_r($arrResult);
	}
return $arrResult ;
} // end function fetch_array(){

function num_rows($dbtype, $result){
	if($dbtype == "mysql"){
		//echo "<hr>res=".$result;
		$numRows=mysql_num_rows($result);
	}
return $numRows ;
} // end function num_rows(){

function num_fields($dbtype, $result){
	if($dbtype == "mysql"){
		//echo "r=".$result;
		$numFields=mysql_num_fields($result);
	}
return $numFields ;
} // end function num_fields(){

function field_name($dbtype, $result,$i){
	if($result){
		if($dbtype == "mysql"){
			//echo "\$result1=$result,\$i=$i<br>";
			$field_name = mysql_field_name($result, $i);
		}
	}
return $field_name ;
} // end function num_fields(){

function fetch_field($dbtype, $result,$i){
	if($result){
		if($dbtype == "mysql"){
			//echo "\$result1=$result,\$i=$i<br>";
			$field_name = mysql_field_name($result, $i);
			$meta = mysql_fetch_field($result, $i);
			$type = $meta->type;
		}
	}
return $type ;
} // end function num_fields(){
function closeDb($dbtype, $link){
	if($dbtype == "mysql"){
		mysql_close($link);
	}
} // end function num_fields(){

function get_mdet_type($dbname,$link){
	$arr_return = array();
	$sql = 'SELECT mis_id, mis_code FROM miscode ';
	$sql .= 'WHERE mis_type = "mdet_type" '; 
	$sql .= 'AND mis_used ="Y" ORDER BY mis_seq ';
	//echo $sql;
	 $result = db_query($dbtype, $dbname, $sql, $link);
	//$result = mysql_db_query($dbname,$sql,$link);
	while( $res = fetch_array($dbtype, $result)){
		$id = $res[0];
		$code = $res[1];
		$arr_return[$id] = $code;
	} // while( $res = mysql_fetch_array($result)){
	Return $arr_return;
} // End of function get_mdet_type

function getMdet_type($dbtype,$dbname,$link){
	$arrResult = array();
	$sql = ' SELECT mis_id, mis_code ';
	$sql .= ' FROM miscode ';
	$sql .= ' WHERE mis_type = "mdet_type" '; 
	$sql .= ' AND mis_show ="1" ';
	$sql .= ' ORDER BY mis_seq ' ;
	//echo $sql;
	 $result = db_query($dbtype, $dbname, $sql, $link);
	//$result = mysql_db_query($dbname,$sql,$link);
	while( $res = fetch_array($dbtype, $result)){
		$id = $res[0];
		$code = $res[1];
		$arrResult[$id] = $code;
	} // while( $res = fetch_array($dbtype, $result)){
	return $arrResult;
} // End of function getMdet_type

function get_author($dbtype,$dbname,$link,$usr_id,$msec_type){
	$type = "msec_".$msec_type ;	
	$sql = "";
	$sql = " SELECT msec.".$type ; 
	$sql .= " FROM menu_security  msec, user usr, user_group ugrp ";
	$sql .= " WHERE usr.ugrp_id = ugrp.ugrp_id ";
	$sql .= " AND ugrp.msec_id = msec.msec_id "; 
	$sql .= " AND usr.usr_code = '".$usr_id."'";
	//echo "$sql<hr>";
	$result = db_query($dbtype, $dbname, $sql, $link);
	//$result = mysql_db_query($dbname,$sql,$link) or die("function get_author error !");
	$res = fetch_array($dbtype, $result);
	//$res = mysql_fetch_array($result);
	Return $res[0];
} // End of function get_author

//function getAuthor($dbtype,$dbname,$link,$usr_id,$msec_type){
//	$type = "msec_".$msec_type ;	
//	$sql = " SELECT msec.".$type ; 
//	$sql .= " FROM menu_security  msec, user usr, user_group ugrp ";
//	$sql .= " WHERE usr.ugrp_id = ugrp.ugrp_id ";
//	$sql .= " AND ugrp.msec_id = msec.msec_id "; 
//	$sql .= " AND usr.usr_code = '".$usr_id."'";
//	//echo "$sql<hr>";
//	$result = db_query($dbtype, $dbname, $sql, $link);
//	$res = fetch_array($dbtype, $result);
//	$arrResult = convertStrToArray($res[0]);
//	return $arrResult;
//} // End of function getAuthor

function ctrlPage($dbtype,$dbname,$sql,$link,$pointer,$pagesize){
	$sql = "$sql ";
	$sql .= " limit $pointer,$pagesize";
	//echo "$sql<hr>";
	$r = db_query($dbtype, $dbname, $sql, $link);
	//echo "\$rr=$r<hr>";
	//$r = mysql_db_query($dbname,$sql,$link) or die("function ctrlPage error !");
	Return $r;
} // End of function ctrlPage

function get_men_id($dbtype,$dbname, $link,$table_name){
	$sql = "";
	$sql = "SELECT men_id "; 
	$sql .= " FROM menu ";
	$sql .= " WHERE men_table = '" .$table_name. "'";
	//echo "\$sql_men_id=$sql<hr>";
	$result = db_query($dbtype, $dbname, $sql, $link);
	//echo"\$r=$r<br>";
	$res = fetch_array($dbtype, $result);
	//$result = mysql_db_query($dbname,$sql,$link) or die("function get_men_id error !");
	//$res = mysql_fetch_array($result);
	Return $res[0];
} // End of function get_men_id

function getMenName($dbtype,$dbname, $link,$tableID,$lang){
	$sql = " SELECT men.men_tname,men.men_ename,men.men_link,mdet.mdet_field,men.men_table  ";
	$sql.= " FROM `menu` as men,menu_detail as mdet ";
	$sql.= " WHERE men.men_id=mdet.men_id ";
	$sql.= " AND mdet.mdet_seq=0 ";
	$sql.= " AND men.men_id='$tableID' ";
	//echo "\$sql=$sql<hr>";
	$result = db_query($dbtype, $dbname, $sql, $link);
	$res = fetch_array($dbtype, $result);
	$men_link = $res[2];
	$mdet_field = $res[3];
	$men_table = $res[4];
	$lang == "th" ? $name = $res[0] : $name = $res[1] ;
	$name == "" ? $name = $res[0]:0;
	$arrName = array($name,$men_link,$mdet_field,$men_table);
	return $arrName;
} // End of function getMenName

function getMenuName($dbtype,$dbname, $link,$tableID,$lang){
	$sql = " SELECT men.men_tname,men.men_ename  ";
	$sql.= " FROM `menu` as men ";
	$sql.= " WHERE men.men_id='$tableID' ";
	//$sql.= " AND mdet.mdet_seq=0 ";
	//$sql.= " AND  ";
	//echo "\$sql1=$sql<hr>";
	$result = db_query($dbtype, $dbname, $sql, $link);
	$res = fetch_array($dbtype, $result);
	$men_link = $res[2];
	$mdet_field = $res[3];
	$men_table = $res[4];
	$lang == "th" ? $name = $res[0] : $name = $res[1] ;
	$name == "" ? $name = $res[0]:0;
	//$arrName = array($name,$men_link,$mdet_field,$men_table);
	return $name;
} // End of function getMenName

function get_mdet_id($dbtype,$dbname,$link,$arr_value){
	$sql = "";
	/*print_r($arr_value);
	echo"<hr>";*/
	foreach($arr_value as $key => $value){
		$men_id = $value[0];
		$mdet_field  = $value[1];
		$sql = "SELECT *  " ; 
		$sql .= " FROM menu_detail ";
		$sql .= " WHERE men_id = ".$men_id ;
		$sql .= " AND mdet_field = '".$mdet_field."' order by mdet_seq asc" ;
		//echo "$sql<hr>";
		$result = db_query($dbtype, $dbname, $sql, $link);
		//$result = mysql_db_query($dbname,$sql,$link) or die("function get_mdet_id error !");
		$res = fetch_array($dbtype, $result);
		//$res = mysql_fetch_array($result);
		!empty($res[0]) ? $arr_result[$res[0]] = $res[0] : 0 ;
		$arr_mdet[$res[0]] = array($res[0], $res[1], $res[2], $res[3], $res[4], $res[5], $res[6],$res[7],$res[8],$res[9]);
		//echo "$res[0]<br>";
	}	
	//$mdet_id = implode(",",$arr_result);
	$mdet_id = $arr_result;
	//echo $arr_mdet;
	$arr_return = array($mdet_id, $arr_mdet);	
	Return $arr_return ;	
	//Return $arr_result ;	
} // End of function get_mdet_id

function getMdet_id($dbtype,$dbname,$link,$tablename){
	if($dbtype == "mysql"){
		$sql = " SELECT mdet.*  " ; 
		$sql .= " FROM `menu_detail` mdet, menu men ";
		$sql .= " WHERE mdet.men_id = men.men_id ";
		$sql .= " AND men.men_table = '".$tablename. "'";
		$sql .= " ORDER BY mdet_seq, mdet_id ";
		//echo "$sql<hr>";
		$result = db_query($dbtype, $dbname, $sql, $link);
	} // if($dbtype == "mysql"){
	return $result ;	
} // End of function getMdet_id

function getPdet($dbtype, $dbname,$link,$criteria,$empcode){
	$sql = " SELECT pdet_id   " ; 
	$sql .= " FROM employee ";
	$sql .= " WHERE emp_code = " .$empcode ;
	//echo "$sql<hr>";
	$pdetID = getValue($dbtype, $dbname, $sql, $link);
	
	$sql = " SELECT pdet_id   " ; 
	$sql .= " FROM position_detail ";
	$sql .= " WHERE 1 = 1 " ;
	if($criteria){
		$criteria=="Vrf" ? $sql .= " AND  pdet_vrf like '%".$pdetID."%'" : 0 ;
		$criteria=="Apr" ? $sql .= " AND  pdet_apr like '%".$pdetID."%'" : 0 ;
	}
	else if(empty($criteria)){
		$sql .= " AND  pdet_vrf like '%".$pdetID."%'" ;
		$sql .= " OR  pdet_apr like '%".$pdetID."%'" ;
	}
	//echo "$sql<hr>";	
	$result = db_query($dbtype, $dbname, $sql, $link);
	$numRow = num_rows($dbtype, $result);
	if ($numRow){
		$arrPdet = array();
		while ($rst = fetch_array($dbtype, $result)){
			$arrPdet[] = $rst["pdet_id"];
		} //while ($rst = fetch_array($dbtype, $result)){	
		$result = implode(",",$arrPdet) . ",".$pdetID;
	} //if ($numRow){
	else $result = 0;
	return $result ;	
} // End of function getPdet

function convertStrToArray($strValue){
	$arr_value = array();$arr_return = array();
	! is_array($strValue) ? $arr_value = explode(",",$strValue) : $arr_value = $strValue ;
	foreach($arr_value as $key => $val ){
		$arr_return[$val] = $val ;
	}
	return $arr_return ;
} // End of function convertStrToArray

function arr_select($field_name,$dbname,$link){
	$arr_return = array();
	if($field_name == "ugrp_id"){
		$sql = 'SELECT ugrp_id, ugrp_name FROM user_group ';
		//$sql .= 'ORDER BY ugrp_name ';
	}
	if($field_name == "msec_id"){
		$sql = 'SELECT msec_id, msec_name FROM menu_security ';
		//$sql .= 'ORDER BY msec_name ';
	}
	if($field_name == "men_type"){
		$sql = 'SELECT mis_id, mis_e_name 	FROM miscode ';
		$sql .= 'WHERE mis_type  = "men_type"';
		//$sql .= 'ORDER BY mis_e_name ';
	}
	if($field_name == "men_id"){
		$sql = 'SELECT men_id, men_e_name  FROM menuname ';
		$sql .= 'WHERE men_table  != ""';
		//$sql .= 'ORDER BY men_e_name ';
	}
	if($field_name == "mdet_type"){
		$sql = 'SELECT mis_id, mis_e_name  FROM miscode ';
		$sql .= 'WHERE mis_type  = "mdet_type"';
		//$sql .= 'ORDER BY mis_e_name ';
	}
	if($field_name == "dsec_id"){
		$sql = 'SELECT dsec_id, dsec_code  FROM document_security ';
		//$sql .= 'ORDER BY dsec_code ';
	}
	if($field_name == "dgrp_id"){
		$sql = 'SELECT dgrp_id, dgrp_id 	FROM document_group ';
		//$sql .= 'ORDER BY dgrp_name ';
	}
	$result = db_query($dbtype, $dbname, $sql, $link);
	//$result = mysql_db_query($dbname,$sql,$link);		
	$html = '<select name="'.$field_name.'" id="'.$field_name.'">';
	while( $res = fetch_array($dbtype, $result)){
		$id = $res[0];
		$name = $res[1];
		$arr_return[$id] = $name; 
	} // while( $res = mysql_fetch_array($result)){
	
	Return $arr_return;
} // End of function arr_select

function gen_input($object,$filed_name,$field_value,$size,$readonly){	
	$html  = "";
	if($object == "text" || $object == "hidden" ||  $object == "radio" || $object == "image" ){
		$html = '<input type = "'.$object.'" name = "'.$filed_name.'[]" value = "'.$field_value.'" size = "'.$size.'"'. $readonly.' >';
	}	
	if($object == "checkbox"){
		//echo $field_value;
		$field_value == "Y" || $field_value == "y" ? $checked = "checked" : $checked = "" ;
		$html = '<input type = "'.$object.'" name = "'.$filed_name.'[]" value = "Y" '. $checked.' >';
	}
	if($object == "file"){
		//$html = '<input type = "text" name = "'.$filed_name.'" value = "'.$field_value.'" size = "'.$size.'"'. $readonly.' >';
		echo "$field_value<br>";
		$html = '<input type = "'.$object.'" name = "'.$filed_name.'" value = "'.$field_value.'" size = "'.$size.'"'. $readonly.' >';
	}
	
	if($object == "textarea"){
		$html = '<textarea name="'.$filed_name.'[]" cols="50" rows="5" >'.$field_value.' </textarea>';
	}
	Return $html;
} // End of function gen_input

function getHtml($dbtype, $dbname, $link, $lang, $object, $filed_name, $field_value, $field_link, $size, $readonly,$mdet_db){	
	//echo "\$field_value=$field_value<br>";
	$html  = "";
	if($object == "text" || $object == "hidden" ||  $object == "radio" || $object == "image" || $object == "password"){
		$html = '<input type = "'.$object.'" name = "'.$filed_name.'[]" value = "'.$field_value.'" size = "'.$size.'"'. $readonly.' onChange="btnEnable()">';
	}	
	if($object == "checkbox"){
		//echo $field_value;
		$field_value == "1"  ? $checked = "checked" : $checked = "" ;
		$html = '<input type = "'.$object.'" name = "'.$filed_name.'[]" value = "1" '. $checked.' onClick="btnEnable()">';
	}
	if($object == "file"){
		//$html = '<input type = "text" name = "'.$filed_name.'" value = "'.$field_value.'" size = "'.$size.'"'. $readonly.' >';
		echo "$field_value<br>";
		$html = '<input type = "'.$object.'" name = "'.$filed_name.'[]" value = "'.$field_value.'" size = "'.$size.'"'. $readonly.' onChange="btnEnable()">';
	}		
	if($object == "textarea"){
		$html = '<textarea name="'.$filed_name.'[]" cols="50" rows="5" onChange="btnEnable()">'.$field_value.' </textarea>';
	}	
	if($object == "select"){
		$html = genOption($dbtype, $dbname, $link, $lang, $object, $filed_name, $field_value, $field_link, $readonly,$mdet_db);
	}
	return $html;
} // End of function getHtml

function getHtml1($dbtype, $dbname, $link, $lang, $object, $filed_name, $field_value, $field_link, $size, $readonly,$mdet_db){	
	//echo "\$field_link=$field_link<br>";
	$html  = "";
	if($filed_name=="hddEmp_id"){
		/*$hostname="localhost";
		$user="root";
		$pass="";
		$name="NO DATA";
		$dbnameMaindata="maindatanew";
		$linkMaindata = mysql_connect($hostname,$user,$pass) or die(mysql_error());
		mysql_select_db($dbnameMaindata,$linkMaindata) or die(mysql_error());*/
		$sqlEmp = " SELECT * ";
		$sqlEmp.= " FROM employee ";
		$sqlEmp.= " WHERE emp_id=$field_value "; 
		$rstEmp = mysql_db_query("maindatanew", $sqlEmp, $link);
		while($rsEmp = fetch_array($dbtype, $rstEmp)){
			//echo "\$sqlEmp=$sqlEmp";
			$tname = $rsEmp[emp_tname];
			$OempId = $rsEmp[emp_id];
			$OempCode = $rsEmp[emp_code];
			$tsurnamename = $rsEmp[emp_tsurname];
			$valName = $tname." ".$tsurnamename;
		}
		if($object == "text" || $object == "hidden" ||  $object == "radio" || $object == "image" || $object == "password"){
			$html = '<input type = "'.$object.'" name = "'.$filed_name.'[]" value = "'.$OempCode.'" size = "'.$size.'"'. $readonly.' onChange="Idvalue()">';
			$html.='&nbsp;<INPUT TYPE="text" NAME="b[]" value="'.$valName.'" disabled >';
			//$filed_name1="emp_id";
			//$html.= '<input type = "'.$object.'" name = "'.$filed_name1.'[]" value = "'.$field_value.'" size = "'.$size.'"'. $readonly.'>';
			$html.='&nbsp;<INPUT TYPE="hidden" NAME="emp_id[]" value="'.$OempId.'">';
			//$html.= '<input type = "text" name = "emp_id[]">';
		}
	}else{
		if($object == "text" || $object == "hidden" ||  $object == "radio" || $object == "image" || $object == "password"){
			$html = '<input type = "'.$object.'" name = "'.$filed_name.'[]" value = "'.$field_value.'" size = "'.$size.'"'. $readonly.' onChange="btnEnable()">';
		}	
	}
	if($object == "checkbox"){
		//echo $field_value;
		$field_value == "1"  ? $checked = "checked" : $checked = "" ;
		$html = '<input type = "'.$object.'" name = "'.$filed_name.'[]" value = "1" '. $checked.' onClick="btnEnable()">';
	}
	if($object == "file"){
		//$html = '<input type = "text" name = "'.$filed_name.'" value = "'.$field_value.'" size = "'.$size.'"'. $readonly.' >';
		echo "$field_value<br>";
		$html = '<input type = "'.$object.'" name = "'.$filed_name.'[]" value = "'.$field_value.'" size = "'.$size.'"'. $readonly.' onChange="btnEnable()">';
	}		
	if($object == "textarea"){
		$html = '<textarea name="'.$filed_name.'[]" cols="50" rows="5" onChange="btnEnable()">'.$field_value.' </textarea>';
	}	
	if($object == "select"){
		$html = genOption($dbtype, $dbname, $link, $lang, $object, $filed_name, $field_value, $field_link, $readonly,$mdet_db);
	}
	return $html;
} // End of function getHtml

function genOption($dbtype, $dbname, $link, $lang, $object, $filed_name, $field_value, $field_link, $readonly,$mdet_db){	
	list($tblName,$fieldName,$where) = explode("|",$field_link);
	list($tblName,$fieldID) = explode(":",$field_link);
	$fieldName =  str_replace(":",",",$fieldName);
	//echo "\$where=$where<br>";
	$temp = strrpos($filed_name, "_");
	$field_show = substr($filed_name,0,$temp)."_show";
	$field_seq = substr($filed_name,0,$temp)."_seq";
	//$readonly ? $disabled = "disabled" : $disabled = "" ;
	if($dbtype == "mysql"){		
		if($mdet_db<>""){
			$dbConn=$mdet_db.".".$tblName.".";
			$tblName=$mdet_db.".".$tblName;
		}
		//$mdet_db<>""?$dbConn=$mdet_db.".".$tblName
		$linkName = $filed_name;
		substr($filed_name,-7) == "_parent" ? $linkName = substr($filed_name,0,3)."_id" : 0 ;
		$sql = " SELECT $dbConn$linkName ";
		$fieldName ? $sql .= " , $dbConn$fieldName " : 0 ;
		$sql .= " FROM $tblName";
		$sql .= " WHERE $dbConn$field_show = 1 ";
		//$where == "mdet_type" ? $sql .= " AND mis_type = '$where' " : 0 ;
		//$where == "men_table" ? $sql .= " AND men_parent =0 " : 0 ;
		$where <>"" ? $sql.=" AND $where ":0;
		$sql .= " ORDER BY $dbConn$field_seq ";
		//echo "genOption = $sql<br>";		
		$rstSel = db_query($dbtype, $dbname, $sql, $link);
		$html = '<select name="'.$filed_name.'[]" id="'.$filed_name.'[]" '.$disabled. ' onChange="btnEnable()">';
		$where == "men_table" ? $html .= '<option value=0>0</option>': 0 ;
		$lang == "th" ? $html .= '<option value="">-- ? --</option>': $html .= '<option value="">-- Chosse Item --</option>';
		while( $res = fetch_array($dbtype, $rstSel)){
			$id = $res[0];
			$name = $res[1];
			$numField = num_fields($dbtype, $rstSel);
			//echo"\$numField=$numField<br>";
			if($numField>2){
				$lang == "th" ? $name = $res[1] : $name = $res[2];								
			}
			//echo "\$field_value=$field_value, \$id=$id<br>";
			$field_value == $id ? $selected = "selected" :  $selected = "";		
			$html .= '<option value="'.$id.'" '.$selected.'>'.$name.'</option>';
			//echo "\$name = $name<br>";
		} // while( $res = mysql_fetch_array($result)){
		$html .= '</select>';
	} // if($dbtype == "mysql"){
	return $html;
} // End of function genOption

function converstForeignkey($dbtype,$dbname, $link,$show_val,$fieldname,$mdet_link,$fieldName){
	//list($mdet_link1,$fieldName) = explode(":",$fieldName);
	$fieldName = str_replace(":",",",$fieldName);
	$fieldname == "men_parent" ? $fieldname = "men_id" : 0 ;
	$sql="select $fieldName from $mdet_link where $fieldname=$show_val";
	//echo"\$sql=$sql<br>";
	$result = db_query($dbtype, $dbname, $sql, $link);
	//$query=mysql_db_query($dbname,$sql,$link) or die("function converstForeignkey error!");
	//$result=mysql_fetch_array($result);
	$arrResult = fetch_array($dbtype, $result);
	$lang == "th" ? $name = $arrResult[0]:$name = $arrResult[0];
	/*$name == ""  ? $name = $arrResult[0]:0;
	$name == ""  ? $name = $arrResult[1]:0;*/
	//echo "\$name=$name<br>";
	return $name;
}

function converstForeignkeyN($dbtype,$dbname, $link,$mdet_field,$mdet_link,$show_val){
//echo $mdet_link."<br>";
	list($tb,$field,$where) = explode(".",$mdet_link);
	list($fieldTh,$fieldEn) = explode(":",$field);
	$fieldName = str_replace(":",",",$field);
	$fieldName == "men_parent" ? $fieldname = "men_id" : 0 ;
	/*$fieldEn == "men_parent" ? $fieldname = "men_id" : 0 ;*/
	$sql="select $fieldName from $tb where $mdet_field=$show_val";
	//echo"\$sql=$sql<br>";
	$result = db_query($dbtype, $dbname, $sql, $link);
	//$query=mysql_db_query($dbname,$sql,$link) or die("function converstForeignkey error!");
	//$result=mysql_fetch_array($result);
	$arrResult = fetch_array($dbtype, $result);
	$lang == "th" ? $name = $arrResult[0]:$name = $arrResult[1];
	$name == ""  ? $name = $arrResult[0]:0;
	$name == ""  ? $name = $arrResult[1]:0;
	//echo "\$name=$name<br>";
	return $name;
}

function sortforeignkey($dbtype,$dbname,$link,$tbname){
	$sql="select * from $tbname";
	//echo "\$sql=$sql<br>";
	$result = db_query($dbtype, $dbname, $sql, $link);
	//$query=mysql_db_query($dbname,$sql,$link) or die("function sortforeignkey error! ");
	//echo "\$result=$result,\$i=$i<br>";
	$lang == "th" ? $name = field_name($dbtype, $result,1) : $name = field_name($dbtype, $result,2);
	//$lang=="th"?$name=mysql_field_name($query,1):$name=mysql_field_name($query,2);
	return $name;
} //function sortforeignkey($tbname,$dbname,$link){

function converstsortforeignkey($dbtype,$dbname,$link,$tbname){
	$sql = " SELECT * ";
	$sql.= " FROM $tbname";
	$result = db_query($dbtype, $dbname, $sql, $link);
	//$query=mysql_db_query($dbname,$sql,$link) or die("function sortforeignkey error! ");
	$name = field_name($dbtype, $result);
	//$name=mysql_field_name($query,0);
	return $name;
}//function converstsortforeignkey($tbname,$dbname,$link){

function ctrlReadonly($action,$add,$edit,$del){
	$result = "";
	$action == "a"  && $add == 0 ?  $result = "readonly" : 0 ;
	$action == "e"  && $edit == 0 ?  $result = "readonly" : 0 ;
	$action == "d"  && $del == 0 ?  $result = "readonly" : 0 ;
	return $result ;
} // End of function ctrlReadonly

function updValue($dbtype, $dbname, $link, $tableName, $action, $id_name, $id_value, $arr_data){
	$query = "";	
	if($action == "a"){
		$arr_data["usr_cre"] = $_SESSION["usr_id"];
		$arr_data["date_cre"] = date("Y/m/d  H:i:s");				
		$query = create_insert_query($tableName, $arr_data) ;
	}	
	if($action == "e"){
		$arr_data["usr_upd"] = $_SESSION["usr_id"];
		$arr_data["date_upd"] = date("Y/m/d  H:i:s");				
		$query = create_update_query($tableName, $arr_data, $id_name, $id_value) ;
	}	
	$action == "d" ? $query = create_delete_query($tableName,$id_name, $id_value)  : 0 ;
	//echo "$query<hr>";return $query ; exit();			
	$result = db_query($dbtype,$dbname,$query,$link)	or die("function updValue error !"); 	
	$arr_data="";
	return $result ;		
}  // End of function updValue

//function create_insert_query($tableName, $arr_data) 
//{
//	//print_r($arr_data);
//	$request = "INSERT INTO ".$tableName." ( ";
//	$request_values = "";
//	foreach($arr_data as $field_name=>$field_val) 
//	{
//		$field_name=strtoupper($field_name);
//		$request .= "$field_name ,";
//		if(!is_int($field_valal)) $field_val = "'$field_val'";
//		$request_values .= $field_val.",";
//	}
//	$request = substr( $request, 0, 0 - strlen(",") );            	
//	$request .= " ) VALUES (";
//	$request_values = substr( $request_values, 0, 0 - strlen(",") );            	
//	$request .= $request_values.")";
//	return $request;
//}// End of function create_insert_query

//function create_update_query($tableName, $arr_data, $id_name, $id_value ) 
//{
//	$request = "UPDATE ".$tableName." SET ";
//	foreach($arr_data as $field_name=>$field_val) 
//	{
//		if( !is_int($field_val)) 	$field_val = "'$field_val'";
//		$request .= " ".$field_name."=".$field_val.",";
//	}
//	$request = substr( $request, 0, 0 - strlen(",") );            	
//	$request .= " WHERE $id_name = ".$id_value;
//	return $request;
//} // End of function create_update_query

function create_delete_query($tableName, $id_name, $id_value ) 
{
	$request = "DELETE  FROM ".$tableName." WHERE ";
	$request .= "  $id_name IN ( ".$id_value . " )" ;
	return $request;
} // End of function create_delete_query

//function getData($dbtype, $dbname,$sql, $link){
//	$res = db_query($dbtype, $dbname, $sql, $link);
//	Return $res;
//} // End of function getData

function getValue($dbtype, $dbname,$sql, $link){
	$res = db_query($dbtype, $dbname, $sql, $link) or die(mysql_error());
	$rs = fetch_array($dbtype,$res) ;
	Return $rs[0];
} // End of function getValue

function arrData($fieldName,$value){
	global $data;
	$data[$fieldName] = $value;
	Return $data;
} // End of function arrData

function display_children1($parent, $level) { 
	global $arrChild;
	// retrieve all children of $parent 
	$sqlCh = " SELECT ltyp_id , ltyp_tname, ltyp_ename";
	$sqlCh .= " FROM leave_type ";
	$sqlCh .= " WHERE ltyp_parent  = ".$parent  ;
	//echo "\$sqlCh=$sqlCh<br>";
	$rst = mysql_query($sqlCh);
	//$rst = db_query($dbtype, $dbnameMaindata, $sql, $linkMaindata);
	//while ($rs = fetch_array($dbtype, $rst)){
	//$arrChild = array();
	while ($rs1 = mysql_fetch_array($rst)) {
	//echo str_repeat('  ',$level).$rs['odet_tname']."<br>"; 
	//echo $rs['odet_tname']."<br>";
	$strCh<>""?$strCh.=",":0;
	$strCh.=$rs1['ltyp_id'];
	$arrChildlt[]=$rs1['ltyp_id'];
	//print_r($arrChildlt);
	// echo "<hr>";
	//$arrChild = array_merge($rs['odet_id'], $arrChild); 
	// call this function again to display this 
	// child's children 
	display_children1($rs1['ltyp_id'], $level+1); 		   
	//exit();
	} //while ($rs = fetch_array($dbtype, $rstMsec)){
	return $strCh;
}  //function display_children($parent, $level) { 

/*function chgDateToDb($strDate)
{
	//echo "$strDate= " . $strDate ; exit();
	$false   = array("-", '.');	
	$true = array("/", "/");
	$res = str_replace($false, $true, $strDate);	
	list($dd, $mm, $yyyy) = explode('/',$res);
	if(strlen($dd) < 2) $dd = '0' . $dd;
	if(strlen($mm) < 2) $mm = '0' . $mm;
	if(strlen($yyyy) < 2) $yyyy = '200' . $yyyy;
	if(strlen($yyyy) < 3) $yyyy = '20' . $yyyy;	
	$res = $yyyy."-".$mm."-".$dd;
	Return $res;
}//function chgDateToDb($strDate)
*/

function chgDateToSh($strDate)
{
	//echo "\$strDate=$strDate";
	$false   = array("-", '.');	
	$true = array("/", "/");
	$res = str_replace($false, $true, $strDate);	
	//echo "\$res=$res";
	list($yyyy, $mm, $dd) = explode('/',$res);
	if(strlen($dd) < 2) $dd = '0' . $dd;
	if(strlen($mm) < 2) $mm = '0' . $mm;
	if(strlen($yyyy) < 2) $yyyy = '200' . $yyyy;
	if(strlen($yyyy) < 3) $yyyy = '20' . $yyyy;
    //if(strlen($dd) > 2) $dd = substr($dd , 0 , -(strlen($dd)-2)); // ??????????????????? $dd 
	$res = $yyyy.$mm.$dd;
	$res=$dd."/".$mm."/".$yyyy;
	Return $res;
}//function chgDateToSh($strDate)

function findEmail($dbtype, $dbname, $link,$emp_id){
	$sql = " SELECT * ";
	$sql.= " FROM employee ";
	$sql.= " WHERE emp_id= $emp_id ";
	$result = db_query($dbtype, $dbname, $sql, $link);
	$RS = fetch_array($dbtype, $result);
	$email = $RS[emp_email];
	return($email);
}
function sendEmail($to,$subject,$message){
	ini_set("SMTP","10.0.2.4");
	ini_set("sendmail_from","kosol@qsncc.co.th");
	mail($to, $subject, $message);
}

function getBoss($miscode,$verify,$approve,$hr,$arrVer,$arrApr,$arrLHTR_S,$linkMaindata,$dbnameMaindata,$dbtype){
	//print_r($arrVer);
	//echo"<br>";
	//echo $miscode;
	if($miscode==9 or $miscode==12 or $miscode==15){
		//$arrVerFun = $arrVer;
		$arrVerFun = explode("|",$verify);
		//if($miscode==9){
			foreach($arrVerFun as $keyVF => $valVF){
				$arrValVf = explode(":",$valVF);
				list($id,$per)=$arrValVf;
				if($per=="Y"){
					//$miscode==12?$sendId=$falseSendId:$sendId = $id;
					$sendId = $id;
				}/*else{
					$falseSendId = $id;
				}*/
			}//foreach($arrVerFun as $keyVF => $valVF){
		  // }//if($miscode==9)	
		//$sendId==""?$sendId=$valVF:0;
		if($sendId==""){
			//echo"hiii";
			list($sendId,$per)= explode(":",$valVF);
		}
		//echo "\$sendId=$sendId<br>";
		$name=$arrVer[$sendId][1]."&nbsp;".$arrVer[$sendId][2];
	}elseif(($miscode==10 or $miscode==11) or $miscode==13 or $miscode==16 or $miscode==17){
		$arrAppFun = explode("|",$approve);
		//print_r($arrAppFun);
		foreach($arrAppFun as $keyAP => $valAP){
			//$arrValAp = $arrApr;
			$arrValAp = explode(":",$valAP);
			list($id,$per)=$arrValAp;
			if($per=="Y"){
				$sendId = $id;
				//break;
			}
		}//foreach($arrVerFun as $keyVF => $valVF){
		$sendId==""?$sendId=$valVF:0;
		//print_r($approve);
		
		if($sendId==""){
			//echo"\$sendId=$sendId<br>";
			$arrValAp = explode(":",$approve);
			//print_r($arrValAp);
			list($sendId,$per)=$arrValAp;
		}
		//$sendId==""?list($sendId,$per)=$arrApr;
		//print_r($arrApr);
		
		$name=$arrApr[$sendId][1]."&nbsp;".$arrApr[$sendId][2];
	}elseif($miscode==14){
		//$arrhrFun = explode("|",$hr);
		//print_r($arrAppFun);
		//print_r($hr);
		$arrValHR = explode(":",$hr);
		//print_r($arrValHR);
		list($sendId,$per)=$arrValHR;
		$sql = "SELECT * ";
		$sql.= "FROM employee ";
		$sql.= "WHERE emp_id = $sendId";
		$query = db_query($dbtype, $dbnameMaindata, $sql, $linkMaindata);
		$rs = fetch_array($dbtype, $query);
		$name=$rs[emp_tname]."&nbsp;".$rs[emp_tsurname];
	}
	//echo"<hr>";
	//print_r($arrVer);
	return $name;
}

function getBoss1($miscode,$verify,$approve,$hr,$arrVer,$arrApr,$arrLHTR_S,$linkMaindata,$dbnameMaindata,$dbtype){
	//print_r($arrVer);
	//echo"<br>";
	//echo $miscode;
	if($miscode==9 or $miscode==12 or $miscode==15){
		//$arrVerFun = $arrVer;
		$arrVerFun = explode("|",$verify);
		//if($miscode==9){
			foreach($arrVerFun as $keyVF => $valVF){
				$arrValVf = explode(":",$valVF);
				list($id,$per)=$arrValVf;
				if($per=="Y"){
					//$miscode==12?$sendId=$falseSendId:$sendId = $id;
					$sendId = $id;
				}/*else{
					$falseSendId = $id;
				}*/
			}//foreach($arrVerFun as $keyVF => $valVF){
		  // }//if($miscode==9)	
		//$sendId==""?$sendId=$valVF:0;
		if($sendId==""){
			//echo"hiii";
			list($sendId,$per)= explode(":",$valVF);
		}
		//echo "\$sendId=$sendId<br>";
		//$name=$arrVer[$sendId][1]."&nbsp;".$arrVer[$sendId][2];
		$sql = "SELECT * ";
		$sql.= "FROM employee ";
		$sql.= "WHERE emp_id = $sendId";
		$query = db_query($dbtype, $dbnameMaindata, $sql, $linkMaindata);
		$rs = fetch_array($dbtype, $query);
		$name=$rs[emp_tname]."&nbsp;".$rs[emp_tsurname];
	}elseif(($miscode==10 or $miscode==11) or $miscode==13 or $miscode==16 or $miscode==17){
		$arrAppFun = explode("|",$approve);
		//print_r($arrAppFun);
		foreach($arrAppFun as $keyAP => $valAP){
			//$arrValAp = $arrApr;
			$arrValAp = explode(":",$valAP);
			list($id,$per)=$arrValAp;
			if($per=="Y"){
				$sendId = $id;
				//break;
			}
		}//foreach($arrVerFun as $keyVF => $valVF){
		$sendId==""?$sendId=$valVF:0;
		//print_r($approve);
		
		if($sendId==""){
			//echo"\$sendId=$sendId<br>";
			$arrValAp = explode(":",$approve);
			//print_r($arrValAp);
			list($sendId,$per)=$arrValAp;
		}
		//$sendId==""?list($sendId,$per)=$arrApr;
		//print_r($arrApr);
		
		$name=$arrApr[$sendId][1]."&nbsp;".$arrApr[$sendId][2];
	}elseif($miscode==14){
		//$arrhrFun = explode("|",$hr);
		//print_r($arrAppFun);
		//print_r($hr);
		$arrValHR = explode(":",$hr);
		//print_r($arrValHR);
		list($sendId,$per)=$arrValHR;
		$sql = "SELECT * ";
		$sql.= "FROM employee ";
		$sql.= "WHERE emp_id = $sendId";
		$query = db_query($dbtype, $dbnameMaindata, $sql, $linkMaindata);
		$rs = fetch_array($dbtype, $query);
		$name=$rs[emp_tname]."&nbsp;".$rs[emp_tsurname];
	}
	//echo"<hr>";
	//print_r($arrVer);
	return $name;
} //function getBoss1

function chkVar0($var){
	if($var==0.0){
		$var = "-";
	}
	return $var;
} //function chkVar0($var){

function ereg_replacestr($str){
	$var = "@";// "@@"
	$str = ereg_replace($var,"@nccmail.",$str);
	return $str;
}

function get_children($dbtype, $dbname,$link,$parent, $level) { 
   // retrieve all children of $parent 
	$sql = " SELECT odet_id, odet_tname, odet_parent, omas_id ";
	$sql .= " FROM org_detail";
	$sql .= " WHERE odet_parent = ".$parent  ;
	//echo "\$get_children=$sql<hr>";
	$rst = db_query($dbtype, $dbname, $sql, $link);
	while ($rs = fetch_array($dbtype, $rst)){
	   $odet_id = $rs['odet_id'];
	   $omas_id = $rs['omas_id'];
	   //echo str_repeat('-',$level).$rs['odet_id']." : ".$rs['odet_tname']."<br>"; 
		$_SESSION["children"] ? $_SESSION["children"] .= ",".$odet_id : $_SESSION["children"] .= $odet_id ;
	   get_children($dbtype, $dbname,$link,$rs['odet_id'], $level+1); 		   
	} //while ($rs = fetch_array($dbtype, $rst)){
	return $_SESSION["children"];		
}  //function display_children($parent, $level) { 		

function get_parent($dbtype, $dbname,$link,$node) { 
	// look up the parent of this node 
	//echo "\$node=$node<br>";
	$sql = " SELECT omas_id, odet_tname, odet_parent";
	$sql .= " FROM org_detail";
	$sql .= " WHERE odet_id = ".$node ;
	//$sql .= " AND omas_id <> 1 " ;
	//echo "$sql<br>";
	$rst = db_query($dbtype, $dbname, $sql, $link);
	$row = fetch_array($dbtype, $rst);
	$parent = $row['odet_parent']; 
   //echo "\$parent = $parent<br>";
		
	if ($parent >= 1) { 
		$value = $row['omas_id'].":".$row['odet_tname']; 
	   if($_SESSION["parent"])
			$_SESSION["parent"] .= "|" . $value; 
	   else
			$_SESSION["parent"] = $value; 
	   $tmp = get_parent($dbtype, $dbname,$link,$parent);	   
	} 	
	// return the path 
	return $_SESSION["parent"]; 
}  //function get_parent($node) { 

function showChildren($dbtype, $dbname,$dbnameMaindata,$link,$linkMaindata,$parent, $level) { 
   // retrieve all children of $parent 
  //echo "\$dbname=$dbname<br>\$dbnameMaindata=$dbnameMaindata<br>";   
   	$lang = $_SESSION["lang"]; 
	//echo "\$lang=$lang<br>";
	$sql = " SELECT odet_id, odet_tname, odet_parent";
	$sql .= " FROM org_detail";
	$sql .= " WHERE odet_parent = ".$parent  ;
	//echo "$sql<hr>";
	$rst = db_query($dbtype, $dbnameMaindata, $sql, $linkMaindata);
	while ($rs = fetch_array($dbtype, $rst)){
	   $odetID = $rs['odet_id'];
	   $lang = "th" ? $odetName = $rs['odet_tname'] : $odetName = $rs['odet_ename'] ;
	  // $show = str_repeat('-',$level).$rs['odet_id']." : ".$rs['odet_tname']; 
	  
	  ## begin display	  		
			$sql = " SELECT pdet_id FROM position_detail WHERE odet_id = ".$odetID ;
			//$sql .= " ORDER BY pdet_id ";
			//echo "$sql<br>";
			$result = db_query($dbtype, $dbnameMaindata, $sql, $linkMaindata);
			$arrPdetID = array();
			while ($rsPdetID = fetch_array($dbtype, $result)){
				$arrPdetID[] =  $rsPdetID["pdet_id"];
			} //while ($rsPdetID = fetch_array($dbtype, $result)){
			$strPdetID = implode(",",$arrPdetID);
			//echo "\$strPdetID=$strPdetID<br>";	
			
			$sql = " SELECT emp_id, emp_ttitle, emp_tname, emp_tsurname,emp_etitle, emp_ename, emp_esurname, pdet_id ";
			$sql .= " FROM employee ";
			$sql .= " WHERE pdet_id in (  ".$strPdetID. " )" ;			
			$sql .= " AND emp_resign = '0' ";
			$sql .= " ORDER BY emp_grade desc ";
			//echo "$sql<br>";
			$rstEmp = db_query($dbtype, $dbnameMaindata, $sql, $linkMaindata);
			$numrow = num_rows($dbtype, $rstEmp);
			//echo "\$numrow=$numrow<br>";
			if($numrow){
				$lang = $_SESSION["lang"]; 
				$defYear = $_SESSION["defYear"] ;
				$defLtyp = $_SESSION["defLtyp"] ;
				$defStatus = $_SESSION["defStatus"] ;
				while ($rsEmp = fetch_array($dbtype, $rstEmp)){				
					if ($lang == "th" )
						$empName = $rsEmp["emp_ttitle"].$rsEmp["emp_tname"]."  ".$rsEmp["emp_tsurname"];
					else
						$empName = $rsEmp["emp_etitle"].$rsEmp["emp_ename"]."  ".$rsEmp["emp_esurname"];
						
					$sql = " SELECT * FROM leave_tran ";
					$sql .= " WHERE 1 = 1 " ;
					$defYear ? 	$sql .= " AND left(ltrn_bgdate,4) >= ".$defYear ." AND left(ltrn_endate,4) <= ".$defYear : 0 ;				
					$defLtyp ? 	$sql .= " AND ltyp_id in ( ".$defLtyp." )"  : 0 ;
					$defStatus ? $sql .= " AND ltrn_status in ( ".$defStatus ." )" : 0 ;
					$sql .= " AND emp_id = " . $rsEmp["emp_id"] ;
					$sql .= " ORDER BY ltrn_bgdate desc " ;
					//echo "$sql<br>";
					$rstLtran = db_query($dbtype, $dbname, $sql, $link);
					//$arrLadd = array();
					//echo "<td><table>";										
					while ($rsLtran = fetch_array($dbtype, $rstLtran)){					
						$empID = $rsLtran["emp_id"];
						$day = $rsLtran["ltrn_day"];
						$date =$rsLtran["ltrn_bgdate"]." - ".$rsLtran["ltrn_endate"];
						$reason =$rsLtran["ltrn_lreason"];
						$time = $rsLtran["date_cre"];
						$arrLtran[$empID][] = array($day,$date,$reason,$time);
					} //while ($rstLtran = fetch_array($dbtype, $rstEmp)){
					
					if($level == 0) 	$pref = "Division ";
					if($level == 1) 	$pref = "Department ";
					if($level == 2) 	$pref = "Section ";
					if($level == 3) 	$pref = "Unit ";
					$showDept = $pref." : ".$odetName;
					$Dept == $showDept ? $showDept = ""  : $Dept = $showDept ;
					
					$bgcolor == "#E7F0F8" ? $bgcolor="#F5F9FC" : $bgcolor="#E7F0F8" ;
					echo "<tr bgcolor='".$bgcolor."'><td>";
					echo str_repeat('&nbsp;&nbsp;',$level).$showDept; 					
					echo "</td>";					
					echo "<td>".$empName."</td>";
					$cntLtran = count($arrLtran[$empID]);
					//echo "\$cntLtran=$cntLtran<br>";
					if($cntLtran <= 1){
						echo "<td>".$arrLtran[$empID][0][0]."</td>";
						echo "<td>".$arrLtran[$empID][0][1]."</td>";
						echo "<td>".$arrLtran[$empID][0][2]."</td>";
						echo "<td>".$arrLtran[$empID][0][3]."</td>";
					} //f($cntLtran <= 1){
					if($cntLtran > 1){
						foreach ($arrLtran[$empID] as $key =>$val){
							echo "<td>".$val[0]."</td>";
							echo "<td>".$val[1]."</td>";
							echo "<td>".$val[2]."</td>";
							echo "<td>".$val[3]."</td>";
							if ($key < ($cntLtran - 1)) echo "<tr bgcolor='".$bgcolor."'><td colspan='2'></td>"  ;
						} //foreach ($arrLtran[$empID] as $key =>$val){
					} //if($cntLtran > 1){					
					echo "</tr>"; 	   										
					
				} //while ($rsEmp = fetch_array($dbtype, $result)){				
			} //if($numrow){
			else{
				/*
				echo "<tr><td>222";
				echo str_repeat('_',$level).$odetID." : ".$odetName; 
				echo "</td>";
				echo "<td>".$empName."</td>";
				echo "<td></td>";
				echo "<td></td>";
				echo "<td></td>";
				echo "</td></tr>"; 	   
				*/
			} //else{
		showChildren($dbtype, $dbname,$dbnameMaindata,$link,$linkMaindata, $odetID, $level+1); 		   
	} //while ($rs = fetch_array($dbtype, $rst)){
}  //function showChildren($parent, $level) { 		

function showOrganize($dbtype, $dbname,$dbnameMaindata,$link,$linkMaindata,$parent, $level){ 
   // retrieve all children of $parent 
   	$lang = $_SESSION["lang"]; 	
	$sql = " SELECT odet_id, odet_tname, odet_parent , odet_code ";
	$sql .= " FROM org_detail";
	$sql .= " WHERE odet_id = ".$parent  ;
	//echo "$sql<hr>";
	$rstTemp = db_query($dbtype, $dbnameMaindata, $sql, $linkMaindata);	
	while ($rsTemp = fetch_array($dbtype, $rstTemp)){
	   $odetID = $rsTemp['odet_id'];
	   $odetP = $rsTemp['odet_parent'];
	   $lang = "th" ? $odetName = $rsTemp['odet_code'].' : '.$rsTemp['odet_tname'] : $odetName = $rsTemp['odet_code'].' : '.$rsTemp['odet_ename'] ;
	} //while ($rs = fetch_array($dbtype, $rst)){
	
	$sql = " SELECT * FROM position_detail WHERE odet_id = ".$parent ;
	$sql .= " ORDER BY pmas_id ";
	//echo "$sql<br>";
	$result = db_query($dbtype, $dbnameMaindata, $sql, $linkMaindata);
	$numrow = num_rows($dbtype, $result);
	//echo "\$numrow=$numrow<br>";
	if($numrow){			
		while ($rsPdet = fetch_array($dbtype, $result)){				
			$DepID = $rsPdet["pdet_id"];
			$DepTname = $rsPdet["pdet_code"].' : '.$rsPdet["pdet_tname"];
			$DepEname = $rsPdet["pdet_ename"];				
			$showDept = $odetID." : ".$odetName;
			$Dept == $showDept ? $showDept = ""  : $Dept = $showDept ;
			
			echo "<tr><td>";
			echo str_repeat('=>',$level).$showDept; 					
			echo "</td>";					
			echo "<td>".$DepID."</td>";
			echo "<td>".$DepTname."</td>";
			echo "<td>".$DepEname."</td>";
			echo "<td></td>";
			
		} //while ($rsEmp = fetch_array($dbtype, $result)){				
	} //if($numrow){			
				
	$sql = " SELECT odet_id, odet_tname, odet_parent";
	$sql .= " FROM org_detail";
	$sql .= " WHERE odet_parent = ".$parent  ;
	//echo "$sql<hr>";
	$rst = db_query($dbtype, $dbnameMaindata, $sql, $linkMaindata);	
	while ($rs = fetch_array($dbtype, $rst)){
	   $odetID = $rs['odet_id'];
		showOrganize($dbtype, $dbname,$dbnameMaindata,$link,$linkMaindata, $odetID, $level+1); 		   
	} //while ($rsPdet = fetch_array($dbtype, $rst)){
}  //function showOrganize($dbtype, $dbname,$dbnameMaindata,$link,$linkMaindata,$parent, $level) { 

function showLadd($dbtype, $dbname,$dbnameMaindata,$link,$linkMaindata,$parent, $level,$bgcolor) { 
   // retrieve all children of $parent 
  //echo "\$dbname=$dbname<br>\$dbnameMaindata=$dbnameMaindata<br>";   
   	$lang = $_SESSION["lang"]; 
	//echo "\$lang=$lang<br>";
	$sql = " SELECT odet_id, odet_tname, odet_parent";
	$sql .= " FROM org_detail";
	$sql .= " WHERE odet_parent = ".$parent  ;
	//echo "$sql<hr>";
	$rst = db_query($dbtype, $dbnameMaindata, $sql, $linkMaindata);
	while ($rs = fetch_array($dbtype, $rst)){
	   $odetID = $rs['odet_id'];
	   $lang = "th" ? $odetName = $rs['odet_tname'] : $odetName = $rs['odet_ename'] ;
	  // $show = str_repeat('-',$level).$rs['odet_id']." : ".$rs['odet_tname']; 
	  
	  ## begin display	  		
			$sql = " SELECT pdet_id FROM position_detail WHERE odet_id = ".$odetID ;
			//$sql .= " ORDER BY pdet_id ";
			//echo "$sql<br>";
			$result = db_query($dbtype, $dbnameMaindata, $sql, $linkMaindata);
			$arrPdetID = array();
			while ($rsPdetID = fetch_array($dbtype, $result)){
				$arrPdetID[] =  $rsPdetID["pdet_id"];
			} //while ($rsPdetID = fetch_array($dbtype, $result)){
			$strPdetID = implode(",",$arrPdetID);
			//echo "\$strPdetID=$strPdetID<br>";	
			
			$sql = " SELECT emp_id, emp_ttitle, emp_tname, emp_tsurname,emp_etitle, emp_ename, emp_esurname, pdet_id ";
			$sql .= " FROM employee ";
			$sql .= " WHERE pdet_id in (  ".$strPdetID. " )" ;			
			$sql .= " AND emp_resign = '0' ";
			$sql .= " ORDER BY emp_grade desc ";
			//echo "$sql<br>";
			$rstEmp = db_query($dbtype, $dbnameMaindata, $sql, $linkMaindata);
			$numrow = num_rows($dbtype, $rstEmp);
			//echo "\$numrow=$numrow<br>";			
			if($numrow){
				$lang = $_SESSION["lang"]; 
				$defYear = $_SESSION["defYear"] ;
				$defLtyp = $_SESSION["defLtyp"] ;
				$defStatus = $_SESSION["defStatus"] ;
				while ($rsEmp = fetch_array($dbtype, $rstEmp)){				
					if ($lang == "th" )
						$empName = $rsEmp["emp_ttitle"].$rsEmp["emp_tname"]."  ".$rsEmp["emp_tsurname"];
					else
						$empName = $rsEmp["emp_etitle"].$rsEmp["emp_ename"]."  ".$rsEmp["emp_esurname"];
						
					$sql = " SELECT * FROM leave_add ";
					$sql .= " WHERE 1 = 1 " ;
					$defYear ? 	$sql .= " AND left(date_cre,4) = ".$defYear  : 0 ;				
					$defLtyp ? 	$sql .= " AND ltyp_id in ( ".$defLtyp." )"  : 0 ;
					$sql .= " AND emp_id = " . $rsEmp["emp_id"] ;
					$sql .= " ORDER BY ltyp_id asc, date_cre desc " ;
					//echo "$sql<br>";
					$rstLadd = db_query($dbtype, $dbname, $sql, $link);
					$arrLadd = array();
					//echo "<td><table>";										
					while ($rsLadd = fetch_array($dbtype, $rstLadd)){					
						$empID = $rsLadd["emp_id"];
						$prev =$rsLadd["ladd_prev"];
						$qty = $rsLadd["ladd_qty"];
						$new = $prev + $qty ;
						$remark =$rsLadd["ladd_remark"];
						$time = $rsLadd["date_cre"];
						$arrLadd[$empID][] = array($prev,$qty,$new,$remark,$time);
					} //while ($rstLtran = fetch_array($dbtype, $rstEmp)){
					
					if($level == 0) 	$pref = "Division ";
					if($level == 1) 	$pref = "Department ";
					if($level == 2) 	$pref = "Section ";
					if($level == 3) 	$pref = "Unit ";
					$showDept = $pref." : ".$odetName;
					$Dept == $showDept ? $showDept = ""  : $Dept = $showDept ;
					
					$bgcolor == "#E7F0F8" ? $bgcolor="#c6e2ff" : $bgcolor="#E7F0F8" ;
					echo "<tr bgcolor='".$bgcolor."'><td>";
					echo str_repeat('&nbsp;&nbsp;',$level).$showDept; 					
					echo "</td>";					
					echo "<td>".$empName."</td>";
					$cntLadd = count($arrLadd[$empID]);
					//echo "\$cntLtran=$cntLtran<br>";
					if($cntLadd <= 1){
						echo "<td>".$arrLadd[$empID][0][0]."</td>";
						echo "<td>".$arrLadd[$empID][0][1]."</td>";
						echo "<td>".$arrLadd[$empID][0][2]."</td>";
						echo "<td>".$arrLadd[$empID][0][3]."</td>";
						echo "<td>".$arrLadd[$empID][0][4]."</td>";
					} //f($cntLadd <= 1){
					if($cntLadd > 1){
						foreach ($arrLadd[$empID] as $key =>$val){
							echo "<td>".$val[0]."</td>";
							echo "<td>".$val[1]."</td>";
							echo "<td>".$val[2]."</td>";
							echo "<td>".$val[3]."</td>";
							echo "<td>".$val[4]."</td>";
							if ($key < ($cntLadd - 1)) echo "<tr bgcolor='".$bgcolor."'><td colspan='2'></td>"  ;
						} //foreach ($arrLadd[$empID] as $key =>$val){
					} //if($cntLadd > 1){					
					echo "</tr>"; 	   										
					
				} //while ($rsEmp = fetch_array($dbtype, $result)){				
			} //if($numrow){
			else{
				/*
				echo "<tr><td>222";
				echo str_repeat('_',$level).$odetID." : ".$odetName; 
				echo "</td>";
				echo "<td>".$empName."</td>";
				echo "<td></td>";
				echo "<td></td>";
				echo "<td></td>";
				echo "</td></tr>"; 	   
				*/
			} //else{
		showLadd($dbtype, $dbname,$dbnameMaindata,$link,$linkMaindata, $odetID, $level+1,$bgcolor); 		   
	} //while ($rs = fetch_array($dbtype, $rst)){
}  //function showLadd($parent, $level) { 		

function getBossName($dbtype, $dbname, $link, $lang, $status, $verify, $approve, $hrdept)
{
	if ($status == 9 or $status == 12 or $status == 15 ) $data = $verify;
	else if ($status == 10 or $status == 11 or $status == 13) $data = $approve;
	else if ($status == 14  or $status == 16 or $status == 17  ) $data = $hrdept;
	if($data){
		$arrData = "";
		$arrData = explode("|",$data);
		foreach($arrData as $key => $val){
			$arrVal = explode(":",$val);
			list($empID,$per)=$arrVal;
			$per == "Y" || $per == "y" ? $result = $empID : 0 ;
			if ($result) break; 
		} //foreach($arrData as $key => $val){
		$result = $empID;
		$sql = " SELECT emp_ttitle, emp_tname, emp_tsurname, emp_etitle, emp_ename, emp_esurname ";
		$sql.= " FROM employee ";
		$sql.= " WHERE emp_id = $result";
		$query = db_query($dbtype, $dbname, $sql, $link);
		$rs = fetch_array($dbtype, $query);
		//$rs["emp_ttitle"].$rs["emp_etitle"].
		$lang == "th" ? $name = $rs["emp_tname"]."&nbsp;".$rs["emp_tsurname"]:
		$name = $rs["emp_ename"]."&nbsp;".$rs["emp_esurname"];
		return $name;
	} //if($data){
} // End function getBossName
function birthday($birthday){
	//calculate years of age (input string: YYYY-MM-DD)
    list($year,$month,$day) = explode("-",$birthday);
    $year_diff  = date("Y") - $year;
    $month_diff = date("m") - $month;
    $day_diff   = date("d") - $day;
    if ($day_diff < 0 || $month_diff < 0)
      $year_diff--;
    return $year_diff;
  } //function birthday ($birthday){

function backupData($dbtype, $dbname, $link, $tableName, $fieldName, $fieldVal) {
	$sql = "SELECT * 	FROM ".$tableName ;
	$sql .= " WHERE $fieldName = $fieldVal " ;
	//echo "backupData=<br>$sql<hr>";
	$res_fields = db_query($dbtype, $dbname, $sql, $link);
	$num_fields = num_fields($dbtype, $res_fields);
	
	while($rs = fetch_array($dbtype, $res_fields)){
		$arrData = array();
		$arrData["id"] = "";
		for($i = 0 ; $i < $num_fields ; $i++){		
			$fname = field_name($dbtype, $res_fields, $i) ;			
			if(substr($fname, -4) != "_cre" && substr($fname,-4) != "_upd" ){
				$fvalue = $rs["$fname"];
				$arrData["$fname"] = $fvalue;		
			} 
		} // for($i = 0 ; $i < $num_fields ; $i++){
		//echo "backupData=<br>";print_r($arrData);echo "<hr>";exit();
		$bk = updValue($dbtype, $dbname, $link, $tableName."b", "a", $fieldName, $fieldVal, $arrData);
	} //while($rs = fetch_array($dbtype, $res_fields)){	
} //function backupData($dbtype, $dbname, $link, $tableName, $fieldName, $fieldVal)

?>