<?
function generate_thebook($arr_loc = array(),$arr_eloc=array()){ 
    $thebook = '<table width="100%" cellspacing="3" class="calendar">'."\n". 
        '<caption class="calendar-month">'.$p.($month_href ? '<a href="'.htmlspecialchars($month_href).'">'.$title.'</a>' : $title).$n."</caption>\n"; 
		//Show caption
		$thebook .= '<tr><td>Date</td>'; 
		for($loc=0; $loc<count($arr_loc); $loc++){ 
			if(isset($arr_loc[$loc]) and is_array($arr_loc[$loc])){ 
				list($id, $shortname) = $arr_loc[$loc]; 
				$thebook .= '<td>'.$shortname.'</td>'; 
			}  //if(isset($arr_loc[$loc]) and is_array($arr_loc[$loc])){ 
		} //for($loc=0; $loc<count($arr_loc); $loc++){ 
		$thebook .= "</tr>";
		
		//Show Date
			
		for($date=1; $date<=31; $date++){ 				
			$thebook .= '<tr>';
			$thebook .= '<td>'.$date.'</td>';					
			
			for($loc=0; $loc<count($arr_loc); $loc++){ 
				list($id, $shortname) = $arr_loc[$loc];
				$cnt_event = 0;
				for($eloc=0; $eloc<count($arr_eloc); $eloc++){ 
					list($eid, $eshortname,$indate,$color) = $arr_eloc[$eloc];
						if($id==$eid  && $date == $indate)
							$cnt_event += 1;
							
				} //for($eloc=0; $eloc<count($arr_eloc); $eloc++){ 
				if ($cnt_event != 0){
					if ($cnt_event == 1)
						$temp = '<td bgcolor = "' .$color.  '">'.$eshortname ;
					else
						$temp = '<td bgcolor = "' .$color.  '">'.$cnt_event ." ".$eshortname ;
				}				
				else
					$temp =  '<td>&nbsp;' ;
					
				$thebook .= $temp .'</td>';
				
			} //for($loc=0; $loc<count($arr_loc); $loc++){ 
			
		}	//for($date=1; $date<=31; $date++){
		$thebook .= '</tr>';
		
		
		
	 return $thebook."</table>\n"; 
} 
?>
