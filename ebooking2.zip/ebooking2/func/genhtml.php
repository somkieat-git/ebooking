<?	
function viewForm() {
	include_once("DB/connect.func.php");
	include_once("DB/sql.func.php");
	$table_name = tableName;
	$updForm = updForm;
	$field_id = field_id;
	
	$result = get_viewForm($table_name,"","");
	$totalrecord = mysql_num_rows($result);
	$pagesize = 10;
	$totalpage = ceil($totalrecord/$pagesize);  
	
	if (empty($_REQUEST["pageno"]))
		$pageno =0;
	else
		$pageno = $_REQUEST["pageno"];		
	$pointer = $pageno * $pagesize;
	$result = get_viewForm($table_name,$pointer,$pagesize);
	$fieldname = get_table_fieldname($table_name); 
	$cnt_fieldname = count($fieldname);
?>

<html>
<head>
<title>viewForm => <?=$table_name?> </title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/thebook.css.php" rel="stylesheet" type="text/css">

</head>
<body>
<form name="viewForm" method="post" action="">
  <div align="center"></div>
  <div align="center"></div>
  <table width="760" border="1" align="center" cellpadding="2" cellspacing="2" bordercolor="#0033CC">
    <tr bgcolor="#E9FFD2">
      <td colspan=<?=$cnt_fieldname + 1?> bgcolor="#33CCFF" class="tblHeaders">Result :: <?= $totalrecord ?> &nbsp;records &nbsp;&nbsp;
	  	<a href="<?=$updForm?>?a=a">Insert <?=$table_name?></a><div align="right"></div></td>
    </tr>
    <tr bgcolor="#336600">
	 <?
		for ($i = 0; $i < $cnt_fieldname; $i++) 
		{
	?>
			<td class="tblHeadWarn"><div align="center" ><?=$fieldname[$i] ?></div></td>
	<?
		}
	?>	
		  <td  class="tblHeadWarn"><div align="center">Action</div></td>
    </tr>
	
    <? while($row=mysql_fetch_array($result)){ 
			if ($color == "#3399FF")
				$color = "#FFFFFF" ;
			else
				$color = "#3399FF" ;
			?>
		  
			<tr align="center" bgcolor="<?=$color?>">			
				 <?
					for ($i = 0; $i < $cnt_fieldname; $i++) 
					{
				?>
						<td class="navDrop"><?= $row[$i] ?></td>
				<?
					}
				?>	
					  <td width="6%" class="navDrop"> <a href="<?=$updForm?>?a=e&id=<?=$row["$field_id"]?>"> <img src="images/b_edit.png" alt="" border="0"> </a>
					  <a href="<?=$updForm?>?a=d&id=<?=$row["$field_id"]?>"> <img src="images/b_drop.png" alt="ź" border="0"> </a></td>
			</tr>
	
       <? } ?>
	   
    <tr align="center" bgcolor="#FFFFFF">
      <td colspan="9" class="tblHeaders"><div align="left">
        <?	
			//Control botton Prev
			$p =$pageno-1 ;
			if (($p) < 0 ) {
				echo "[".Prev."]";
				}
			else
				echo "[<a href='viewForm.php?pageno=$p&keyword=$keyword'> Prev </a>]";			
			
			for($i=0;$i<$totalpage;$i++)
				if ($i == $pageno)
					echo "[".($i+1)."]";
				else{
					echo "[<a href='viewForm.php?pageno=$i&keyword=$keyword'>".($i+1)."</a>]";					
				}
				
			//Control botton Next
			$n = $pageno+1 ;
			if (($n) > $totalpage-1 ){
				$totalpage =  $totalpage - 1;
				echo "[".Next."]";				
			}
			else
				echo "[<a href='viewForm.php?pageno=$n&keyword=$keyword'>Next</a>]";			
		  ?>
      </div></td>
    </tr>
  </table>
</form>
</body>
</html>
<?
}  //function viewForm() {

function updForm() {
	include_once("DB/connect.func.php");
	include_once("DB/sql.func.php");
	$updForm = updForm;
	$updSave = updSave;	
	$table_name = tableName;
	$field_id = field_id;
	$action = action;
	$id = id;
	$beg_id = beg_id;
	$end_id = end_id;
	
	echo "table_name = $table_name<br>field_id = $field_id<br> action = $action<br>id = $id<br>beg_id = $beg_id<br>end_id = $end_id<br>";
	if ($action == "a"){
		$caption = "Insert  "  ;
		$button = "Save";
	}
	if ($action == "e"){
		$caption = "Edit  "  ;
		$button = "Update";
	}
	if ($action == "d"){
		$caption = "Delete  "  ;
		$button = "Delete";
	}
	if(!empty($id)){
		$result = get_updForm($table_name,$field_id,$id);	
		$row=mysql_fetch_array($result);
	}
		$fieldname = get_table_fieldname($table_name); 
		$cnt_fieldname = count($fieldname);
?>
<html>
<head>
<title>updForm => <?=$table_name?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/thebook.css.php" rel="stylesheet" type="text/css">
</head>
	
<body>
<form action="<?=$updSave ?>" method="post" name="frm"  id="frm" >
  <table width="413" border="1" align="center" cellpadding="3" cellspacing="1" bordercolor="#336600">
    <tr bgcolor="#33CCFF">
      <td colspan="2" class="tblHeaders"><div align="center"><strong ><?=$caption.$table_name ?></strong></div></td>
    </tr>
	
	<?	for ($i = $beg_id; $i <= $end_id; $i++) {?>	
		<tr bgcolor="#00CCFF">
		  <td width="96" bgcolor="#00CCFF" class="tblHeadWarn" ><span ><?=$fieldname[$i] ?></span></td>
		  <td width="266" bgcolor="#3399FF" class="navDrop">
		  	<input name=<?=$fieldname[$i]?> 
			type=<? if($fieldname[$i] == "mem_pass") echo "password" ; else echo "text" ;	?> 
			id=<?=$fieldname[$i]?> value="<? if (!empty($id)) echo $row[$i]?>"></td>  
		</tr>
	<?
		} //for ($i = 1; $i < $cnt_fieldname; $i++)
	?>	
	
	
    <tr align="center" class="tblHeaders">
      <td colspan="2">	  	
	  	<input type="submit" name="Submit" value="<?=$button?>">
		<input name="Button" type="button" id="Submit" value="Cancel"  onClick="history.go(-1)" >      
		<input name="<?= $field_id ?>" type="hidden" id="<?=$field_id ?>" value="<? if (!empty($id)) echo $row["$field_id"]?>">
	   <input name="action" type="hidden" id="action" value="<?=$action ?>">
	  </td>
    </tr>
  </table>
</form>
</body>
</html>
<?	
}  //function updForm() {

?>

