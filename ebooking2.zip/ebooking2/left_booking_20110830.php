<?
	ob_start(); 
	session_start();	
	include("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	$b = $_REQUEST["s"];	
	$b = 1;
	$menu = array();
	$menu = getMenu($_SESSION["sec_view"],"B");
	$user_id = $_SESSION["UsrID"];
	//print_r(array_keys($menu));
	//echo "\$user_id=$user_id<br>";
	//echo "<pre>"; print_r($menu);
?>

<html>
<head>
	<title></title>	
	<link rel="stylesheet" href="css/format.css.css" type="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<body style="margin-left:11px;">
<table width="165px" class="BorderGreen" style="background-color: #F0F0F0;" cellspacing="0">
<a href="left_booking.php?s=<? echo !$b ;?>" >
	<tr style="background-color: #339900; color: White;">	
		<td width="16" align="center"><img src="images/dot.gif" height="12" width="12"></td>
		<td style="margin: 0 0 0 0; font-weight:bold;"><div align="center">Booking</div></td>
	</tr></a>
	<?
	if($b){
	foreach($menu as $menu=>$link) {
		if ($color == "#F0F0F0")
			$color = "#FFFFFF" ;
		else
			$color = "#F0F0F0" ;	
			
		($link == "usr_chgForm.php") ? $link = "usr_chgForm.php?id=$user_id" : 0 ;	
	?>
	<tr bgcolor="<?=$color ?>">
		<td width="16" style="padding: 3px;">&nbsp;</td>
		<td class="HeaderWhiteSmall">
			<a href="<?=$link ?>" target="frame_details">
			<?=$menu ?></a>
		</td>
	</tr>	
	<?
	} //foreach($menu as $menu=>$link) {
	} //if($b){
	?>	
</table>
<br>
<br>
<div align="center"></div>
</body>
</html>