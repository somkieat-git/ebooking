<?php
	ob_start(); 
	session_start();
		

	include_once("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");	
	define("updSave","erbk_updForm.php");
	
	$evn_id = $_REQUEST["id"];
	$action = $_REQUEST["a"];

	
	if(!empty($evn_id)){
		$sql = "SELECT * FROM eventname WHERE evn_id = '$evn_id'  ";
		$result = getData($sql);
		$row = mysql_fetch_array($result);
		$evn_fullname = $row["evn_fullname"];
	} //if(!empty($ev_id)){	
	
	
	
	
	// ==========  Booking Status Code  ================ //
	$sql = "SELECT * FROM bookingstatus ";
	$result = getData($sql);
	$bks_status = array();
	while( $row = mysql_fetch_array($result)){
		$bks_status[$row["bks_id"]] = $row["bks_code"] . " - " . $row["bks_name"];
	}
	//echo "<pre>"; print_r($bks_status); exit();


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Rebook Event - <?php echo $evn_id . " - " . $evn_fullname ; ?></title>
<link href="css/format.css.css" rel="stylesheet" type="text/css">

<!--------------  jQuery Datepick (Popup Calendra)  ---------------------->
	
	<link href="./css/jquery.datepick.css" type="text/css" rel="stylesheet" />
	<script type="text/javascript" src="lib/jquery.min.js"></script>	
	<script type="text/javascript" src="js/jquery.datepick.js"></script>
	<script type="text/javascript">
	$(function() {
		jQuery('#eloc_in_date').datepick({onSelect: ctrlButtonAdd 
		, rangeSelect: true
		, onDate: $.datepick.noWeekends
		, yearRange: '1980:2025' 
		, showTrigger: '#calImg'});
	});
	

	 
	</script>
	
	<script type="text/javascript">
	
		window.onload = function(){
			document.getElementById('add').disabled = true;
			document.getElementById('remove').disabled = true;
		};
	
		function addOption( in_date ){
			
			var bStatus = document.getElementById("hdd_bks").value ;
			var elOptNew = document.createElement('option');
				elOptNew.text = in_date.value + "           " + bStatus ;
				elOptNew.value = in_date.value+"|"+bStatus ;
			 
			var elSel = document.getElementById("list");
				elSel.add(elOptNew);
					
			clearForm();
		}
		
		function removeOptionSelected(){
			var elSel = document.getElementById("list");
			var i;
			 for (i = elSel.length - 1; i>=0; i--) {
				if (elSel.options[i].selected) {
				  elSel.remove(i);
				}
			 }
			 clearForm();
		}
		
		function chkDup(text){
			document.getElementById("hdd_bks").value = text;
		}
		
		function clearForm(){
			document.getElementById("eloc_in_date").value = "";
			document.getElementById("bks_id").selectedIndex = 0;
			document.getElementById("hdd_bks").value = "" ;	
			document.getElementById('add').disabled = true;		
			document.getElementById('remove').disabled = true;
		}
		
		function ctrlButtonAdd(){
			
			var in_date = document.getElementById("eloc_in_date").value ;
			if( in_date != "" ){
				document.getElementById('add').disabled = false;
			}else{
				document.getElementById('add').disabled = true;
			}
		}
		
		function ctrlButtonRemove(value){
			if(value != ""){
				document.getElementById('remove').disabled = false;
			}
		}

		function selectAll(list) {
			var arrList = new Array();
			for(var i=0; i<list.length; i++) {
				arrList[i] = list[i].value; // 09/01/2011|CF - Confirmed
				//alert(list[i].value);
			}
			 document.frm.hdd_list.value = arrList ;	
		}
		
	</script>

</head>

<body>
<br />
<form action="<?=$updSave ?>?id=<?php echo $evn_id ; ?>" method="post" name="frm"  id="frm" >
  <table border="0" class="BorderGreen" width="350">
    <tr class="BorderSilver">
      <td colspan="4" style="background-color:#339900;font-weight:bold;color:White;">
	  	<div align="center"><strong >Rebook Event - <?php echo $evn_id . " - " . $evn_fullname ; ?></strong></div>
	  </td>
    </tr>
	<tr>
		<td colspan="4">
			<table border="0" class="BorderGreen" width="450">
				<tr>
					<td colspan="2">In Date (Event Date) : </td>
					<td colspan="2">
						<input type="text" name="eloc_in_date" id="eloc_in_date" value="" />
						<div style="display: none;"> 
							<img id="calImg" src="images/calendar.gif" alt="Pick a date" class="trigger" > 
						</div>
					</td>
				</tr>
				<tr>
					<td colspan="2">Booking Status Code : </td>
					<td colspan="2">
						<select name="bks_id" id="bks_id" onchange="javascript:chkDup(this.options(selectedIndex).text);">
							<?php foreach( $bks_status as $bks_id => $bks_name ) :?>
								<option value="<?php echo $bks_id ; ?>"><?php echo $bks_name; ?></option>
							<?php endforeach;?>
						</select>
						<input type="hidden" id="hdd_bks" name="hdd_bks" value="" />
					</td>
				</tr>
				<tr>
					<td colspan="4">
						<div align="center">
							<input name="add" id="add" type="button" class="Button" value="Add" 
							onclick="javascript:addOption( document.frm.eloc_in_date );" >
							<input name="remove" id="remove"  type="button" class="Button" value="Remove" 
							onclick="javascript:removeOptionSelected();" >
						</div>
					</td>
				</tr>
			</table>
		</td>
	</tr>	
	<tr>
		<td colspan="4">
			<select name="list" id="list" size="10" multiple style="width:450px;" 
			onClick="javascript:ctrlButtonRemove(this.value);" >
			</select>
		</td>
	</tr>
    <tr align="center" >
      <td colspan="3">	  	
  	    <div align="center">
			<input name="Submit2" type="button" class="Button" value="&lt;= Back " onClick="window.location = 'ecus_updForm.php?id=<?=$evn_id?>'" >
			<input name="Submit" type="submit" class="Button" value="   OK   " <?=$disabled ;?> onClick="selectAll(document.frm.list);" >
			<input name="Button" type="button" class="Button" id="Button"  onClick="history.go(-1)" value="Cancel" >
			<input name="Submit22" type="button" class="Button" value="Next =&gt;" onClick="window.location = 'eloc_viewForm.php?id=<?=$evn_id?>'" >		  
			<input name="hdd_list" type="hidden" id="hdd_list" value="" />

		  </div></td>
    </tr>
  </table>
</form>


<?php 

// ========================  Save Rebook ================================= //

	$Submit = $_REQUEST["Submit"];
	
	if(!empty($Submit)){
		$evn_id = $_REQUEST["id"];
		$hdd_list = $_REQUEST["hdd_list"];
		$time = "0800";
		
		
		$data = array();
		$date_in_out = array();
		$date = array();
		$lst_value = array();
		$data = explode("," , $hdd_list); // result => 01/01/2011 - 01/01/2011|CF - Confirmed
		for($i=0; $i<sizeof($data); $i++){
			//echo $data[$i]; echo "<hr>";
			
			$lst_value = explode("|" , $data[$i]);
			$date_in_out = $lst_value[0];
			$status = $lst_value[1]; //echo "<hr>";
			
			
			$date_event =  explode(" - " , $date_in_out);
			$show_date = $date_event[0];
			$out_date = $date_event[1]; //echo "<hr>"; 			
			
			
			//echo $add_date = strtotime("tomorrow" , $out_date); echo "<hr>";
			
			
			list($dd_sh , $mm_sh , $yyyy_sh) = explode("/" , $show_date);
			$show_date = $yyyy_sh.$mm_sh.$dd_sh;
			
			list($dd_out , $mm_out , $yyyy_out) = explode("/" , $out_date);
			$out_date = $yyyy_out.$mm_out.$dd_out; 
			
			
			
			
			//$sql = "SELECT * FROM ev_location WHERE evn_id = $evn_id ";
//			$sql .= "AND eloc_event_date  = '$show_date' ";
			//$sql .= "OR eloc_out_date = '$out_date' ";
			//$sql .= "AND eloc_in_time = '$time' ";
			//echo "\$sql= $sql"; echo "<hr>";
			//$result = getData($sql);
//			$num_row = getNumRow($sql);
			
			
			//if( $num_row == 0 ){
				$valdate = chgDateToDb($in_date);
				$valbegtime = "0800";
				$valendtime = "1800";
				$usr_cre = $_SESSION["usr_name"];
				$date_cre = date("Y/m/d  H:i:s");		
				$val_date_cre = date("d/m/Y");
				
				if(strlen($mm_sh) < 2) $mm_sh = '0' . $mm_sh;
				$yymm_sh = substr($yyyy_sh,2,2).$mm_sh;
				$sql = "SELECT MAX(evn_id) as id FROM eventname
							 WHERE evn_id like '$yymm_sh%' ";
				$result = getData($sql);
				$row = mysql_fetch_array($result);
				
				if(is_null($row["id"]))
					$evn_id_new =  "$yymm_sh"."0001";
				else{
					$running = "99".substr($row["id"], 4)+1;
					$evn_id_new = "$yymm_sh".substr($running, 2);
				}
								 
			
				
				// ============= eventname =============//
				
				$sql = "SELECT * FROM eventname WHERE evn_id = '$evn_id' " ;
				$result = getData($sql);
				$row = mysql_fetch_array($result);
				$evn_shortname = $row["evn_shortname"];
				$evn_fullname = $row["evn_fullname"];
				$evn_thainame = $row["evn_thainame"];
				
				$query = "INSERT INTO eventname values(
					'$evn_id_new','$evn_shortname','$evn_fullname','$evn_thainame','Y','$usr_cre','$date_cre','',''
				) ";
				//echo "$query<br>";
				//mysql_query($query) or die("Insert table eventname error");		
				
				
				
				
				// ========  ev_statistics  ========= // 
				
				$sql_sta = "SELECT * FROM ev_statistics   
					WHERE evn_id = '$evn_id' ";
				//echo "$sql<hr>";
				$result_sta = getData($sql_sta);
				$row_sta = mysql_fetch_array($result_sta);
				$rtc_id = $row_sta["rtc_id"];
				$esta_atten = $row_sta["esta_atten"];
				$esta_num_session = $row_sta["esta_num_session"];
				
				
				
				$query = "INSERT INTO ev_statistics (evn_id, bks_id, rtc_id, esta_atten, esta_num_session,usr_cre, date_cre) VALUES('$evn_id_new', $status, $rtc_id, $esta_atten, $esta_num_session, '$usr_cre','$date_cre')";
				//echo "$query<br>";
				//mysql_query($query) or die("Insert table ev_statistics error");	
				
				
				
				
				
				// ========  ev_dateblock  ========= //
				
/*				$sql_dbk = "SELECT * FROM ev_dateblock   
					WHERE evn_id = '$evn_id' ";
				//echo "$sql<hr>";
				$result_dbk = getData($sql_dbk);
				$row_dbk = mysql_fetch_array($result_dbk);
				*/
				
				/*$query = "INSERT INTO ev_dateblock (evn_id, edbk_item,edbk_in_date, edbk_in_time, edbk_ev_begdate,
								edbk_ev_begtime, edbk_ev_enddate, edbk_ev_endtime, edbk_out_date, edbk_out_time,
								usr_cre, date_cre)
								VALUES('$evn_id_new', 0,'$valdate','$valbegtime', '$valdate','$valbegtime',
								'$valdate','$valendtime','$valdate','$valendtime','$usr_cre','$date_cre')
								";
				//echo "$query<br>";
				mysql_query($query) or die("Insert table ev_dateblock error");	*/


			
				// ===============  ev_customer ==================== //
				
				$sql_cus = "SELECT * FROM ev_customer WHERE evn_id = '$evn_id' ";
				$result_cus = getData($sql_cus);
				$row_cus = mysql_fetch_array($result_cus);
				$ecus_item = $row_cus["ecus_item"];
				$cus_id = $row_cus["cus_id"];
				$link_cus = $row_cus["link_cus"];
				
				
				$query = "INSER INSERT INTO ev_customer ( evn_id , ecus_item , cus_id , link_cus , usr_cre , date_cre , usr_upd , date_upd ) VALUES('$evn_id_new' , '$ecus_item' , '$cus_id' , '$link_cus' , '$usr_cre' , '$date_cre' , '' , '' )";
				
				//mysql_query($query) or die("Insert table ev_customer error");
				
				
				
				// ================= ev_staff =============== //
				
				$sql_staff = "SELECT * FROM ev_staff WHERE evn_id = '$evn_id' ";
				$result_staff = getData($sql_staff);
				$row_staff = mysql_fetch_array($result_staff);
				$estf_item = $row_staff["estf_item"];
				$usr_id = $row_staff["usr_id"];
				
				
				$query = "INSERT INTO ev_staff ( evn_id , estf_item , usr_id , usr_cre , date_cre , usr_upd , date_upd ) VALUES( '$evn_id_new' , '$estf_item' , '$usr_id' , '$usr_cre' , '$date_cre' , '' , '' )";
				
				//mysql_query($query) or die("Insert table ev_staff error");
				
				
				
				
				// ================ ev_location =================== //
				
				//$sql = "SELECT * FROM ev_location WHERE evn_id = '$evn_id' ";
				$sql = "SELECT * FROM ev_location WHERE evn_id = $evn_id ";
				$sql .= "AND eloc_event_date  = '$show_date' ";
				$num_row = getNumRow($sql);
			
			
				if( $num_row != 0 ){
				
					$result = getData($sql);
					$row = mysql_fetch_array($result);
					//$field_name = get_table_fieldname("ev_location");
					
					
					$value = array();
					$field_name = get_table_fieldname("ev_location");
					foreach( $field_name as $fKey => $fVal ){
						
						if( ereg("evn_id" , $fVal)){
							$row[$fVal] = $evn_id_new ;
						}
						
						if( ereg("eloc_event_date" , $fVal)){
							$row[$fVal] = $show_date ;
						}
						
						if( ereg("eloc_end_date" , $fVal)){
							$row[$fVal] = $out_date ;
						}
						
						//$eloc_in_date = $show_date - 1 ;
						//$eloc_end_date = $out_date + 1 ;
						
						if( ereg("bks_id" , $fVal)){
							$row[$fVal] = $status ;
						}
						
						if( ereg("usr_cre" , $fVal)){
							$row[$fVal] = $usr_cre ;
						}
						
						if( ereg("date_cre" , $fVal)){
							$$fVal = $date_cre ;
						}
						
						$value[$fVal] = $row[$fVal];
						
					}
					
					$query = create_insert_query("ev_location" , $value);
					//echo "\$query= $query"; echo "<hr>";
					
					//mysql_query($query) or die("Insert table ev_location error");
				
				}
				
				
				
				// ================ ev_equip_serv =================== //
				$sql = "SELECT * FROM ev_equip_serv WHERE evn_id = '$evn_id' ";
				$num_row = getNumRow($sql);
			
			
				if( $num_row != 0 ){
					$result = getData($sql);
					$row = mysql_fetch_array($result);
				
				
				
					$value = array();
					$field_name = get_table_fieldname("ev_equip_serv");
					foreach( $field_name as $fKey => $fVal ){
						
						if( ereg("evn_id" , $fVal)){
							$row[$fVal] = $evn_id_new ;
						}
						
						if( ereg("usr_cre" , $fVal)){
							$row[$fVal] = $usr_cre ;
						}
						
						if( ereg("date_cre" , $fVal)){
							$row[$fVal] = $date_cre ;
						}
						
						$value[$fVal] = $row[$fVal];
						
					}
					
					$query = create_insert_query("ev_equip_serv" , $value);
					//echo "\$query= $query"; echo "<hr>";
					
					//mysql_query($query) or die("Insert table ev_equip_serv error");
				
				}
				
				
				
				
				// ================ ev_food_serv =================== //
				
				$sql = "SELECT * FROM ev_food_serv WHERE evn_id = '$evn_id' ";
				$num_row = getNumRow($sql);
				
				if( $num_row != 0 ){
					$result = getData($sql);
					$row = mysql_fetch_array($result);
					
					$value = array();
					$field_name = get_table_fieldname("ev_food_serv");
					foreach( $field_name as $fKey => $fVal ){
						
						if( ereg("evn_id" , $fVal)){
							$row[$fVal] = $evn_id_new ;
						}
						
						if( ereg("usr_cre" , $fVal)){
							$row[$fVal] = $usr_cre ;
						}
						
						if( ereg("date_cre" , $fVal)){
							$row[$fVal] = $date_cre ;
						}
						
						$value[$fVal] = $row[$fVal];
					}
					
					
					$query = create_insert_query("ev_food_serv" , $value);
					//echo "\$query= $query";
					
					//mysql_query($query) or die("Insert table ev_food_serv error");
				}
				
				
				
				
				// ================ ev_comment =================== //
				
				$sql = "SELECT * FROM ev_comment WHERE evn_id = '$evn_id' ";
				$num_row = getNumRow($sql);
				
				if( $num_row != 0 ){
					$result = getData($sql);
					$row = mysql_fetch_array($result);
					
					$value = array();
					$field_name = get_table_fieldname("ev_comment");
					foreach( $field_name as $fKey => $fVal ){
					
						if( ereg("evn_id" , $fVal)){
							$row[$fVal] = $evn_id_new ;
						}
						
						if( ereg("usr_cre" , $fVal)){
							$row[$fVal] = $usr_cre ;
						}
						
						if( ereg("date_cre" , $fVal)){
							$row[$fVal] = $date_cre ;
						}
						
						$value[$fVal] = $row[$fVal];
					}
					
					
					$query = create_insert_query("ev_comment" , $value);
					//echo "\$query= $query";
					
					//mysql_query($query) or die("Insert table ev_comment error");
				}
				
				
				// ================ ev_checklist  =================== //
				
				$sql = "SELECT * FROM ev_checklist  WHERE evn_id = '$evn_id' ";
				$num_row = getNumRow($sql);
				
				if( $num_row != 0 ){
					$result = getData($sql);
					$row = mysql_fetch_array($result);
					
					$value = array();
					$field_name = get_table_fieldname("ev_checklist ");
					foreach( $field_name as $fKey => $fVal ){
					
						if( ereg("evn_id" , $fVal)){
							$row[$fVal] = $evn_id_new ;
						}
						
						if( ereg("usr_cre" , $fVal)){
							$row[$fVal] = $usr_cre ;
						}
						
						if( ereg("date_cre" , $fVal)){
							$row[$fVal] = $date_cre ;
						}
						
						$value[$fVal] = $row[$fVal];
					}
					
					
					$query = create_insert_query("ev_checklist" , $value);
					//echo "\$query= $query";
					
					//mysql_query($query) or die("Insert table ev_checklist  error");
				}
				
				
				
				// ================ ev_dailyperday  =================== //
				
				$sql = "SELECT * FROM ev_dailyperday WHERE evn_id = '$evn_id' ";
				$num_row = getNumRow($sql);
				
				if( $num_row != 0 ){
					$result = getData($sql);
					$row = mysql_fetch_array($result);
					
					$value = array();
					$field_name = get_table_fieldname("ev_dailyperday");
					foreach( $field_name as $fKey => $fVal ){
					
						if( ereg("evn_id" , $fVal)){
							$row[$fVal] = $evn_id_new ;
						}
						
						if( ereg("usr_cre" , $fVal)){
							$row[$fVal] = $usr_cre ;
						}
						
						if( ereg("date_cre" , $fVal)){
							$row[$fVal] = $date_cre ;
						}
						
						$value[$fVal] = $row[$fVal];
					}
					
					
					$query = create_insert_query("ev_dailyperday" , $value);
					//echo "\$query= $query";
					
					//mysql_query($query) or die("Insert table ev_dailyperday error");
				}
				
				
				
				// ================ ev_schedule =================== //
				
				$sql = "SELECT * FROM ev_schedule WHERE evn_id = '$evn_id' ";
				$num_row = getNumRow($sql);
				
				if( $num_row != 0 ){
					$result = getData($sql);
					$row = mysql_fetch_array($result);
					
					$value = array();
					$field_name = get_table_fieldname("ev_schedule");
					foreach( $field_name as $fKey => $fVal ){
					
						if( ereg("evn_id" , $fVal)){
							$row[$fVal] = $evn_id_new ;
						}
						
						if( ereg("usr_cre" , $fVal)){
							$row[$fVal] = $usr_cre ;
						}
						
						if( ereg("date_cre" , $fVal)){
							$row[$fVal] = $date_cre ;
						}
						
						$value[$fVal] = $row[$fVal];
					}
					
					
					$query = create_insert_query("ev_schedule" , $value);
					//echo "\$query= $query";
					
					//mysql_query($query) or die("Insert table ev_schedule error");
				}
				
				
				// ================ ev_setup  =================== //
				
				$sql = "SELECT * FROM ev_setup WHERE evn_id = '$evn_id' ";
				$num_row = getNumRow($sql);
				
				if( $num_row != 0 ){
					$result = getData($sql);
					$row = mysql_fetch_array($result);
					
					$value = array();
					$field_name = get_table_fieldname("ev_setup");
					foreach( $field_name as $fKey => $fVal ){
					
						if( ereg("evn_id" , $fVal)){
							$row[$fVal] = $evn_id_new ;
						}
						
						if( ereg("usr_cre" , $fVal)){
							$row[$fVal] = $usr_cre ;
						}
						
						if( ereg("date_cre" , $fVal)){
							$row[$fVal] = $date_cre ;
						}
						
						$value[$fVal] = $row[$fVal];
					}
					
					
					$query = create_insert_query("ev_setup" , $value);
					//echo "\$query= $query";
					
					//mysql_query($query) or die("Insert table ev_setup error");
				}
				
				
				
				
				
			/*}else{
				echo "<script>
					alert ('Event Date is duplicate');
					history.go(-1);
				    </script>";	
			}*/

			
			
		}
		
		
		
			
			

	}



?>

</body>
</html>
