<?php
class ConManager{
	function getConnection(){
		//change to your database server/user name/password
		mysql_connect("localhost","root","NCC2009") or
		die("Could not connect: " . mysql_error());
		//change to your database name
		mysql_select_db("thebook16") or 
		die("Could not select database: " . mysql_error());
		mysql_query("SET NAMES 'utf8'");
	}
	
}
?>