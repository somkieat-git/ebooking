<?php
include_once("../ConnectionManager.php");
header('Content-type:text/javascript;charset=utf-8');

//This Edit Only
$tableName="equip_serv";
$fieldID="esv_id";
$arrFields=array(
"esv_id","esv_name","esv_dept","stt_id","esv_qty","esv_amt ","esv_status","esv_include_vat","usr_cre","date_cre","usr_upd","date_upd"
);  
//End


$json=json_decode(stripslashes($_POST["_gt_json"]));
$pageNo = $json->{'pageInfo'}->{'pageNum'};
$pageSize = $json->{'pageInfo'}->{'pageSize'};
if(!$pageSize) $pageSize = 10 ;


$conManager = new ConManager();
$conManager->getConnection();

/*
echo "json->action = "; echo $json->{'action'};echo "\n";
echo "json->deletedRecords = "; print_r($json->{'deletedRecords'});echo "\n";
echo "json->updatedRecords = "; print_r($json->{'updatedRecords'});echo "\n";
echo "json->insertedRecords = "; print_r($json->{'insertedRecords'});echo "\n";
*/
if($json->{'action'} == 'load'){
	
	//to get how many records totally.
	$sql = "select count(*) as cnt from $tableName";
	$handle = mysql_query($sql);
	$row = mysql_fetch_object($handle);
	$totalRec = $row->cnt;
	
	//make sure pageNo is inbound
	if($pageNo<1||$pageNo>ceil(($totalRec/$pageSize))){
	  $pageNo = 1;
	}
	
	
	//page index starts with 1 instead of 0
	$sql = "select * from $tableName limit " . ($pageNo - 1)*$pageSize . ", " . $pageSize;
	$handle = mysql_query($sql);	
	$retArray = array();
	while ($row = mysql_fetch_row($handle)) {
	  $retArray[] = $row;
	}
	
	
	$data = json_encode($retArray);
	$ret = "{data:" . $data .",\n";
	$ret .= "pageInfo:{totalRowNum:" . $totalRec . "},\n";
	$ret .= "pageInfo:{totalRowNum:" . $totalRec . ", pagesize:".$pageSize."},\n";
	$ret .= "recordType : 'array'}";
	echo $ret;
	
}elseif($json->{'action'} == 'save'){

  $sql = "";
  $params = array();
  $errors = "";
  
  //deal with those deleted
  $deletedRecords = $json->{'deletedRecords'};
  foreach ($deletedRecords as $value){
    $params[] = $value[0];
  }
  $sql = "delete from $tableName where $fieldID in (" . join(",", $params) . ")";
  if(mysql_query($sql)==FALSE){
    $errors .= mysql_error();
  }
  
  
  //deal with those updated
  $sql = "";  
  $updatedRecords = $json->{'updatedRecords'};
  $sumdata = count($arrFields); 
  foreach ($updatedRecords as $value){
	$set=""; 
	for ($i=0;$i<$sumdata;$i++) 
	{ 
		if (!empty($set)){ 
			$set=$set.","; 
		} 
		$set=$set.$arrFields[$i]."='".$value[$i]."'"; 
	} 
	$where="$fieldID=".$value[0];
	$sql="UPDATE ".$tableName." SET ".$set." WHERE ".$where; 
	//echo "$sql";
	  
	if(mysql_query($sql)==FALSE){
		$errors .= mysql_error();
	}
  } //foreach ($updatedRecords as $value){
  
  
  $cntInsert=count($json->{'insertedRecords'});
  if($cntInsert){
	  echo "json->insertedRecords = "; print_r($json->{'insertedRecords'});echo "\n";
  }//if($cntInsert){

  
  //deal with those inserted
  $sql = "";
  $insertedRecords = $json->{'insertedRecords'}; 
  $arrInsert=$insertedRecords;
  $sumdata = count($arrFields); 
  foreach ($arrInsert as $value){
  	$add="";$val="";
	for ($i=0;$i<$sumdata;$i++) 
	{ 
		if (empty($add)){ 
			$add="("; 
		}else{ 
			$add=$add.","; 
		} 
		
		if (empty($val)){ 
			$val="("; 
		}else{ 
			$val=$val.","; 
		} 
		$add=$add.$arrFields[$i]; 
		$val=$val."'".$value[$i]."'"; 
		
		
	} 
	$add=$add.")"; 
	$val=$val.")"; 
		
	$sql="INSERT INTO ".$tableName." ".$add." VALUES ".$val; 
	echo "$sql \n";
	
	if(mysql_query($sql)==FALSE){
      $errors .= mysql_error();
    }
	
  } //foreach ($insertedRecords as $value){

  $ret = "{success : true,exception:''}";
  echo $ret;
  
} //if($json->{'action'} == 'save'){




?>