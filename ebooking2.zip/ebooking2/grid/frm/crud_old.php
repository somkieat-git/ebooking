<?php
include_once("../ConnectionManager.php");
header('Content-type:text/javascript;charset=utf-8');

$TestType=($_POST['TestType']);
echo "$TestType";


//This Edit Only
$tableName="formname";
$fieldID="frm_id";
$arrFields=array(
"frm_id","frm_name","frm_menu","frm_status","frm_used","usr_cre","date_cre","usr_upd","date_upd"
);  
//End


$json=json_decode(stripslashes($_POST["_gt_json"]));
$pageNo = $json->{'pageInfo'}->{'pageNum'};
$pageSize = $json->{'pageInfo'}->{'pageSize'};
$pageSize ? $pageSize=10 : 0 ;


$conManager = new ConManager();
$conManager->getConnection();

/*
echo "json->action = "; echo $json->{'action'};echo "\n";
echo "json->deletedRecords = "; print_r($json->{'deletedRecords'});echo "\n";
echo "json->updatedRecords = "; print_r($json->{'updatedRecords'});echo "\n";
echo "json->insertedRecords = "; print_r($json->{'insertedRecords'});echo "\n";
*/
if($json->{'action'} == 'load'){
	
	//to get how many records totally.
	$sql = "select count(*) as cnt from $tableName";
	$handle = mysql_query($sql);
	$row = mysql_fetch_object($handle);
	$totalRec = $row->cnt;
	
	//make sure pageNo is inbound
	if($pageNo<1||$pageNo>ceil(($totalRec/$pageSize))){
	  $pageNo = 1;
	}
	
	
	//page index starts with 1 instead of 0
	$sql = "select * from $tableName limit " . ($pageNo - 1)*$pageSize . ", " . $pageSize;
	$handle = mysql_query($sql);	
	$retArray = array();
	while ($row = mysql_fetch_row($handle)) {
	  $retArray[] = $row;
	}
	
	
	$data = json_encode($retArray);
	$ret = "{data:" . $data .",\n";
	$ret .= "pageInfo:{totalRowNum:" . $totalRec . "},\n";
	$ret .= "recordType : 'array'}";
	echo $ret;
	
}elseif($json->{'action'} == 'save'){

  $sql = "";
  $params = array();
  $errors = "";
  
  //deal with those deleted
  $deletedRecords = $json->{'deletedRecords'};
  foreach ($deletedRecords as $value){
    $params[] = $value[0];
  }
  $sql = "delete from $tableName where $fieldID in (" . join(",", $params) . ")";
  if(mysql_query($sql)==FALSE){
    $errors .= mysql_error();
  }
  
  
  //deal with those updated
  $sql = "";  
  $updatedRecords = $json->{'updatedRecords'};
  $sumdata = count($arrFields); 
  foreach ($updatedRecords as $value){
	$set=""; 
	for ($i=0;$i<$sumdata;$i++) 
	{ 
		if (!empty($set)){ 
			$set=$set.","; 
		} 
		$set=$set.$arrFields[$i]."='".$value[$i]."'"; 
	} 
	$where="$fieldID=".$value[0];
	$sql="UPDATE ".$tableName." SET ".$set." WHERE ".$where; 
	//echo "$sql";
	  
	if(mysql_query($sql)==FALSE){
		$errors .= mysql_error();
	}
  } //foreach ($updatedRecords as $value){
  
  
  
  
  //deal with those inserted
  $arrCreate=$json->{'insertedRecords'};
  $cntInsert=count($arrCreate);
  //echo "cntInsert=$cntInsert\n";
  if($cntInsert){
  	  
	  //echo "arrCreate = "; print_r($arrCreate);echo "\n";	  
	  $sumdata = count($arrFields);
	  //echo "sumdata=$sumdata\n";
	  //echo "Start foreach\n";
	  
	  foreach ($arrCreate as $value){
		$add=0;$val=0;
		//echo "In foreach\n";		
		
		for ($i=1;$i<$sumdata;$i++){ 		 
			echo "In for i=$i \n";
			
			if (!$add){ 
				$add="( "; 
			}else{ 
				$add.=","; 
			} 
			
			if (!$val){ 
				$val="( "; 
			}else{ 
				$val.=","; 
			} 
			
			$add.=$arrFields[$i]; 			
			$val.="'".$value[$i]."'"; 
			//$val.="'".$i."'"; 
			
			echo $value[0];
			
		} //for ($i=0;$i<$sumdata;$i++)
		
		//echo "Out for i \n";		
		
		$add.=" )"; 
		$val.=" )"; 
		
			
		$sql="INSERT INTO ".$tableName." ".$add." VALUES ".$val; 
		//echo "$sql \n";
		
		if(mysql_query($sql)==FALSE){
		  $errors .= mysql_error();
		}
		
	  } //foreach ($insertedRecords as $value){	
	  //echo "End foreach\n";
  }//if($cntInsert){  
  
	
  $ret = "{success : true,exception:''}";
  echo $ret;
  
} //if($json->{'action'} == 'save'){




?>