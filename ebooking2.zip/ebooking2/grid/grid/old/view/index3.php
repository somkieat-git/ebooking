<?
//include("../../../header.php");
?>

<link rel="stylesheet" type="text/css" href="../grid/gt_grid.css" />
<link rel="stylesheet" type="text/css" href="../grid/skin/vista/skinstyle.css" />
<link rel="stylesheet" type="text/css" href="../grid/skin/china/skinstyle.css" />
<link rel="stylesheet" type="text/css" href="../grid/skin/mac/skinstyle.css" />

<script type="text/javascript" src="../grid/gt_msg_en.js"></script>
<script type="text/javascript" src="../grid/gt_msg_th.js"></script>
<script type="text/javascript" src="../grid/gt_grid_all.js"></script>
<script type="text/javascript" src="../grid/flashchart/fusioncharts/FusionCharts.js"></script>
<script type="text/javascript" src="../grid/calendar/calendar.js"></script>
<script type="text/javascript" src="../grid/calendar/calendar-setup.js"></script>
<script type="text/javascript" src="../grid/xml2json.js"></script>
    
<script type="text/javascript" >

var grid_demo_id = "myGrid1" ;


var dsOption= {

	fields :[
		{name : 'order_no'  },
		{name : 'employee'  },
		{name : 'country'  },
		{name : 'customer'  },
		{name : 'order2005' ,type: 'float' },
		{name : 'order2006' ,type: 'float' },
		{name : 'order2007' ,type: 'float' },
		{name : 'order2008' ,type: 'float' },
		{name : 'delivery_date' ,type:'date'  }
		
	],
	recordType : 'object'
}

var colsOption = [
     {id: 'order_no' , header: "Order No" , width :60 , sortable : false },
     {id: 'employee' , header: "Employee" , width :80  },
	   {id: 'country' , header: "Country" , width :70  },
	   {id: 'customer' , header: "Customer" , width :80  },
	   {id: 'order2005' , header: "2005" , width :60},
	   {id: 'order2006' , header: "2006" , width :60},
	   {id: 'order2007' , header: "2007" , width :60},
	   {id: 'order2008' , header: "2008" , width :60},
	   {id: 'delivery_date' , header: "Delivery Date" , width :100}
       
];

var gridOption={
	id : grid_demo_id,
	loadURL : 'Controller.php',
	width: "100%",  //"100%", // 700,
	height: "200",  //"100%", // 330,
	container : 'gridbox', 
	replaceContainer : true, 
	encoding : 'utf-8', // Sigma.$encoding(), 
	dataset : dsOption ,
	columns : colsOption ,
	
	
	pageSize : 5 ,
	pageSizeList :[5,10,20,50,100],	
	resizable : true,
	showGridMenu : true,	
	allowCustomSkin	: true ,
	allowFreeze	: true ,
	allowHide	: true ,
	allowGroup	: true ,
	toolTip : false,
	lightOverRow : true,
	//language : 'th',
	
	//loadURL : './export_php/testList.php',
	exportURL : './export_php/Controller.php,?export=true',	
	exportFileName : 'test_export_doc.xls',
	
	
	toolbarContent : 'nav | pagesize | reload print xls pdf state',
	loadResponseHandler : function(response,requestParameter){
    var json=xml2json.parser(response.text);
    if(json.root.data.length&&json.root.data.length>1){//root.data is an array
        //mygrid.setContent({data:json.root.data, pageInfo:{totalRowNum:json.root.cnt}});
		mygrid.setContent({data:json.root.data, pageInfo:{totalRowNum:json.root.cnt} });
    }else{//root.data is object
        mygrid.setContent({data:[json.root.data], pageInfo:{totalRowNum:json.root.cnt} });
    }
    return true;
  }
};

var mygrid=new Sigma.Grid( gridOption );
Sigma.Util.onLoad(function(){mygrid.render()});


//////////////////////////////////////////////////////////

function doFilter() {
	var filterInfo=[
	{
		fieldName : "employee",
		//logic : "startWith",
		logic : "like",
		value : Sigma.Util.getValue("f_value1")
	}
	]
	var grid=Sigma.$grid("myGrid1");
	var rowNOs=grid.filterGrid(filterInfo); 
}




</script>


  <div id="content">    
	  <h2>Sigma Grid Sample - Loading From XML - Paginal Output</h2>
	  <ul>
          <li>Input first letters of employee name(case sensitive):<input type="text" id="f_value1" value="" onKeyUp="doFilter()"></li>

          <li>Grid will present orders of those employees whose name starts with your input just
          now.</li>
          <li>Note that employee names are case sensitive.</li>
    </ul>

    <div id="bigbox" style="margin:15px;display:!none;">
      <div id="gridbox" style="border:0px solid #cccccc;background-color:#f3f3f3;padding:5px;height:200px;width:700px;" ></div>
    </div>

  </div>
  
<?
include("../../../footer.php");
?>

