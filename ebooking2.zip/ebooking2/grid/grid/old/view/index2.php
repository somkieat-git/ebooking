<?

//require_once("mainfile.php");
//$PHP_SELF = "index.php";
//GETMODULE($_GET[name],$_GET[file]);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?=WEB_TITLE;?></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="">
<meta name="description" content="">

<link rel="shortcut icon" href="../../../images/favicon.ico" />
<link rel="stylesheet" href="../../../templates/joomla_admin/css/template_css.css" type="text/css" />
<link rel="stylesheet" href="../../../templates/joomla_admin/css/theme.css" type="text/css" />
<script language="JavaScript" src="../../../js/JSCookMenu_mini.js" type="text/javascript"></script>
<script language="JavaScript" src="../../../js/theme.js" type="text/javascript"></script>

<link rel="stylesheet" type="text/css" href="../grid/gt_grid.css" />
<link rel="stylesheet" type="text/css" href="../grid/skin/vista/skinstyle.css" />
<link rel="stylesheet" type="text/css" href="../grid/skin/china/skinstyle.css" />
<link rel="stylesheet" type="text/css" href="../grid/skin/mac/skinstyle.css" />

<script type="text/javascript" src="../grid/gt_msg_en.js"></script>
<script type="text/javascript" src="../grid/gt_msg_th.js"></script>
<script type="text/javascript" src="../grid/gt_grid_all.js"></script>
<script type="text/javascript" src="../grid/flashchart/fusioncharts/FusionCharts.js"></script>
<script type="text/javascript" src="../grid/calendar/calendar.js"></script>
<script type="text/javascript" src="../grid/calendar/calendar-setup.js"></script>
<script type="text/javascript" src="../grid/xml2json.js"></script>
    
<script type="text/javascript" >

var grid_demo_id = "myGrid1" ;


var dsOption= {

	fields :[
		{name : 'order_no'  },
		{name : 'employee'  },
		{name : 'country'  },
		{name : 'customer'  },
		{name : 'order2005' ,type: 'float' },
		{name : 'order2006' ,type: 'float' },
		{name : 'order2007' ,type: 'float' },
		{name : 'order2008' ,type: 'float' },
		{name : 'delivery_date' ,type:'date'  }
		
	],
	recordType : 'object'
}

var colsOption = [
     {id: 'order_no' , header: "Order No" , width :60 , sortable : false },
     {id: 'employee' , header: "Employee" , width :80  },
	   {id: 'country' , header: "Country" , width :70  },
	   {id: 'customer' , header: "Customer" , width :80  },
	   {id: 'order2005' , header: "2005" , width :60},
	   {id: 'order2006' , header: "2006" , width :60},
	   {id: 'order2007' , header: "2007" , width :60},
	   {id: 'order2008' , header: "2008" , width :60},
	   {id: 'delivery_date' , header: "Delivery Date" , width :100}
       
];

var gridOption={
	id : grid_demo_id,
	loadURL : 'Controller.php',
	width: "100%",  //"100%", // 700,
	height: "200",  //"100%", // 330,
	container : 'gridbox', 
	replaceContainer : true, 
	encoding : 'utf-8', // Sigma.$encoding(), 
	dataset : dsOption ,
	columns : colsOption ,
	
	
	pageSize : 5 ,
	pageSizeList :[5,10,20,50,100],	
	resizable : true,
	showGridMenu : true,	
	allowCustomSkin	: true ,
	allowFreeze	: true ,
	allowHide	: true ,
	allowGroup	: true ,
	toolTip : false,
	lightOverRow : true,
	//language : 'th',


	
	
	toolbarContent : 'nav | pagesize | reload print xls pdf state',
	loadResponseHandler : function(response,requestParameter){
    var json=xml2json.parser(response.text);
    if(json.root.data.length&&json.root.data.length>1){//root.data is an array
        //mygrid.setContent({data:json.root.data, pageInfo:{totalRowNum:json.root.cnt}});
		mygrid.setContent({data:json.root.data, pageInfo:{totalRowNum:json.root.cnt} });
    }else{//root.data is object
        mygrid.setContent({data:[json.root.data], pageInfo:{totalRowNum:json.root.cnt} });
    }
    return true;
  }
};

var mygrid=new Sigma.Grid( gridOption );
Sigma.Util.onLoad(function(){mygrid.render()});


//////////////////////////////////////////////////////////

function doFilter() {
	var filterInfo=[
	{
		fieldName : "employee",
		//logic : "startWith",
		logic : "like",
		value : Sigma.Util.getValue("f_value1")
	}
	]
	var grid=Sigma.$grid("myGrid1");
	var rowNOs=grid.filterGrid(filterInfo); 
}




</script>

</head>

<body>

<div id="wrapper">
	<div id="header">
			<div id="joomla"><img src="../../../templates/joomla_admin/images/header_text.png" alt="Joomla! Logo" /></div>
	</div>
</div>

<table width="100%" class="menubar" cellpadding="0" cellspacing="0" border="0">
<tr>
	<td class="menubackgr" style="padding-left:5px;">
		<div id="myMenuID"></div>

		<script language="JavaScript" type="text/javascript">
		var myMenu =
		[
			[null,'Home','index.php',null,'Control Panel'],
			_cmSplit,
			[null,'Site',null,null,'Site Management',
				['<img src="../includes/js/ThemeOffice/config.png" />','Global Configuration','index2.php?option=com_config&hidemainmenu=1',null,'Configuration'],
				['<img src="../includes/js/ThemeOffice/language.png" />','Language Manager',null,null,'Manage languages',
					['<img src="../includes/js/ThemeOffice/language.png" />','Site Languages','index2.php?option=com_languages',null,'Manage Languages'],
				],
			['<img src="../includes/js/ThemeOffice/media.png" />','Media Manager','index2.php?option=com_media',null,'Manage Media Files'],
			['<img src="../includes/js/ThemeOffice/preview.png" />', 'Preview', null, null, 'Preview',
				['<img src="../includes/js/ThemeOffice/preview.png" />','In New Window','http://localhost/joomla/index.php','_blank','http://localhost/joomla'],
				['<img src="../includes/js/ThemeOffice/preview.png" />','Inline','index2.php?option=com_admin&task=preview',null,'http://localhost/joomla'],
				['<img src="../includes/js/ThemeOffice/preview.png" />','Inline with Positions','index2.php?option=com_admin&task=preview2',null,'http://localhost/joomla'],
			],
			['<img src="../includes/js/ThemeOffice/globe1.png" />', 'Statistics', null, null, 'Site Statistics',
				['<img src="../includes/js/ThemeOffice/search_text.png" />', 'Search Text', 'index2.php?option=com_statistics&task=searches', null, 'Search Text']
			],
			['<img src="../includes/js/ThemeOffice/template.png" />','Template Manager',null,null,'Change site template',
				['<img src="../includes/js/ThemeOffice/template.png" />','Site Templates','index2.php?option=com_templates',null,'Change site template'],
				_cmSplit,
				['<img src="../includes/js/ThemeOffice/template.png" />','Administrator Templates','index2.php?option=com_templates&client=admin',null,'Change admin template'],
				_cmSplit,
				['<img src="../includes/js/ThemeOffice/template.png" />','Module Positions','index2.php?option=com_templates&task=positions',null,'Template positions']
			],
			['<img src="../includes/js/ThemeOffice/trash.png" />','Trash Manager','index2.php?option=com_trash',null,'Manage Trash'],
			['<img src="../includes/js/ThemeOffice/users.png" />','User Manager','index2.php?option=com_users&task=view',null,'Manage users'],
			],
			_cmSplit,
			[null,'Menu',null,null,'Menu Management',
			['<img src="../includes/js/ThemeOffice/menus.png" />','Menu Manager','index2.php?option=com_menumanager',null,'Menu Manager'],
			_cmSplit,
			['<img src="../includes/js/ThemeOffice/menus.png" />','mainmenu','index2.php?option=com_menus&menutype=mainmenu',null,''],
			['<img src="../includes/js/ThemeOffice/menus.png" />','othermenu','index2.php?option=com_menus&menutype=othermenu',null,''],
			['<img src="../includes/js/ThemeOffice/menus.png" />','topmenu','index2.php?option=com_menus&menutype=topmenu',null,''],
			['<img src="../includes/js/ThemeOffice/menus.png" />','usermenu','index2.php?option=com_menus&menutype=usermenu',null,''],
			],
			_cmSplit,
			[null,'Content',null,null,'Content Management',
			['<img src="../includes/js/ThemeOffice/edit.png" />','Content by Section',null,null,'Content Managers',
			['<img src="../includes/js/ThemeOffice/document.png" />','News', null, null,'News',
			['<img src="../includes/js/ThemeOffice/edit.png" />', 'News Items', 'index2.php?option=com_content&sectionid=1',null,null],
			['<img src="../includes/js/ThemeOffice/backup.png" />', 'News Archives','index2.php?option=com_content&task=showarchive&sectionid=1',null,null],
			['<img src="../includes/js/ThemeOffice/add_section.png" />', 'News Categories', 'index2.php?option=com_categories&section=1',null, null],
			],
			['<img src="../includes/js/ThemeOffice/document.png" />','Newsflashes', null, null,'Newsflashes',
			['<img src="../includes/js/ThemeOffice/edit.png" />', 'Newsflashes Items', 'index2.php?option=com_content&sectionid=2',null,null],
			['<img src="../includes/js/ThemeOffice/backup.png" />', 'Newsflashes Archives','index2.php?option=com_content&task=showarchive&sectionid=2',null,null],
			['<img src="../includes/js/ThemeOffice/add_section.png" />', 'Newsflashes Categories', 'index2.php?option=com_categories&section=2',null, null],
			],
			['<img src="../includes/js/ThemeOffice/document.png" />','FAQs', null, null,'FAQs',
			['<img src="../includes/js/ThemeOffice/edit.png" />', 'FAQs Items', 'index2.php?option=com_content&sectionid=3',null,null],
			['<img src="../includes/js/ThemeOffice/backup.png" />', 'FAQs Archives','index2.php?option=com_content&task=showarchive&sectionid=3',null,null],
			['<img src="../includes/js/ThemeOffice/add_section.png" />', 'FAQs Categories', 'index2.php?option=com_categories&section=3',null, null],
			],
			],
			_cmSplit,
			['<img src="../includes/js/ThemeOffice/edit.png" />','All Content Items','index2.php?option=com_content&sectionid=0',null,'Manage Content Items'],
			['<img src="../includes/js/ThemeOffice/edit.png" />','Static Content Manager','index2.php?option=com_typedcontent',null,'Manage Typed Content Items'],
			_cmSplit,
			['<img src="../includes/js/ThemeOffice/add_section.png" />','Section Manager','index2.php?option=com_sections&scope=content',null,'Manage Content Sections'],
			['<img src="../includes/js/ThemeOffice/add_section.png" />','Category Manager','index2.php?option=com_categories&section=content',null,'Manage Content Categories'],
			_cmSplit,
			['<img src="../includes/js/ThemeOffice/home.png" />','Front Page Manager','index2.php?option=com_frontpage',null,'Manage Front Page Items'],
			['<img src="../includes/js/ThemeOffice/edit.png" />','Archive Manager','index2.php?option=com_content&task=showarchive&sectionid=0',null,'Manage Archive Items'],
			['<img src="../includes/js/ThemeOffice/globe3.png" />', 'Page Impressions', 'index2.php?option=com_statistics&task=pageimp', null, 'Page Impressions'],
			],
			_cmSplit,
			[null,'Components',null,null,'Component Management',
			['<img src="../includes/js/ThemeOffice/component.png" />','Banners',null,null,'Banner Management',
			['<img src="../includes/js/ThemeOffice/edit.png" />','Manage Banners','index2.php?option=com_banners',null,'Active Banners'],
			['<img src="../includes/js/ThemeOffice/categories.png" />','Manage Clients','index2.php?option=com_banners&task=listclients',null,'Manage Clients']
			],
			['<img src="../includes/js/ThemeOffice/user.png" />','Contacts',null,null,'Edit contact details',
			['<img src="../includes/js/ThemeOffice/edit.png" />','Manage Contacts','index2.php?option=com_contact',null,'Edit contact details'],
			['<img src="../includes/js/ThemeOffice/categories.png" />','Contact Categories','index2.php?option=categories&section=com_contact_details',null,'Manage contact categories']
			],
			['<img src="../includes/js/ThemeOffice/mass_email.png" />','Mass Mail','index2.php?option=com_massmail&hidemainmenu=1',null,'Send Mass Mail'
			],
			['<img src="../includes/js/ThemeOffice/component.png" />','News Feeds',null,null,'News Feeds Management',
			['<img src="../includes/js/ThemeOffice/edit.png" />','Manage News Feeds','index2.php?option=com_newsfeeds',null,'Manage News Feeds'],
			['<img src="../includes/js/ThemeOffice/categories.png" />','Manage Categories','index2.php?option=com_categories&section=com_newsfeeds',null,'Manage Categories']
			],
			['<img src="../includes/js/ThemeOffice/component.png" />','Polls','index2.php?option=com_poll',null,'Manage Polls'
			],
			['<img src="../includes/js/ThemeOffice/component.png" />','Syndicate','index2.php?option=com_syndicate&hidemainmenu=1',null,'Manage Syndication Settings'
			],
			['<img src="../includes/js/ThemeOffice/globe2.png" />','Web Links',null,null,'Manage Weblinks',
			['<img src="../includes/js/ThemeOffice/edit.png" />','Web Link Items','index2.php?option=com_weblinks',null,'View existing weblinks'],
			['<img src="../includes/js/ThemeOffice/categories.png" />','Web Link Categories','index2.php?option=categories&section=com_weblinks',null,'Manage weblink categories']
			],
			],
			_cmSplit,
			[null,'Modules',null,null,'Module Management',
			['<img src="../includes/js/ThemeOffice/module.png" />', 'Site Modules', "index2.php?option=com_modules", null, 'Manage Site modules'],
			['<img src="../includes/js/ThemeOffice/module.png" />', 'Administrator Modules', "index2.php?option=com_modules&client=admin", null, 'Manage Administrator modules'],
			],
			_cmSplit,
			[null,'Mambots',null,null,'Mambot Management',
			['<img src="../includes/js/ThemeOffice/module.png" />', 'Site Mambots', "index2.php?option=com_mambots", null, 'Manage Site Mambots'],
			],
			_cmSplit,
			[null,'Installers',null,null,'Installer List',
			['<img src="../includes/js/ThemeOffice/install.png" />','Templates - Site','index2.php?option=com_installer&element=template&client=',null,'Install Site Templates'],
			['<img src="../includes/js/ThemeOffice/install.png" />','Templates - Admin','index2.php?option=com_installer&element=template&client=admin',null,'Install Administrator Templates'],
			['<img src="../includes/js/ThemeOffice/install.png" />','Languages','index2.php?option=com_installer&element=language',null,'Install Languages'],
			_cmSplit,
			['<img src="../includes/js/ThemeOffice/install.png" />', 'Components','index2.php?option=com_installer&element=component',null,'Install/Uninstall Components'],
			['<img src="../includes/js/ThemeOffice/install.png" />', 'Modules', 'index2.php?option=com_installer&element=module', null, 'Install/Uninstall Modules'],
			['<img src="../includes/js/ThemeOffice/install.png" />', 'Mambots', 'index2.php?option=com_installer&element=mambot', null, 'Install/Uninstall Mambots'],
			],
			_cmSplit,
			[null,'Messages',null,null,'Messaging Management',
			['<img src="../includes/js/ThemeOffice/messaging_inbox.png" />','Inbox','index2.php?option=com_messages',null,'Private Messages'],
			['<img src="../includes/js/ThemeOffice/messaging_config.png" />','Configuration','index2.php?option=com_messages&task=config&hidemainmenu=1',null,'Configuration']
			],
			_cmSplit,
			[null,'System',null,null,'System Management',
			['<img src="../includes/js/ThemeOffice/joomla_16x16.png" />', 'Version Check', 'http://www.joomla.org/latest10', '_blank','Version Check'],
			['<img src="../includes/js/ThemeOffice/sysinfo.png" />', 'System Info', 'index2.php?option=com_admin&task=sysinfo', null,'System Information'],
			['<img src="../includes/js/ThemeOffice/checkin.png" />', 'Global Checkin', 'index2.php?option=com_checkin', null,'Check-in all checked-out items'],
			],
			_cmSplit,
			[null,'Help','index2.php?option=com_admin&task=help',null,null]
		];
		cmDraw ('myMenuID', myMenu, 'hbr', cmThemeOffice, 'ThemeOffice');
		</script>
		
		</td>
		<td class="menubackgr" align="right">
			<a href="http://localhost/joomla" target="_blank">Preview</a>
		</td>
		<td class="menubackgr" align="right">
			<div id="wrapper1">		
				<div>
					<a href="index2.php?option=com_messages" style="color: black; text-decoration: none;">0 
						<img src="images/nomail.png" align="middle" border="0" alt="Mail" />
					</a>
				</div>
				<div>1 
					<img src="images/users.png" align="middle" alt="Users Online" />
				</div>		
			</div>
		</td>
		
		<td class="menubackgr" align="right" style="padding-right:5px;">
			<a href="index2.php?option=logout" style="color: #333333; font-weight: bold">
				Logout
			</a>
			<strong>admin</strong>		
		</td>
</tr>
</table>


<div id="page-container">   

  <div id="content">    
	  <h2>Sigma Grid Sample - Loading From XML - Paginal Output</h2>
	  <ul>
          <li>Input first letters of employee name(case sensitive):<input type="text" id="f_value1" value="" onKeyUp="doFilter()"></li>

          <li>Grid will present orders of those employees whose name starts with your input just
          now.</li>
          <li>Note that employee names are case sensitive.</li>
    </ul>

    <div id="bigbox" style="margin:15px;display:!none;">
      <div id="gridbox" style="border:0px solid #cccccc;background-color:#f3f3f3;padding:5px;height:200px;width:700px;" ></div>
    </div>

  </div>





<div align="center" class="footer">
	<table width="99%" border="0">
	<tr>
		<td align="center">
			<div align="center">
				<a href="">Web Application</a> by IT Dept.			
			</div>
			<div align="center" class="smallgrey">
				Web2.0 Create 2009-12-17<br />
				<a href="" target="_blank">Contact Developer</a>
			</div>
		</td>
	</tr>
	</table>
</div>

</body>
</html>
