<?php
include_once("../ConnectionManager.php");
header('Content-type:text/javascript;charset=utf-8');

$json=json_decode(stripslashes($_POST["_gt_json"]));
//$pageNo = $json->{'pageInfo'}->{'pageNum'};

$conManager = new ConManager();
$conManager->getConnection();

/*
echo "json->action = "; echo $json->{'action'};echo "\n";
echo "json->deletedRecords = "; print_r($json->{'deletedRecords'});echo "\n";
echo "json->updatedRecords = "; print_r($json->{'updatedRecords'});echo "\n";
echo "json->insertedRecords = "; print_r($json->{'insertedRecords'});echo "\n";
*/

if($json->{'action'} == 'load'){
  $sql = "select * from eventname";
  $handle = mysql_query($sql);
		
  $retArray = array();
  while ($row = mysql_fetch_object($handle)) {
    $retArray[] = $row;
  }
  $data = json_encode($retArray);
  $ret = "{data:" . $data .",\n";
  $ret .= "recordType : 'object'}";
  echo $ret;

}else if($json->{'action'} == 'save'){
  $sql = "";
  $params = array();
  $errors = "";
  
  //deal with those deleted
  $deletedRecords = $json->{'deletedRecords'};
  foreach ($deletedRecords as $value){
    $params[] = $value[0];
  }
  $sql = "delete from eventname where evn_id in (" . join(",", $params) . ")";
  if(mysql_query($sql)==FALSE){
    $errors .= mysql_error();
  }
  
  
  
  //deal with those updated
  $sql = "";
  $updatedRecords = $json->{'updatedRecords'};
  foreach ($updatedRecords as $value){
    $sql = "update `eventname` set ".
      "`evn_id`='".$value[0] . "', ".
      "`evn_shortname`='".$value[1] . "', ".
      "`evn_fullname`='".$value[2] . "', ".
      "`evn_used`='".$value[3] . "', ".
      "`usr_cre`='".$value[4] . "', ".
      "`date_cre`='".$value[5] . "', ".
      "`usr_upd`='".$value[6] . "', ".
      "`date_upd`='".$value[7] . "' ".
      " where `evn_id`='".$value[0]. "' ";
	  
	  //echo "$sql";
	  
      if(mysql_query($sql)==FALSE){
        $errors .= mysql_error();
      }
  } //foreach ($updatedRecords as $value){
  


  //deal with those inserted
  $sql = "";
  $insertedRecords = $json->{'insertedRecords'};
  foreach ($insertedRecords as $value){
    $sql = "insert into eventname (`evn_id`, `evn_shortname`, `evn_fullname`, `evn_used`,`usr_cre`, `date_cre`, `usr_upd`, `date_upd`) VALUES ('".
      $value->evn_id."', '".$value->evn_shortname."', '".$value->evn_fullname."', '".$value->evn_used."', '".$value->usr_cre."', '".$value->date_cre."', '".$value->usr_upd."',  '".$value->date_upd."')";
    if(mysql_query($sql)==FALSE){
      $errors .= mysql_error();
    }
  } //foreach ($insertedRecords as $value){
  
  

  $ret = "{success : true,exception:''}";
  echo $ret;
}




?>