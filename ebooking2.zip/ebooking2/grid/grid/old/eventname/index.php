<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd" -->
<html>
<head>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<title>Sigma Grid 2.0 JSON Array Paging Sample</title>


<link rel="stylesheet" type="text/css" href="modules/grid/grid/gt_grid.css" />
<link rel="stylesheet" type="text/css" href="modules/grid/grid/skin/vista/skinstyle.css" />
<link rel="stylesheet" type="text/css" href="modules/grid/grid/skin/china/skinstyle.css" />
<link rel="stylesheet" type="text/css" href="modules/grid/grid/skin/mac/skinstyle.css" />

<script type="text/javascript" src="modules/grid/grid/gt_msg_en.js"></script>
<script type="text/javascript" src="modules/grid/grid/gt_msg_th.js"></script>
<script type="text/javascript" src="modules/grid/grid/gt_grid_all.js"></script>
<script type="text/javascript" src="modules/grid/grid/flashchart/fusioncharts/FusionCharts.js"></script>
<script type="text/javascript" src="modules/grid/grid/calendar/calendar.js"></script>
<script type="text/javascript" src="modules/grid/grid/calendar/calendar-setup.js"></script>
<script type="text/javascript" src="modules/grid/grid/xml2json.js"></script>

    
    
<script type="text/javascript" >

var grid_demo_id = "myGrid1" ;
var grid_demo_id2 = "myGrid2" ;



var dsOption= {

	fields :[
		{name : 'evn_id' },
		{name : 'evn_shortname' },
		{name : 'evn_fullname' },
		{name : 'evn_used' },
		{name : 'usr_cre' },
		{name : 'date_cre' ,type: 'date' },
		{name : 'usr_upd' },
		{name : 'date_upd' ,type: 'date' }
	],
	recordType : 'array'
}


var colsOption = [
	//{id: 'chk' ,isCheckColumn : true, 	editable:false,frozen : true },
	//{id: 'evn_id' , header: "Event ID" , width :60 ,frozen : true },
	
	{ id : 'evn_id'    , header : "Event ID" , width : 100 ,  editable:false ,
    renderer : function(value ,record,columnObj,grid,colNo,rowNo){
				return '<a target=blank href="http://www.' + value + '.com">' + value + '</a>';
				}	
	},	
	
	
	{id: 'evn_shortname' , header: "Short Name" , width :80 , editor:{type:'text'}},
	{id: 'evn_fullname' , header: "Full Name" , width :200, editor : { type :"text" }},	  
	{id: 'evn_used' , header: "Used " , width :150,editor: { type :"select" ,options : {'Y': 'Yes' ,'N':'No' ,'C':'Cancel'},defaultText : 'Y'  }},
	{id: 'usr_cre' , header: "User Create" , width :80 , editor: { type :"text" }},
	{id: 'date_cre' , header: "Date Create" , width :80 , editor: { type :"date" }},
	{id: 'usr_upd' , header: "User Update" , width :80 , editor: { type :"text"}},
	{id: 'date_upd' , header: "Date Update" , width :80 , editor: { type :"date" }}  
];



var gridOption={
	id : grid_demo_id,
	loadURL : 'modules/grid/eventname/Controller_view.php',
	saveURL : 'modules/grid/eventname/Controller_crud.php',
	width: "100%",  //"100%", // 700,
	height: "300",  //"100%", // 330,
	container : 'gridbox', 
	replaceContainer : true, 
	
	//showIndexColumn : true,	
	//SigmaGridPath : '../grid/',	
	
	/*
	beforeSave : function(reqParam){
		alert(Sigma.toJSONString(reqParam) ) ;
		//Sigma.toJSONString(reqParam);
		alert(Sigma.toJSONString(reqParam) ) ;		
		return true;
	},
	*/
	
	showGridMenu : true,	
	allowCustomSkin	: true ,
	allowFreeze	: true ,
	allowHide	: true ,
	allowGroup	: true ,
	
	resizable : true,
	encoding : 'utf-8', // Sigma.$encoding(), 
	dataset : dsOption ,
	columns : colsOption ,
	clickStartEdit : true ,
	defaultRecord : {'evn_id':"2009",'evn_shortname':"Test",'evn_fullname':"Test",'evn_used':"Y",'usr_cre':"",'date_cre':"",'usr_upd':"",'date_upd':""},
	pageSize : 5 ,
	pageSizeList : [5,10,15,20,30],		
	toolbarPosition : 'bottom',
	toolbarContent : 'nav | goto | pagesize | reload  | csv xls xml chart  pdf filter | add del save | state'
	
};
/*
var gridOption2={
	id : grid_demo_id2,
	width: "700",  //"100%", // 700,
	height: "200",  //"100%", // 330
	container : 'gridbox2', 
	replaceContainer : true,
	showGridMenu : true,
	allowCustomSkin	: true ,
	allowFreeze	: true ,
	allowHide	: true ,
	allowGroup	: true ,
	toolbarContent : 'nav',
	dataset : dsOption ,
	columns : colsOption
};
*/

var mygrid=new Sigma.Grid( gridOption );
Sigma.Util.onLoad(function(){mygrid.render()});

//var mygrid2=new Sigma.Grid( gridOption2 );
//Sigma.Util.onLoad( Sigma.Grid.render(mygrid2) );




//////////////////////////////////////////////////////////

function doFilter() {
	var filterInfo=[
	{
		fieldName : "evn_fullname",
		logic : "startWith",
		value : Sigma.Util.getValue("f_value1")
	}
	]
	var grid=Sigma.$grid("myGrid1");
	var rowNOs=grid.filterGrid(filterInfo); 
}




</script>
</head>
<body>

<div id="page-container">
   
  <div id="content">
    
	  <h2>&nbsp;Sigma Grid Sample - Loading From JSON Array - Paginal Output</h2>
	  <ul>
          <li>Input first letters of employee name(case sensitive):<input type="text" id="f_value1" value="" onKeyUp="doFilter()"></li>

          <li>Grid will present orders of those employees whose name starts with your input just
          now.</li>
          <li>Note that employee names are case sensitive.</li>
    </ul>

    <div id="bigbox" style="margin:15px;display:!none;">
      <div id="gridbox" style="border:0px solid #cccccc;background-color:#f3f3f3;padding:5px;height:200px;width:700px;" ></div>
    </div>

  </div>

</div>

</body>
</html>