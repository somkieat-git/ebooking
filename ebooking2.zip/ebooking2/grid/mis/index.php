<?
	$tbrContent="toolbarContent : 'nav | goto | pagesize | reload |  mybtn-add  save | state'";
	$pageSizeList="pageSizeList : [5,10,15,20,30,50,100,1000,2000]";
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd" -->
<html>
<head>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<title>Sigma Grid 2.0 JSON Array Paging Sample</title>


<link rel="stylesheet" type="text/css" href="../grid/gt_grid.css" />
<link rel="stylesheet" type="text/css" href="../grid/skin/default/skinstyle.css" />
<link rel="stylesheet" type="text/css" href="../grid/skin/default/skinstyle.css" />
<link rel="stylesheet" type="text/css" href="../grid/skin/vista/skinstyle.css" />
<link rel="stylesheet" type="text/css" href="../grid/skin/china/skinstyle.css" />
<link rel="stylesheet" type="text/css" href="../grid/skin/mac/skinstyle.css" />
<link rel="stylesheet" type="text/css" media="all" href="../grid/calendar/calendar-blue.css"  />

<script type="text/javascript" src="../grid/gt_msg_en.js"></script>
<script type="text/javascript" src="../grid/gt_msg_th.js"></script>
<script type="text/javascript" src="../grid/gt_grid_all.js"></script>
<script type="text/javascript" src="../grid/flashchart/fusioncharts/FusionCharts.js"></script>
<script type="text/javascript" src="../grid/calendar/calendar.js"></script>
<script type="text/javascript" src="../grid/calendar/calendar-setup.js"></script>
<script type="text/javascript" src="../grid/xml2json.js"></script>

    
    
<script type="text/javascript" >

var grid_demo_id = "myGrid1" ;
var dsOption= {

	fields :[
		{name : 'mis_id' },
		{name : 'mis_type' },
		{name : 'mis_code' },
		{name : 'mis_name' },
		{name : 'mis_used' },
		{name : 'usr_cre' },
		{name : 'date_cre'},
		{name : 'usr_upd' },
		{name : 'date_upd' }
			
	],
	recordType : 'array'
}


var colsOption = [
	{ id : 'mis_id' , header : "ID" , width :50 ,  editor:false,
    renderer : function(value ,record,columnObj,grid,colNo,rowNo){
				return '<a target=frame_details href="../../mis_updForm.php?a=e&id=' + value + '">' + value + '</a>';
				}		
	},		
	{id: 'mis_type' , header: "Type" , width :200 , editor:{type:"text"}},
	{id: 'mis_code' , header: "Code" , width :100, editor : {type :"text"}},	  
	{id: 'mis_name' , header: "Name " , width :150,editor: {type :"text"}},
	{id: 'mis_used' , header: "used" , width :80 , editor:{type :"text"}},	
	{id: 'usr_cre' , header: "User Create" , width :80 , editor:false},
	{id: 'usr_upd' , header: "Date Create" , width :80 , editor:false} , 
	{id: 'usr_upd' , header: "User Update" , width :80 , editor:false} , 
	{id: 'date_upd' , header: "Date Update" , width :80 , editor:false}  
	
];

Sigma.ToolFactroy.register(
    'mybtn-add',  
    {
        cls : 'mybtn-add',  
        toolTip : 'Add',
        action : function(event,grid) {  
		//alert( 'The id of this grid is  '+grid.id) 
		 window.open ("../../mis_updForm.php?a=a", "frame_details" );		
		}
    }
);


var gridOption={
	id : grid_demo_id,
	loadURL : 'crud.php',
	saveURL : 'crud.php',
	width: "100%",  //"100%", // 700,
	height: "300",  //"100%", // 330,
	container : 'gridbox', 
	replaceContainer : true, 
	
	showGridMenu : true,	
	//allowCustomSkin	: true ,
	allowFreeze	: true ,
	allowHide	: true ,
	allowGroup	: true ,
	
	resizable : true,
	//encoding : 'utf-8', // Sigma.$encoding(), 
	dataset : dsOption ,
	columns : colsOption ,
	clickStartEdit : true ,
	//defaultRecord : {'evn_id':"2009",'evn_shortname':"Test",'evn_fullname':"Test",'evn_used':"Y",'usr_cre':"",'date_cre':"",'usr_upd':"",'date_upd':""},
	pageSize : 10 ,
	//pageSizeList : [10,15,20,30,50,100],	
	<?=$pageSizeList;?>,	
	toolbarPosition : 'bottom',
	
	<?=$tbrContent;?>
	
	//toolbarContent : 'nav | goto | pagesize | reload | mybtn-add del save | state'
	//toolbarContent : 'nav | goto | pagesize | reload  | csv xls xml chart  pdf filter | add del save | state'
	
};


var mygrid=new Sigma.Grid( gridOption );
Sigma.Util.onLoad(function(){mygrid.render()});


function doFilter() {
    var filterInfo=[
    {
        fieldName : Sigma.Util.getValue("f_fieldName1"),
        logic : Sigma.Util.getValue("f_logic1"),
        value : Sigma.Util.getValue("f_value1")
    }
    ]
    var grid=Sigma.$grid("myGrid1");
    var rowNOs=grid.filterGrid(filterInfo); 
}


function doUnfilter(){
    var grid=Sigma.$grid("myGrid1");
    var rowNOs=grid.unfilterGrid();
}

</script>
</head>
<body>

<div id="page-container">
   
  <div id="content">
  
  
  		<table class="adminheading" width="100%">
		<tr>
			<th class="menus" width="50%" align="left">Miscelanous Code</th>		
			<td width="50%"><table  border="0" align="right">
                <tr align="right">
                  <td align="right">
				  <select name="select" id="f_fieldName1" style="width:150px;">
                    <option value="mis_id" >ID</option>
                    <option value="mis_type" >Type</option>
                    <option value="mis_code" >Code</option>
                    <option value="mis_name" >Department</option>
                  </select></td>
                  <td align="right">
				    <select name="select2" id="f_logic1">
						<option value="equal">=</option>
						<option value="notEqual">!=</option>
						<option value="less">&lt;</option>
						<option value="great">&gt;</option>
						<option value="lessEqual">&lt;=</option>
						<option value="greatEqual">&gt;=</option>
						<option value="like" selected="selected">like</option>
						<option value="startWith">startWith</option>
						<option value="endWith">endWith</option>
				    </select>				  </td>
                  <td><input name="text" type="text" id="f_value1" value="" onKeyUp="doFilter()"/></td>
                </tr>
                <tr>
                  <td colspan="3" align="right">
					<input name="button" type="button" onclick="doFilter()" value="Filter" />
					<input name="button" type="button" onclick="doUnfilter()" value="Unfilter" />				  </td>
                </tr>
              </table></td>
		</tr>		
	</table>
    
    
      <div id="bigbox" style="margin:15px;display:!none;">
      <div id="gridbox" style="border:0px solid #cccccc;background-color:#f3f3f3;padding:5px;height:200px;width:700px;" ></div>
    </div>

  </div>

</div>

</body>
</html>