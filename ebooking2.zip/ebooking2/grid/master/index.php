<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd" -->
<html>
<head>
<meta http-equiv="Content-type" content="text/html; charset=utf-8" />
<title>Sigma Grid 2.0 JSON Array Paging Sample</title>


<link rel="stylesheet" type="text/css" href="modules/grid/grid/gt_grid.css" />
<link rel="stylesheet" type="text/css" href="modules/grid/grid/skin/vista/skinstyle.css" />
<link rel="stylesheet" type="text/css" href="modules/grid/grid/skin/china/skinstyle.css" />
<link rel="stylesheet" type="text/css" href="modules/grid/grid/skin/mac/skinstyle.css" />

<script type="text/javascript" src="modules/grid/grid/gt_msg_en.js"></script>
<script type="text/javascript" src="modules/grid/grid/gt_msg_th.js"></script>
<script type="text/javascript" src="modules/grid/grid/gt_grid_all.js"></script>
<script type="text/javascript" src="modules/grid/grid/flashchart/fusioncharts/FusionCharts.js"></script>
<script type="text/javascript" src="modules/grid/grid/calendar/calendar.js"></script>
<script type="text/javascript" src="modules/grid/grid/calendar/calendar-setup.js"></script>
<script type="text/javascript" src="modules/grid/grid/xml2json.js"></script>

    
    
<script type="text/javascript" >

var grid_demo_id = "myGrid1" ;
var dsOption= {

	fields :[
		{name : 'frm_id' },
		{name : 'frm_name' },
		{name : 'frm_menu' },
		{name : 'frm_status' },
		{name : 'frm_used' },
		{name : 'usr_cre' },
		{name : 'date_cre' ,type: 'date' },
		{name : 'usr_upd' },
		{name : 'date_upd' ,type: 'date' }
	],
	recordType : 'array'
}


var colsOption = [
	{ id : 'frm_id'    , header : "ID" , width : 100 ,  editor:false,
    renderer : function(value ,record,columnObj,grid,colNo,rowNo){
				return '<a target=blank href="frm_updForm.php?a=e&id=.' + value + '.com">' + value + '</a>';
				}		
	},		
	{id: 'frm_name' , header: "Name" , width :80 , editor:{type:'text'}},
	{id: 'frm_menu' , header: "Menu" , width :200, editor : { type :"text" }},	  
	{id: 'frm_status' , header: "Status " , width :150,editor: { type :"select" ,options : 
		{'B': 'Booking' ,'E':'Event' ,'M':'Master','R':'Report','X':'Cancel'},defaultText : 'B'  }},
	{id: 'frm_used' , header: "Short Name" , width :80 , editor:{ type :"select" ,options : 
		{'V': 'View' ,'VAED':'All' ,'VE':'View & Edit'},defaultText : 'V'  }},		
	{id: 'usr_cre' , header: "User Create" , width :80 , editor: { type :"text" }},
	{id: 'date_cre' , header: "Date Create" , width :80 , editor: { type :"date" }},
	{id: 'usr_upd' , header: "User Update" , width :80 , editor: { type :"text"}},	
	{id: 'date_upd' , header: "Date Update" , width :80 , editor: { type :"date" }}  
];


var gridOption={
	id : grid_demo_id,
	loadURL : 'modules/grid/frm/crud.php',
	saveURL : 'modules/grid/frm/crud.php',
	width: "100%",  //"100%", // 700,
	height: "300",  //"100%", // 330,
	container : 'gridbox', 
	replaceContainer : true, 
	
	showGridMenu : true,	
	//allowCustomSkin	: true ,
	allowFreeze	: true ,
	allowHide	: true ,
	allowGroup	: true ,
	
	resizable : true,
	//encoding : 'utf-8', // Sigma.$encoding(), 
	dataset : dsOption ,
	columns : colsOption ,
	clickStartEdit : true ,
	//defaultRecord : {'evn_id':"2009",'evn_shortname':"Test",'evn_fullname':"Test",'evn_used':"Y",'usr_cre':"",'date_cre':"",'usr_upd':"",'date_upd':""},
	pageSize : 10 ,
	pageSizeList : [5,10,15,20,30],		
	toolbarPosition : 'bottom',
	toolbarContent : 'nav | goto | pagesize | reload | add del save | state'
	//toolbarContent : 'nav | goto | pagesize | reload  | csv xls xml chart  pdf filter | add del save | state'
	
};


var mygrid=new Sigma.Grid( gridOption );
Sigma.Util.onLoad(function(){mygrid.render()});


function doFilter() {
    var filterInfo=[
    {
        fieldName : Sigma.Util.getValue("f_fieldName1"),
        logic : Sigma.Util.getValue("f_logic1"),
        value : Sigma.Util.getValue("f_value1")
    }
    ]
    var grid=Sigma.$grid("myGrid1");
    var rowNOs=grid.filterGrid(filterInfo); 
}


function doUnfilter(){
    var grid=Sigma.$grid("myGrid1");
    var rowNOs=grid.unfilterGrid();
}

</script>
</head>
<body>

<div id="page-container">
   
  <div id="content">
  
  
  		<table class="adminheading">
		<tr>
			<th class="menus" width="50%">Form</th>		
			<td width="50%"><table width="100%" border="0">
                <tr>
                  <td align="right">
					<select name="select" id="f_fieldName1" style="width:150px;">
						<option value="frm_id" >ID</option>
						<option value="frm_name" >Name</option>
						<option value="frm_menu" >Menu</option>
						<option value="frm_status" >Status</option>
						<option value="frm_used" >Used</option>
					</select>				  
				  </td>
                  <td align="right">
				    <select name="select2" id="f_logic1">
						<option value="equal">=</option>
						<option value="notEqual">!=</option>
						<option value="less">&lt;</option>
						<option value="great">&gt;</option>
						<option value="lessEqual">&lt;=</option>
						<option value="greatEqual">&gt;=</option>
						<option value="like" selected="selected">like</option>
						<option value="startWith">startWith</option>
						<option value="endWith">endWith</option>
				    </select>				  
				  </td>
                  <td><input name="text" type="text" id="f_value1" value="" onKeyUp="doFilter()"/></td>
                </tr>
                <tr>
                  <td colspan="3" align="right">
					<input name="button" type="button" onclick="doFilter()" value="Filter" />
					<input name="button" type="button" onclick="doUnfilter()" value="Unfilter" />				  
				  </td>
                </tr>
              </table></td>
		</tr>		
	</table>
    
    
      <div id="bigbox" style="margin:15px;display:!none;">
      <div id="gridbox" style="border:0px solid #cccccc;background-color:#f3f3f3;padding:5px;height:200px;width:700px;" ></div>
    </div>

  </div>

</div>

</body>
</html>