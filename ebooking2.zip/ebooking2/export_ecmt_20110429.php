<?php
	ob_start();
	session_start();
	$arrEcmt=$_SESSION["arrData"];	
	$evn_id =$_REQUEST["evn_id"];
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	
	header("Content-Type: application/vnd.ms-word");
	header('Content-Disposition: attachment; filename="EventComment.doc"');	
?>
<html xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:x="urn:schemas-microsoft-com:office:excel"
xmlns="http://www.w3.org/TR/REC-html40">
<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</HEAD><BODY>

<table width="90%" border="0" align="center" >
<?php 
	$sql = "SELECT * FROM eventname WHERE evn_id = '$evn_id'  ";
	$result = getData($sql);
	$row = mysql_fetch_array($result);
	$shortname = $row["evn_shortname"];
	$fullname = $row["evn_fullname"];
?>
	<tr >
      <td height="22" ><div align="center" class="showbooking"><strong>Event Comment </strong></div></td>
    </tr>
    <tr >
      <td  height="41" ><div align="center" class="showbooking"><strong><?=bchEname;?></strong></div></td>
    </tr>   
	<tr class="BorderSilver">
      <td colspan="3" >
        <div align="center">
          <hr width="100%" noshade  color="#339900">
		   <span class="showbooking">
		    <strong >Event - <?=$evn_id." - " .$fullname ?></strong>
           </span>
		  <hr width="100%" noshade  color="#339900">
       </div>
	  </td>
    </tr>
  </table>
<br />

 <table width="90%" align="center">
  	<tr>
	 <td>
	 	<table border="0" cellspacing="0" cellpadding="0" width="100%">
		  <tr>
			<td colspan="2" valign="top" style="height:27px;padding-left:10px;font-weight:bold;" ></td>
			<td valign="top" style="height:27px;padding-left:10px;font-weight:bold;font-size:12px;">User Update</td>
			<td valign="top" style="height:27px;padding-left:10px;font-weight:bold;font-size:12px;">Update Date</td>
		  </tr>
		  <?php 
		  $cntCol=0;$showTD="";
		  while (list($key, $value) = each($arrEcmt)){
		  	 foreach( $value as $fieldname => $val ){
			  $cntCol++;
			  $show = "<tr>";
			  $show .= " <td colspan='4' style='height:27px;padding-left:10px;font-weight:bold;'>";
			  $show .= "$value[ecmt_item]";
			  $show .= " </td>";
			  $show .= "</tr>";
			  $show .= "<tr>";
			  $show .= " <td width='40' height='36' valign='top'>&nbsp;</td>";
			  $show .= " <td style='font-size:12px;'>" . nl2br($value["ecmt_desc"]) ."</td>";
			  $show .= " <td style='font-size:12px;width:200px;'>$value[usr_upd]</td>";
			  $show .= " <td style='font-size:12px;width:130px;'>$value[date_upd]</td>";
			  $show .= "</tr>";
			 }	
			 echo $show;
		  }
		  
		 ?>		
		</table>		
	 </td>
	</tr>
	<tr>
	 <td colspan="4">
	  <hr width="100%" noshade  color="#339900">
	 </td>
	</tr>
 </table>
</BODY>
</HTML>