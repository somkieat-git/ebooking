<?php
	ob_start();
	session_start();
	$arrEcmt=$_SESSION["arrData"];	
	$evn_id = $_REQUEST["evn_id"];
	$beg_date = $_REQUEST["beg"];
	$end_date = $_REQUEST["end"];
	$r = $_REQUEST["r"];
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	
	//echo "<pre>"; print_r($arrEcmt);exit();
	
	header("Content-Type: application/vnd.ms-word");
	header('Content-Disposition: attachment; filename="EventComment.doc"');	
?>
<html xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:x="urn:schemas-microsoft-com:office:excel"
xmlns="http://www.w3.org/TR/REC-html40">
<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</HEAD><BODY>

<table width="90%" border="0" align="center" >

	<tr >
      <td height="22" ><div align="center" class="showbooking"><strong>Event Comment </strong></div></td>
    </tr>
    <tr >
      <td  height="41" ><div align="center" class="showbooking"><strong><?=bchEname;?></strong></div></td>
    </tr>  
<?php 
	$sql = "SELECT * FROM eventname WHERE evn_id = '$evn_id'  ";
	$result = getData($sql);
	$row = mysql_fetch_array($result);
	$shortname = $row["evn_shortname"];
	$fullname = $row["evn_fullname"];
?>
	<tr class="BorderSilver">
      <td colspan="3" >
	    <?php if($r) { ?>
		<div align="center">
          <span class="showbooking">
		   <strong >Event - <?=$evn_id." - " .$fullname ?></strong>
          </span>
       	</div>
		<?php }else{?>
        <div align="center">
           <span class="showbooking">
		     <strong>From Date : <?php echo $beg_date;?> &nbsp;&nbsp;&nbsp;To Date : <?php echo $end_date; ?></strong>
           </span>
		</div>
		<?php }?>
	  </td>
    </tr>
  </table>
<br />

 <table width="90%" align="center">
  	<tr>
	 <td>
	 	<table width="100%" border="0" cellspacing="0" cellpadding="0">
		  <tr><td colspan="5"><hr width="100%" noshade  color="#339900"></td></tr>
		  <tr>
			<td valign="top" style="height:27px;font-weight:bold;font-size:16px;">FirstDate</td>
			<td valign="top" style="height:27px;font-weight:bold;font-size:16px;">LastDate</td>
			<td valign="top" style="height:27px;font-weight:bold;font-size:16px;">Event Name </td>
			<td valign="top" style="height:27px;font-weight:bold;font-size:16px;">Event Mgr. </td>
			<td valign="top" style="height:27px;font-weight:bold;font-size:16px;">Description</td>
		  </tr>
		  <tr><td colspan="5"><hr width="100%" noshade  color="#339900"></td></tr>
		  <?php 
		   $cntCol=0;$showTD="";
		   while (list($kEvnID, $arrValue) = each($arrEcmt)){
			
			$show = "<tr>";
			foreach($arrValue as $type => $data){
			//foreach($arrEcmt as $type => $data){
			 switch($type){
				case "detail" :
					$show .= "<td valign=\"top\" width=\"10%\">$data[edbk_ev_begdate]</td>";
					$show .= "<td valign=\"top\" width=\"10%\">$data[edbk_ev_enddate]</td>";
					$show .= "<td valign=\"top\" width=\"25%\">$data[evn_shortname]</td>";
					$show .= "<td valign=\"top\" width=\"20%\">$data[usr_name]</td>";
					break;
				
				case "comment" :
					
					  $show .= "<td>";
					  $show .= "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">";
					  foreach($data as $key => $arrVal){
					   foreach($arrVal as $fieldname => $val){
						 if($fieldname <> "evn_id"){
							$show .= "<tr>";
							if($fieldname == "ecmt_item"){
							  $show .= "<td valign=\"top\"><strong>$val</strong></td>";
							}else{
							  $show .= "<td valign=\"top\">$val</td>";
							}
							$show .= "</tr>";
						 }
					   }
						$show .= "<tr>";
						$show .= "<td valign=\"top\">&nbsp;</td>";
						$show .= "</tr>";
					  }
					  $show .= "</table>";
					  $show .= "</td>";
					
					break;
			 }// switch($type){
			} // foreach($arrValue as $type => $data){				
			$show .= "</tr>";
			$show .= "<tr><td colspan=\"5\">&nbsp;</td></tr>";
			echo $show;
		  } // while (list($kEvnID, $arrValue) = each($arrData)){
		  ?>
		 </table>	
	 </td>
	</tr>
	<tr>
	 <td colspan="4">
	  <hr width="100%" noshade  color="#339900">
	 </td>
	</tr>
 </table>
</BODY>
</HTML>