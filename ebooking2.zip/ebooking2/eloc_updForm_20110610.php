<?	
	ob_start();
	session_start();
	//include("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	define("updSave","eloc_updForm.php");
	$evn_id = $_REQUEST["id"];
	$eloc_id =  $_REQUEST["id2"];
	$rtc_id =  $_REQUEST["id3"];
	$show = $_REQUEST["show"];
	//echo "\$evn_id = evn_id<br>\$eloc_id = $eloc_id<br>\$rtc_id = $rtc_id<br>";
	//echo "hdrtc_id = $hdrtc_id<br>";
	//======================Begin prepare standard data======================================
		
	if(!empty($evn_id)){
		$sql = "SELECT * FROM eventname WHERE evn_id = '$evn_id'  ";
		$result = getData($sql);
		$row = mysql_fetch_array($result);
		$disabled = "";
		//if($row[3] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;
		if($row["evn_used"] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;
		$evn_name = $row[1];
	} //if(!empty($ev_id)){	
		$sql = "SELECT bks_id, bks_code , bks_name  FROM bookingstatus 
					ORDER BY bks_code ";
		$resbook_status = getData($sql);	
		
	//======================Begin select data from ev_location===============================
	if (!empty($evn_id)  && !empty($eloc_id)){	
		#Show location
		$sql = "SELECT loc.loc_shortname, loc.loc_fullname, loc.loc_sqm 
					FROM location loc, ev_location eloc 
					WHERE  loc.loc_id = eloc.loc_id
					AND eloc.eloc_id = $eloc_id";
		//echo "$sql<br>";
		//exit();
		$result = getData($sql);
		$rs_loc = mysql_fetch_array($result);	
		$loc_name = $rs_loc[0]." - ".$rs_loc[1];
		$loc_sqm = $rs_loc[2];
		
		#show ev_location
		$sql = "SELECT * 
					FROM ev_location 
					WHERE eloc_id = $eloc_id";
		//echo "$sql<br>";
		$result = getData($sql);
		$numrow = mysql_num_rows($result);
		$rs_eloc = mysql_fetch_array($result);	
		$loc_id =  $rs_eloc[2];		
		$indate = $rs_eloc[3];
		$intime = $rs_eloc[4];
		$sindate =  chgDate($indate)."  ".chgTime($intime);
		$showdate =  chgDate($rs_eloc[5])." - ".chgDate($rs_eloc[7]);
		$showtime =  chgTime($rs_eloc[6])." - ".chgTime($rs_eloc[8]);
		$outdate =  chgDate($rs_eloc[9])."  ".chgTime($rs_eloc[10]);
		
		$bks_id = $rs_eloc[11];		
		$rtc_id = $rs_eloc[12];
		$show_qty = chgNumber($rs_eloc[13]) ;
		$show_amt = chgNumber($rs_eloc[14]) ;
		$show_total = chgNumber($rs_eloc[15]) ;
		$show_adj = chgNumber($rs_eloc[16]) ;
		$show_net = chgNumber($rs_eloc[17]) ;
		
		$inout_qty  = chgNumber($rs_eloc[18]); 
		$inout_amt  = chgNumber($rs_eloc[19]) ; 
		$inout_total  = chgNumber($rs_eloc[20]) ; 
		$inout_adj = chgNumber($rs_eloc[21]) ;
		$inout_net = chgNumber($rs_eloc[22]) ;
		
		$out_qty  = chgNumber($rs_eloc[23]) ; 
		$out_amt  = chgNumber($rs_eloc[24]) ; 
		$out_total  = chgNumber($rs_eloc[25]) ; 			
		$out_adj = chgNumber($rs_eloc[26]) ;
		$out_net = chgNumber($rs_eloc[27]) ;
		
		$g_total = chgNumber($rs_eloc[28]);
		$g_adj = chgNumber($rs_eloc[29]);			
		$g_net = chgNumber($rs_eloc[30]);			
		
		$eloc_seat_type = $rs_eloc[31];
		$eloc_room_code = $rs_eloc[32];
		$eloc_atten = chgNumber($rs_eloc[33]);
		$eloc_num_session = chgNumber($rs_eloc[34]);
		$eloc_sqm = chgNumber($rs_eloc[35]);
		if($eloc_sqm==0) $eloc_sqm = $loc_sqm;

	} //if (!empty($evn_id)){			
		
		$sql = "SELECT rtc_id, rtc_code , rtc_name  FROM ratecode ";
		$sql .= " where ( rtc_used = 'Y' or  rtc_id = ".$rtc_id ." )";
		$sql .= " ORDER BY rtc_code ";
		//echo "ratecode=$sql<hr>";		
		$resrate_code = getData($sql);			
		$arr_rtc = array();
		while( $row = mysql_fetch_array($resrate_code)){
			$arr_rtc[] = $row[0].",".$row[1].",".$row[2] ;
		}
		/*
		$sql = "SELECT show_amt, inout_amt, out_amt  FROM sub_ratecode 
					WHERE  loc_id = $loc_id ";
		$result = getData($sql);				
		*/
		
		$seat_type = "Seating Type";
		$room_code = "Room Use Code";			
		$sql = "SELECT * FROM miscode 
					ORDER BY mis_type ASC,  mis_code ASC ";
		$result = getData($sql);		
		$arrseat_type = array();
		$arrroom_code = array();	
		
		while( $row = mysql_fetch_array($result)){
			if ($row["mis_type"] == $seat_type ){
				$arrseat_type[]= $row["mis_code"]." - ".$row["mis_name"];
			} 			
			if ($row["mis_type"] == $room_code ){
				$arrroom_code[]= $row["mis_code"]." - ".$row["mis_name"];
			}
		} //while( $row = mysql_fetch_array($result)){
	
		
	//======================End prepare stand data========================================


	
?>
<html>
<script language="javascript">
	function validate() 
	{
		if(frm.bks_id.value==1)
		{
			alert('Please input data in Booking Status Code');
			frm.bks_id.focus()
			return false;
		}
		if(frm.rtc_id.value==1)
		{
			alert('Please input data in Rate Code');
			frm.rtc_id.focus()
			return false;
		}
	}
	
	function replaceAll(txt, replace, with_this) {
	  return txt.replace(new RegExp(replace, 'g'),with_this);
	}//replaceAll(document.frm.txtShow_adj.value, ',', '')
	
	function click_rtc() {	
		var x1, x2 
		var y1, y2 
		var val1, val2, val3 ,val4, val5, val6 
		var samt=0, stotal=0, sadj = 0, snet = 0
		var iamt=0, itotal=0,  iadj = 0, inet = 0
		var oamt=0, ototal=0,  oadj = 0, onet = 0
		var gtotal=0, gadj=0, gnet=0 
		var arr_y,arr_y0, arr_y1,arr_y2,arr_y3,arr_y4 ;
		x1 = document.frm.rtc_id.selectedIndex ;
		//alert(x1);
		x2 = document.frm.rtc_id[x1].value;		
		//alert(x2);
		y1 = x1;
		y2 = document.frm.hd_rtc_id[y1].value;
		//alert(y2);
		arr_y  =  y2.split(",");
		arr_y0 = arr_y[0];
		arr_y1 = arr_y[1];
		arr_y2 = arr_y[2];
		arr_y3 = arr_y[3];
		arr_y4 = arr_y[4];				
		
		//alert(document.frm.txtShow_adj.value);
		//alert(Number(replaceAll(document.frm.txtShow_adj.value, ',', '')));
		
		/*sadj = Number(document.frm.txtShow_adj.value.replace(",","")) ;
		iadj = Number(document.frm.txtIn_adj.value.replace(",","")) ;
		oadj = Number(document.frm.txtOut_adj.value.replace(",","")) ;*/
		
		sadj = Number(replaceAll(document.frm.txtShow_adj.value , ',' , '')) ;
		iadj = Number(replaceAll(document.frm.txtIn_adj.value , ',' , '')) ;
		oadj = Number(replaceAll(document.frm.txtOut_adj.value , ',' , '')) ;
		
		
		
		if (arr_y4 == "L" ){
			//alert("L");
			val1 = Number(document.frm.txtShow_qty.value.replace(",",""));
			val2 = Number(document.frm.txtIn_qty.value.replace(",",""));
			val3 = Number(document.frm.txtOut_qty.value.replace(",",""));
			//alert(val1 + " / " + val2 + " / " + val3);
			samt = Number(arr_y1);
			iamt = Number(arr_y2) ;
			oamt = Number(arr_y3) ;			
			if(iamt != 0 || val2 != 0 ){
				itotal = iamt * val2 ;
				inet = itotal + iadj;
				if(inet < 0){
					alert("IN : Adjust เกิน Total!!");	
					document.frm.txtIn_adj.focus();
					return false;
				}
			}			
			if(samt != 0 || val1 != 0 ){
				stotal = samt * val1;
				snet = stotal + sadj;
				if(snet < 0){
					alert("SHOW : Adjust เกิน Total!!");	
					document.frm.txtShow_adj.focus();
					return false;
				}				
			}
			if(oamt != 0 || val3 != 0 ){
				ototal = oamt * val3 ;	
				onet = ototal + oadj;	
				if(onet < 0){
					alert("OUT : Adjust เกิน Total!!");	
					document.frm.txtOut_adj.focus();
					return false;
				}
			}
			
			gtotal = stotal + itotal + ototal ;
			gadj = sadj + iadj + oadj ;
			gnet = Number(gtotal) +Number(gadj);
		}		
		if (arr_y4 == "P"){
			//alert("P");
			val1 = Number(document.frm.txtShow_qty.value.replace(",",""));
			val2 = Number(document.frm.txtIn_qty.value.replace(",",""));
			val3 = Number(document.frm.txtOut_qty.value.replace(",",""));
			val4 = Number(document.frm.eloc_atten.value.replace(",",""));
			val5 = Number(document.frm.eloc_num_session.value.replace(",",""));
			arr_y1 = Number(document.frm.txtShow_amt.value.replace(",",""));
			arr_y2 = Number(document.frm.txtIn_amt.value.replace(",",""));
			arr_y3 = Number(document.frm.txtOut_amt.value.replace(",",""));
			val6 = val4 * val5 ;
			samt = arr_y1;
			iamt = arr_y2 ;
			oamt = arr_y3 ;
			
			stotal = samt * val6 * val1;
			snet = stotal + sadj;
			itotal = iamt * val6 * val2 ;
			inet = itotal + iadj ;
			ototal = ototal * val6 * val3 ;
			onet = ototal + oadj ;
			gtotal = stotal + itotal + ototal ;
			gadj = sadj + iadj + oadj ;
			gnet = Number(gtotal) +Number(gadj);
		}		
		
		 document.frm.txtShow_amt.value = samt ;
		 document.frm.txtShow_total.value = stotal ;
		 document.frm.txtShow_net.value = snet ;
		 
		 document.frm.txtIn_amt.value = iamt ;
		 document.frm.txtIn_total.value = itotal ;
		 document.frm.txtIn_net.value = inet ;
		 
		 document.frm.txtOut_amt.value = oamt ;
		 document.frm.txtOut_total.value = ototal ;
		 document.frm.txtOut_net.value = onet ;
		 
		 document.frm.txtG_total.value = gtotal ;
		 document.frm.txtG_adj.value = gadj ;
		 document.frm.txtG_net.value = gnet ;
		 
	}
	
	function parseelement(thisone){
		var prefix="$"
		var wd
		if (thisone.value.charAt(0)=="$")
		return
		wd="w"
		var tempnum=thisone.value
		for (i=0;i<tempnum.length;i++){
			if (tempnum.charAt(i)=="."){
				wd="d"
				break
			}
		}
		if (wd=="w")
			thisone.value=prefix+tempnum+".00"
		else{
			if (tempnum.charAt(tempnum.length-2)=="."){
				thisone.value=prefix+tempnum+"0"
			}
		else{
			tempnum=Math.round(tempnum*100)/100
			thisone.value=prefix+tempnum
		}
		} //for (i=0;i<tempnum.length;i++){
	}
	
	function CalcKeyCode(aChar) {
	  var character = aChar.substring(0,1);
	  var code = aChar.charCodeAt(0);
	  return code;
	}
	
	function checkNumber(val) {
	  var strPass = val.value;
	  var strLength = strPass.length;
	  var lchar = val.value.charAt((strLength) - 1);
	  var cCode = CalcKeyCode(lchar);
	  	
	  /* Check if the keyed in character is a number
		 do you want alphabetic UPPERCASE only ?
		 or lower case only just check their respective
		 codes and replace the 48 and 57 */
	
	  if (cCode < 44 || cCode > 57) {
		var myNumber = val.value.substring(0, (strLength) - 1);
		val.value = myNumber;
	  }
	  return false;
	}
	
</script>

<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">
</head>
	
<body >
<form action="<?=updSave?>?id=<?=$evn_id?>&id2=<?=$eloc_id?>" method="post" name="frm"  id="frm" onSubmit="return validate();" >
  <table border="0" class="BorderGreen" width="70%">
    <tr class="BorderSilver">
      <td colspan="6" style="background-color:#339900;font-weight:bold;color:White;">
	  	<div align="center"><strong >Location - <?=$evn_id." - " .$evn_name ?></strong></div>
	  </td>
    </tr>
	<tr>
	  <td height="18" colspan="6"><div align="center">
</div></td>
    </tr>		
		<tr>
		  <td width="153" ><div align="right">Location :</div></td>
		  <td width="381" colspan="4"><?=$loc_name;?></td>
    </tr>
		<tr>
		  <td ><div align="right">In Date/Time : </div></td>
		  <td colspan="4"><?=$sindate;?></td>
    </tr>
		<tr>
		  <td ><div align="right">Show Date : </div></td>
		  <td colspan="4"><?=$showdate;?></td>
    </tr>
		<tr>
		  <td ><div align="right"> Time : </div></td>
		  <td colspan="4"><?=$showtime;?></td>
    </tr>
		<tr>
		  <td ><div align="right">Out Date/Time : </div></td>
		  <td colspan="4"><?=$outdate;?></td>
    </tr>
		<tr>
		  <td colspan="5" ><hr width="100%" noshade  color="#339900"></td>
    </tr>
		<tr>
		  <td ><div align="right">*Booking Status Code : </div></td>
		  <td colspan="4"><div align="left">
		    <select name="bks_id" id="bks_id">			
			  <?			
			  	//$data = $rs_esta[1];
			  	while($book_status  =  mysql_fetch_array($resbook_status)){
					$val_book_status = "$book_status[1] - $book_status[2]"; ?>
					<option value='<?=$book_status[0]?>'<?  if($book_status[0]==$bks_id) echo "selected" ?> >
					<?=$val_book_status ?></option>				
			  <?	
				}
			  ?>
	        </select>
		  </div></td>
    </tr>
		<tr>
		  <td ><div align="right">Seating Type : </div></td>
		  <td colspan="4" ><div align="left">
		    <select name="eloc_seat_type" id="eloc_seat_type">
              <?
			  	foreach($arrseat_type as $key=>$val){ ?>
              <option value='<?=$val ?>' <?  if($val==$seat_type) echo "selected" ?> >
              <?=$val ?>
              </option>
              <?	
				}
			  ?>
            </select>
		  </div></td>
    </tr>
		<tr>
		  <td ><div align="right">Room Use Code :</div></td>
		  <td colspan="4" ><select name="eloc_room_code" id="eloc_room_code">
            <?
			  	foreach($arrroom_code as $key=>$val){ ?>
            <option value='<?=$val ?>' <?  if($val==$eloc_room_code) echo "selected" ?> >
            <?=$val ?>
            </option>
            <?	
				}
			  ?>
          </select></td>
    </tr>
		<tr>
		  <td ><div align="right">Attendance  : </div></td>
		  <td colspan="4" ><div align="left">
		    <input name="eloc_atten" type="text" id="eloc_atten" value="<?=$eloc_atten;?>" onBlur="return click_rtc();">
		  </div></td>
    </tr>
		<tr>
		  <td ><div align="right">Num Sessions  : </div></td>
		  <td colspan="4" ><div align="left">
		    <input name="eloc_num_session" type="text" id="eloc_num_session" value="<?=$eloc_num_session;?>" onBlur="return click_rtc();">
		  </div></td>
    </tr>
		<tr>
		  <td ><div align="right">Square Meter  : </div></td>
		  <td colspan="4" ><div align="left">
		    <input name="eloc_sqm" type="text" id="eloc_sqm" value="<?=$eloc_sqm;?>">
		  </div></td>
    </tr>
		<tr>
		  <td colspan="5" >&nbsp;</td>
    </tr>
		<tr>
		  <td ><div align="right">*Rate Code  : </div></td>
		  <td colspan="4" ><div align="left">
		    <select name="rtc_id" id="rtc_id"  
			onChange="click_rtc();">
              <?			
			  	foreach($arr_rtc as $key=>$val){
					list($val0, $val1,$val2) = explode(",",$val);
					$val_rate_code = "$val1 - $val2"; 					
				?>
              <option value='<?=$val0 ;?>'
			  <?  if($val0==$rtc_id) { 
			  	echo "selected" ;			  	
			  }?> >
              <?=$val_rate_code ?>
              </option>
              <?	
				}
			  ?>
            </select>
			<?
			$sql = "SELECT srtc.rtc_id, srtc.show_amt, srtc.inout_amt, srtc.out_amt,
			rtc.rtc_status, rtc.rtc_name
			FROM ratecode rtc, sub_ratecode srtc
			WHERE  rtc.rtc_id = srtc.rtc_id 
			AND  srtc.loc_id = $loc_id
			ORDER BY  rtc.rtc_code
			 ";
			//echo "\$sql = <br> $sql<br>";
			$result = getData($sql);	
			
			while ($res_srtc =  mysql_fetch_array($result)){
				$id = $res_srtc[0];
				$val = $res_srtc[0] .",".$res_srtc[1].",".$res_srtc[2].",".$res_srtc[3].",".$res_srtc[4];
				echo '<input name="hd_rtc_id" type="hidden" id="hd_rtc_id" value="'.$val .'">';	
			}			
			?>            
</div></td>
    </tr>
		<tr>
		  <td >&nbsp;</td>
		  <td colspan="4" bordercolor="#666666" >&nbsp;</td>
    </tr>
	<tr>
	 <td colspan="5">
	  <table width="100%">
		<tr>
		  <td width="18%" >&nbsp;</td>
		  <td width="21%" bordercolor="#666666" ><div align="center" class="mandatory">In</div></td>
		  <td width="21%" bordercolor="#666666" ><div align="center" class="mandatory">Show</div></td>
		  <td width="21%" bordercolor="#666666" ><div align="center" class="mandatory">Out</div></td>
		  <td width="19%" bordercolor="#666666" ><div align="center" class="mandatory">Total</div></td>
		</tr>
		<tr>
		  <td ><div align="right">Days(s) : </div></td>
		  <td bordercolor="#666666" >
		   <input name="txtIn_qty" type="text" id="txtIn_qty"  value="<?=$inout_qty;?>" readonly="true">
		  </td>
		  <td bordercolor="#666666" >
		   <input name="txtShow_qty" type="text" id="txtShow_qty" value="<?=$show_qty;?>" readonly="true">
		  </td>
		  <td bordercolor="#666666" >
		   <input name="txtOut_qty" type="text" id="txtOut_qty" value="<?=$out_qty;?>" readonly="true">
		  </td>
		  <td bordercolor="#666666" >&nbsp;</td>
		</tr>
			<tr>
			  <td ><div align="right">Per day : </div></td>
			  <td bordercolor="#666666" >
			   <input name="txtIn_amt" type="text" id="txtIn_amt" value="<?=$inout_amt;?>" readonly="true">
			  </td>
			  <td bordercolor="#666666" >
			   <input name="txtShow_amt" type="text" id="txtShow_amt" value="<?=$show_amt;?>" onChange="return click_rtc();" readonly="true">
			  </td>
			  <td bordercolor="#666666" >
			   <input name="txtOut_amt" type="text" id="txtOut_amt" value="<?=$out_amt;?>" readonly="true">
			  </td>
			  <td bordercolor="#666666" >&nbsp;</td>
		</tr>
			<tr>
			  <td ><div align="right">Total : </div></td>
			  <td bordercolor="#666666" >
			   <input name="txtIn_total" type="text" id="txtIn_total" value="<?=$inout_total;?>" readonly="true">
			  </td>
			  <td bordercolor="#666666" >
			   <input name="txtShow_total" type="text" id="txtShow_total" value="<?=$show_total;?>" readonly="true">
			  </td>
			  <td bordercolor="#666666" >
			   <input name="txtOut_total" type="text" id="txtOut_total" value="<?=$out_total;?>" readonly="true">
			  </td>
			  <td bordercolor="#666666" >
			   <input name="txtG_total" type="text" id="txtG_total" value="<?=$g_total;?>" readonly="true">
			  </td>
		</tr>
			<tr>
			  <td ><div align="right">adjust : </div></td>
			  <td bordercolor="#666666" >
			   <input name="txtIn_adj" type="text" id="txtIn_adj" value="<?=$inout_adj;?>" onChange="return click_rtc();" >
			  </td>
			  <td bordercolor="#666666" >
			   <input name="txtShow_adj" type="text" id="txtShow_adj" value="<?=$show_adj;?>"  onChange="return click_rtc();" >
			  </td>
			  <td bordercolor="#666666" >
			   <input name="txtOut_adj" type="text" id="txtOut_adj" value="<?=$out_adj;?>"  onChange="return click_rtc();" >
			  </td>
			  <td bordercolor="#666666" >
			   <input name="txtG_adj" type="text" id="txtG_adj" value="<?=$g_adj;?>"  onChange="return click_rtc();" readonly="true">
			  </td>
		</tr>
		<tr>
		  <td ><div align="right">Net : </div></td>
		  <td bordercolor="#666666" >
		  <input name="txtIn_net" type="text" id="txtIn_net" value="<?=$inout_net;?>" readonly="true">
		  </td>
		  <td bordercolor="#666666" >
		  <input name="txtShow_net" type="text" id="txtShow_net" value="<?=$show_net;?>" readonly="true">
		  </td>
		  <td bordercolor="#666666" >
		  <input name="txtOut_net" type="text" id="txtOut_net" value="<?=$out_net;?>" readonly="true">
		  </td>
		  <td bordercolor="#666666" >
		  <input name="txtG_net" type="text" id="txtG_net" value="<?=$g_net;?>" readonly="true">
		  </td>
		</tr>
		<tr>
		  <td ><div align="right"></div></td>
		  <td colspan="4" ><div align="left"></div></td>
		</tr>
		  <tr align="center" >
		  <td colspan="5">	 	
			  <input name="Submit2" type="button" class="Button" value="&lt;= Back " onClick="window.location = 'estf_updForm.php?id=<?=$evn_id?>'" >
			  <input name="Submit" type="submit" id="submit" class="Button" value="   OK   " <?=$disabled ;?> >
			  <input name="show" type="submit" id="show" class="Button" value="Show" <?=$disabled ;?> />
			  <input name="Button" type="button" class="Button" id="Button"  onClick="history.go(-1)" value="Cancel" >
			  <input name="Submit22" type="button" class="Button" value="Next =&gt;" onClick="window.location = 'eesv_viewForm.php?id=<?=$evn_id?>'" >
		  </td>
		</tr>
	 </table>
	 </td>
	</tr>  
  </table>

<!-- ########################  Show Detail  ######################## -->


</form>
<?

	//======================Begin Save Data==============================================
	//request data into varible
	$Submit = $_REQUEST["Submit"];
	if(!empty($Submit) || !empty($show)){
		
		$a_bks_id = $_REQUEST["bks_id"];
		$a_eloc_seat_type = $_REQUEST["eloc_seat_type"];
		$a_eloc_room_code = $_REQUEST["eloc_room_code"];
		$a_eloc_atten = chgNumberToDb($_REQUEST["eloc_atten"]);
		$a_eloc_num_session = chgNumberToDb($_REQUEST["eloc_num_session"]);
		$a_eloc_sqm = chgNumberToDb($_REQUEST["eloc_sqm"]);
		$a_rtc_id = $_REQUEST["rtc_id"];		
		$a_eloc_show_amt = chgNumberToDb($_REQUEST["txtShow_amt"]);
		$a_eloc_show_total = chgNumberToDb($_REQUEST["txtShow_total"]);
		$a_eloc_show_adj = chgNumberToDb($_REQUEST["txtShow_adj"]);
		$a_eloc_show_net = chgNumberToDb($_REQUEST["txtShow_net"]);
		$a_eloc_inout_amt = chgNumberToDb($_REQUEST["txtIn_amt"]);
		$a_eloc_inout_total = chgNumberToDb($_REQUEST["txtIn_total"]);
		$a_eloc_inout_adj = chgNumberToDb($_REQUEST["txtIn_adj"]);
		$a_eloc_inout_net = chgNumberToDb($_REQUEST["txtIn_net"]);
		$a_eloc_out_amt = chgNumberToDb($_REQUEST["txtOut_amt"]);
		$a_eloc_out_total = chgNumberToDb($_REQUEST["txtOut_total"]);
		$a_eloc_out_adj = chgNumberToDb($_REQUEST["txtOut_adj"]);
		$a_eloc_out_net = chgNumberToDb($_REQUEST["txtOut_net"]);
		$a_eloc_g_total = chgNumberToDb($_REQUEST["txtG_total"]);
		$a_eloc_g_adjust = chgNumberToDb($_REQUEST["txtG_adj"]);
		$a_eloc_g_net = chgNumberToDb($_REQUEST["txtG_net"]);
		/*
		echo "
		submit = $Submit<br>
		evn_id =  $evn_id<br>
		loc_id =  $loc_id<br>
		a_bks_id = $a_bks_id<br> 
		a_eloc_seat_type = $a_eloc_seat_type<br>
		a_eloc_room_code = $a_eloc_room_code <br> 
		a_eloc_atten = $a_eloc_atten<br>
		a_eloc_num_session = $a_eloc_num_session <br>
		a_eloc_sqm = $a_eloc_sqm<br>
		a_rtc_id = $a_rtc_id <br>
		a_eloc_rate_adjust = $a_eloc_rate_adjust<br>
		";
		*/
		//check duplicate data in table ev_statistics
		$sql = "SELECT evn_id FROM ev_statistics WHERE evn_id = '$evn_id'  ";
		//echo "$sql<br>";
		//exit();
		$result = getData($sql);
		$numrow = mysql_num_rows($result);
		$row = mysql_fetch_array($result);
		//echo "numrow = $numrow<br>";
		//echo "\$Submit= $Submit";
		//echo "\$txtBtn= $txtBtn";
		if($show){
			$action = "show";
		}else if($numrow == 0){
			$action = "add";
		}else{
			$action = "edit";
		}
		
		//echo "action=$action<br>";
		
		function  checklist($value,$label,$field){
			global $resData;
			$resData[$field] = $value;
		} //function checklist($var,$name){
		
		//checklist($evn_id,"","evn_id");
		
		checklist($a_bks_id,"","bks_id");
		checklist($a_eloc_seat_type,"","eloc_seat_type");
		checklist($a_eloc_room_code,"","eloc_room_code");
		checklist($a_eloc_atten,"","eloc_atten");
		checklist($a_eloc_num_session,"","eloc_num_session");
		checklist($a_eloc_sqm,"","eloc_sqm");
		checklist($a_rtc_id,"","rtc_id");
		checklist($a_eloc_show_amt,"","eloc_show_amt");
		checklist($a_eloc_show_total,"","eloc_show_total");
		checklist($a_eloc_show_adj,"","eloc_show_adj");
		checklist($a_eloc_show_net,"","eloc_show_net");
		checklist($a_eloc_inout_amt,"","eloc_inout_amt");
		checklist($a_eloc_inout_total,"","eloc_inout_total");
		checklist($a_eloc_inout_adj,"","eloc_inout_adj");
		checklist($a_eloc_inout_net,"","eloc_inout_net");
		checklist($a_eloc_out_amt,"","eloc_out_amt");
		checklist($a_eloc_out_total,"","eloc_out_total");
		checklist($a_eloc_out_adj,"","eloc_out_adj");
		checklist($a_eloc_out_net,"","eloc_out_net");
		checklist($a_eloc_g_total,"","eloc_g_total");
		checklist($a_eloc_g_adjust,"","eloc_g_adjust");
		checklist($a_eloc_g_net,"","eloc_g_net");		

		//$action = "Show" ;
		//echo "\$action= $action"; exit();
		//echo "\$resData= <pre>"; print_r($resData); echo "<hr>";
			if($action=="add"){
				$resData["evn_id"] = $evn_id;
				$resData["usr_cre"] = $_SESSION["usr_name"];
				$resData["date_cre"] = date("Y/m/d  H:i:s");		
				
				$query = create_insert_query("ev_location",$resData);	
				//echo "$query<br>";
				//exit();
				mysql_query($query) or die("Insert error");		
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");				
				$updRev = updRevenue("a","ev_location","eloc_id",$eloc_id);
				//Show alert by javascript
				echo "<script>
						alert ('Insert complete');
						window.location = 'esta_updForm.php?id=$evn_id&id2=$eloc_id' ;
					  </script>";
				exit();
			}
			
			if($action=="edit"){
				$_SESSION["showRev"] = "";
				$resData["usr_upd"] = $_SESSION["usr_name"];
				$resData["date_upd"] = date("Y/m/d  H:i:s");		
				
				$query = create_update_evquery("ev_location", $resData, $evn_id, "evn_id",$eloc_id,"eloc_id");				
			    //echo "$query<br>";
				//exit();
				mysql_query($query) or die("Update error");		
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");
				$updRev = updRevenue("e","ev_location","eloc_id",$eloc_id);
				$showRev = updRevenue("s","ev_location","eloc_id",$eloc_id);
				$_SESSION["showRev"] = $showRev ;
				
				
				//$eloc_id_new = mysql_insert_id();
				//$showRev = updRevenue("s","ev_location","eloc_id",$eloc_id);
				//$_SESSION["showRev"] = $showRev ;
				
				//Show alert by javascript
				echo "<script>
						alert ('Update complete');
						window.location = 'eloc_updForm.php?id=$evn_id&id2=$eloc_id&show=y' ;
					  </script>";
				exit();
			}
			
			//echo "\$action=$action";
			if($action == "show"){
				$_SESSION["showRev"] = "";
				$resData["usr_upd"] = $_SESSION["usr_name"];
				$resData["date_upd"] = date("Y/m/d  H:i:s");		
				
				$showRev = updRevenue("s","ev_location","eloc_id",$eloc_id);
				$_SESSION["showRev"] = $showRev ;
				//echo "\$showRev= <pre>"; print_r($showRev); echo "<hr>";
			}

	} //if(!empty($Submit)){
	
	//======================End Save Data==============================================
?>
<?php 
	//$show = $_REQUEST["show"];
	if($show){	
		include_once("eloc_showDetail.php");		
	}		
?>