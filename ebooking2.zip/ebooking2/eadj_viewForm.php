<?
	ob_start(); 
	session_start();
	include("db/chksession.db.php");
	$evn_id = $_REQUEST["id"];
	define("sysName","Manual Adjustment");
	define("tableName","pay_adj");
	$type = "adj";
	define("viewForm","eadj_viewForm.php");
	define("updForm","eadj_updForm.php");	
	define("addForm","eadj_updForm.php");	
	define("field_id","stt_id");	
	define("beg_id",1);	
	define("end_id",4);		
	
	$sql = "SELECT pad.stt_id, stt.stt_name,
				pad.str1, pad.str2, pad.tran_date, pad.amt 
				FROM settle_cat stt, pay_adj pad
				WHERE stt.stt_id = pad.stt_id
				AND pad.evn_id = '$evn_id' 
				AND type = '$type'
				";
	//echo "$sql";
	define("query","$sql");
		
	$cap_name = array();
	$cap_name = array("#","Settlement Category","Name of item being changed","Description","Transaction Date","Amount");
	
	//=============check authorize================
	$key = array_keys($_SESSION["sec_add"], viewForm); 
	if($key[0])
		define("insert",1);		
	else
		define("insert",0);			
		
	$key = array_keys($_SESSION["sec_edit"], viewForm); 
	if($key[0])
		define("edit",1);		
	else
		define("edit",0);			
		
	$key = array_keys($_SESSION["sec_del"], viewForm); 
	if($key[0])
		define("del",0);		
	else
		define("del",0);			
		
	include("func/ev_viewForm.func1.php");
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</body>
</html>
