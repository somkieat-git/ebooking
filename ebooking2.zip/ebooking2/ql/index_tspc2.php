<?php
session_start();
echo "index_tspc2 site=",$_SESSION["site"],"<br>";
echo "request ncc =",$_REQUEST["ncc"],"<br>";

$site="tspc";
$_SESSION["site"]="tspc";

//exit();

include "./inc/config.php";
include "./inc/auth.php";
include "./inc/function.php";
include "./inc/header.php";
	
echo"
<table border='0' cellpadding='0' width='100%' height='100%' cellspacing='0' align='center'>
<tr>
	<td width='20%' align='center' valign='top'>"; include "inc/menu.php"; echo"</td>
	<td width='80%' height='100%' align='center' valign='top'>
	<table width='98%'>
	<tr>
		<td  width='100%'>
		";
		if(!empty($_GET['link']))
		{
			//include "src/$_GET[link].php";
			echo "<script> window.location = '../fra_main.php' ;</script>";
		}else{
			//include "src/sysinfo.php";
			echo "<script> window.location = '../fra_main.php' ;</script>";
			
		}
		echo"
		</td>
	</tr>
	</table>
	</td>
</tr>
</table>
";
	
	
include "inc/footer.php";
?>
