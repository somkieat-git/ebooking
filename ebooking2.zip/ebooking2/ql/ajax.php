<?php
	header("content-type: application/x-javascript; charset=utf-8");
	
	$login=0;
	/******************** process ********************/
	/*
		Value from Form :
			$_POST['username']
			$_POST['password']
			$_POST['language']
		
		Check username and password here.
			Read from txt file or database.
		Ex.
		*/
		
		#########################
		//MrTaN
		include_once("../cfg/config.cfg.php");
		$hostname=hostname;
		$user=username;
		$pass=password;
		$dbname=dbname;
		$result=0;
		$link = mysql_connect($hostname,$user,$pass) or die(mysql_error());
		mysql_select_db($dbname,$link) or die(mysql_error());
		mysql_query("SET NAMES 'utf8'",$link);
		
		$usr_login=$_POST['username'];
		
		$sql = " select usr.*, sec.* ";
		$sql.= " from user usr, security sec ";
		$sql.= " where usr.usr_sec = sec.sec_id ";
		$sql.= " and usr.usr_login = '".$usr_login."' ";		
		//echo "\$sql=$sql<br>";	exit();
		
		$result=mysql_query($sql,$link);
	
		$arrResult = mysql_fetch_array($result);
		$getUser=$arrResult["usr_id"];	
		$getPass=$arrResult["usr_pass"];
		
		if($getUser){			
			$md5LogPass=($_POST['password']);
			$md5LogPass=md5($md5LogPass);		
			
			if($md5LogPass == $getPass){
				$login=1;				
				
				// #3. Save data in Logfile
				include_once("../func/sql.func.php");
				$SaveLog=updLog($usr_login, 'index.php', 'login by '.$_SERVER['HTTP_USER_AGENT']);	
				
				
				// #4. check authorize save in $_SESSION["?"]
				//$arrView= array();
				//$arrViewn= array();
				$arrView = explode(",", $arrResult["sec_view"]);				
				$arrViewn = getAuthor($arrView);				
				//print_r(array_keys($arrViewn));
				
				session_start();
				$_SESSION["sec_view"]  = $arrViewn ; 
				
				//echo "index.php.sec_add =  ".$row["sec_add"]."<br>";
				
				$arrAdd = explode(",", $arrResult["sec_add"]);				
				$arrAddn = getAuthor($arrAdd);				
				//print_r(array_keys($arrAddn));
				$_SESSION["sec_add"] = $arrAddn;
				
				$arrEdit = explode(",", $arrResult["sec_edit"]);				
				$arrEditn = getAuthor($arrEdit);				
				//print_r(array_keys($arrEditn));
				$_SESSION["sec_edit"] = $arrEditn;
				
				$arrDel = explode(",", $arrResult["sec_del"]);				
				$arrDeln = getAuthor($arrDel);				
				//print_r(array_keys($arrDeln));
				
				
				$_SESSION["sec_del"] = $arrDeln;
				
				
				// #5. check authorize admin & save in $_SESSION["admin"]			
				if ($arrResult["sec_name"]=='admin'){
					$_SESSION["admin"] = true;
				}					
				else{
					$_SESSION["admin"] = false;			
				}				
				
			}
		} //if($getUser){		
		if( ($_POST['username'] == 'admin') and ($_POST['password'] == 'phayoune'))	
		{		
			$login=1;
			$_SESSION["admin"] = true;
		}
		#########################
				
	
	/***************** do not modify *****************/
	if($login == 0)
	{
		echo"$login";
	}else{
		session_start();
		$_SESSION['username']=$_POST['username'];
		$_SESSION['language']=$_POST['language'];
		
		$_SESSION["usr_name"] = $arrResult['usr_name'];
		$_SESSION["usr_id"] = $arrResult['usr_id'];
		$_SESSION["UsrID"] = $arrResult['usr_id'];
		$_SESSION["usr_pass"] = $_POST['password'];
		$_SESSION["id"] = $arrResult['usr_id'];		

		$_SESSION['start'] = time(); // Taking now logged in time.
		// Ending a session in 30 minutes from the starting time.
		$_SESSION['expire'] = $_SESSION['start'] + (60 * 60);
		
		echo"$login";
	}
	/***************** do not modify *****************/
?>
