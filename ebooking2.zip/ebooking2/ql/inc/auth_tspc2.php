<?php	
session_start();
echo "at auth_tspc2.php <br>";	

	echo "ncc = ",$_SESSION["site"],"<br>"; //exit();
//	$_SESSION["site"] = $_REQUEST["ncc"];
//	echo "site_auth_tspc2=".$_SESSION['site']."<br>"; //exit();
	
//	echo "<script>alert("Break");</script>";
	
	if(!isset($_SESSION['username']))
	{
		echo"<script>window.location='http://nccubuntu.qsncc.co.th/app/nccgroup/thebook1.7/ql/login_tspc2.php?ncc=".<? $_SESSION["site"]; ?>."'</script>";
		//echo'<script type="text/javascript">window.location.assign("http://nccubuntu.qsncc.co.th/app/nccgroup/thebook1.7/ql/login_tspc2.php");</script>';
	}
?>
