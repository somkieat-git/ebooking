<?php
$menu="
	<table width='100%'>
	<tr>
		<td>
	
		<table cellpadding='0' width='99%' cellspacing='0'>
		<tr>
			<td><a href='index.php?link=sysinfo'><b>System info</b></a></td>
		</tr>
		<tr>
			<td><table><tr><td></td></tr></table></td>
		</tr>
		<tr>
			<td bgcolor='#cccccc'></td>
		</tr>
		<tr>
			<td><table><tr><td></td></tr></table></td>
		</tr>
		<tr>
			<td><a href='index.php?link=quick_start'><b>Quick Start</b></a></td>
		</tr>
		<tr>
			<td><table><tr><td></td></tr></table></td>
		</tr>
		<tr>
			<td bgcolor='#cccccc'></td>
		</tr>
		<tr>
			<td><table><tr><td></td></tr></table></td>
		</tr>
		<tr>
			<td><a href='index.php?link=services'><b>Services</b></a></td>
		</tr>
		<tr>
			<td><table><tr><td></td></tr></table></td>
		</tr>
		<tr>
			<td bgcolor='#cccccc'></td>
		</tr>
		<tr>
			<td><table><tr><td></td></tr></table></td>
		</tr>
		<tr>
			<td><a href='index.php?link=webcam'><b>WebCam</b></a></td>
		</tr>
		<tr>
			<td><table><tr><td></td></tr></table></td>
		</tr>
		<tr>
			<td bgcolor='#cccccc'></td>
		</tr>
		<tr>
			<td><table><tr><td></td></tr></table></td>
		</tr>
		<tr>
			<td><b>Log</b></td>
		</tr>
		<tr>
			<td><table cellpadding='0' cellspacing='0'><tr><td></td></tr></table></td>
		</tr>
		<tr>
			<td> &nbsp; <a href='index.php?link=log_squid'>Squid</a></td>
		</tr>
		<tr>
			<td> &nbsp; <a href='index.php?link=log_apache'>Apache</b></td>
		</tr>
		<tr>
			<td> &nbsp; <a href='index.php?link=log_firewall'>Firewall</b></td>
		</tr>
		<tr>
			<td> &nbsp; <a href='index.php?link=log_kernel'>Kernel</b></td>
		</tr>
		<tr>
			<td><table cellpadding='0' cellspacing='0'><tr><td></td></tr></table></td>
		</tr>
	
		<tr>
			<td bgcolor='#cccccc'></td>
		</tr>
		<tr>
			<td><table><tr><td></td></tr></table></td>
		</tr>
		<tr>
			<td><a href='logout.php'><b>Logout</b></a></td>
		</tr>

		</table>
		
		</td>
	</tr>
	</table>
";

echo"
	<table border='0' cellpadding='0' width='100%' height='100%' cellspacing='0' align='center'>
	<tr>
		<td><img src='img/j_crn_tl_light.png'></td>
		<td background='img/j_crn_top.png' width='100%'></td>
		<td><img src='img/j_crn_tr_light.png'></td>
	</tr>
	<tr>
		<td background='img/j_crn_left.png'></td>
		<td height='100%' valign='top'>
		
		<ul id='tree'>
			
			<li><img src='img/ms.png'>&nbsp;<a href='index.php?link=sysinfo'>System info</a></li>
			
			<li><img src='img/ms.png'>&nbsp;<a href='index.php?link=services'>Services</a></li>

			<li><img src='img/ms.png'>&nbsp;<a href='index.php?link=webuser'>User Account</a></li>
			
			<li><img src='img/ms.png'>&nbsp;<a href='index.php?link=webcam'>WebCam</a></li>

			<li><img src='img/ms.png'>&nbsp;Logs
				<ul>
					<li><img src='img/m.png'>&nbsp;<a href='index.php?link=log_squid'>Squid</a></li>
					<li><img src='img/m.png'>&nbsp;<a href='index.php?link=log_apache'>Apache</a></li>
					<li><img src='img/m.png'>&nbsp;<a href='index.php?link=log_firewall'>Firewall</a></li>
					<li><img src='img/m.png'>&nbsp;<a href='index.php?link=log_kernel'>Kernel</a></li>
					<li><img src='img/m.png'>&nbsp;<a href='index.php?link=sarg'>Sarg</a></li>
				</ul>
			</li>
				

			<li><img src='img/ms.png'>&nbsp;<a href='logout.php'>Logout</a></li>
			
		</ul>
		<br><br><br><br><br>
		&nbsp;&nbsp;&nbsp;<img src='img/phayoune.png'>
		</td>

		<td background='img/j_crn_right.png'></td>
	</tr>
	<tr>
		<td><img src='img/j_crn_bl_light.png'></td>
		<td background='img/j_crn_bottom.png'></td>
		<td><img src='img/j_crn_br_light.png'></td>
	</tr>
	</table>
";


?>


<script type="text/javascript">
	var tree = new Zapatec.Tree({
		tree: "tree",
		expandOnLabelClick: true,
		saveState: true,
		saveId: "saveState",
		keyboardNavigation: true,
		compact: true,
		highlightSelectedNode: true,
		keyboardNavigation: true
		//deselectOnLeave: true
	});
</script>
