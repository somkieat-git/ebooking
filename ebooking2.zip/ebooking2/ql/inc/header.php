<?php
echo"
<html>
<head>
	<title>".TITLE."</title>
	<meta name='description' content='Booking System by Information Technology'>
	<meta name='generator' content='Booking System v.1.6'>
	<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>
	<meta name='keywords' content='Booking System'>
	<script language='javascript' src='inc/js.js'></script>
	<script language='javascript' src='inc/prototype.js'></script>
	<link rel='StyleSheet' href='css/style.css'>
</head>
<body topmargin='10' leftmargin='0' bottommargin='0' rightmargin='0' bgcolor='#ffffff'>
<table border='0' cellpadding='0' cellspacing='0' width='98%' height='98%' align='center'>
<tr>
	<td><img src='img/j_header_left.png'></td>
	<td background='img/j_header_middle.png' width='100%' valign='middle' class='title'>".APP_NAME."</td>
	<td><img src='img/j_header_right.png'></td>
</tr>
<tr>
	<td background='img/j_left.png'></td>
	<td height='100%' style='padding-top:9;'>
"

?>