<?php
echo"
	</td>
	<td background='img/j_right.png'></td>
</tr>
<tr>
	<td><img src='img/j_corner_bl.png'></td>
	<td background='img/j_bottom.png'></td>
	<td><img src='img/j_corner_br.png'></td>
</tr>
</table>

</body>
</html>
";
?>
