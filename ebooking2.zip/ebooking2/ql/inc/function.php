<?php
function small_box($detail)
{
	$txt="
	<table border='0' cellpadding='0' width='100%' height='100%' cellspacing='0' align='center'>
	<tr>
		<td><img src='img/j_crn_tl_light.png'></td>
		<td background='img/j_crn_top.png' width='100%'></td>
		<td><img src='img/j_crn_tr_light.png'></td>
	</tr>
	<tr>
		<td background='img/j_crn_left.png'></td>
		<td height='100%'>$detail</td>
		<td background='img/j_crn_right.png'></td>
	</tr>
	<tr>
		<td><img src='img/j_crn_bl_light.png'></td>
		<td background='img/j_crn_bottom.png'></td>
		<td><img src='img/j_crn_br_light.png'></td>
	</tr>
	</table>
	";
	return($txt);
}
?>
