function cEnter (event)
{
	var keyCode = event.keyCode ? event.keyCode : event.which ? event.which : event.charCode;
	if(keyCode == 13){ check_login(); } 
}    

function Inint_AJAX()
{
   try { return new ActiveXObject("Msxml2.XMLHTTP");  } catch(e) {} //IE
   try { return new ActiveXObject("Microsoft.XMLHTTP"); } catch(e) {} //IE
   try { return new XMLHttpRequest();          } catch(e) {} //Native Javascript
   alert("XMLHttpRequest not supported");
   return null;
}

function check_login()
{
	
	var u = document.getElementById("username");
	var p = document.getElementById("password");
	var sl = document.getElementById("slang");
	var msg =document.getElementById("msg_login");
	console.log("username="+u+"&password="+p+"&language="+sl);
	console.log("u.value.length: " + u.value.length);
	
	if(u.value.length==0)
	{
		msg.innerHTML='Please Insert Username';
		msg.className="msg_red";
		u.focus();
	}else if(p.value.length==0){
		msg.innerHTML='Please Insert Password';
		msg.className="msg_red";
		p.focus();
	}else{
		msg.innerHTML="<center><img src='img/loading.gif'></center>";
		ajax_login(u.value,p.value,sl.value);
	}
}

function ajax_login(u,p,sl)
{
	console.log("username="+u+"&password="+p+"&language="+sl);
	
	var req = Inint_AJAX();
	req.onreadystatechange=function()
	{ 
		var req_status=req.readyState;
        if(req.status==200)
		{ 
			var stxt = req.responseText;
			console.log(stxt);
			if(stxt==1)
			{
				window.location='../fra_main.php';
			}else{
				document.getElementById("username").value="";
				document.getElementById("password").value="";				
				document.getElementById("msg_login").innerHTML="Username and Password do not Match";
				document.getElementById("msg_login").className="msg_red";				
				document.getElementById("username").focus();
			}
		}
	};
	req.open('POST', 'ajax.php');
	req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=utf-8"); //Header ???????
	req.send("username="+u+"&password="+p+"&language="+sl); //?????
}
