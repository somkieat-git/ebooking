<?php
function QUptime(){
	print("<pre>");
	print("<b>Uptime:</b><br>");
	system("uptime");
	print("<pre>");
	}	
function QKernel(){
	print("<pre>");
	print("<b>Kernel Information:</b><br>");
	system("uname -a");
	print("<pre>");
	}
function QMemory(){
	print("<pre>");
	print("<b>Memory Usage (MB):</b><br>");
	system("free -m");
	print("<pre>");
	}
function QDisk(){
	print("<pre>");
	print("<b>Disk Usage:</b><br>");
	system("df -h");
	print("<pre>");
	}	
function QCPU(){
	print("<pre>");
	print("<b>CPU Information:</b><br>");
	system("cat /proc/cpuinfo | grep \"model name\\|processor\\|cpu MHz\" ");
	print("<pre>");
	}
function OnOff($ONOFF) {
	//echo "$ONOFF<br>";
	switch($ONOFF){
		case "dhcpd":
			exec("ps ax | grep dhcp | grep SNs | awk '{print $5}' " ,$DHCP_status); 
			if ( $DHCP_status[0] == "/usr/sbin/dhcpd" ) {  
			print("<td width=\"10px\">on<br><INPUT type=\"radio\" checked></td><td width=\"10px\">off<br><INPUT type=\"radio\" ></td>");
			}else{	
			print("<td width=\"10px\">on<br><INPUT type=\"radio\"  ></td><td width=\"10px\">off<br><INPUT type=\"radio\"  checked ></td>"); 
			} break; 
		case "sshd":
			exec("ps ax | grep sshd | grep SNs | awk '{print $5}' " ,$SSHD_status); 
			if ( $SSHD_status[0] == "/usr/sbin/sshd" ) {  
			print("<td width=\"25px\">on<br><INPUT type=\"radio\" checked></td><td width=\"25px\">off<br><INPUT type=\"radio\" ></td>");
			}else{	
			print("<td width=\"25px\">on<br><INPUT type=\"radio\"  ></td><td width=\"25px\">off<br><INPUT type=\"radio\"  checked ></td>"); 
			} break; 
		case "webcam":
			exec("ps ax | grep motion | grep Sl | awk '{print $5}' " ,$WebCam_status); 
			//echo $WebCam_status[0];
			if ( $WebCam_status[0] == "motion" ) {  
			print("<td width=\"25px\">on<br><INPUT type=\"radio\" checked></td><td width=\"25px\">off<br><INPUT type=\"radio\" ></td>");
			}else{	
			print("<td width=\"25px\">on<br><INPUT type=\"radio\"  ></td><td width=\"25px\">off<br><INPUT type=\"radio\"  checked ></td>"); 
			} break; 
		case "x11vnc":
			exec("ps ax | grep x11vnc | grep S+ | awk '{print $5}' " ,$X11vnc_status); 
			//echo $WebCam_status[0];
			if ( $X11vnc_status[0] == "x11vnc" ) {  
			print("<td width=\"25px\">on<br><INPUT type=\"radio\" checked></td><td width=\"25px\">off<br><INPUT type=\"radio\" ></td>");
			}else{	
			print("<td width=\"25px\">on<br><INPUT type=\"radio\"  ></td><td width=\"25px\">off<br><INPUT type=\"radio\"  checked ></td>"); 
			} break; 
		case "halt":
			print("<td width=\"25px\"><div align=\"center\">&nbsp;-&nbsp;</div></td>");
			print("<td width=\"25px\"><div align=\"center\">&nbsp;-&nbsp;</div></td>"); 
			break; 
		default:
 		break; 
	}
}

function QServices_Form($FTEXT, $MESSAGE, $VSUBMIT1, $VSUBMIT2, $SERV){
	print("<FORM method=\"POST\" target=\"_self\">");
	print("<table border=\"1\"><tbody>");
    	print("<tr align='center' >");
		print("<td width=\"200px\">Services</td><td colspan=\"2\">Status</td><td>Message</td><td colspan='2'>Operation</td>");
	print("</tr>");
	print("<tr>");
		print("<td><strong>$FTEXT</strong></td>");
	OnOff($SERV) ;
		print("<td width=\"200px\">$MESSAGE</td>");
	print("<td align='center' width=\"160px\"><INPUT type=\"submit\" name=\"submit\" value=\"$VSUBMIT1\"></td>");
	print("<td align='center' width=\"160px\"><INPUT type=\"submit\" name=\"submit\" value=\"$VSUBMIT2\"></td></tr>");
	print("</tbody></table>");
        print("</FORM>");
}
?>