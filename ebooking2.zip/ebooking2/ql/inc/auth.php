<?php
	// session_start();
	// if(!isset($_SESSION['username']))
	// {
	// 	echo"<script>window.location='login.php'</script>";
	// }

	session_start();
    if (!isset($_SESSION['username'])) {
		echo "Please Login again";
		echo"<script>window.location='login.php'</script>";
        
    }
    else {
        $now = time(); // Checking the time now when home page starts.

        if ($now > $_SESSION['expire']) {
            session_destroy();
			echo "Your session has expired!";
			echo"<script>window.location='login.php'</script>";
        }
    }
?>
