<?php
	define("TITLE",		"Booking System");
	define("APP_NAME",	"NCC-eBooking");
	define("LOGIN_TITLE",	"Please Login");
?>
