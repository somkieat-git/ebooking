<?php
	header("Expires: Sat, 1 Jan 2005 00:00:00 GMT");
	header("Last-Modified: ".gmdate( "D, d M Y H:i:s")."GMT");
	header("Cache-Control: no-cache, must-revalidate");
	header("Pragma: no-cache");
	header("content-type: application/x-javascript; charset=tis-620");
	
	exec("tail -10 /var/log/kern.log",$return_var);
	
	echo"
	<table width=\"100%\" cellpadding=\"0\" cellspacing=\"0\" align=\"center\">
	<tr>
		<td><font size=\"+1\"><strong>Kernel Log</strong></font></td>
	</tr>
	";
	$i=1;
	foreach($return_var as $var)
	{
		$bg="#dddddd"; $i%2?0:$bg="#ffffff";
		echo"
		<tr>
			<td bgcolor=\"$bg\" height=\"19\">$var</td>
		</tr>
		";
		$i++;
	}
	echo"</table>";
?>
