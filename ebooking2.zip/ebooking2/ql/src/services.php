<?php
	if ( !isset($_SESSION['username']) ) {
		echo"<script>window.location='/index.php';</script>";
	}else{
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	echo"
	<table width='100%' cellpadding='0' cellspacing='0' align='center'>
	<tr>
		<td align='left'><font size='+1'><strong>This page will guide you to setup your server services.</strong></font></td>
	</tr>
	<tr>
		<td><table><tr><td></td></tr></table></td>
	</tr>
	<tr>
		<td width='100%'>
		<table width='100%' cellpadding='0' cellspacing='1' border='0' bgcolor='#66cc00'>
		<tr bgcolor='#eeeeee'>
			<td align='center' width='25%' height='30'><b>Services</b></td>
			<td align='center' width='20%'><b>Status</b></td>
			<td align='center' width='30%'><b>Message</b></td>
			<td align='center' colspan='2'  width='25%'><b>Operation</b></td>
		</tr>
		<tr bgcolor='#ffffff'>
			<td height='30' align='center'><b>Secure Shell ( SSH )</b></td>
			<td align='center'>&nbsp;<span id='sshd_status'></span>&nbsp;</td>
			<td align='center'>&nbsp;<span id='sshd_msg'></span>&nbsp;</td>
			<td align='center'>&nbsp;<span id='sshd_start'></span>&nbsp;</td>
			<td align='center'>&nbsp;<span id='sshd_stop'></span>&nbsp;</td>
		</tr>

		<tr bgcolor='#ffffff'>
			<td height='30' align='center'><b>DHCP Server</b></td>
			<td align='center'>&nbsp;<span id='dhcpd_status'></span>&nbsp;</td>
			<td align='center'>&nbsp;<span id='dhcpd_msg'></span>&nbsp;</td>
			<td align='center'>&nbsp;<span id='dhcpd_start'></span>&nbsp;</td>
			<td align='center'>&nbsp;<span id='dhcpd_stop'></span>&nbsp;</td>
		</tr>

		<tr bgcolor='#ffffff'>
			<td height='30' align='center'><b>System Management</b></td>
			<td align='center'><img src='img/green.png' border='0'></td>
			<td align='center'>&nbsp;<span id='halt'></span>&nbsp;</td>
			<td align='center'><a href=\"#\" onclick=\"javascript:halt('restart');\" ><img src='img/restart.png' border='0'></td>
			<td align='center'><a href=\"#\" onclick=\"javascript:halt('shutdown');\" ><img src='img/shutdown.png' border='0'></td>
		</tr>
		</table>
		</td>
	</tr>
	</table>
	";
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	}
?>
<script>
function halt(cs){
	var req = Inint_AJAX();
	req.onreadystatechange=function()
	{
		if (req.readyState==4 && req.status==200){
			var rtext=req.responseText;
			document.getElementById("halt").innerHTML=rtext;
		}
	};
	req.open('POST', 'src/services_ajax.php');
	req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=tis-620"); //Header ������
	req.send("services="+cs);
}

function webcam(cs){
	var req = Inint_AJAX();
	req.onreadystatechange=function()
	{
		if (req.readyState==4 && req.status==200){
			var rtext=req.responseText.split('##');
			switch (rtext[0]) {
				case "C" :
					if(rtext[1]=='1'){
						document.getElementById("webcam_status").innerHTML = "<img src=\"img/green.png\" border=\"0\">";
						document.getElementById("webcam_msg").innerHTML = rtext[2];
						document.getElementById("webcam_start").innerHTML = "<img src=\"img/start_off.png\" border=\"0\">";
						document.getElementById("webcam_stop").innerHTML = "<a href=\"#\" onclick=\"javascript:webcam_stop();\" ><img src=\"img/stop.png\" border=\"0\"></a>";
					}else{
						document.getElementById("webcam_status").innerHTML = "<img src=\"img/red.png\" border=\"0\">";
						document.getElementById("webcam_msg").innerHTML = rtext[2];
						document.getElementById("webcam_start").innerHTML = "<a href=\"#\" onclick=\"javascript:webcam_start();\" ><img src=\"img/start.png\" border=\"0\"></a>";
						document.getElementById("webcam_stop").innerHTML = "<img src=\"img/stop_off.png\" border=\"0\">";
					}
				break;
				case "start" :
					if(rtext[1]=='1'){
						document.getElementById("webcam_status").innerHTML = "<img src=\"img/green.png\" border=\"0\">";
						document.getElementById("webcam_msg").innerHTML = rtext[2];
						document.getElementById("webcam_start").innerHTML = "<img src=\"img/start_off.png\" border=\"0\">";
						document.getElementById("webcam_stop").innerHTML = "<a href=\"#\" onclick=\"javascript:webcam_stop();\" ><img src=\"img/stop.png\" border=\"0\"></a>";
					}else{
						document.getElementById("webcam_status").innerHTML = "<img src=\"img/red.png\" border=\"0\">";
						document.getElementById("webcam_msg").innerHTML = rtext[2];
						document.getElementById("webcam_start").innerHTML = "<a href=\"#\" onclick=\"javascript:webcam_start();\" ><img src=\"img/start.png\" border=\"0\"></a>";
						document.getElementById("webcam_stop").innerHTML = "<img src=\"img/stop_off.png\" border=\"0\">";
						webcam("webcam_check_start");
					}
				break;
				case "stop" :
					if(rtext[1]=='1'){
						document.getElementById("webcam_status").innerHTML = "<img src=\"img/red.png\" border=\"0\">";
						document.getElementById("webcam_msg").innerHTML = rtext[2];
						document.getElementById("webcam_start").innerHTML = "<a href=\"#\" onclick=\"javascript:webcam_start();\" ><img src=\"img/start.png\" border=\"0\"></a>";
						document.getElementById("webcam_stop").innerHTML = "<img src=\"img/stop_off.png\" border=\"0\">";
					}else{
						document.getElementById("webcam_status").innerHTML = "<img src=\"img/green.png\" border=\"0\">";
						document.getElementById("webcam_msg").innerHTML = rtext[2];
						document.getElementById("webcam_start").innerHTML = "<img src=\"img/start_off.png\" border=\"0\">";
						document.getElementById("webcam_stop").innerHTML = "<a href=\"#\" onclick=\"javascript:webcam_stop();\" ><img src=\"img/stop.png\" border=\"0\"></a>";
						webcam("webcam_check_stop");
					}
				break;
			}
		}
	};
	req.open('POST', 'src/services_ajax.php');
	req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=tis-620"); //Header ������
	req.send("services="+cs);
}

function webcam_start(){
	var req = Inint_AJAX();
	req.onreadystatechange=function()
	{
		if (req.readyState==4 && req.status==200){
			webcam("webcam_check_start");
		}
	};
	req.open('POST', 'src/services_ajax.php');
	req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=tis-620"); //Header ������
	req.send("services=webcam_start");
}

function webcam_stop(){
	var req = Inint_AJAX();
	req.onreadystatechange=function()
	{
		if (req.readyState==4 && req.status==200){
			webcam("webcam_check_stop");
		}
	};
	req.open('POST', 'src/services_ajax.php');
	req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=tis-620"); //Header ������
	req.send("services=webcam_stop");
}

//#########################################################################

function sshd(cs){
	var req = Inint_AJAX();
	req.onreadystatechange=function()
	{
		if (req.readyState==4 && req.status==200){
			var rtext=req.responseText.split('##');
			switch (rtext[0]) {
				case "C" :
					if(rtext[1]=='1'){
						document.getElementById("sshd_status").innerHTML = "<img src=\"img/green.png\" border=\"0\">";
						document.getElementById("sshd_msg").innerHTML = rtext[2];
						document.getElementById("sshd_start").innerHTML = "<img src=\"img/start_off.png\" border=\"0\">";
						document.getElementById("sshd_stop").innerHTML = "<a href=\"#\" onclick=\"javascript:sshd_stop();\" ><img src=\"img/stop.png\" border=\"0\"></a>";
					}else{
						document.getElementById("sshd_status").innerHTML = "<img src=\"img/red.png\" border=\"0\">";
						document.getElementById("sshd_msg").innerHTML = rtext[2];
						document.getElementById("sshd_start").innerHTML = "<a href=\"#\" onclick=\"javascript:sshd_start();\" ><img src=\"img/start.png\" border=\"0\"></a>";
						document.getElementById("sshd_stop").innerHTML = "<img src=\"img/stop_off.png\" border=\"0\">";
					}
				break;
				case "start" :
					if(rtext[1]=='1'){
						document.getElementById("sshd_status").innerHTML = "<img src=\"img/green.png\" border=\"0\">";
						document.getElementById("sshd_msg").innerHTML = rtext[2];
						document.getElementById("sshd_start").innerHTML = "<img src=\"img/start_off.png\" border=\"0\">";
						document.getElementById("sshd_stop").innerHTML = "<a href=\"#\" onclick=\"javascript:sshd_stop();\" ><img src=\"img/stop.png\" border=\"0\"></a>";
					}else{
						document.getElementById("sshd_status").innerHTML = "<img src=\"img/red.png\" border=\"0\">";
						document.getElementById("sshd_msg").innerHTML = rtext[2];
						document.getElementById("sshd_start").innerHTML = "<a href=\"#\" onclick=\"javascript:sshd_start();\" ><img src=\"img/start.png\" border=\"0\"></a>";
						document.getElementById("sshd_stop").innerHTML = "<img src=\"img/stop_off.png\" border=\"0\">";
						sshd("sshd_check_start");
					}
				break;
				case "stop" :
					if(rtext[1]=='1'){
						document.getElementById("sshd_status").innerHTML = "<img src=\"img/red.png\" border=\"0\">";
						document.getElementById("sshd_msg").innerHTML = rtext[2];
						document.getElementById("sshd_start").innerHTML = "<a href=\"#\" onclick=\"javascript:sshd_start();\" ><img src=\"img/start.png\" border=\"0\"></a>";
						document.getElementById("sshd_stop").innerHTML = "<img src=\"img/stop_off.png\" border=\"0\">";
					}else{
						document.getElementById("sshd_status").innerHTML = "<img src=\"img/green.png\" border=\"0\">";
						document.getElementById("sshd_msg").innerHTML = rtext[2];
						document.getElementById("sshd_start").innerHTML = "<img src=\"img/start_off.png\" border=\"0\">";
						document.getElementById("sshd_stop").innerHTML = "<a href=\"#\" onclick=\"javascript:sshd_stop();\" ><img src=\"img/stop.png\" border=\"0\"></a>";
						sshd("sshd_check_stop");
					}
				break;
			}
		}
	};
	req.open('POST', 'src/services_ajax.php');
	req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=tis-620"); //Header ������
	req.send("services="+cs);
}

function sshd_stop(){
	var req = Inint_AJAX();
	req.onreadystatechange=function()
	{
		if (req.readyState==4 && req.status==200){
			sshd("sshd_check_stop");
		}
	};
	req.open('POST', 'src/services_ajax.php');
	req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=tis-620"); //Header ������
	req.send("services=sshd_stop");
}

function sshd_start(){
	var req = Inint_AJAX();
	req.onreadystatechange=function()
	{
		if (req.readyState==4 && req.status==200){
			sshd("sshd_check_start");
		}
	};
	req.open('POST', 'src/services_ajax.php');
	req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=tis-620"); //Header ������
	req.send("services=sshd_start");
}

//#########################################################################

function x11vnc(cs){
	var req = Inint_AJAX();
	req.onreadystatechange=function()
	{
		if (req.readyState==4 && req.status==200){
			var rtext=req.responseText.split('##');
			switch (rtext[0]) {
				case "C" :
					if(rtext[1]=='1'){
						document.getElementById("x11vnc_status").innerHTML = "<img src=\"img/green.png\" border=\"0\">";
						document.getElementById("x11vnc_msg").innerHTML = rtext[2];
						document.getElementById("x11vnc_start").innerHTML = "<img src=\"img/start_off.png\" border=\"0\">";
						document.getElementById("x11vnc_stop").innerHTML = "<a href=\"#\" onclick=\"javascript:x11vnc_stop();\" ><img src=\"img/stop.png\" border=\"0\"></a>";
					}else{
						document.getElementById("x11vnc_status").innerHTML = "<img src=\"img/red.png\" border=\"0\">";
						document.getElementById("x11vnc_msg").innerHTML = rtext[2];
						document.getElementById("x11vnc_start").innerHTML = "<a href=\"#\" onclick=\"javascript:x11vnc_start();\" ><img src=\"img/start.png\" border=\"0\"></a>";
						document.getElementById("x11vnc_stop").innerHTML = "<img src=\"img/stop_off.png\" border=\"0\">";
					}
				break;
				case "start" :
					if(rtext[1]=='1'){
						document.getElementById("x11vnc_status").innerHTML = "<img src=\"img/green.png\" border=\"0\">";
						document.getElementById("x11vnc_msg").innerHTML = rtext[2];
						document.getElementById("x11vnc_start").innerHTML = "<img src=\"img/start_off.png\" border=\"0\">";
						document.getElementById("x11vnc_stop").innerHTML = "<a href=\"#\" onclick=\"javascript:x11vnc_stop();\" ><img src=\"img/stop.png\" border=\"0\"></a>";
					}else if(rtext[1]=='0'){
						document.getElementById("x11vnc_status").innerHTML = "<img src=\"img/red.png\" border=\"0\">";
						document.getElementById("x11vnc_msg").innerHTML = rtext[2];
						document.getElementById("x11vnc_start").innerHTML = "<a href=\"#\" onclick=\"javascript:x11vnc_start();\" ><img src=\"img/start.png\" border=\"0\"></a>";
						document.getElementById("x11vnc_stop").innerHTML = "<img src=\"img/stop_off.png\" border=\"0\">";
						x11vnc("x11vnc_check_start2");
					}else{
						document.getElementById("x11vnc_status").innerHTML = "<img src=\"img/red.png\" border=\"0\">";
						document.getElementById("x11vnc_msg").innerHTML = rtext[2];
						document.getElementById("x11vnc_start").innerHTML = "<a href=\"#\" onclick=\"javascript:x11vnc_start();\" ><img src=\"img/start.png\" border=\"0\"></a>";
						document.getElementById("x11vnc_stop").innerHTML = "<img src=\"img/stop_off.png\" border=\"0\">";
						alert("Service Cannot Start !!");
					}
				break;
				case "stop" :
					if(rtext[1]=='1'){
						document.getElementById("x11vnc_status").innerHTML = "<img src=\"img/red.png\" border=\"0\">";
						document.getElementById("x11vnc_msg").innerHTML = rtext[2];
						document.getElementById("x11vnc_start").innerHTML = "<a href=\"#\" onclick=\"javascript:x11vnc_start();\" ><img src=\"img/start.png\" border=\"0\"></a>";
						document.getElementById("x11vnc_stop").innerHTML = "<img src=\"img/stop_off.png\" border=\"0\">";
					}else{
						document.getElementById("x11vnc_status").innerHTML = "<img src=\"img/green.png\" border=\"0\">";
						document.getElementById("x11vnc_msg").innerHTML = rtext[2];
						document.getElementById("x11vnc_start").innerHTML = "<img src=\"img/start_off.png\" border=\"0\">";
						document.getElementById("x11vnc_stop").innerHTML = "<a href=\"#\" onclick=\"javascript:x11vnc_stop();\" ><img src=\"img/stop.png\" border=\"0\"></a>";
						x11vnc("x11vnc_check_stop");
					}
				break;
				default:
				alert("aaa");
			}
		}
	};
	req.open('POST', 'src/services_ajax.php');
	req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=tis-620"); //Header ������
	req.send("services="+cs);
}

function x11vnc_stop(){
	var req = Inint_AJAX();
	req.onreadystatechange=function()
	{
		if (req.readyState==4 && req.status==200){
			x11vnc("x11vnc_check_stop");
		}
	};
	req.open('POST', 'src/services_ajax.php');
	req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=tis-620"); //Header ������
	req.send("services=x11vnc_stop");
}
function x11vnc_start(){
	var req = Inint_AJAX();
	req.onreadystatechange=function()
	{
		if (req.readyState==4 && req.status==200){
			var rtext=req.responseText.split('##');
			x11vnc("x11vnc_check_start");
		}
	};
	req.open('POST', 'src/services_ajax.php');
	req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=tis-620"); //Header ������
	req.send("services=x11vnc_start");
}

//#########################################################################

function dhcpd(cs){
	var req = Inint_AJAX();
	req.onreadystatechange=function()
	{
		if (req.readyState==4 && req.status==200){
			var rtext=req.responseText.split('##');
			switch (rtext[0]) {
				case "C" :
					if(rtext[1]=='1'){
						document.getElementById("dhcpd_status").innerHTML = "<img src=\"img/green.png\" border=\"0\">";
						document.getElementById("dhcpd_msg").innerHTML = rtext[2];
						document.getElementById("dhcpd_start").innerHTML = "<img src=\"img/start_off.png\" border=\"0\">";
						document.getElementById("dhcpd_stop").innerHTML = "<a href=\"#\" onclick=\"javascript:dhcpd_stop();\" ><img src=\"img/stop.png\" border=\"0\"></a>";
					}else{
						document.getElementById("dhcpd_status").innerHTML = "<img src=\"img/red.png\" border=\"0\">";
						document.getElementById("dhcpd_msg").innerHTML = rtext[2];
						document.getElementById("dhcpd_start").innerHTML = "<a href=\"#\" onclick=\"javascript:dhcpd_start();\" ><img src=\"img/start.png\" border=\"0\"></a>";
						document.getElementById("dhcpd_stop").innerHTML = "<img src=\"img/stop_off.png\" border=\"0\">";
					}
				break;
				case "start" :
					if(rtext[1]=='1'){
						document.getElementById("dhcpd_status").innerHTML = "<img src=\"img/green.png\" border=\"0\">";
						document.getElementById("dhcpd_msg").innerHTML = rtext[2];
						document.getElementById("dhcpd_start").innerHTML = "<img src=\"img/start_off.png\" border=\"0\">";
						document.getElementById("dhcpd_stop").innerHTML = "<a href=\"#\" onclick=\"javascript:dhcpd_stop();\" ><img src=\"img/stop.png\" border=\"0\"></a>";
					}else if(rtext[1]=='0'){
						document.getElementById("dhcpd_status").innerHTML = "<img src=\"img/red.png\" border=\"0\">";
						document.getElementById("dhcpd_msg").innerHTML = rtext[2];
						document.getElementById("dhcpd_start").innerHTML = "<a href=\"#\" onclick=\"javascript:dhcpd_start();\" ><img src=\"img/start.png\" border=\"0\"></a>";
						document.getElementById("dhcpd_stop").innerHTML = "<img src=\"img/stop_off.png\" border=\"0\">";
						dhcpd("dhcpd_check_start2");
					}else{
						document.getElementById("dhcpd_status").innerHTML = "<img src=\"img/red.png\" border=\"0\">";
						document.getElementById("dhcpd_msg").innerHTML = rtext[2];
						document.getElementById("dhcpd_start").innerHTML = "<a href=\"#\" onclick=\"javascript:dhcpd_start();\" ><img src=\"img/start.png\" border=\"0\"></a>";
						document.getElementById("dhcpd_stop").innerHTML = "<img src=\"img/stop_off.png\" border=\"0\">";
						alert("Service Cannot Start!!");
					}
				break;
				case "stop" :
					if(rtext[1]=='1'){
						document.getElementById("dhcpd_status").innerHTML = "<img src=\"img/red.png\" border=\"0\">";
						document.getElementById("dhcpd_msg").innerHTML = rtext[2];
						document.getElementById("dhcpd_start").innerHTML = "<a href=\"#\" onclick=\"javascript:dhcpd_start();\" ><img src=\"img/start.png\" border=\"0\"></a>";
						document.getElementById("dhcpd_stop").innerHTML = "<img src=\"img/stop_off.png\" border=\"0\">";
					}else{
						document.getElementById("dhcpd_status").innerHTML = "<img src=\"img/green.png\" border=\"0\">";
						document.getElementById("dhcpd_msg").innerHTML = rtext[2];
						document.getElementById("dhcpd_start").innerHTML = "<img src=\"img/start_off.png\" border=\"0\">";
						document.getElementById("dhcpd_stop").innerHTML = "<a href=\"#\" onclick=\"javascript:dhcpd_stop();\" ><img src=\"img/stop.png\" border=\"0\"></a>";
						dhcpd("dhcpd_check_stop");
					}
				break;
			}
		}
	};
	req.open('POST', 'src/services_ajax.php');
	req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=tis-620"); //Header ������
	req.send("services="+cs);
}

function dhcpd_stop(){
	var req = Inint_AJAX();
	req.onreadystatechange=function()
	{
		if (req.readyState==4 && req.status==200){
			dhcpd("dhcpd_check_stop");
		}
	};
	req.open('POST', 'src/services_ajax.php');
	req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=tis-620"); //Header ������
	req.send("services=dhcpd_stop");
}
function dhcpd_start(){
	var req = Inint_AJAX();
	req.onreadystatechange=function()
	{
		if (req.readyState==4 && req.status==200){
			dhcpd("dhcpd_check_start");
		}
	};
	req.open('POST', 'src/services_ajax.php');
	req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=tis-620"); //Header ������
	req.send("services=dhcpd_start");
}

webcam("webcam_check");
sshd("sshd_check");
x11vnc("x11vnc_check");
dhcpd("dhcpd_check");
</script>



