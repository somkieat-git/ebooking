<?php
	header("Expires: Sat, 1 Jan 2005 00:00:00 GMT");
	header("Last-Modified: ".gmdate( "D, d M Y H:i:s")."GMT");
	header("Cache-Control: no-cache, must-revalidate");
	header("Pragma: no-cache");
	header("content-type: application/x-javascript; charset=tis-620");
	$QFILE="/tmp/ql_action";  $QCOMMAND_PATH="/srv/www/ql/wroot";
	$fh = fopen($QFILE,"w");
	switch($_POST['services'])
	{
		case "webcam_check" : 
			exec("ps ax | grep motion | grep Sl | awk '{print $5}' " ,$var);
			if($var[0] == "/usr/bin/motion"){
				echo"C##1##CCTV Started";
			}else{
				echo"C##0##Stop";
			}
		break;
		case "webcam_check_start" : 
			exec("ps ax | grep motion | grep Sl | awk '{print $5}' " ,$var);
			if($var[0] == "/usr/bin/motion"){
				echo"start##1##Low Cost CCTV";
			}else{
				echo"start##0##Starting...";
			}
		break;
		case "webcam_check_stop" : 
			exec("ps ax | grep motion | grep Sl | awk '{print $5}' " ,$var);
			if($var[0] == "/usr/bin/motion"){
				echo"stop##0##Stoping...";
			}else{
				echo"stop##1##Stop";
			}
		break;
		case "webcam_start" : 
			fwrite($fh,"PHAYOUNE   webcam   start");
			fclose($fh);
			system($QCOMMAND_PATH);
		break;
		case "webcam_stop" : 
			fwrite($fh,"PHAYOUNE  webcam   stop"); 
			fclose($fh);
			system($QCOMMAND_PATH);
		break;
		
		
		case "sshd_check" : 
			exec("ps ax | grep sshd | grep SNs | awk '{print $5}' " ,$var);
			if($var[0] == "/usr/sbin/sshd"){
				echo"C##1##sshd Started";
			}else{
				echo"C##0##Stop";
			}
		break;
		case "sshd_stop" : 
			fwrite($fh,"PHAYOUNE   sshd   stop"); 
			fclose($fh);
			system($QCOMMAND_PATH);
		break;
		case "sshd_start" : 
			fwrite($fh,"PHAYOUNE   sshd   start");
			fclose($fh);
			system($QCOMMAND_PATH);
		break;
		case "sshd_check_start" : 
			exec("ps ax | grep sshd | grep SNs | awk '{print $5}' " ,$var);
			if($var[0] == "/usr/sbin/sshd"){
				echo"start##1##sshd Started";
			}else{
				echo"start##0##sshd Starting...";
			}
		break;
		case "sshd_check_stop" : 
			exec("ps ax | grep sshd | grep SNs | awk '{print $5}' " ,$var);
			if($var[0] == "/usr/sbin/sshd"){
				echo"stop##0##sshd Stoping...";
			}else{
				echo"stop##1##sshd Stop";
			}
		break;
		
		
		case "x11vnc_check" : 
			exec("ps ax | grep x11vnc | grep S | awk '{print $5}' " ,$var);
			if($var[0] == "/usr/bin/x11vnc"){
				echo"C##1##X11VNC Started";
			}else{
				echo"C##0##Stop";
			}
		break;
		case "x11vnc_stop" : 
			fwrite($fh,"PHAYOUNE   x11vnc   stop"); 
			fclose($fh);
			system($QCOMMAND_PATH);
			sleep(3);
		break;
		case "x11vnc_start" : 
			fwrite($fh,"PHAYOUNE   x11vnc   start"); 
			fclose($fh);
			system($QCOMMAND_PATH);
			sleep(1);
		break;
		case "x11vnc_check_start" : 
			exec("ps ax | grep x11vnc | grep S | awk '{print $5}' " ,$var);
			if($var[0] == "/usr/bin/x11vnc"){
				echo"start##1##X11VNC Started";
			}else{
				echo"start##0##Starting...";
			}
		break;
		case "x11vnc_check_start2" : 
			exec("ps ax | grep x11vnc | grep S | awk '{print $5}' " ,$var);
			if($var[0] == "/usr/bin/x11vnc"){
				echo"start##1##X11VNC Start";
			}else{
				echo"start##2##Stop";
			}
		break;
		case "x11vnc_check_stop" : 
			exec("ps ax | grep x11vnc | grep S | awk '{print $5}' " ,$var);
			if($var[0] == ""){
				echo"stop##0##Stoping...";
			}else{
				echo"stop##1##Stop";
			}
		break;
				
		case "dhcpd_check" : 
			exec("ps ax | grep dhcp | grep SNs | awk '{print $5}' " ,$var);
			if($var[0] == "/usr/sbin/dhcpd"){
				echo"C##1##dhcpd Started";
			}else{
				echo"C##0##Stop";
			}
		break;
		case "dhcpd_stop" : 
			fwrite($fh,"PHAYOUNE   dhcpd   stop"); 
			fclose($fh);
			system($QCOMMAND_PATH);
		break;
		case "dhcpd_start" : 
			fwrite($fh,"PHAYOUNE   dhcpd   stop"); 
			fclose($fh);
			system($QCOMMAND_PATH);
			sleep(1);
		break;
		case "dhcpd_check_start" : 
			exec("ps ax | grep 'dhcpd -q eth1' | grep SNs | awk '{print $5}' " ,$var);
			if($var[0] == "/usr/sbin/dhcpd"){
				echo"start##1##dhcpd Started";
			}else{
				echo"start##0##Starting...";
			}
		break;
		case "dhcpd_check_start2" : 
			exec("ps ax | grep dhcp | grep SNs | awk '{print $5}' " ,$var);
			if($var[0] == "/usr/sbin/dhcpd"){
				echo"start##1##dhcpd Start";
			}else{
				echo"start##2##Stop";
			}
		break;
		case "dhcpd_check_stop" : 
			exec("ps ax | grep dhcp | grep SNs | awk '{print $5}' " ,$var);
			if($var[0] == "/usr/sbin/dhcpd"){
				echo"stop##0##Stoping...";
			}else{
				echo"stop##1##Stop";
			}
		break;
		
		case "restart" : 
			fwrite($fh,"PHAYOUNE   reboot   0"); 
			fclose($fh);
			system($QCOMMAND_PATH);
		break;
		case "shutdown" : 
			fwrite($fh,"PHAYOUNE   init   0"); 
			fclose($fh);
			system($QCOMMAND_PATH);
		break;
	}
?>