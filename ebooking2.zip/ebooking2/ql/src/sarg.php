<?php
	header("Expires: Sat, 1 Jan 2005 00:00:00 GMT");
	header("Last-Modified: ".gmdate( "D, d M Y H:i:s")."GMT");
	header("Cache-Control: no-cache, must-revalidate");
	header("Pragma: no-cache");
	if ( isset($_SESSION['username']) ) {
		$filename = "/srv/www/htdocs/sarg/index.html";
 		if (!file_exists($filename)) {
     			echo "<h2>The sarge report  has not generated yet!!!</h2>";
 			} else {
			echo"
			<table width='100%' height='500' cellpadding='0' cellspacing='0' align='center'>
				<tr>
					<td align='center' valign='middle' width='100%' height='100%'>
					<iframe id='sarg' name='sarg' frameborder='0' width='99%' height='99%' src='http://".$_SERVER["SERVER_ADDR"]."/sarg/' scrolling='auto'></iframe>
					</td>
				</tr>
			</table>";
			}
	}else{
	echo"<script>window.location='index.php';</script>";
	}
?>