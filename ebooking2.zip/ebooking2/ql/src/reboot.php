<?php
		//Create /tmp/ql_action
		$QFILE="/tmp/ql_action";
		$QKEY="PHAYOUNE";
		$Qcommand = "init";
		$Qparameter = "6";

		$fh = fopen($QFILE,"w") or die("can not open file"); 
		$ql_data="$QKEY    $Qcommand    $Qparameter  0\n";
		fwrite($fh,$ql_data) ;
		fclose($fh);


		print("<h1>System will reboot Now</h1>");
		print("<center><INPUT type=\"submit\" name=\"submit\" value=\"Back\"><center>");
		sleep(2);
		system("/srv/www/ql/wroot");
?>

