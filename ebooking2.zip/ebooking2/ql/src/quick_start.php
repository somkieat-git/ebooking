<?php
	if ( !isset($_SESSION['username']) ) {
	echo"<script>window.location='/index.php';</script>";
	}else{
		if ( isset($submit) ){	
			if (empty($HD)) { $HD="" ; }
			if (empty($IP1)) { $IP1=0 ; }	
			if (empty($NetMask1)) { $NetMask1=0 ; }	
			if (empty($IP2)) { $IP2=0 ; }	
			if (empty($NetMask2)) { $NetMask2=0 ; }	
			if (empty($Gateway)) { $Gateway=0 ; }	
			if (empty($DNS1)) { $DNS1=0 ; }	
			if (empty($DNS2)) { $DNS2=0 ; }	
			if (empty($DHCP_START)) { $DHCP_START=0 ; }
			if (empty($DHCP_END)) { $DHCP_END=0 ; }		
			if (isset($DHCPD)) { $DHCPD=1 ; } else{ $DHCPD=0 ;}
			if (isset($SSH)) { $SSH=1 ; } else{ $SSH=0 ;}
			if (isset($WebCam)) { $WebCam=1 ; } else{ $WebCam=0 ;}
		$QKEY="PHAYOUNE";
//////////////////////////////////////////////////////////////////////////////
//// Fdisk
		if (!empty($HD)) {
		$QFILE1="/tmp/qlfdisk_req";
		$fh1 = fopen($QFILE1,"w") or die("can not open file"); 
		$ql_data1  = "$QKEY  FDISK $HD[0]\n";
		fwrite($fh1,$ql_data1) ;
		fclose($fh1);
		system("/srv/www/ql/qlfdisk");
		}
///////////////////////////////////////////////////////////////////////////////
//// Show Post value
		$QFILE2="/tmp/ql_quick_config";
		$fh2 = fopen($QFILE2,"w") or die("can not open file"); 
		$ql_data2  = "$QKEY  $IP1  $NetMask1  $IP2  $NetMask2  $Gateway  $DNS1  $DNS2  $SSH  $WebCam\n";
		fwrite($fh2,$ql_data2) ;
		fclose($fh2);

//		print("<FORM action=\"index.php?link=reboot\" method=\"POST\" target=\"_self\">");
		print("<h3>Your Server will be config with data as details the following.</h3>");
		print("External IP: $IP1 netmask $NetMask1 <br><br>") ;
		print("Internal IP: $IP2 netmask $NetMask2 <br><br>") ;
		print("Gateway IP: $Gateway<br><br>") ;
		print("Primary  DNS: $DNS1  and Secondary DNS: $DNS2 <br><br>") ;
		print("DHCP Assign IP: $DHCP_START to  $DHCP_END <br><br>") ;
			if ( $DHCPD == 1 ) { $DHCPD_V="on" ; } else{ $DHCPD_V="Off" ;}
			if ( $SSH == 1 ) { $SSH_V="on" ; } else{ $SSH_V="Off" ;}
			if ( $WebCam == 1 ) { $WebCam_V="On" ; } else{ $WebCam_V="Off" ;}	
		print("Servives on Startup: Secure Shell(ssh) = $SSH_V  and WebCam = $WebCam_V <br>") ;
		//system("/srv/www/ql/quick_start");
/////////////////////////////////////////////////////////////////////////////////
//// write config file
		if ( is_dir("/media/floppy/qlconfig") )	{//temp
//		if ( is_dir("/ql_bin/config/QLconfig") )	{
		$QFILE3="/media/floppy/qlconfig/QLconfig"; //temp
//		$QFILE3="/ql_bin/config/QLconfig";
		//$QKEY="PHAYOUNE";
		$fh3 = fopen($QFILE3,"w") or die("can not open file"); 
		fwrite($fh3,"#Create by Phayoune Quicl log script"); 		fwrite($fh3,"\n");
		fwrite($fh3,"KEY=$QKEY"); 		fwrite($fh3,"\n");
		fwrite($fh3,"IP1=$IP1"); 		fwrite($fh3,"\n");
		fwrite($fh3,"NM1=$NetMask1"); 		fwrite($fh3,"\n");
		fwrite($fh3,"IP2=$IP2"); 		fwrite($fh3,"\n");
		fwrite($fh3,"NM2=$NetMask2"); 		fwrite($fh3,"\n");
		fwrite($fh3,"GW=$Gateway"); 		fwrite($fh3,"\n");
		fwrite($fh3,"DNS1=$DNS1"); 		fwrite($fh3,"\n");
		fwrite($fh3,"DNS2=$DNS2"); 		fwrite($fh3,"\n");
		fwrite($fh3,"DHCP_START=$DHCP_START"); 	fwrite($fh3,"\n");
		fwrite($fh3,"DHCP_END=$DHCP_END"); 	fwrite($fh3,"\n");
		fwrite($fh3,"#Start Services"); 	fwrite($fh3,"\n");
		fwrite($fh3,"DHCPD=$DHCPD"); 		fwrite($fh3,"\n");
		fwrite($fh3,"SSH=$SSH"); 		fwrite($fh3,"\n");
		fwrite($fh3,"WebCam=$WebCam"); 	fwrite($fh3,"\n");
		fwrite($fh3,"Firewall=1"); 		fwrite($fh3,"\n");
		fwrite($fh3,"Squid=1"); 	fwrite($fh3,"\n");
		fclose($fh3);
			}
		}else{
/////////////////////////////////////////////////////////////////////////
		print("<FORM method=\"POST\" target=\"_self\">");

		$QFILE="/tmp/qlfdisk_req";
		$QKEY="PHAYOUNE";
		$fh = fopen($QFILE,"w") or die("can not open file"); 
		$ql_data  = "$QKEY  CHK_DISK  text\n";
		fwrite($fh,$ql_data) ;
		fclose($fh);
		system("/srv/www/ql/qlfdisk");	
		//exec("fdisk -l | grep Disk",$QDISK);
		$FH = fopen("/tmp/qlfdisk_info","r");
		while( !feof($FH) ){$QDISK[] = fgets($FH) ; }fclose($FH);
		print("<h3>I ��������췴�ʡ�</h3>");
		print("1. ����������á<br>");
		for( $i=0 ; $i < count($QDISK)-1 ; $i++){
		$SUB_disk = substr($QDISK[$i],strpos($QDISK[$i],":")-3,3) ; 
		//echo $SUB_disk."<br>" ;
//		print("&nbsp;&nbsp;&nbsp;<INPUT type=\"checkbox\" name=\"HD$i\"  value=$QDISK[$i]> $QDISK[$i]<br>");
		print("&nbsp;&nbsp;&nbsp;<INPUT type=\"checkbox\" name=\"HD[]\"  value=$SUB_disk> $QDISK[$i]<br>");
		}
////////////////////////////////////////////////////////////////////////
		print("<h3>II �͹�ԡ��ҵ�ҧ�</h3>");
		print("1. ����;բҹ͡����Ѻ�͡�Թ�����絾����������(Type your  IP address and Netmask for Internet.)<br>");
		print("&nbsp;&nbsp;&nbsp;<strong>ip</strong>:&nbsp;<INPUT type=\"text\" name=\"IP1\"> &nbsp; <strong>netmask</strong>:&nbsp;<INPUT type=\"text\" name=\"NetMask1\">");
		print("<br><br><br>");

		print("2. ����;բ������Ѻǧ�Ź�����������(Type your  IP address and Netmask for LAN or Intranet.)<br>");
		print("&nbsp;&nbsp;&nbsp;<strong>ip</strong>:&nbsp;<INPUT type=\"text\" name=\"IP2\"> &nbsp; <strong>netmask</strong>:&nbsp;<INPUT type=\"text\" name=\"NetMask2\">");
		print("<br><br><br>");

		print("3. ����;�ࡵ��������Ѻ�͡�Թ������(Type your Gateway or Router IP)<br>");
		print("&nbsp;&nbsp;&nbsp;<strong>ip</strong>:&nbsp;<INPUT type=\"text\" name=\"Gateway\">");
		print("<br><br><br>");

		print("4. ����;� DNS1 ��� DNS2 (Type your DNS IP)<br>");
		print("&nbsp;&nbsp;&nbsp;<strong>DNS1</strong>:&nbsp;<INPUT type=\"text\" name=\"DNS1\"> &nbsp; <strong>DNS2</strong>:&nbsp;<INPUT type=\"text\" name=\"DNS2\">");
		print("<br><br><br>");

		print("5. �ó��� DHCP �������ǧ�;� ����ͧ���ᨡ<br>");
		print("&nbsp;&nbsp;&nbsp;<strong>�����</strong>:&nbsp;<INPUT type=\"text\" name=\"DHCP_START\"> &nbsp; <strong>�֧</strong>:&nbsp;<INPUT type=\"text\" name=\"DHCP_END\">");
		print("<br><br><br>");

		print("6. ���͡��ԡ�÷���ͧ����Դ�ء���駷���Դ����ͧ (Select services which you want.)<br>");
		print("&nbsp;&nbsp;&nbsp;<strong>DHCP</strong>:&nbsp;<INPUT type=\"checkbox\" name=\"DHCPD\">
		       &nbsp; <strong>SSH</strong>:&nbsp;<INPUT type=\"checkbox\"  name=\"SSH\" >  &nbsp;<strong>WebCam</strong>:&nbsp;<INPUT type=\"checkbox\"  name=\"WebCam\" >");
		print("<br><br><br>");

		print("<center><INPUT type=\"submit\" name=\"submit\" value=\"Next>\"><center>");
		print("<INPUT type=\"hidden\" name=\"link\" value=\"quick_start>\"><center>");
         	print("</FORM>");
		} //if2
	}//if1
?>


