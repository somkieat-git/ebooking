<?php
if ( isset($_SESSION['username']) ) {
	echo"
	<table width='100%' cellpadding='0' cellspacing='0' align='center'>
	<tr>
		<td align='left'><div id='show_log_squid'></div></td>
	</tr>
	</table>
	";
}else{
	echo"<script>window.location='index.php';</script>";
}
?>
<script>
function log_squid()
{
	var req = Inint_AJAX();
	req.onreadystatechange=function()
	{
		if (req.readyState==4 && req.status==200){
			document.getElementById("show_log_squid").innerHTML = req.responseText;
			setTimeout("log_squid()", 1000);
		}
	};
	req.open('POST', 'src/log_squid_ajax.php');
	req.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=tis-620"); //Header ������
	req.send(null);
}
log_squid();
</script>