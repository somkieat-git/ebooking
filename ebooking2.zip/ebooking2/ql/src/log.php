<?php
	if ( isset($_SESSION['username']) ) {
		print("<pre>");
		system("tail -20 /var/log/apache/access_log");
		print("<pre>");
	}else{
	echo"<script>window.location='/index.php';</script>";
	}
?>