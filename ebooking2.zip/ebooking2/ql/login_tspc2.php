<?php
session_start();

include "inc/config.php";
include "inc/function.php";
include "inc/header.php";
//error_reporting(E_ALL ^E_NOTICE ^E_WARNING);

echo "ql/login_tspc2.php >br>";
exit();

if(isset($_REQUEST["ncc"])) {
	Ssite=$_REQUEST["ncc"];
	$_SESSION["site"]=$site;
}

//if(isset($_SESSION["site"])){
//	$site=$_SESSION["site"];
//}else{
//	echo "site session = null";
//	$site=$_REQUEST['s'];	
//}	

switch ($site) {
case "tspc":
	$logo="../images/logo/tspc.png";
	break;
case "gjc":
	$logo="../images/logo/gjc.png";
	break;
case "psu":
	$logo="../images/logo/psu.png";
	break;
default:
	$logo="../images/logo/gjc.png";
	$site="gjc";
	$_SESSION["site"]=$site;
}


$form_login="
<table cellpadding='2' cellspacing='2' align='center' border='0'>
<tr>
	<td>Username</td>
	<td>&nbsp;</td>
	<td><input type='text' id='username' name='username' class='input_text' onkeypress=\"return cEnter(event);\"></td>
</tr>
<tr>
	<td>Password</td>
	<td>&nbsp;</td>
	<td><input center(event);\"=\"true\" type=\"password\" name=\"password\" id=\"password\" class=\"input_text\" onkeypress=\"return cEnter(event);\"></td>
</tr>
<tr style=\"display:none\">
	<td>Language</td>
	<td>&nbsp;</td>
	<td><select name='slang' id='slang' class='input_text'><option value='th'>Thai<option value='en'>English</select></td>
</tr>
<tr>
	<td><a href='../usr_forgot.php'>Forgot Password</a></td>
	<td>&nbsp;</td>
	<td><input type='image' src='img/login_button.png' onclick='javascript:check_login();'>	  	
	</td>
</tr>
</table>
";

$detail="
<table border='0' cellpadding='0' cellspacing='0' align='center' width='100%'>
<tr>
	<td colspan='2'><br></td>
</tr>
<tr>
	<td class='login_title' colspan='2' align='center'>".LOGIN_TITLE."</td>
</tr>
<tr>
	<td colspan='2'><br></td>
</tr>
<tr>
	<td width='40%' valign='top' style='padding-left:5;'><span id='msg_login'>Use a valid username and password to gain access to the administration console.</span></td>
	<td colspan='2' width='60%'>".small_box($form_login)."</td>		
</tr>
<tr>
	<td valign='middle' align='center' style='padding-right:30;'><img src='img/icon_login.gif'></td>
	<td align='center'><table><tr><td><img src='img/p_ncc_logo.gif'></td><td>&nbsp;</td></tr></table></td>
	<td align='center'><table><tr><td><img src='$logo'></td><td>&nbsp;</td></tr></table></td>
</tr>
<tr>
	<td colspan='2'><br></td>
</tr>
</table>
";

echo"
<table border='0' width='100%' height='100%' cellpadding='0' cellspacing='0'>
<tr>
	<td valign='middle' height='100%' width='100%' align='center'>
	
	<table border='0' width='55%' cellpadding='0' cellspacing='0'>
	<tr>
		<td>".small_box($detail)."</td>
	</tr>
	</table>
	
	</td>
</tr>
</table>
";
include "inc/footer.php";
?>
<script>document.getElementById("username").focus();</script>

