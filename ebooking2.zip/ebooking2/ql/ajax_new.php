<?php
	header("content-type: application/x-javascript; charset=tis-620");
	
	$login=0;
	/******************** process ********************/
	/*
		Value from Form :
			$_POST['username']
			$_POST['password']
			$_POST['language']
		
		Check username and password here.
			Read from txt file or database.
		Ex.
		*/
		
		#########################
		//MrTaN
		$hostname="localhost";
		$user="root";
		$pass="NCC2009";
		$dbname="thebook16";
		$result=0;
		$link = mysql_connect($hostname,$user,$pass) or die(mysql_error());
		mysql_select_db($dbname,$link) or die(mysql_error());
		//mysql_query("SET NAMES 'tis620'",$link);
		
//		$sql=" select login, password from `users` ";
//		$sql.=" where login = '".$_POST['username']."'";
//		//$sql.=" and password = '".substr(md5($_POST['password']),0,16)."'";	
		
		$sql = " select usr.*, sec.* ";
		$sql.= " from user usr, security sec ";
		$sql.= " where usr.usr_sec = sec.sec_id ";
		$sql.= " and usr.usr_login = '".$_POST['username']."' ";		
			
		
		$result=mysql_query($sql,$link);
	
		$row = mysql_fetch_array($result);
		$getUser=$row["usr_id"];	
		$getPass=$row["usr_pass"];
		
		if($getUser){			
			$md5LogPass=($_POST['password']);
			$md5LogPass=md5($md5LogPass);		
			
			if($md5LogPass == $getPass){
				$login=1;
				
/*				//include_once("../db/connect.db.php");
				include_once("../func/sql.func.php");		
				
				// #2.Save usr_name in $_SESSION["usr_name"]
				$_SESSION["usr_name"] = $row['usr_name'];
				$_SESSION["usr_id"] = $row['usr_id'];
				$_SESSION["usr_pass"] = $_POST['password'];
				//echo "\$usr_pass=$usr_pass<hr>"; exit();
				
				// #3. Save data in Logfile
				$log_ip = $_SERVER["REMOTE_ADDR"];
				$sql = "insert into logfile values(
					'',now(),'$usr_login','$log_ip','index.php','begin use program'
					)";
				//echo $sql ; 
				mysql_query($sql) or die ("Save logfile error");
				
				// #4. check authorize save in $_SESSION["?"]
				//$arrView= array();
				//$arrViewn= array();
				$arrView = explode(",", $row["sec_view"]);				
				$arrViewn = getAuthor($arrView);				
				//print_r(array_keys($arrViewn));
				$_SESSION["sec_view"]  = $arrViewn ; 
				
				//echo "index.php.sec_add =  ".$row["sec_add"]."<br>";
				
				$arrAdd = explode(",", $row["sec_add"]);				
				$arrAddn = getAuthor($arrAdd);				
				//print_r(array_keys($arrAddn));
				$_SESSION["sec_add"] = $arrAddn;
				
				$arrEdit = explode(",", $row["sec_edit"]);				
				$arrEditn = getAuthor($arrEdit);				
				//print_r(array_keys($arrEditn));
				$_SESSION["sec_edit"] = $arrEditn;
				
				$arrDel = explode(",", $row["sec_del"]);				
				$arrDeln = getAuthor($arrDel);				
				//print_r(array_keys($arrDeln));
				$_SESSION["sec_del"] = $arrDeln;
				
				
				// #5. check authorize admin & save in $_SESSION["admin"]			
				if ($row["sec_name"]=='admin')
					$_SESSION["admin"] = true;
				else
					$_SESSION["admin"] = false;					
					
					$_SESSION["id"]=$usr_login;
					
/*					echo "<script> window.location = 'fra_main.php' ;</script>";			
*/			
				
				//include("../db/disconnect.db.php");
*/			}
			
		} //if($getUser){		


	/******************** process ********************/
	
	
	/***************** do not modify *****************/
	if($login == 0)
	{
		echo"$login";
	}else{
		session_start();
		$_SESSION['username']=$_POST['username'];
		$_SESSION['language']=$_POST['language'];
		$_SESSION["id"]=$_POST['username'];
		echo"$login";
	}
	/***************** do not modify *****************/
?>
