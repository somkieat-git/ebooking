<?php
	
	$sid=$_REQUEST["sid"];
	$Juser=$_REQUEST["u"];
	$FormName=$_REQUEST["f"];
	//echo "\$sid=$sid<br>\$Juser=$Juser<br>\$FormName=$FormName<br>"; exit();
	
	if($sid && $Juser){
		//echo "Yes:app/it/thebook1.7/index.php<hr>"; //exit();
		
		session_start();
		$_SESSION['username']=$Juser;
		
		switch ($FormName) {
		case "index_tspc.php":
			$_SESSION["site"]="tspc";
			break;
		case "index_gjc.php":
			$_SESSION["site"]="gjc";
			break;
		case "index_psu.php":
			$_SESSION["site"]="psu";
			break;
		default:
			$_SESSION["site"]="gjc";
		}//end switch ($site) {
		
		include_once("cfg/config.cfg.php");
		
		$hostname=hostname;
		$user=username;
		$pass=password;
		$dbname=dbname;
		//echo "<hr>\$hostname=$hostname, \$user=$user, \$pass=$pass, \$dbname=$dbname"; exit();
		
		$result=0;
		$link = mysql_connect($hostname,$user,$pass) or die(mysql_error());
		mysql_select_db($dbname,$link) or die(mysql_error());
		mysql_query("SET NAMES 'utf8'",$link);
		//echo "<br>\$link=$link<br>"; //exit();
		
		//MrTan
		$usr_login=$Juser;
		
		$sql = " select usr.*, sec.* ";
		$sql.= " from user usr, security sec ";
		$sql.= " where usr.usr_sec = sec.sec_id ";
		$sql.= " and usr.usr_login = '".$usr_login."' ";	
		$sql.= " and ( usr.usr_used  = 'Y'";	
		$sql.= " or usr.usr_used  = 'y')";	
		//echo "\$sql=$sql<br>";exit();
		
		$result=mysql_query($sql,$link);		
		$arrResult = mysql_fetch_array($result);
		//echo "\$arrResult=<pre>";print_r($arrResult); exit();
		
		$getUser=$arrResult["usr_id"];	
		$getPass=$arrResult["usr_pass"];
		
		include_once("func/sql.func.php");
		$SaveLog=updLog($usr_login, 'index.php', 'login by '.$_SERVER['HTTP_USER_AGENT']);			
		
		//check authorize save in $_SESSION["?"]
		$arrView = explode(",", $arrResult["sec_view"]);				
		$arrViewn = getAuthor($arrView);				
		//echo "<pre>";print_r(array_keys($arrViewn));

		
		//session_start();
		$_SESSION["sec_view"]  = $arrViewn ; 
		
		//echo "index.php.sec_add =  ".$row["sec_add"]."<br>";		
		$arrAdd = explode(",", $arrResult["sec_add"]);		
		$arrAddn = getAuthor($arrAdd);				
		//print_r(array_keys($arrAddn));
		$_SESSION["sec_add"] = $arrAddn;
		
		
		$arrEdit = explode(",", $arrResult["sec_edit"]);				
		$arrEditn = getAuthor($arrEdit);				
		//print_r(array_keys($arrEditn));
		$_SESSION["sec_edit"] = $arrEditn;
		
		$arrDel = explode(",", $arrResult["sec_del"]);				
		$arrDeln = getAuthor($arrDel);				
		//print_r(array_keys($arrDeln));		
		$_SESSION["sec_del"] = $arrDeln;		
		
		// #check authorize admin & save in $_SESSION["admin"]			
		if ($arrResult["sec_name"]=='admin'){
			$_SESSION["admin"] = true;
		}					
		else{
			$_SESSION["admin"] = false;			
		}		
		
		//Collect Value in Session Variable		
		$_SESSION["usr_name"] = $arrResult['usr_name'];		
		$_SESSION["UsrID"] = $arrResult['usr_id'];				
		$_SESSION["id"] = $arrResult['usr_id'];						
		
		$RedirectURL="fra_main.php";	
		//echo "\$RedirectURL=$RedirectURL<br>"; //exit();
	}else{
		//echo "No<br>";exit();
		$RedirectURL="ql/index.php";
		//echo "\$RedirectURL=$RedirectURL<br>";exit();
	}//if($sid && $Juser){
	
?>
<script>
window.location='<?php echo $RedirectURL ?>';
</script>
