<?
	
	//ob_start();
	session_start();
//	$_SESSION["site"]="tspc";
	$site="tspc";
	session_register("site");
	
	//$nccSite=$_REQUEST['s'];
?>
<script>
window.location='./ql/index_tspc2.php';
//window.location='http://nccubuntu.qsncc.co.th/app/nccgroup/thebook1.7/ql/index_tspc2.php';
//window.location='http://nccubuntu.qsncc.co.th/app/nccgroup/thebook1.7/ql/index_tspc2.php?s=<?=$nccSite?>';
//window.location='http://nccubuntu.qsncc.co.th/app/nccgroup/tsp-cc/thebook1.6/index.php';
</script>
