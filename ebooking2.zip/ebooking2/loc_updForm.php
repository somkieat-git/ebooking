<?
//	ob_start();
//	session_start();	
	error_reporting(E_ALL ^E_NOTICE ^E_WARNING ^ E_DEPRECATED);
	$loc_id = $_REQUEST["loc_id"];
	$loc_shortname = $_REQUEST["loc_shortname"];
	$loc_fullname = $_REQUEST["loc_fullname"];
	$loc_sqm = $_REQUEST["loc_sqm"];
	$lgp_id = $_REQUEST["lgp_id"];
	$loc_seq = $_REQUEST["loc_seq"];
	$stt_id = $_REQUEST["stt_id"];

	$id = $_REQUEST["id"];
	$action = $_REQUEST["a"];
	$Submit = $_REQUEST["Submit"];
	$cap_name = array();
	$cap_name = array("#","Short Name","Full Name","Sqm.","Location Group","Seq.","Settlement Group");
	
	/*echo "frm_id = $frm_id<br>
	   frm_name= $frm_name<br>
	   frm_status = $frm_status<br>
	   id = $id<br>
	   action = $action<br>
	   Submit = $Submit <hr>";*/
			   
	define("viewForm","flexigrid/loc_vfrm.php");
	define("updSave","loc_updForm.php");
	define("tableName","location");
	define("menuName","Location");
	define("field_id","loc_id");
	define("action",$action);
	define("id",$id);	
	define("beg_id",1);	
	define("end_id",6);	
	include_once("func/updForm.func.php");	
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");	
		
	function duplicate($field,$value){
		global $dup;		
		$sql = "select $field 
				from location
				where $field = '$value' ";
		//cho $sql;		
		$table = mysql_query($sql) or die ("Connect Err.");
		$row=mysql_fetch_array($table);
		if($row[$field]== $value){
			$dup[$field] = $value;
		}//if($row[$field]== $value){
	}//	function duplicate($field,$value){	
				
	function checklist($var,$name){
		global $data;global $flag;

		if(empty($var)){
			if(preg_match("/loc_shortname|loc_fullname|loc_sqm/",$name))
				$flag = 1;
		}  //if(empty($var)){
		$data[$name] = $var;
	} //function checklist($var,$name){
	
	if(!empty($Submit)){
		checklist($loc_shortname,"loc_shortname");
		checklist($loc_fullname,"loc_fullname");
		checklist($loc_sqm,"loc_sqm");
		checklist($lgp_id,"lgp_id");
		checklist($loc_seq,"loc_seq");
		checklist($stt_id,"stt_id");
		if($flag){
			$mesg = "Please input data in ";
			while(list($key,$value) = each($data)){
				if(empty($value)){
					//จุดที่ต้องแก้ไข 5.copy ในจุดที่ 3 มาไว้บรรทัดนี้ด้วย
				if(!preg_match("/loc_shortname|loc_fullname|loc_sqm/",$name))
						$str .= "$key,";
				}  //if(empty($value)){
				//$str = substr( $str, strlen($str)-1, 1 );
			}
			echo errmesg ("$mesg $str");			
		}	//if($flag){
		else{
			//จุดที่ต้องแก้ไข 6 เตรียมWrite ลง DB ตามเงื่อนไข Action		
			if ($action=="a"){
				$data["loc_id"] = "";
				$data["usr_cre"] = $_SESSION["usr_name"];
				$data["date_cre"] = date("Y/m/d  H:i:s");
				
				duplicate("loc_shortname",$loc_shortname);
				duplicate("loc_fullname",$loc_fullname);
				if(count($dup)>0) {
					while(list($key,$value)= each($dup)){
						//echo "$key<br>";
						if(preg_match("/loc_shortname|loc_fullname/",$key))
							$str .= $key.",";
					} // while(list($key,$value)= each($dup)){				
					echo errmesg("Duplicate $str");
					exit();					
				}//if(count($dup)>0) {
				
				$query = create_insert_query($table_name,$data);				
				//echo "$query<br>";
				mysql_query($query) or die("Insert error");		
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");			
				//Show alert by javascript
				echo "<script>
						alert ('Insert complete');
						window.location = 'loc_updForm.php?a=a';
					  </script>";
				exit();
			} //if ($action=="a"){
			
			if ($action=="e"){
				$data["usr_upd"] = $_SESSION["usr_name"];
				$data["date_upd"] = date("Y/m/d  H:i:s");				
				/*
				duplicate("loc_shortname",$loc_shortname);
				duplicate("loc_fullname",$loc_fullname);
				if(count($dup)>0) {
					while(list($key,$value)= each($dup)){
						//echo "$key<br>";
						if(preg_match("rtc_code|rtc_name",$key))
							$str .= $key.",";
					} // while(list($key,$value)= each($dup)){				
					echo errmesg("Duplicate $str");
					exit();
				}//if(count($dup)>0) {
				*/
				$query = create_update_query($table_name, $data, $id, $field_id);				
				//echo "$query<br>";
				mysql_query($query) or die("Update error");		
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");			
				//Show alert by javascript
				echo "<script>
						alert ('Update complete');
						window.location = '".viewForm."';
					  </script>";
				exit();
			}  //if ($action=="e"){
			
			if ($action=="d"){
				$query = "DELETE FROM $table_name WHERE $field_id = $id " ;
				//echo "$query<br>";
				//exit();
				
				mysql_query($query) or die("Delete error");
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");					
				//Show alert by javascript
				echo "<script>
						alert ('Delete complete');
						window.location = '".viewForm."';
					  </script>";
				exit();
			}  //if ($action=="e"){
						
		}  //else{ of if($flag){
	}  //if(!empty($Submit)){
	
?>
<script language="javascript">
	function validate() 
	{
		if(frm.loc_shortname.value=="")
		{
			alert('Please input data in Short Name');
			frm.loc_shortname.focus()
			return false;
		}

		if(frm.loc_fullname.value=="")
		{
			alert('Please input data in Full Name');
			frm.loc_fullname.focus()
			return false;
		}
		
		if(frm.loc_sqm.value=="" || frm.loc_sqm.value=="0")
		{
			alert('Please input data in Sqm.');
			frm.loc_sqm.focus()
			return false;
		}	
	}
</script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</body>
</html>
