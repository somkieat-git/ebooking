<?php 
	ob_start();
	session_start();
	//include_once("db/connect.db.php");
	//include_once("func/sql.func.php");
	$efsv_showRev = $_SESSION["efsv_showRev"];
	//echo "\$efsv_showRev= <pre>"; print_r($efsv_showRev); echo "<hr>";

?>
<table width="50%" border="1" cellpadding="0" cellspacing="0" bordercolor="#DDDDFF" class="BorderGreen">
  <tr height="30">
   <th style="background-color:#6699CC;font-weight:bold;color:White;">DATE</th>
   <th style="background-color:#6699CC;font-weight:bold;color:White;">Food</th>
   <th style="background-color:#6699CC;font-weight:bold;color:White;">Rentotal</th>
  </tr>
  <?php 
  	foreach( $efsv_showRev as $revSource => $arrData ){
	 foreach($arrData as $key => $data){
	 $rev_date = chgDate($data["rev_date"]);
	 $rev_net = $data["rev_net"];	
	 $rev_link = $data["rev_link"];
	 $sum_net += $rev_net;
  ?>
  <tr height="25">
   <td align="center"><?php echo $rev_date; ?></td>
   <td align="center">
    <?php 
		$sql = "SELECT eesv.esv_id , esv.esv_name ";
		$sql .= " FROM ev_food_serv eesv , equip_serv esv ";
		$sql .= " WHERE eesv_id = $rev_link ";
		$sql .= " AND eesv.esv_id = esv.esv_id ;" ;
		$result = getData($sql);
		$rs = mysql_fetch_array($result);
		$esv_name = $rs["esv_name"];
		
		echo $esv_name;
	?>
   </td>
   <td align="center">
    <?php echo chgNumber($rev_net) ; ?>
   </td>
  </tr>
  <?php 
  	 }
  	} 
  ?>
  <tr height="25">
   <td style="background-color:#6699CC;font-weight:bold;color:White;" align="right" colspan="2" >Total : &nbsp;&nbsp;</td>
   <td style="background-color:#6699CC;font-weight:bold;color:White;" align="center"><?php echo chgNumber($sum_net); ?></td>
  </tr>
 </table>