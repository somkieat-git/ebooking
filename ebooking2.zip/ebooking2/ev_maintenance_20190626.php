<?	
	ob_start();
	session_start();
	include_once("db/connect.db.php");
	//include_once("db/chksession.db.php");
	include_once("func/sql.func.php");
	define("updSave","new_event.php");
	
	//request value from other form
	$evn_id = $_REQUEST["id"];
	$bk18 = $_SESSION["bk18"];  // By Kae
	
	
	//======================Begin prepare standard data======================================
		
	if(!empty($evn_id)){
		$sql = "SELECT * FROM eventname WHERE evn_id = '$evn_id'  ";
		$result = getData($sql);
		$row = mysql_fetch_array($result);
	} //if(!empty($ev_id)){	
	
?>
<html>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">

</head>
	
<body >
<form name="frm"  id="frm" method="post" action="" >
  <div align="center"></div>
  <div align="center"></div>
  <table width="90%"  border="0" align="left" cellpadding="6" cellspacing="6" class="BorderSilver">
    <tr class="BorderSilver">
      <td height="25" colspan="5" style="background-color:#339900;font-weight:bold;color:White;">
        <div align="center"><strong >Event Maintenance </strong></div>
	  </td>
    </tr>
    <tr>
      <td width="22%" height="20"><span class="mandatory">Event Id </span></td>
	  <td width="33%"><div align="right"><span class="mandatory">Full Event Name : </span></div></td>
      <td colspan="2"><?=$row["evn_fullname"]?></td>
    </tr>
    <tr>
      <td height="20"><?=$evn_id?></td>
      <td><div align="right"><span class="mandatory">Short Event Name : </span></div></td>
      <td colspan="2"><?=$row["evn_shortname"]?></td>
    </tr>
    <tr>
      <td height="20" colspan="4"><hr width="100%" noshade  color="#339900"></td>
    </tr>
    <tr>
      <td height="20" colspan="4"><span class="mandatory">Mandatory Items </span></td>
    </tr>
    <tr>
		<a href="esta_updForm.php?id=<?=$evn_id?>"><td  class="TD_Button"><a href="esta_updForm.php?id=<?=$evn_id?>"><div align="center" >Statistics</div></td></a></a>
		<a href="edbk_viewForm.php?id=<?=$evn_id?>"><td class="TD_Button"><a href="edbk_viewForm.php?id=<?=$evn_id?>"><div align="center">Event Date </div></td></a></a>
		<?php 
		if( $bk18 == "Yes" ){ // By Kae
			$link = "ecus_updForm2.php?id=$evn_id";
			$link2 = "ecmt_updForm2.php?id=$evn_id";
		}else{
			$link = "ecus_updForm.php?id=$evn_id";
			$link2 = "ecmt_updForm.php?id=$evn_id";
		}
		?>
		<a href="<?=$link?>">
			<td  class="TD_Button">
				<a href="<?=$link?>">
					<div align="center">Clients</div>
				</td></a>
			
		</a>
		<a href="estf_updForm.php?id=<?=$evn_id?>"><td class="TD_Button">
		<a href="estf_updForm.php?id=<?=$evn_id?>"><div align="center">Staff</div></td></a></a>
    </tr>
    <tr>
      <td height="20" colspan="4"><span class="mandatory">Optional Items </span></td>
    </tr>
    <tr class="TD_Button">
      <a href="eloc_viewForm.php?id=<?=$evn_id?>"><td height="20" class="TD_Button"><a href="eloc_viewForm.php?id=<?=$evn_id?>"><div align="center">Location</div></td></a></a>
      <a href="eesv_viewForm.php?id=<?=$evn_id?>"><td class="TD_Button"><a href="eesv_viewForm.php?id=<?=$evn_id?>"><div align="center">Equipment/Services</div></td></a></a>
      <a href="efsv_viewForm.php?id=<?=$evn_id?>"><td class="TD_Button"><a href="efsv_viewForm.php?id=<?=$evn_id?>"><div align="center">Food Serviecs</div></td></a></a>
      <a href="<?=$link2?>"><td class="TD_Button"><a href="<?=$link2?>"><div align="center">Comments</div></td></a></a>
    </tr>
    <tr class="TD_Button">
      <a href="eckl_viewForm.php?id=<?=$evn_id?>"><td height="20" class="TD_Button"><a href="eckl_viewForm.php?id=<?=$evn_id?>"><div align="center">Check Lists </div></td></a></a>
       <a href="dpd_viewForm.php?id=<?=$evn_id?>"><td class="TD_Button"><a href="dpd_viewForm.php?id=<?=$evn_id?>"><div align="center">Event Per Day </div></td></a></a>
      <a href="esch_viewForm.php?id=<?=$evn_id?>"><td class="TD_Button"><a href="esch_viewForm.php?id=<?=$evn_id?>"><div align="center">Schedule</div></td></a></a>
       <a href="eset_viewForm.php?id=<?=$evn_id?>"><td class="TD_Button"><a href="eset_viewForm.php?id=<?=$evn_id?>"><div align="center">Setup Instruction</div></td></a></a>
    </tr>
    <tr>
      <td height="20" colspan="4"><span class="mandatory">Utilities</span></td>
    </tr>
    <tr>
      <!--<td height="20" class="TD_Button"><div align="center">Rebook</div></td>-->
	  <a href="erbk_updForm.php?id=<?=$evn_id?>"><td height="20" class="TD_Button"><a href="erbk_updForm.php?id=<?=$evn_id?>"><div align="center">Rebook</div></td></a></a>
      <td class="TD_Button"><div align="center">Cancel Event </div></td>
      <td><div align="center"></div></td>
      <td><div align="center"></div></td>
    </tr>
    <tr>
      <td height="29" colspan="2"><div align="right">
          <input name="Submit" type="submit" class="Button" value="   OK   " onClick="window.location = 'fra_booking.php'">
      </div></td>
      <td colspan="2"><div align="left">
          <input name="Button" type="button" class="Button" id="Button2"  onClick="history.go(-1)" value="Cancel" >
      </div></td>
    </tr>
  </table>
</form>
</body>
</html>

