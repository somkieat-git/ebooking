<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<!-- saved from url=(0043)http://192.168.90.18/php/cuteflow/index.php -->
<HTML><HEAD><TITLE>CuteFlow</TITLE>
<META http-equiv=Content-Type content="text/html; charset=utf-8"><LINK 
href="file:///C|/My%20Documents/CuteFlow_files/format.css" type=text/css rel=stylesheet>
<SCRIPT language=JavaScript src="file:///C|/My%20Documents/CuteFlow_files/jsval.js" 
type=text/javascript></SCRIPT>

<SCRIPT language=JavaScript1.2>
	<!--
		function setProps()
		{
			var objForm = document.forms["Login"];
			
			objForm.Password.required = 1;
			objForm.Password.err = "Please enter a valid password!";
			
			objForm.UserId.required = 1;
			objForm.UserId.err = "Please enter a valid user id!";
		}
	//-->
	</SCRIPT>

<META content="MSHTML 5.50.4134.600" name=GENERATOR>
<link href="include/thebook.css.php" rel="stylesheet" type="text/css">
</HEAD>
<BODY onload=setProps()><BR>
<H2 
style="FONT-WEIGHT: bold; BACKGROUND-COLOR: #dfdfdf; TEXT-ALIGN: center"> The Book System </H2>
<BR><BR><BR>
<DIV align=center class="syntax_indent7"><BR>
  <BR><BR>
<TABLE class="warning">
  <TBODY>
  <TR>
    <TD vAlign=top><img style="LEFT: 35px; POSITION: relative; TOP: -15px" 
      height=48 alt=login src="file:///C|/My%20Documents/CuteFlow_files/login.png" width=48> </TD>
    <TD>
      <FORM id=Login onsubmit="return jsVal(this);" action=file:///C|/My%20Documents/login.php 
method=post>
      <TABLE class=note border=0>
        <TBODY>
        <TR>
          <TD style="FONT-WEIGHT: bold; COLOR: white; BACKGROUND-COLOR: red" 
          colSpan=2><STRONG style="PADDING-LEFT: 35px">Login</STRONG></TD></TR>
        <TR>
          <TD colSpan=2 height=15></TD></TR>
        <TR>
          <TD>Username:</TD>
          <TD><INPUT name=usr_login class=FormInput id="usr_login"></TD></TR>
        <TR>
          <TD>Password:</TD>
          <TD><INPUT name=usr_pass type=password class=FormInput id="usr_pass"></TD></TR>
        <TR>
          <TD 
          style="PADDING-RIGHT: 0px; BORDER-TOP: #b8b8b8 1px solid; PADDING-LEFT: 0px; PADDING-BOTTOM: 4px; PADDING-TOP: 6px" 
          align=right colSpan=2><INPUT class=syntax_alpha_charset type=submit value=Login> 
          </TD></TR></TBODY></TABLE>
      </FORM></TD>
  <TD width=48>&nbsp;</TD></TR></TBODY></TABLE><BR><BR>
</DIV>
</BODY></HTML>
