<?
ob_start(); 
session_start();	
//echo "sec_view=<pre>";print_r($_SESSION["sec_view"]);
//echo "sec_edit=<pre>";print_r($_SESSION["sec_edit"]);

$rptID=$_REQUEST["f"];
$arrReport=array(
	"47"=>array("Event Maintenance","fra_ev_maintenance.php"),
	"29"=>array("Event Profile","rpt_ev_profile.php"),
	"30"=>array("Event Document","rpt_ev_document.php"),
	"31"=>array("Event Settlement","rpt_set_eloc.php"),
);
//echo "\$arrReport=<pre>";print_r($arrReport);
//echo "\$rptID=$rptID<br>";

$urlLink=""; $rstOption=""; $arrOption=array();
foreach($arrReport as $kRpt=>$vRpt){
	#gen Option
	$chkAuth=0; $selected="";
	$kRpt==47? $sec_auth=$_SESSION["sec_edit"] : $sec_auth=$_SESSION["sec_view"];
	$chkAuth=array_key_exists($kRpt,$sec_auth);
	if($chkAuth){
		$firstAuth=="" ? $firstAuth="$kRpt" : 0 ;
		$rptID==$kRpt ? $selected="selected": $selected="";			
		$arrOption[$kRpt]=array($selected, $vRpt[0]);		
	}//if($chkAuth){	
}//foreach($arrReport as $kRpt=>$vRpt){
//echo "\$arrOption=<pre>";print_r($arrOption); echo"<hr>";




#gen urlLink
if($rptID){
	$urlLink=$arrReport[$rptID][1];
}else{
	$urlLink=$arrReport[$firstAuth][1];
}
//echo "\$urlLink=$urlLink<br>";

include_once("../cfg/config.cfg.php");
function runSQL($rsql) {

	$db['default']['hostname'] = hostname;
	$db['default']['username'] = username;
	$db['default']['password'] = password;
	$db['default']['database'] = dbname;
	
	$db['live']['hostname'] = 'localhost';
	$db['live']['username'] = '';
	$db['live']['password'] = '';
	$db['live']['database'] = '';
	
	$active_group = 'default';
	
	$base_url = "http://".$_SERVER['HTTP_HOST'];
	$base_url .= str_replace(basename($_SERVER['SCRIPT_NAME']),"",$_SERVER['SCRIPT_NAME']);

	$connect = mysql_connect($db[$active_group]['hostname'],$db[$active_group]['username'],$db[$active_group]['password']) or die ("Error: could not connect to database");
	$db = mysql_select_db($db[$active_group]['database']);
	mysql_query("SET NAMES 'utf8'",$connect);
	$result = mysql_query($rsql) or die ($rsql);
	
	return $result;
	mysql_close($connect);
}


##Prepare bookingstatus
$sql ="SELECT bks_id, bks_code, bks_name FROM bookingstatus ";
$sql .="  WHERE bks_id <> 1 ORDER BY bks_code ";				
$result = runSQL($sql);
$arr_bks[0] = array("bks_code"=>"ALL","bks_sname"=>"ALL - BKS");
while($rs_bks = mysql_fetch_array($result)){
	//$arr_bks[$rs_bks[0]] =  $rs_bks[1]." - ".$rs_bks[2];
	$arr_bks[$rs_bks["bks_id"]]=array(
		"bks_code"=>$rs_bks["bks_code"],
		"bks_sname"=>$rs_bks["bks_code"].' - '.$rs_bks["bks_name"]
	);
} //while($rs_bks = mysql_fetch_array($result)){
//echo "\$arr_bks=<pre>";print_r($arr_bks);
//$_SESSION[arr_bks]=$arr_bks;

##Prepare Show Fields
$arrSField=array(
	"bks_code"=>"Booking Status Code",
	"evn_id"=>"Event ID",
	"evn_shortname"=>"Event Short Name",
	"evn_fullname"=>"Event Full Name",
	"evn_thainame"=>"Event Thai Name",
	"Event_Manager"=>"Event Manager",
	"Event_Attendance"=>"Event Attendance",
	"Sales_Person"=>"Sales Person"	
);

$optLink=$_REQUEST["opt"];
if($optLink=="1"){	
	$optLink="index.php?opt=0&f=$rptID";
	$optDisplay='style="display:"';
	$calendarDisp='style="display:none"';
	$RptType='style="display:none"';
}else{
	$optLink="index.php?opt=1&f=$rptID";
	$optDisplay='style="display:none"';
	$calendarDisp='style="display:"';
	$RptType='style="display:"';
}//if($optLink=="1"){

$btnBKS=$_REQUEST["btnBKS"];
if($btnBKS){
	$bks_id = $_REQUEST["bks_id"];
	$_SESSION["bks_id"]=$bks_id;
	$selF1=$_REQUEST["selF1"];
	$_SESSION["selF1"]=$selF1;
	$selF2=$_REQUEST["selF2"];
	$_SESSION["selF2"]=$selF2;	
}else{
	$bks_id =$_SESSION["bks_id"];
	$selF1 =$_SESSION["selF1"];
	$selF2 =$_SESSION["selF2"];	
}//if($btnBKS){
if(is_array($bks_id)){
	count($bks_id)? $strBksID=implode(",",$bks_id): $strBksID="";	
}
!$selF1 ? $selF1="bks_code":0;
!$selF2 ? $selF2="evn_shortname":0;

//echo "\$selF1=$selF1, \$selF2=$selF2<hr>";

$nextyear  = date("Ym", mktime(0, 0, 0, date("m"),   date("d"),   date("Y")+1));
$prevyear  = date("Ym", mktime(0, 0, 0, date("m"),   date("d"),   date("Y")-1));

$sql ="SELECT evn.evn_id, evn.evn_shortname as evn_shortname, evn.evn_fullname as evn_fullname";
$sql.=" , evn.evn_thainame as evn_thainame, eloc.eloc_event_date";
$sql.=" ,eloc.eloc_event_time, eloc.eloc_end_date, eloc.eloc_end_time, bks.bks_code as bks_code";

$sql.=" ,estf1.usr_cre as Event_Manager, estf2.usr_cre as Event_Attendance, estf3.usr_cre as Sales_Person";

$sql.=" FROM eventname as evn";
$sql.=" left join ev_location as eloc on (evn.evn_id = eloc.evn_id)";
$sql.=" left join ev_statistics as esta on (evn.evn_id =esta.evn_id)";

$sql.=" left join ev_staff as estf1 on (evn.evn_id=estf1.evn_id and estf1.estf_item like 'Event Manager')";
$sql.=" left join ev_staff as estf2 on (evn.evn_id=estf2.evn_id and estf2.estf_item like 'Event Attendance')";
$sql.=" left join ev_staff as estf3 on (evn.evn_id=estf3.evn_id and estf3.estf_item like 'Sales Person')";

$sql.=" , bookingstatus as bks";
$sql.=" WHERE 1 = 1";

//$sql.=" and evn.evn_id = eloc.evn_id";
//$sql.=" and evn.evn_id =esta.evn_id";

$sql.=" and esta.bks_id=bks.bks_id";
$strBksID ? $sql.=" and esta.bks_id in ( $strBksID )":0;
$sql.=" and left(eloc_event_date,6) >= '".$prevyear."'";
$sql.=" and left(eloc_event_date,6) <= '".$nextyear."'";
$sql.=" and ( evn.evn_used='Y' or evn.evn_used='y' )";

//$sql.=" and estf1.evn_id=evn.evn_id";
//$sql.=" and estf2.evn_id=evn.evn_id";
//$sql.=" and estf3.evn_id=evn.evn_id";


//$sql.=" and estf1.evn_id=eloc.evn_id";
//$sql.=" and estf2.evn_id=eloc.evn_id";
//$sql.=" and estf3.evn_id=eloc.evn_id";

//$sql.=" and estf1.evn_id=esta.evn_id";
//$sql.=" and estf2.evn_id=esta.evn_id";
//$sql.=" and estf3.evn_id=esta.evn_id";

//$sql.=" and estf1.evn_id = estf2.evn_id";
//$sql.=" and estf1.evn_id = estf3.evn_id";
//$sql.=" and estf2.evn_id = estf3.evn_id";

/*
$sql.=" and estf1.estf_item like 'Event Manager'";
$sql.=" and estf2.estf_item like 'Event Attendance'";
$sql.=" and estf3.estf_item like 'Sales Person'";
*/

//$sql.=" and evn.evn_id like '10060010'";

$sql.=" group by eloc.eloc_event_date, evn.evn_id ";
$sql.=" order by eloc.eloc_event_date, evn.evn_id ";

//echo "$sql<hr>"; //exit();
$result = runSQL($sql);

$event="events: [ ";
$sp=false;
while ($row = mysql_fetch_array($result)) {
	//return $row[0];
	$sY=substr($row['eloc_event_date'],0,4);
	$sm=substr($row['eloc_event_date'],4,2)-1;
	$evnID=$row['evn_id'];
	//$title="'".$row['evn_shortname']."'";
	$title=htmlspecialchars($row[$selF2]);	
	$bksCode=$row['bks_code'];
	$showF1=htmlspecialchars($row[$selF1]);
	$showF2=$title;
	$start=substr($row['eloc_event_date'],6,2);	
	$sTime=substr($row['eloc_event_time'],0,2).", ".substr($row['eloc_event_time'],2,2);
	$start= "new Date($sY, $sm, $start, $sTime)";
	//echo "\$sTime=$sTime<br>";
	

	if($urlLink){
		$showLink="../$urlLink?id=$evnID";
	}//if($urlLink){
	
	
	$eY=substr($row['eloc_end_date'],0,4);
	$em=substr($row['eloc_end_date'],4,2)-1;
	$end=substr($row['eloc_end_date'],6,2);	
	$eTime=substr($row['eloc_end_time'],0,2).", ".substr($row['eloc_end_time'],2,2);
	$end= "new Date($eY, $em, $end, $eTime)";
	$allDay="true";
	if ($sp) $event .= ",";
	$event.="
		{
			title: \"[$showF1] $showF2\",			
			start: $start,
			end: $end,
			allDay: $allDay,
			url: \"$showLink\"			
		} ";
	$sp = true;

}	
$event.=" ]";

//echo "<pre>$event<br>";
//url: \"../fra_ev_maintenance.php?id=$evnID\"	





?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN""http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel='stylesheet' type='text/css' href='redmond/theme.css' />
<link rel='stylesheet' type='text/css' href='fullcalendar.css' />
<script type='text/javascript' src='jquery/jquery.js'></script>
<script type='text/javascript' src='jquery/ui.core.js'></script>
<script type='text/javascript' src='jquery/ui.draggable.js'></script>
<script type='text/javascript' src='jquery/ui.resizable.js'></script>
<script type='text/javascript' src='fullcalendar.min.js'></script>
<script type='text/javascript'>
<!--
$(document).ready(function() {
	
		var date = new Date();
		var d = date.getDate();
		var m = date.getMonth();
		var y = date.getFullYear();
		
		$('#calendar').fullCalendar({
			theme: true,
			header: {
				left: 'prev,next today',
				center: 'title',
				right: 'month,basicWeek,basicDay'
			},
			editable: true,
			<? echo $event; ?>

		});		
		
	});

function MM_jumpMenu(targ,selObj,restore){ //v3.0
  var rpt = selObj.options[selObj.selectedIndex].value;
  rpt="index.php?f="+rpt;	
  eval(targ+".location='"+rpt+"'");  
  if (restore) selObj.selectedIndex=0;
}
//-->
</script>
<style type='text/css'>

	body {
		margin-top: 40px;
		text-align: center;
		font-size: 14px;
		font-family: "sans-serif",Helvetica,Arial,Verdana,Lucida Grande;
		}

	#calendar {
		width: 900px;
		height:500px;
		margin: 0 auto;
		
		}

</style>
</head>
<body>
<div align="center">
	<?
	if(count($arrOption)){
	?>
	<form id="frm" action="<?=$optLink;?>" method="post" name="frm" >	
	<span id="RptType" <?=$RptType;?>>
	  <select name="menRpt" onchange="MM_jumpMenu('self',this,0)">
		<?
		foreach($arrOption as $k=>$v){
			echo "<option value='$k' $v[0]>$v[1]</option>";
		}//foreach($arrOption as $k=>$v){
		?>
	  </select>
	</span>	
  <span id="spOption"><a href="<?=$optLink;?>" >Option</a>&nbsp;:&nbsp;  
  <?
  	//echo print_r($bks_id);
	if(is_array($bks_id)){
		foreach($bks_id as $k=>$v){
			$arrShowBks[]=$arr_bks[$v]["bks_code"];
		}
		$ShowBks=implode(",",$arrShowBks);
	}//if(is_array($bks_id)){	
	echo "<b>$ShowBks</b>";
  ?>
  </span>
  
  <div id="showOpt" align="center" <?=$optDisplay;?> >		
	<table>
	<tr>
	  <td><strong>Booking Status Code:</strong></td>
	  <td>&nbsp;</td>
	  <td><strong>Show Title:</strong></td>	  
	</tr>
	<tr>
		<td>
			<select name="bks_id[]" size="10" multiple id="bks_id[]" >		
			<? foreach($arr_bks as $value=>$name) {
			echo "<option value= '".$value."'" ;
			if(is_array($bks_id)){
			if (in_array($value, $bks_id)) 
			echo ' selected' ; 																	
			} //if(is_array($bks_id)){				
			echo " >".$name["bks_sname"]."</option>";
			}	  //foreach($arr_bks as $value=>$name) {  
			?>
			</select>		
		</td>
		<td>&nbsp;</td>
		<td valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td>Field#1&nbsp;:&nbsp;</td>
            <td><select name="selF1">
			<? foreach($arrSField as $value=>$name) {
			echo "<option value= '".$value."'" ;	
				if($selF1){
					if($selF1==$value){					
						echo ' selected' ; 																	
					} //if($selF1==$value){					
				}else{
					if($value=="bks_code"){					
						echo ' selected' ; 																	
					} //if($selF1==$value){					
				}//if($selF1){			
				echo " >".$name."</option>";
			}//foreach($arr_bks as $value=>$name) {  
			?>
            </select>
            </td>
          </tr>
          <tr>
            <td>Field#2&nbsp;:&nbsp;</td>
            <td><select name="selF2" id="selF2">
			<? foreach($arrSField as $value=>$name) {
			echo "<option value= '".$value."'" ;	
				if($selF2){
					if($selF2==$value){					
						echo ' selected' ; 																	
					} //if($selF1==$value){					
				}else{
					if($value=="evn_shortname"){					
						echo ' selected' ; 																	
					} //if($selF1==$value){					
				}//if($selF1){			
				echo " >".$name."</option>";
			}//foreach($arr_bks as $value=>$name) {  
			?>
            </select></td>
          </tr>
        </table></td>
	    
	</tr>
	<tr><td colspan="3" align="center"><input name="btnBKS" type="submit" value="   OK   " />
	  <input name="btnCancel" type="button" id="btnCancel" value="Cancel" onclick="window.location='<?=$optLink;?>;'"/></td>
	  </tr>
	</table>	
  </div>	
		  
	</form>
	<?
	}//if(count($arrOption)){
	?>
</div>


<div id='calendar' <?=$calendarDisp;?>>
</div>
</body>
</html>
