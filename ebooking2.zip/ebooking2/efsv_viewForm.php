<?
	ob_start(); 
	session_start();
	include("db/chksession.db.php");
	$evn_id = $_REQUEST["id"];
	define("sysName","Food Services");
	define("tableName","ev_food_serv");
	define("viewForm","efsv_viewForm.php");
	define("updForm","efsv_updFormE.php");	
	define("addForm","efsv_updFormE.php");	
	define("field_id","eesv_id");	
	define("beg_id",1);	
	define("end_id",10);		
	
	$sql = "SELECT eesv.eesv_id, loc.loc_shortname, eesv.eesv_beg_date,
				eesv.eesv_end_date, esv.esv_name,  
				eesv.eesv_qty, eesv.eesv_day, eesv.eesv_amt, eesv.eesv_total,
				eesv.eesv_adj, eesv.eesv_net
				FROM ev_food_serv eesv, location loc, equip_serv esv
				WHERE eesv.loc_id = loc.loc_id
				AND eesv.esv_id = esv.esv_id
				AND eesv.evn_id = '$evn_id' 
				ORDER BY loc.loc_shortname, eesv.eesv_beg_date, eesv.eesv_end_date,
				esv.esv_name, eesv.eesv_id ";
	//echo "$sql";
	define("query","$sql");
		
	$cap_name = array();
	$cap_name = array("#","Room","Beg Date","End Date","Food Service","Qty","Days","@","Total","Adj","Net");
	
	//=============check authorize================
	$key = array_keys($_SESSION["sec_add"], viewForm); 
	if($key[0])
		define("insert",1);		
	else
		define("insert",0);			
		
	$key = array_keys($_SESSION["sec_edit"], viewForm); 
	if($key[0])
		define("edit",1);		
	else
		define("edit",0);			
		
	$key = array_keys($_SESSION["sec_del"], viewForm); 
	if($key[0])
		define("del",1);		
	else
		define("del",0);			
		
	include("func/ev_viewForm.func1.php");
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</body>
</html>
