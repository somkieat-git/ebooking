<?	
	ob_start();
	session_start();
	//include("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	define("updSave","dpd_updForm.php");
	$action = $_REQUEST["a"];
	$dpd_id = $_REQUEST["id"];
	$Submit = $_REQUEST["Submit"];
	//echo "action=$action<br>dpd_id= $dpd_id<br>submit = $Submit<hr>";

	//======================Begin select data from ev_dateblock===============================

	if($action != "a") {
			#Show ev_dateblock
			$sql = "SELECT *
						FROM dailyperday
						WHERE  dpd_id = '$dpd_id'
						";
			//echo "$sql<br>";
			$result = getData($sql);
			$rs_dpd = mysql_fetch_array($result);							
			$dpd_id =  $rs_dpd["dpd_id"];
			$dpd_code =  $rs_dpd["dpd_code"];
			$dpd_name =  $rs_dpd["dpd_name"];
		}
		

	
?>
<html>
<script language="javascript">
	function validate() 
	{
		if(frm.txt_dpd_code.value=="")
		{
			//Ϳ.ػó.value
			alert('Please input data in Code');
			frm.txt_dpd_code.focus()
			return false;
		}
		
		if(frm.txt_dpd_name.value=="")
		{
			//Ϳ.ػó.value
			alert('Please input data in Name');
			frm.txt_dpd_name.focus()
			return false;
		}
		
	}
</script>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">
<script language="javascript" type="text/javascript" src="datetimepicker.js"></script>
</head>
	
<body >
<form action="<?=updSave?>?a=<?=$action ?>&id=<?=$dpd_id?>" method="post" name="frm"  id="frm" onSubmit="return validate();" >
  <table border="0" class="BorderGreen" >
    <tr class="BorderSilver">
      <td colspan="2"  style="background-color:#339900;font-weight:bold;color:White;">
	  	<div align="center"><strong >Dailyperday</strong></div>
	  </td>
    </tr>
	<tr>
	  <td height="16" colspan="2" ><input name="dpd_id" type="hidden" id="dpd_id" value="<?=$dpd_id ;?>"></td>
    </tr>
	<tr>
	  <td ><div align="right">Code : </div></td>
      <td >	  
	  <input name="txt_dpd_code" type="text" id="txt_dpd_code" value="<?=$dpd_code;?>">
	  </td>
    </tr>
	<tr>
	  <td height="18" ><div align="right">Name : </div></td>
	  <td ><input name="txt_dpd_name" type="text" id="txt_dpd_name" value="<?=$dpd_name;?>" size="80">
	  </td>
    </tr>
	<tr>
	  <td height="16" colspan="2" >&nbsp;</td>
    </tr>
	<tr>
	  <td height="18" colspan="2" ><div align="center">
        <input name="Submit" type="submit" class="Button" value="   OK   "  onClick="return validate();" >
        <input name="btnDel" type="button" class="Button" id="btnDel"   value="Delete" <? if ($action=='a') echo "disabled" ;?> 
		onClick= "window.location = 'dpd_updForm.php?a=d&id=<?=$dpd_id?>' " >
        <input name="btnCancel" type="button" class="Button" id="btnCancel"  onClick="history.go(-1)" value="Cancel" >
      </div></td>
    </tr>		
  </table>
</form>
<?

	//======================Begin Save Data==============================================
	//request data into varible
	if(!empty($Submit)){			
		$dpd_code =  $_REQUEST["txt_dpd_code"];
		$dpd_name =  $_REQUEST["txt_dpd_name"];
		$usr =  $_SESSION["usr_name"];
		$date = date("Y/m/d  H:i:s");		
		
/*		echo "
		dpd_id =  $dpd_id<br>
		dpd_code =   $dpd_code<br>
		dpd_name =   $rtc_name<br>
		";*/
		
		
		function  checklist($value,$label,$field){
			global $resData;
			$resData[$field] = $value;
		}		
		
		checklist($rtc_code,"","rtc_code");
		checklist($rtc_name,"","rtc_name");

			if($action=="a"){				
				
				$resData["rtc_id"] = "";
				$resData["usr_cre"] = $usr;
				$resData["date_cre"] = $date;		
				
				$query = create_insert_query("ratecode",$resData);	
				//echo "$query<br>";
				mysql_query($query) or die("Insert ratecode error");						
				$rtc_id = mysql_insert_id();		
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");	
				$sql = "SELECT  loc_id FROM location ";
				$result = getData($sql );
				while($row = mysql_fetch_array($result)){
					$loc_id = $row["loc_id"];
					$sql = "INSERT INTO sub_ratecode(rtc_id, loc_id, show_amt, inout_amt, out_amt, usr_cre,date_cre) 
								VALUES($rtc_id, $loc_id, 0,0,0,'$usr', '$date')" ;
					//echo "$sql<br>";
					mysql_query($sql) or die("Insert sub_ratecode error");	
					$SaveLog=updLog($_SESSION['username'], updSave, "$sql");			
				}							
				
				//Show alert by javascript
				echo "<script>
						alert ('Insert complete');
						window.location = 'rtc_viewForm.php?id=$rtc_id' ;
					  </script>";
				exit();
			} //if($action=="a"){				
			
			if($action=="u"){				
				$resData["usr_upd"] = $_SESSION["usr_name"];
				$resData["date_upd"] = date("Y/m/d  H:i:s");		
				
				$query = create_update_query("ratecode", $resData, $rtc_id, "rtc_id");				
				//echo "$query<br>";
				//exit();
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");
				mysql_query($query) or die("Update error");		
				//Show alert by javascript
				echo "<script>
						alert ('Update complete');
						window.location = 'rtc_viewForm.php?id=$rtc_id' ;
					  </script>";
				exit();
			} //if($action=="u"){
	} //if(!empty($Submit) && $action != "d"){			
			
			if($action=="d"){			
				#delete value in ev_dateblock			
				$sql = "DELETE  FROM ratecode  
							WHERE rtc_id = '$rtc_id' 
							";
				//echo "$sql<br>";
				mysql_query($sql) or die("Delete error");	
				$SaveLog=updLog($_SESSION['username'], updSave, "$sql");			
				
				//Show alert by javascript
				echo "<script>
						alert ('Delete complete');
						window.location = 'rtc_viewForm.php?id=$rtc_id' ;
					  </script>";
				exit();				
			} //if($action=="d"){			
	
	//======================End Save Data==============================================
include("db/disconnect.db.php");	
?>
