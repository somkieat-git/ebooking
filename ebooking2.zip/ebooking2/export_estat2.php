<?php
	ob_start();
	session_start();
	$arrEstat=$_SESSION["arrData"];

	header("Content-Type: application/vnd.ms-excel");
	header('Content-Disposition: attachment; filename="Estat.xls"');	
?>
<html xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:x="urn:schemas-microsoft-com:office:excel"
xmlns="http://www.w3.org/TR/REC-html40">
<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</HEAD><BODY>

	  <table width="100%" align="center" x:str BORDER="1">
            <tr class="lst_BorderHead" >
			  <td><div align="center"><b>Rate Date</b></div></td>	
              <td><div align="center"><b>EvDate</b></div></td>
              <td><div align="center"><b>ID</b></div></td>
              <td><div align="center"><b>Name</b></div></td>
              <td><div align="center"><b>Client Grp</b></div></td>
              <td><div align="center"><b>Client</b></div></td>
			   <td><div align="center"><b>Business Type </b></div></td>
			   <td><div align="center"><b>status</b></div></td>
               <td><div align="center"><b>Event Type</b></div></td>
              <td><div align="center"><b>Location</b></div></td>
              <td><div align="center"><b>Q.Person</b></div></td>
              <td><div align="center"><b>Amount</b></div></td>
              <td><div align="center"><b>Sales Name</b></div></td>
              <td><div align="center"><b>Esd Name</b></div></td>
            </tr>
			<?

			
				while (list($key, $val) = each($arrEstat)) {
//				foreach($arrData as $key=>$val){
					$bgcolor == "#E7F0F8" ? $bgcolor="#F5F9FC" : $bgcolor="#E7F0F8" ;
					$EvnID=$val["EvnID"];
					$RtcDate=$val["RtcDate"];
					$Date=$val["Date"];
					$Time=$val["Time"];
					$EventName=$val["EventName"];
					$Customer=$val["Customer"];
					$Atten=$val["Atten"];
					$Amt=$val["Amt"];
					$Location=$val["Location"];
					$Contact=$val["Contact"];			
					$diffTime=$val["diffTime"];			
					$busCode=$val["busCode"];
					$bkStatus=$val["bkStatus"];
					$EventType=$val["EventType"];			
					$Sales=$val["Sales"];			
					$ClientName=$val["ClientName"];			
			?>
            <tr bgcolor="<?=$bgcolor ;?>">
              <td><?=$RtcDate;?></td>
              <td><?=$Date;?></td>
              <td><?=$EvnID;?></td>
              <td><?=$EventName;?></td>
              <td><?=$Customer;?></td>
              <td><?=$ClientName;?></td>
              <td><?=$busCode;?></td>
              <td><?=$bkStatus;?></td>
              <td><?=$EventType;?></td>
              <td><?=$Location;?></td>
              <td><?=$Atten;?></td>
              <td><?=$Amt;?></td>
              <td><?=$Sales;?></td>
              <td><?=$Contact;?></td>
            </tr>
			<?
				} //foreach($arrData as $key=>$val){
			?>
        </table>

</BODY>
</HTML>