<?
	ob_start(); 
	session_start();
	include("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	$menu = array();
	$menu = getMenu($_SESSION["sec_view"],"E");

	//print_r(array_keys($menu));
?>

<html>
<head>
	<title></title>	
	<link rel="stylesheet" href="css/format.css.css" type="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<body style="margin-left:11px;">
<table width="165px" class="BorderGreen" style="background-color: #F0F0F0;" cellspacing="0">
	<tr style="background-color: #339900; color: White;">
		<td width="16" align="center"><img src="images/dot.gif" height="12" width="12"></td>
		<td style="margin: 0 0 0 0; font-weight:bold;"><div align="center">Event</div></td>
	</tr>
	<?
	foreach($menu as $menu=>$link) {
		if ($color == "#F0F0F0")
			$color = "#FFFFFF" ;
		else
			$color = "#F0F0F0" ;	
	?>
	<tr bgcolor="<?=$color ?>">
		<td width="16" style="padding: 3px;">&nbsp;</td>
		<td class="HeaderWhiteSmall">
			<a href="<?=$link ?>" target="frame_details">
			<?=$menu ?></a>
		</td>
	</tr>	
	<?
	}
	?>	
</table>
<br>
<div align="center"></div>
</body>
</html>