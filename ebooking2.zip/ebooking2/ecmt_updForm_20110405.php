<?	
	ob_start();
	session_start();
	include_once("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	define("updSave","ecmt_updForm.php");
	
   	$evn_id =  $_REQUEST["id"];
	$ecmt_item =  $_REQUEST["id2"];
	if ($ecmt_item == "") $ecmt_item = "0 - Event Comment";
	//echo "\$evn_id =$evn_id<br>\$ecmt_item = $ecmt_item<br>";	

	//======================Begin prepare standard data======================================
	if(!empty($evn_id)){
		$sql = "SELECT * FROM eventname WHERE evn_id = '$evn_id'  ";
		$result = getData($sql);
		$row = mysql_fetch_array($result);
		$disabled = "";
		//if($row[3] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;
		if($row["evn_used"] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;
		$evn_name = $row["evn_shortname"];
	} //if(!empty($ev_id)){	
	
		$comment = "Comment";
		$sql = "SELECT  * FROM miscode ";
		$sql.=" WHERE mis_type = '$comment'";
		$sql.=" AND mis_used not in ('N','n')";
		$sql.="	ORDER BY mis_type ASC,  mis_code ASC ";
		//echo "$sql<br>";
		//xit();
		$result = getData($sql);
		$arrcomment = array();
					
		while( $row = mysql_fetch_array($result)){
			if ($row["mis_type"] == $comment ){
				$arrcomment[] = $row["mis_code"]." - ".$row["mis_name"];
				$arrComType[] = $row["mis_name"];
			} //if ($row["mis_type"]=="$event "){
		} //while( $row = mysql_fetch_array($result)){
	//======================End prepare stand data========================================

	//======================Begin select data from ev_comment===============================
	if (!empty($evn_id)){
		if(empty($ecmt_item)){
			$ecmt_item ="$arrcomment[0]";
		} //if(empty($ecmt_item)){
		
		$sql = "SELECT * FROM ev_comment WHERE evn_id = '$evn_id' 
					AND ecmt_item like '$ecmt_item' 
					";
		//echo "$sql<br>";
		//exit();
		$result = getData($sql);
		$numrow = mysql_num_rows($result);
		$rs_ecmt= mysql_fetch_array($result);	
	} //if (!empty($evn_id)){
	
	?>
<html>
<script language="javascript">	
	function validate() 	
	{
		var chkdesc = frm.ecmt_desc.value;
		if(trimAll(chkdesc)=="" )
		{
			alert('Please input data in Description');
			frm.ecmt_desc.focus();
			return false;
		}			
	}
	
	function trimAll( strValue ) {
	 var objRegExp = /^(\s*)$/;
		//check for all spaces
		if(objRegExp.test(strValue)) {
		   strValue = strValue.replace(objRegExp, '');
		   if( strValue.length == 0)
			  return strValue;
		}
	
	   //check for leading & trailing spaces
	   objRegExp = /^(\s*)([\W\w]*)(\b\s*$)/;
	   if(objRegExp.test(strValue)) {
		   //remove leading and trailing whitespace characters
		   strValue = strValue.replace(objRegExp, '$2');
		}
	  return strValue;
	}
	
//-->
</script>


<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">


<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
<script type="text/javascript" src="lib/jquery.min.js"></script>
<script type="text/javascript" src="js/sliding.form.js"></script>

<script type="text/javascript">
function chkTypeComment(type_cm , ecmt_item){
	//alert(type_cm);   hd_ecmt_item2
	
	document.getElementById('hd_ecmt_item').value = type_cm ;
	
}

function saveComplete(txt , evn_id , a_ecmt_item ){			
	window.location = "ecmt_updForm_20110405.php?id="+evn_id+"&id2="+a_ecmt_item+"&cmt_item="+txt ;
}
</script>

</head>
<style>
        span.reference{
            position:fixed;
            left:5px;
            top:5px;
            font-size:10px;
            text-shadow:1px 1px 1px #fff;
        }
        span.reference a{
            color:#555;
            text-decoration:none;
			text-transform:uppercase;
        }
        span.reference a:hover{
            color:#000;
            
        }
        h1{
            color:#ccc;
            font-size:36px;
            text-shadow:1px 1px 1px #fff;
            padding:20px;
        }
    </style>
<body>
<div id="div_body">
	<div id="content">
            <h2 style="width:700px;">Comment - <?=$evn_id." - " .$evn_name ?></h2>
			<?php $cmt_item != "" ? $div_display = "" : $div_display = "display:none;"; ?>
			<div id="div_complete" style="height:15px;<?php echo $div_display; ?>">
				<?php $txt = "Save  '" . $cmt_item . "' Complete.. " ;?>
				<span id="txt_complete" style="font-size:11px;font-weight:bold;color:#0000FF;"><?php echo $txt; ?></span>
			</div>
            <div id="wrapper">
				<div id="navigation" style="display:none;">
                    <ul>
					<?
					//$showButton="";
					//$updSave=updSave;
					//echo "<pre>"; print_r($arrcomment);
					
					for($i=0;$i<count($arrcomment);$i++){
						$i == 0 ? $selected = "class=selected" : $selected = "" ;
					?>
					<li <?php echo $selected; ?> >
						<a href="#" onClick="javascript:chkTypeComment('<?php echo $arrcomment[$i] ;?>' , '<?php echo $ecmt_item ;?>');"><?=$arrcomment[$i] ;?></a>
					</li>
									
					<?	
					}//for($i=0;$i<=count($arrcomment);$i++){		
					//echo "$showButton";	
					?>
                    </ul>
                </div>
                <div id="steps">
                    <form action="<?=updSave ?>?id=<?=$evn_id?>" method="post" name="frm"  id="frm"  onSubmit="return validate() ;" >
					
					<?php for( $i=0 ; $i<count($arrComType); $i++ ): ?>
						<?php 
						$sql = "SELECT * FROM ev_comment WHERE evn_id = '$evn_id' 
									AND ecmt_item like '$arrcomment[$i]' 
									";
						//echo "$sql<br>";
						//exit();
						$result = getData($sql);
						//$numrow = mysql_num_rows($result);
						$rw_ecmt= mysql_fetch_array($result);	
						$rw_ecmt["ecmt_desc"] <> "" ? $defDesc = $rw_ecmt["ecmt_desc"] : $defDesc = "$arrComType[$i] :    " ;
						?>
						<fieldset class="step">
                            <legend><?php echo $arrComType[$i]; ?></legend>
                            <p>
            <textarea name="ecmt_desc_<?php echo $i ; ?>" cols="77" rows="12" wrap="OFF" id="ecmt_desc" value="<?=$arrComType[$i];?>"><?php echo $defDesc ; ?></textarea>    
                            </p>
							<p class="submit">
							<table align="center" border="0">
								<tr>
									<td><input name="Submit2" type="button" class="Button" value="&lt;= Back " onClick="window.location = 'efsv_viewForm.php?id=<?=$evn_id ;?>'" ></td>
									<td><input name="Submit" type="submit" class="Button" value="   OK   "<?=$disabled ;?>  ></td>        
									<td><input name="Button" type="button" class="Button" id="Button"  onClick="history.go(-1)" value="Cancel" ></td>
									<td><input name="Submit22" type="button" class="Button" value="Next =&gt;" onClick="window.location = 'eckl_viewForm.php?id=<?=$evn_id?>'" ></td>
								</tr>
							</table>
							</p>
						</fieldset>
						<?php endfor;?>
						<input name="hd_ecmt_item" type="hidden" id="hd_ecmt_item" value="<?php echo $ecmt_item ;?>">							
					</form>
				</div>               
            </div>
        </div>
	</div>



<?

	//======================Begin Save Data==============================================
	//request data into varible
	$Submit = $_REQUEST["Submit"];
	
	if(!empty($Submit)){		
		$arrEcmtItem = array();
		$arrComValue = array();
		$a_ecmt_item = $_REQUEST["hd_ecmt_item"];
		$arrEcmtItem = explode(" - " ,$a_ecmt_item);
		$item_code = $arrEcmtItem[0];
		$item_name = $arrEcmtItem[1];
		
	
		function  checklist($value,$label,$field){
			global $resData;
			$resData[$field] = $value;
		} //function checklist($var,$name){
		
		
		for( $i=0 ; $i<count($arrComType); $i++ ){
			$a_ecmt_desc = $_REQUEST["ecmt_desc_$i"];
			$arrComValue = explode(" : " ,$a_ecmt_desc);
			$comItem = $arrComValue[0];
			$comValue = $arrComValue[1];
			
			if( $comItem == $item_name ){
				//echo "\$item_name=$item_name" ; echo "<hr>";
				$a_ecmt_desc = htmlspecialchars($a_ecmt_desc);
				checklist($a_ecmt_desc,"","ecmt_desc");
				break;
			}			
			
		} // for( $i=0 ; $i<count($arrComType); $i++ ){
	
		
		/*echo "
		submit = $Submit<br>
		evn_id =  $evn_id<br>
		ecmt_desc = $ecmt_desc<br>
		a_ecmt_item = $a_ecmt_item<br> 
		a_ecmt_desc = $a_ecmt_desc<br>
		";  
		exit();
		*/
		
		
		//check duplicate data in table ev_comment
		$sql = "SELECT * FROM ev_comment WHERE evn_id = '$evn_id' AND ecmt_item = '$a_ecmt_item'  ";
		//echo "$sql<br>";
		//exit();
		$result = getData($sql);
		$numrow = mysql_num_rows($result);
		$row = mysql_fetch_array($result);
		//echo "numrow = $numrow<br>";
		if ($numrow == 0 ){
				$action = "add";}
			else{
				$action = "edit";
		}
		//echo "action=$action<br>";
		//exit();
		
		
		
			if($action=="add"){
				$resData["ecmt_id"]="";
				$resData["ecmt_item"]="$a_ecmt_item";
				$resData["evn_id"] = $evn_id;
			
				$resData["usr_cre"] = $_SESSION["usr_name"];
				$resData["date_cre"] = date("Y/m/d  H:i:s");		
				
				$query = create_insert_query("ev_comment",$resData);	
				//echo "$query<br>";
				//exit();
				mysql_query($query) or die("Insert error");	
				//$SaveLog=updLog($_SESSION['username'], updSave, "$query");					
				//Show alert by javascript
				/*echo "<script>
						alert ('Insert complete');
						window.location = 'ecmt_updForm.php?id=$evn_id&id2=$a_ecmt_item';
					  </script>";*/
				echo "<script type=\"text/javascript\">saveComplete(\"$item_name\" , $evn_id , \"$a_ecmt_item\" );</script>";
				exit();
			}
			
			if($action=="edit"){
				$resData["usr_upd"] = $_SESSION["usr_name"];
				$resData["date_upd"] = date("Y/m/d  H:i:s");		
				
				$query = create_update_query("ev_comment", $resData, $evn_id, "evn_id");				
				$query .= " AND ecmt_item = '$a_ecmt_item' " ;
				//echo "$query<br>";
				mysql_query($query) or die("Update error");		
				//$SaveLog=updLog($_SESSION['username'], updSave, "$query");
				//Show alert by javascript
				/*echo "<script>
						alert ('Update complete');
						window.location = 'ecmt_updForm.php?id=$evn_id&id2=$a_ecmt_item' ;
					  </script>";*/
				echo "<script type=\"text/javascript\">saveComplete(\"$item_name\" , $evn_id , \"$a_ecmt_item\" );</script>";
				exit();
			}
			
		
//		} // for( $i=0 ; $i<count($arrComType); $i++ ){
	} //if(!empty($Submit)){
	
	//======================End Save Data==============================================
?>