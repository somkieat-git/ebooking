<?php 
	ob_start();
	session_start();
	$showRev = $_SESSION["showRev"];
	//$txtBtn = "   OK   ";
	//echo "\$showRev= <pre>"; print_r($showRev); echo "<hr>";
?>
 <table width="71%" border="1" cellpadding="0" cellspacing="0" bordercolor="#DDDDFF" class="BorderGreen">
  <tr height="30">
   <th style="background-color:#6699CC;font-weight:bold;color:White;" width="100">DATE</th>
   <th style="background-color:#6699CC;font-weight:bold;color:White;">IN</th>
   <th style="background-color:#6699CC;font-weight:bold;color:White;">SHOW</th>
   <th style="background-color:#6699CC;font-weight:bold;color:White;">OUT</th>
   <th style="background-color:#6699CC;font-weight:bold;color:White;">TOTAL</th>
  </tr>
  <?php 
  	foreach( $showRev as $revSource => $arrData ){
	 foreach($arrData as $key => $data){
	 $rev_date = chgDate($data["rev_date"]);
	 $rev_net = $data["rev_net"];	 
  ?>
  <tr height="25">
   <td align="center"><?php echo $rev_date; ?></td>
   <td align="center">
    <?php 
		if($revSource == "in"){
		  $inet = chgNumber($rev_net) ;
		  $sum_inet += $rev_net;
		}else{ 
		  $inet = "&nbsp;";
		}
		echo $inet; 
	?>
   </td>
   <td align="center">
    <?php 
		if($revSource == "show"){ 
		 $snet = chgNumber($rev_net);
		 $sum_snet += $rev_net;
		}else{ 
		 $snet = "&nbsp;"; 
		}
		echo $snet ;  
	?>
   </td>
   <td align="center">
    <?php 
		if($revSource == "out"){
		 $onet = chgNumber($rev_net) ;
		 $sum_onet += $rev_net;
		}else{
		 $onet = "&nbsp;"; 
		}
		echo $onet ;  
	?>
   </td>
   <td align="center">
    <?php echo chgNumber($rev_net) ; $total += $rev_net; ?>
   </td>
  </tr>
  <?php 
  	 }
  	} 	
  ?>
  <tr height="25">
   <td style="background-color:#6699CC;font-weight:bold;color:White;" align="right">Total : &nbsp;&nbsp;</td>
   <td style="background-color:#6699CC;font-weight:bold;color:White;" align="center"><?php echo chgNumber($sum_inet); ?></td>
   <td style="background-color:#6699CC;font-weight:bold;color:White;" align="center"><?php echo chgNumber($sum_snet); ?></td>
   <td style="background-color:#6699CC;font-weight:bold;color:White;" align="center"><?php echo chgNumber($sum_onet); ?></td>
   <td style="background-color:#6699CC;font-weight:bold;color:White;" align="center"><?php echo chgNumber($total) ; ?></td>
  </tr>
 </table>

