<?
	
//ob_start();
session_start();

echo "ncc=",$_REQUEST["ncc"],"<br>";
echo "site=",$_SESSION["site"];
echo "<br>";
echo "xxx=",$_SESSION["xxx"];
echo "<br>",session_id(),"<BR>";


?>
