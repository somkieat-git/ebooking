<?	
	ob_start();
	session_start();
	include_once("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	define("updSave","new_event.php");
	
	//request value from other form
	$date = $_REQUEST["d"];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<script language="javascript">
	function validate() 
	{
		if(frm.txtEvn_date.value == "")
		{
			//ชื่อฟอร์ม.ชื่ออุปกรณ์.value
			alert('Please input data in Event Date');
			frm.txtEvn_date.focus()
			return false;
		}
		if(frm.txtFullname.value == "")
		{
			//ชื่อฟอร์ม.ชื่ออุปกรณ์.value
			alert('Please input data in Full Event Name');
			frm.txtFullname.focus()
			return false;
		}
		if(frm.txtShortname.value == "")
		{
			//ชื่อฟอร์ม.ชื่ออุปกรณ์.value
			alert('Please input data in Short Event Name');
			frm.txtShortname.focus()
			return false;
		}
	}
	
//	function autotext() {
//		document.frm.txtShortname.value = document.frm.txtFullname.value
//		return false ;
//	}
	
	function autotext(elem_id) {
		if(elem_id == "txtShortname"){
			document.frm.txtFullname.value = document.frm.txtShortname.value;
		}else{
			document.frm.txtShortname.value = document.frm.txtFullname.value;
		}
		return false ;
	}
	
	
	function chkEnglishCharsOnly(str , elem_id){	
		var elem = document.getElementById(elem_id);
		
		if(isEnglishchar(str)==false){
			alert("Please enter only English characters");
			elem.value=elem.value.substr(0,elem.value.length-1);
			return false;
		}
		autotext(elem_id);
	
	}
	
	/*function isEnglishchar_bk(str){   
		var orgi_text="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890._-";
		var str_length=str.length;   
		var isEnglish=true;   
		var Char_At="";   
		for(i=0;i<str_length;i++){   
			Char_At=str.charAt(i);   
			//alert(Char_At);
			if(orgi_text.indexOf(Char_At)==-1){   
				isEnglish=false;  
				break;
			}    
		}   
		return isEnglish; 
	}  */
	
	function isEnglishchar(str){   
		var regexLetter = /[a-zA-z]/;
		var regexThai = /[ก-๙]/;
		var str_length=str.length;   
		var isEnglish=true;   
		var Char_At="";   
		for(i=0;i<str_length;i++){   
			Char_At=str.charAt(i);   
			//alert(Char_At);
			// เงื่อนไข  ถ้าไม่ใช่ตัวอักษรภาษาอังกฤษ  หรือ  เป็นตัวอักษรภาษาไทย  ให้แสดงข้อความเตือน
			if(!regexLetter.test(str) || regexThai.test(str)){
				//alert('Type character only');
				isEnglish=false;
				break;
				//return false;
			}    
		}   
		return isEnglish; 
	}  

</script>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">
<script language="javascript" type="text/javascript" src="datetimepicker.js"></script>

<!--------------  jQuery Datepick (Popup Calendra)  ---------------------->
	
	<link href="./css/jquery.datepick.css" type="text/css" rel="stylesheet" />
	<script type="text/javascript" src="lib/jquery.min.js"></script>	
	<script type="text/javascript" src="js/jquery.datepick.js"></script>
	<script type="text/javascript">
	$(function() {
		jQuery('#txtEvn_date').datepick({showOnFocus: false , yearRange: '1980:2025' , showTrigger: '#calImg'});
	});
	</script>
	
	
</head>
	
<body >
<form name="frm"  id="frm" method="post" action="<?=updSave?>" onSubmit="return validate();" >
  <table width="63%"  border="0" cellpadding="0" cellspacing="1" class="BorderSilver">
    <tr class="BorderSilver">
      <td height="25" colspan="3" style="background-color:#339900;font-weight:bold;color:White;">
        <div align="center"><strong >New Event </strong></div></td>
    </tr>
    <tr>
      <td height="20" colspan="3">&nbsp;</td>
    </tr>
    <tr>
      <td width="50%" height="20"><div align="right">Event Date : </div></td>
	  <?
	  	if($date)
			$date=chgDate($date);
	  ?>
      <td>	  
	  
	  <input type="text" name="txtEvn_date" id="txtEvn_date" value="<?=$date?>" size="10" />
		<div style="display: none;"> 
			<img id="calImg" src="images/calendar.gif" alt="Pick a date" class="trigger" > 
		</div>
	  
	  </td>
    </tr>
    <tr>
      <td height="20"><div align="right">Full Event Name : </div></td>
      <td><input name="txtFullname" type="text" id="txtFullname" onKeyUp="javascript:chkEnglishCharsOnly(this.value , 'txtFullname');"></td>
	</tr>
    <tr>
      <td height="22"><div align="right">Short Event Name : </div></td>
      <td><input name="txtShortname" type="text" id="txtShortname" onKeyUp="javascript:chkEnglishCharsOnly(this.value , 'txtShortname');"></td>
    </tr>
    <tr>
      <td height="22"><div align="right">Thai Event Name : </div></td>
      <td><input name="txtThainame" type="text" id="txtThainame"></td>
    </tr>
	<!--<tr>
      <td height="22"><div align="right">Test : </div></td>
      <td><input name="test" type="text" id="test" onKeyUp="javascript:testCha(this.value);"></td>
    </tr>-->
    <tr>
      <td height="14">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td height="29"><div align="right">
          <input name="Submit" type="submit" class="Button" value="   OK   ">
      </div></td>
      <td><div align="left">
          <input name="Button" type="button" class="Button" id="Button2"  onClick="history.go(-1)" value="Cancel" >
      </div></td>
    </tr>
  </table>
</form>
</body>
</html>

<?
	//======================Begin Save Data==============================================
	//request data into varible
	$Submit = $_REQUEST["Submit"];
	if(!empty($Submit)){
		$txtEvn_date = $_REQUEST["txtEvn_date"];
		$txtFullname = $_REQUEST["txtFullname"];
		$txtShortname = $_REQUEST["txtShortname"];
		$txtThainame = $_REQUEST["txtThainame"];
		/*
		echo "
		submit = $Submit<br>
		txtEvn_date =  $txtEvn_date<br>
		txtFullname = $txtFullname<br> 
		txtShortname = $txtShortname<br>
		";
		*/
		//exit();
		
		
		//check duplicate data in table ev_statistics
		$sql = "SELECT * FROM eventname   
					WHERE evn_shortname = '$txtShortname' ";
		//echo "$sql<hr>";
		$result = getData($sql);
		$numrow = mysql_num_rows($result);
		//$row = mysql_fetch_array($result);
		//echo "numrow = $numrow<br>";			
		
		if ($numrow == 0 )
			$action = "add";
		else{			
			echo "<script>
					alert ('Short Event Name is duplicate');
					history.go(-1);
				    </script>";			
				}			
		//echo "action=$action<br>";
		
			if($action=="add"){
				$valdate = chgDateToDb($txtEvn_date);
				$valbegtime = "0800";
				$valendtime = "1800";
				list($dd, $mm, $yyyy) = explode('/',$txtEvn_date);
				if(strlen($mm) < 2) $mm = '0' . $mm;
				$yymm = substr($yyyy,2,2).$mm;
				
				$sql = "SELECT MAX(evn_id) as id FROM eventname
							 WHERE evn_id like '$yymm%' ";
				//echo "\$sql=$sql<br>";
				//exit();
				
				$result = getData($sql);
				$row = mysql_fetch_array($result);
				
				//echo $row[0]; echo "<hr>";
				//echo "\$yymm=$yymm<br>";

				if(is_null($row["id"]))
					$evn_id =  "$yymm"."0001";
				else{
					//$evn_id = ($row[0]+1);
					$running = "99".substr($row["id"], 4)+1;
					$evn_id = "$yymm".substr($running, 2);
					//echo "runing=$running<br>"; 
				}
					
				//echo "\$evn_id=$evn_id<br>"; exit();

				$usr_cre = $_SESSION["usr_name"];
				$date_cre = date("Y/m/d  H:i:s");		
				$val_date_cre = date("d/m/Y");	
				
				

					
				
				$query = "INSERT INTO eventname values(
					'$evn_id','$txtShortname','$txtFullname','$txtThainame','Y','$usr_cre','$date_cre','',''
				) ";
				//echo "$query<br>";
				mysql_query($query) or die("Insert table eventname error");						
				
				$query = "INSERT INTO ev_dateblock (evn_id, edbk_item,edbk_in_date, edbk_in_time, edbk_ev_begdate, edbk_ev_begtime, 
								edbk_ev_enddate, edbk_ev_endtime, edbk_out_date, edbk_out_time, usr_cre, date_cre)
								VALUES('$evn_id', 0,'$valdate','$valbegtime', '$valdate','$valbegtime',
								'$valdate','$valendtime','$valdate','$valendtime','$usr_cre','$date_cre')
								";
				//echo "$query<br>";
				mysql_query($query) or die("Insert table ev_dateblock error");						
				
				$query = "INSERT INTO ev_statistics (evn_id, bks_id, rtc_id, esta_atten, esta_num_session,usr_cre, date_cre)
					VALUES('$evn_id', 9,1,1,1,'$usr_cre','$date_cre')
				";
				//echo "$query<br>";
				mysql_query($query) or die("Insert table ev_statistics error");	
				
				#insert default checklist to ev_checklist
				list($dd, $mm, $yy) = explode('/',$val_date_cre);
				$start_date = date("Ymd", mktime(0, 0, 0, $mm,$dd,$yy));
				
				$sql = "SELECT * FROM checklist  
							ORDER BY ckl_name
							";
				//echo "$sql<br>";				
				$result = getData($sql);
				$arr_ckl = array();
				$arr_tmp = array();
				while ($rs_ckl = mysql_fetch_array($result)){
					$ckl_id = $rs_ckl["ckl_id"];
					$ckl_name = $rs_ckl["ckl_name"];
					$ckl_val = $rs_ckl["ckl_val"];
					$ckl_cnt_fr  = $rs_ckl["ckl_cnt_fr"];
					
					if ($ckl_cnt_fr == 0 ) {
						$follow_date = date("Ymd", mktime(0, 0, 0, $mm,$dd,$yy));
						$d = date("d", mktime(0, 0, 0, $mm,$dd,$yy));
					}
					else {
						$dd = $arr_tmp[$ckl_cnt_fr] + $ckl_val ; 
						$follow_date = date("Ymd", mktime(0, 0, 0, $mm,$dd,$yy));
						$d = date("d", mktime(0, 0, 0, $mm,$dd,$yy));
					}  
					
					$arr_ckl[$ckl_id] = $follow_date.",".$ckl_name; 
					$arr_tmp[$ckl_id] = $d; 
					
				} //while ($rs_ckl = mysql_fetch_array($result)){
				for($i=2;$i <= count($arr_ckl);$i++){
					list($eckl_follow_date, $eckl_item) = explode(',',$arr_ckl[$i]);
					$query = "INSERT INTO ev_checklist (eckl_id, evn_id, eckl_follow_date, eckl_item, eckl_fperson, 
									eckl_complete_date, eckl_cperson, usr_cre, date_cre, usr_upd, date_upd )
									VALUES('','$evn_id','$eckl_follow_date','$eckl_item','$usr_cre',
									'','','$usr_cre','$date_cre','',''  
									)
					";
					//echo "$query<br>";
					mysql_query($query) or die("Insert table ev_checklist error");										
				} //for($i=2;$i <= count($arr_ckl);$i++){
				
				
				//Show alert by javascript
				echo "<script>
						alert ('Insert completed');						
						window.open('fra_ev_maintenance.php?id=$evn_id','main_Frame');
					  </script>";
				exit();
			}
	} //if(!empty($Submit)){
	
	//======================End Save Data==============================================
?>
