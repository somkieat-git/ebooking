<?php 
	ob_start(); 
	session_start();
		
	include_once("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	include "./cfg/config.cfg.php";
	$prefix = strtoupper(prefix);	
	
	function chgDate2($rev_date){
		$yyyy = substr($rev_date, 0 , 4); 
		$mm = substr($rev_date, 4 , 2);
		$dd = substr($rev_date, 6 , 2); 
		$date = $yyyy . "-" . $mm . "-" . $dd ;
		return $date;
	}
	
	$pagesize = 5 ;
	$sql = "SELECT COUNT( DISTINCT (evn_id)) AS count_evn_id
			FROM `ev_location` 
			WHERE eloc_show_total > 0 
			";
	$result = getData($sql);
	$row = mysql_fetch_array($result);
	$totalrecord = $row["count_evn_id"]; //echo "<br />";
	$totalpage = ceil($totalrecord / $pagesize);
	/*while( $row = mysql_fetch_array($result) ){
		$arrEvnId[] = $row["dis_evn_id"];
	}*/
	$start = 0 ;
	for ($i=1; $i<=$totalpage; $i++) {
		$arrLimit[$i] = $start;
		$sql1 = "SELECT DISTINCT(evn_id) AS dis_evn_id
				FROM `ev_location` 
				WHERE eloc_show_total > 0 
				ORDER BY dis_evn_id DESC
				LIMIT $start , $pagesize 
				";
		//echo "\$sql1= $sql1<br />";
		$result1 = getData($sql1);
		$arrEvnId = array();
		while( $rs = mysql_fetch_array($result1)){
			$arrEvnId[] = $rs["dis_evn_id"];
		}
		//echo "<pre>"; print_r($arrEvnId);
		$arrVal[$i] = $arrEvnId ;
		$start = $pagesize * $i ;
		
	}
	//exit();
	//echo "<pre>"; print_r($arrVal);
	//echo "<pre>"; print_r($arrLimit);

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Gen Script Import</title>
<link href="css/format.css.css" rel="stylesheet" type="text/css">
<script type="text/javascript">
function Conf(){
		if(confirm("Are You Sure!!")== true){			
			window.location =  "gen_script.php";
			return true;
		}
		return false;
}

function clicks(val){
	window.location="gen_script.php?i="+val+"&btn=Click&script_id=1&d=Y_"+val;
	//document.getElementById("disableBtn"+val).disabled = true ;
	//return true ;
}
</script>
</head>

<body style="margin-left:11px;margin-top:15px;">

<form id="frm" name="frm" method="post" action="" >
  <table border="0" class="BorderGreen" width="557">
     <tr class="BorderSilver">
      <td colspan="4" style="background-color:#339900;font-weight:bold;color:White;">
	  <div align="center"><strong >Script Import</strong></div>
	  </td>
    </tr>
    <tr>
      <td height="32" colspan="2"><div align="left">Insert Nameinfo to Profile : </div></td>
      <td width="213">
		  <div align="center">
		  	<input type="hidden" name="script_id" id="script_id" value="0"/>
			<input type="submit" name="Submit" id="Submit" value="Run Script" onclick="return Conf();" />
		  </div>
	  </td>
    </tr>
	<?php 
		for( $i=1; $i<=sizeof($arrVal); $i++ ){	
	  ?>
	 <tr>
      <td width="116" height="32" colspan="2"><div align="left">Gen Script Event Id : </div></td>
	  <td>
	  <?php
	  	echo $arrVal[$i][0];
		echo "  -  ";
		$last = count($arrVal[$i]) - 1 ;
		echo $arrVal[$i][$last];
	  ?>
	  </td>
      <td width="213">
		  <div align="center">
		  <?php 
		  $d = $_REQUEST["d"];
		  list($status , $btn_id) = explode("_" , $d );
		  
		  if( $status == "Y" && $btn_id == $arrLimit[$i] ){
		  	$disabled = "disabled" ;
		  }else{
		  	 $disabled = "" ;
		  }
		  ?>
		  	<input type="button" name="btn" id="btn_<?php echo $btn_id; ?>" value="Click" onclick="javascript:clicks(<?php echo $arrLimit[$i]; ?>);" <?php echo $disabled; ?>/>
			
		  </div>
	  </td>
    </tr>
	<?php } ?>
	<!--<tr>
      <td width="92">SCRIPT : </td>
      <td width="306">
	  	<?php 
		/*$sql = "SELECT COUNT( DISTINCT (evn_id) ) AS count
				FROM `ev_location` 
				WHERE eloc_show_total > 0 ";
		$result = getData( $sql );
		$rs = mysql_fetch_array( $result );*/
		?>
		<input type="submit" name="Submit" id="Submit" value="Click" onclick="javascript:clicks();" />
		<input type="hidden" name="hdd_limit" id="hdd_limit" value="10"/>
		<input type="hidden" name="val" id="val" value="1"/>
		<input type="hidden" name="script_id" id="script_id" value="1" />
	 </td>
    </tr>-->
	<tr>
	  <td></td>
	  <td width="212">
		  <div align="center">
			<input type="submit" name="Submit" id="Submit" value="Run Script" onclick="return Conf();" />
		  </div>
	  </td>
	</tr>
  </table>
</form>
<?php 
$Submit = $_REQUEST["Submit"];
$btn = $_REQUEST["btn"];
$start = $_REQUEST["i"];


if( !empty($Submit) || !empty($btn) ){
	
	$script_id = $_REQUEST["script_id"];
	
	/*$sql = "SELECT DISTINCT(evn_id) AS evn_id FROM ev_location e WHERE eloc_show_net > 0 ORDER BY evn_id DESC";
	$result = getData($sql);
	while( $row = mysql_fetch_array($result) ){
		$arrEvnId[] = $row["evn_id"];
	}*/
	
	
	switch($script_id){
		case "0" :
			$sql = "SELECT * FROM nameinfo ";
			//$result = getData($sql);
			$result = mysql_query($sql);
			$info_data = array();
			
			while( $row = mysql_fetch_array( $result ) ){
				
				$f_nameinfo = get_table_fieldname("nameinfo");
				foreach( $f_nameinfo as $key => $val ){
					//$row = mysql_fetch_array( $result ) ;
					$info_data[$val] = $row[$val];					
				}
				
				$arrData[] = $info_data;
				
			}
			
			//echo "<pre>"; print_r($arrData); echo "<hr>";
			
			$arrProfile = array();
			for($i=0; $i<sizeof($arrData); $i++){
				foreach( $arrData[$i] as $inField => $inVal ){ //$arrData[0][id]
					$f_name = get_table_fieldname("profile");
					foreach( $f_name as $fKey => $fVal ){
						if( ( $fVal == "pro_etitle" ) && ( $inField == "nif_title" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_efname" ) && ( $inField == "nif_firstname" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_elname" ) && ( $inField == "nif_lastname" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_ecname" ) && ( $inField == "nif_company" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_eaddress1" ) && ( $inField == "nif_no" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_esoi" ) && ( $inField == "nif_soi" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_eroad" ) && ( $inField == "nif_road" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_etambol" ) && ( $inField == "nif_tumbol" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_edistrict" ) && ( $inField == "nif_amphur" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_eprovince" ) && ( $inField == "nif_province" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_epostcode" ) && ( $inField == "nif_zipcode" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_etel" ) && ( $inField == "nif_tel" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_efax" ) && ( $inField == "nif_fax" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_mobile" ) && ( $inField == "nif_mobile" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_email1" ) && ( $inField == "nif_email" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_website" ) && ( $inField == "nif_website" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "pro_remark" ) && ( $inField == "nif_remark" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "usr_cre" ) && ( $inField == "usr_cre" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "date_cre" ) && ( $inField == "date_cre" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "usr_upd" ) && ( $inField == "usr_upd" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
						if( ( $fVal == "date_upd" ) && ( $inField == "date_upd" ) ){		
							$arrProfile[$i][$fVal] = $inVal;
						}
					}// foreach( $f_name as $fKey => $fVal ){
				}// foreach( $arrData[$i] as $inField => $inVal ){	
			}// for($i=0; $i<sizeof($arrData); $i++){
			
			//echo "<pre>"; print_r($arrProfile); exit();
			
			
			
			## New concept insert code this area
			$run = "insert into run1 value('','1')";
			$updRun = mysql_query($run) or die("Insert table run1 error");	
			
			$getID = mysql_insert_id($connect);
			$number = '000000'.$getID;
			$year = date("y");
			$number = $prefix.'/'.$year.'-'.substr($number,-6);
			
			//echo "\$number= $number"; exit();
			
			$value = array();
			for($i=0; $i<sizeof($arrProfile); $i++){
			
				$f_name = get_table_fieldname("profile");
				foreach( $f_name as $fKey => $fVal ){
					$value[$fVal] = "";
					foreach( $arrProfile[$i] as $pField => $pVal ){
						if( $fVal == "pro_code" ){
							$value[$fVal] = $number ;
						}
						if( ( $fVal == "pro_default" ) || ( $fVal == "pro_sex" ) 
							|| ( $fVal == "pro_occupation" ) || ( $fVal == "pro_industry" ) 
							|| ( $fVal == "pro_education" ) || ( $fVal == "pro_reject" ) )
						{
							$value[$fVal] = "0" ;
						}
						if( $fVal == "pro_lang" ){
							$value[$fVal] = "th" ;
						}
						if( $fVal == "pro_show" ){
							$value[$fVal] = "1" ;
						}
						if( $fVal == "pro_source" ){
							$value[$fVal] = $prefix ;
						}
						if( $fVal == $pField ){
							$value[$fVal] = $pVal ;
						}
					}// foreach( $arrProfile[$i] as $pField => $pVal ){
					
				}//foreach( $f_name as $fKey => $fVal ){
				
				//echo "<pre>"; print_r($value); exit();
				$query = create_insert_query("profile" , $value);
				$result = mysql_query($query) or die("<script>alert ('Insert table profile error');</script>");
				
			} // for($i=0; $i<sizeof($arrProfile); $i++){
			if($result){
				echo "<script>
						alert ('Run Script Import complete');
					  </script>";
				exit();
			}
			break;
			
		case "1" :
			
	
			$sql1 = "SELECT DISTINCT (evn_id) AS dis_evn_id
					FROM `ev_location` 
					WHERE eloc_show_total > 0 
					ORDER BY dis_evn_id DESC
					LIMIT $start , $pagesize " ;
			//echo "\$sql1=$sql1"; exit();
			$result1 = getData($sql1);
			while( $row = mysql_fetch_array($result1)){			
				$evn_id = $row["dis_evn_id"]; //echo "<br />";
			
				$sql = "
						SELECT eloc_id ,evn_id ,loc_id 
						,eloc_in_date ,eloc_event_date ,eloc_end_date ,eloc_out_date ,rtc_status
						,eloc_inout_qty ,eloc_inout_total ,eloc_inout_adj ,eloc_inout_net
						,eloc_show_qty ,eloc_show_total ,eloc_show_adj ,eloc_show_net
						,eloc_out_qty ,eloc_out_total ,eloc_out_adj ,eloc_out_net
						FROM ev_location eloc, ratecode rtc 
						WHERE eloc_show_net > 0
						AND evn_id = $evn_id
						AND eloc.rtc_id = rtc.rtc_id						
					";
				echo "$sql<hr>"; //exit();
				
				$result = mysql_query($sql);
				while( $rs = mysql_fetch_array($result)){
					#get value from $rs
					$eloc_id = $rs["eloc_id"];
					$evn_id = $rs["evn_id"];
					$loc_id = $rs["loc_id"];
					$eloc_in_date = $rs["eloc_in_date"];
					$eloc_event_date = $rs["eloc_event_date"];
					$eloc_end_date = $rs["eloc_end_date"];
					$eloc_out_date = $rs["eloc_out_date"];
					$rtc_status = $rs["rtc_status"];
					if($rtc_status=="L") $rev_type = "space_L";
					if($rtc_status=="P") $rev_type = "space_P";	
					
					$eloc_inout_qty = $rs["eloc_inout_qty"];
					$eloc_inout_total = $rs["eloc_inout_total"];
					$eloc_inout_adj = $rs["eloc_inout_adj"];
					$eloc_inout_net = $rs["eloc_inout_net"];
							
					$eloc_show_qty = $rs["eloc_show_qty"];			
					$eloc_show_total = $rs["eloc_show_total"];
					$eloc_show_adj = $rs["eloc_show_adj"];
					$eloc_show_net = $rs["eloc_show_net"];
					
					$eloc_out_qty = $rs["eloc_out_qty"];
					$eloc_out_total = $rs["eloc_out_total"];
					$eloc_out_adj = $rs["eloc_out_adj"];
					$eloc_out_net = $rs["eloc_out_net"];
					
					
					$arrQuery=array();	
					#chk eloc_in_date
					$arrQuery["in"]=genRevenue($evn_id,$loc_id,"in",$rev_type,$eloc_in_date,($eloc_event_date-1),$eloc_inout_qty,$eloc_inout_total,$eloc_inout_adj,$eloc_inout_net,"Y",$eloc_id);	
					
					#chk eloc_show_date
					$arrQuery["show"]=genRevenue($evn_id,$loc_id,"show",$rev_type,$eloc_event_date,$eloc_end_date,$eloc_show_qty ,$eloc_show_total ,$eloc_show_adj ,$eloc_show_net ,"Y",$eloc_id);	
					
					#chk eloc_out_date
					$arrQuery["out"]=genRevenue($evn_id,$loc_id,"out",$rev_type,($eloc_end_date+1),$eloc_out_date,$eloc_out_qty,$eloc_out_total,$eloc_out_adj,$eloc_out_net,"Y",$eloc_id);
					
				
				} // while( $rs = mysql_fetch_array($result)){
				
				//echo "<br>\$arrQuery=<pre>";
				//print_r($arrQuery); //exit();
				
				foreach($arrQuery as $key=>$val) {
					foreach($val as $subKey=>$subVal) {			
						$strSQl=$subVal;
						echo "\$strSQl=$strSQl<br>";	
						//mysql_query($strSQl) or die("Insert ev_revenue error!");		
					}//foreach($val[$key] as $subKey=>$subVal) {
				}//foreach($arrQuery as $key=>$val) {	
				
			} // while( $row = mysql_fetch_array($result1)){			
			

			
			
			
			/*exit();
			
			$inc_yn = "Y";
			$resData = array();
			$user_name = $_SESSION["usr_name"];
			$date_name = date("Y/m/d  H:i:s");	
			
			$sql = "SELECT * FROM ev_location WHERE eloc_g_total > 0";
			$result = getData($sql);
			
			while( $row = mysql_fetch_array($result) ){
			
				$arrData = array();
				$evn_id = $row["evn_id"];
				$loc_id = $row["loc_id"];
				$eloc_in_date = $row["eloc_in_date"]; //echo " - ";
				$eloc_event_date = $row["eloc_event_date"];  //echo "<hr>";
				$eloc_end_date = $row["eloc_end_date"];
				$eloc_out_date = $row["eloc_out_date"];
				$eloc_g_total = $row["eloc_g_total"];
				$eloc_g_adjust = $row["eloc_g_adjust"];
				$eloc_g_net = $row["eloc_g_net"];
				$eloc_id = $row["eloc_id"];
				
				
				$in_date = conToGregoriantojd($eloc_in_date); 
				$show_date = conToGregoriantojd($eloc_event_date);
				$end_date = conToGregoriantojd($eloc_end_date);
				$out_date = conToGregoriantojd($eloc_out_date);
				
				$rev_b4vat = ( $eloc_g_net/107 )* 100 ;
				$rev_vat = ( $eloc_g_total/107 )* 7 ;
				$rev_incvat = $rev_b4vat + $rev_vat ;
				
				
				## IN ##
				$rev_source = "in";
				$rev_type = "space_L";
				
				for( $i=$in_date; $i<$show_date; $i++ ){
					//echo $i;
					$date = jdtogregorian($i); //echo "<hr>";
					list($mm , $dd , $yyyy) = explode("/" , $date );
					$rev_date = $yyyy.$mm.$dd;	//echo "<hr>";
					$esv_id = 0 ;	
								
					$resData = setRevenue($evn_id,$loc_id,$esv_id,$rev_date,$rev_source
										,$rev_type,$eloc_g_total,$eloc_g_adjust,$eloc_g_net
										,$rev_b4vat,$rev_vat,$rev_incvat,$eloc_id,$user_name,$date_name);			
					
					$arrData[] = $resData;
				} // for( $i=$in_date; $i<$show_date; $i++ ){
				
				
				## SHOW ##
				$rev_source = "show";
				$rev_type = "space_L";
				for( $i=$show_date; $i<=$end_date; $i++ ){
					//echo $i;
					$date = jdtogregorian($i); //echo "<hr>";
					list($mm , $dd , $yyyy) = explode("/" , $date );
					$rev_date = $yyyy.$mm.$dd;	//echo "<hr>";				
					$esv_id = 0 ;	
								
					$resData = setRevenue($evn_id,$loc_id,$esv_id,$rev_date,$rev_source
										,$rev_type,$eloc_g_total,$eloc_g_adjust,$eloc_g_net
										,$rev_b4vat,$rev_vat,$rev_incvat,$eloc_id,$user_name,$date_name);	
					
					$arrData[] = $resData;
				} // for( $i=$show_date; $i<=$end_date; $i++ ){
				
				
				
				## OUT ##
				$rev_source = "out";
				$rev_type = "space_L";
				
				for( $i=$end_date; $i<=$out_date; $i++ ){
					//echo $i;
					
					$date = jdtogregorian($i); //echo "<hr>";
					list($mm , $dd , $yyyy) = explode("/" , $date );
					$rev_date = $yyyy.$mm.$dd;	//echo "<hr>";				
					$esv_id = 0 ;	
								
					$resData = setRevenue($evn_id,$loc_id,$esv_id,$rev_date,$rev_source
										,$rev_type,$eloc_g_total,$eloc_g_adjust,$eloc_g_net
										,$rev_b4vat,$rev_vat,$rev_incvat,$eloc_id,$user_name,$date_name);			
					
					$arrData[] = $resData;
				} // for( $i=$end_date; $i<=$out_date; $i++ ){
				
				
				## EQUIP_FOOD ##
				$eqs_sql = "SELECT * 
							FROM ev_equip_serv 
							WHERE evn_id = $evn_id 
							AND loc_id = $loc_id " ;
						
				$eqs_result = getData($eqs_sql);
				
				while( $eqs_row = mysql_fetch_array($eqs_result) ){
				
					$esv_id = $eqs_row["esv_id"];
					$eesv_beg_date = $eqs_row["eesv_beg_date"];
					$eesv_end_date = $eqs_row["eesv_end_date"];
					$eesv_total = $eqs_row["eesv_total"];
					$eesv_adj = $eqs_row["eesv_adj"];
					$eesv_net = $eqs_row["eesv_net"];
					
					$beg_date = conToGregoriantojd($eesv_beg_date); 
					$end_date = conToGregoriantojd($eesv_end_date);
					
					$rev_b4vat = ( $eesv_net/107 )* 100 ;
					$rev_vat = ( $eesv_total/107 )* 7 ;
					$rev_incvat = $rev_b4vat + $rev_vat ;
				
					## EQUIP ##
					$rev_source = "equip_food";
					$rev_type = "equip";
					
					for( $i=$beg_date; $i<=$end_date; $i++ ){
						//echo $i;
						
						$date = jdtogregorian($i); //echo "<hr>";
						list($mm , $dd , $yyyy) = explode( "/" , $date );
						$rev_date = $yyyy.$mm.$dd ;	//echo "<hr>";				
									
						$resData = setRevenue($evn_id,$loc_id,$esv_id,$rev_date,$rev_source
											,$rev_type,$eesv_total,$eesv_adj,$eesv_net
											,$rev_b4vat,$rev_vat,$rev_incvat,$eloc_id,$user_name,$date_name);			
						
						$arrData[] = $resData ;
						
					} // for( $i=$beg_date; $i<=$end_date; $i++ ){
				
				} // while( $eqs_row = mysql_fetch_array($eqs_result) ){
				
				
				
				## EQUIP_FOOD ##
				$fd_sql = "SELECT * 
						FROM ev_food_serv 
						WHERE evn_id = $evn_id 
						AND loc_id = $loc_id " ;
				
				$fd_result = getData($fd_sql);
				
				while( $fd_row = mysql_fetch_array($fd_result) ){
				
					$esv_id = $fd_row["esv_id"];
					$eesv_beg_date = $fd_row["eesv_beg_date"];
					$eesv_end_date = $fd_row["eesv_end_date"];
					$eesv_total = $fd_row["eesv_total"];
					$eesv_adj = $fd_row["eesv_adj"];
					$eesv_net = $fd_row["eesv_net"];
					
					$beg_date = conToGregoriantojd($eesv_beg_date); 
					$end_date = conToGregoriantojd($eesv_end_date);
					
					$rev_b4vat = ( $eesv_net/107 )* 100 ;
					$rev_vat = ( $eesv_total/107 )* 7 ;
					$rev_incvat = $rev_b4vat + $rev_vat ;
				
				
					## FOOD ##
					$rev_source = "equip_food";
					$rev_type = "food";					
					for( $i=$beg_date; $i<=$end_date; $i++ ){
						//echo $i;
						
						$date = jdtogregorian($i); //echo "<hr>";
						list($mm , $dd , $yyyy) = explode("/" , $date );
						$rev_date = $yyyy.$mm.$dd;	//echo "<hr>";				
						
									
						$resData = setRevenue($evn_id,$loc_id,$esv_id,$rev_date,$rev_source
											,$rev_type,$eesv_total,$eesv_adj,$eesv_net
											,$rev_b4vat,$rev_vat,$rev_incvat,$eloc_id,$user_name,$date_name);			
						
						$arrData[] = $resData ;
					} // for( $i=$beg_date; $i<=$end_date; $i++ ){
				
				} // while( $fd_row = mysql_fetch_array($fd_result) ){		
				
				
				
				//echo "<pre>"; print_r($arrData); exit();

				
				for( $j=0; $j<sizeof($arrData); $j++ ){
					$query = create_insert_query("ev_revenue_new" , $arrData[$j]);
					//echo "\$query= $query"; echo "<br />";
					$result = mysql_query($query) or die("<script>alert ('Insert table profile error');</script>");
				} // for( $j=0; $j<sizeof($arrData); $j++ ){
				
				$del = "DELETE FROM ev_revenue WHERE evn_id = $evn_id AND loc_id = $loc_id ";
				//echo "\$del= $del"; echo "<hr>";
				mysql_query($del) or die("DELETE ev_revenue Error!!");
			
			} // while( $row = mysql_fetch_array($result) ){*/
			
			break;
	}
	
	
}

?>
</body>
</html>
