<?	
	ob_start();
	session_start();
	include("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	define("updSave","esta_updForm.php");
	global $evn_id;
	$evn_id = $_REQUEST["id"];
	//======================Begin prepare standard data======================================
		
	if(!empty($evn_id)){
		$sql = "SELECT * FROM eventname WHERE evn_id = '$evn_id'  ";
		$result = getData($sql);
		$row = mysql_fetch_array($result);
		$disabled = "";
		if($row["evn_used"] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;
		$evn_name = $row["evn_shortname"];
	} //if(!empty($ev_id)){	

		$sql = "SELECT bks_id, bks_code , bks_name  FROM bookingstatus 
					ORDER BY bks_code ";
		$resbook_status = getData($sql);	
		
	//======================Begin select data from ev_statistics===============================
	if (!empty($evn_id)){
		$sql = "SELECT * FROM ev_statistics WHERE evn_id = '$evn_id'  ";
//		echo "$sql<br>";
		$result = getData($sql);
		$numrow = mysql_num_rows($result);
		$rs_esta = mysql_fetch_array($result);	
		//echo "$rs_esta[2]<br>";
	} //if (!empty($evn_id)){	
		
		$sql = "SELECT rtc_id, rtc_code , rtc_name  FROM ratecode ";
		$sql .= " where ( rtc_used = 'Y' or  rtc_id = ".$rs_esta[rtc_id] ." )";
		$sql .= " ORDER BY rtc_code ";
		//echo "ratecode=$sql<hr>";
		$resrate_code = getData($sql);	
		
		$event = "Nature of Event";
		$bus_code = "Nature of Business Code";
		$param_code = "Event Parameter Code";
		$source_code = "Customer Source Code";
		$room_code = "Room Use Code";	
		$client_grp = "Client_Group";	
		
		
		$sql = "SELECT * FROM miscode 
					ORDER BY mis_type ASC,  mis_code ASC ";
		$result = getData($sql);
		
		$arrevent = array();
		$arrbus_code = array();
		$arrparam_code = array();
		$arrsource_code = array();
		$arrroom_code = array();	
		$arrclient_grp = array();	
		
		while( $row = mysql_fetch_array($result)){
			if ($row["mis_type"] == $event ){
				$arrevent[]= $row["mis_code"]." - ".$row["mis_name"];
			} //if ($row["mis_type"]=="$event "){		
			
			if ($row["mis_type"] == $bus_code ){
				$arrbus_code[]= $row["mis_code"]." - ".$row["mis_name"];
			} //if ($row["mis_type"]=="$bus_code "){		
			
			if ($row["mis_type"] == $param_code ){
				$arrparam_code[]= $row["mis_code"]." - ".$row["mis_name"];
			} //if ($row["mis_type"]=="$param_code "){		
			
			if ($row["mis_type"] == $source_code ){
				$arrsource_code[]= $row["mis_code"]." - ".$row["mis_name"];
			} //if ($row["mis_type"]=="$source_code "){		
			
			if ($row["mis_type"] == $room_code ){
				$arrroom_code[]= $row["mis_code"]." - ".$row["mis_name"];
			} //if ($row["mis_type"]=="$room_code "){				
			
			if ($row["mis_type"] == $client_grp ){
				$arrclient_grp[$row["mis_code"]]= $row["mis_name"];
			} //if ($row["mis_type"]=="$room_code "){				
		} //while( $row = mysql_fetch_array($result)){
		
	//======================End prepare stand data========================================
	
	
?>
<html>
<script language="javascript">
	function validate() 
	{
		if(frm.bks_id.value==1)
		{
			//Ϳ.ػó.value
			alert('Please input data in Booking Status Code');
			frm.bks_id.focus()
			return false;
		}
		if(frm.rtc_id.value==1)
		{
			//Ϳ.ػó.value
			alert('Please input data in Rate Code');
			frm.rtc_id.focus()
			return false;
		}
	
		if(frm.esta_previous[0].checked == false && frm.esta_previous[1].checked == false)
		{
			//Ϳ.ػó.value
			alert('Please input data in Event Previously Held');
			frm.esta_previous[0].focus()
			return false;
		}
		if(frm.esta_open_pub[0].checked == false && frm.esta_open_pub[1].checked == false)
		{
			//Ϳ.ػó.value
			alert('Please input data in Event Open to the Public');
			frm.esta_open_pub[0].focus()
			return false;
		}
		if(frm.esta_media[0].checked == false && frm.esta_media[1].checked == false)
		{
			//Ϳ.ػó.value
			alert('Please input data in Release Event to the Media');
			frm.esta_media[0].focus()
			return false;
		}
		if(frm.esta_tax[0].checked == false && frm.esta_tax[1].checked == false)
		{
			//Ϳ.ػó.value
			alert('Please input data in Tax Exempt');
			frm.esta_tax[0].focus()
			return false;
		}		
	}
</script>

<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">

</head>
	
<body >
<form action="<?=updSave ?>?id=<?=$evn_id?>" method="post" name="frm"  id="frm" onSubmit="return validate();" >
  <div align="left"></div>
  <table border="0" align="left" class="BorderGreen" >
    <tr class="BorderSilver">
      <td colspan="4" style="background-color:#339900;font-weight:bold;color:White;">
	  	<div align="center"><strong >Statistics - <?=$evn_id." - " .$evn_name ?></strong></div>	  </td>
    </tr>
	<tr>
	  <td height="27" colspan="4"><div align="center">
        <input name="esta_id" type="hidden" id="esta_id" value="<?=$evn_id ?>">
</div></td>
    </tr>		
		<tr>
		  <td ><div align="right">*Booking Status Code : </div></td>
		  <td colspan="2"><div align="left">
		    <select name="bks_id" id="bks_id">			
			  <?			
			  	$data = $rs_esta["bks_id"];
			  	while($book_status  =  mysql_fetch_array($resbook_status)){
					$val_book_status = "$book_status[bks_code] - $book_status[bks_name]"; ?>
					<option value='<?=$book_status["bks_id"]?>' " <?  if($book_status["bks_id"]==$data) echo "selected" ?> 
					."><?=$val_book_status ?></option>				
			  <?	
				}
			  ?>
	        </select>
		  </div></td>
    </tr>
		<tr>
		  <td ><div align="right">*Rate Code : </div></td>
		  <td colspan="2" ><div align="left">
		    <select name="rtc_id" id="rtc_id">
			  <?			
			  	$data = $rs_esta["rtc_id"];
			  	while($rate_code  =  mysql_fetch_array($resrate_code)){
					$val_rate_code = "$rate_code[rtc_code] - $rate_code[rtc_name]"; ?>
					<option value='<?=$rate_code["rtc_id"]?>' " <?  if($rate_code["rtc_id"]==$data) echo "selected" ?> 
					."><?=$val_rate_code ?></option>					
			  <?	
				}
			  ?>
	        </select>
		  </div></td>
    </tr>
		<tr>
		  <td ><div align="right">Nature of Event : </div></td>
		  <td colspan="2" ><div align="left">
		    <select name="esta_event" id="esta_event">
			  <?
			  	$data = $rs_esta["esta_event"];
			  	foreach($arrevent as $key=>$val){ ?>
					<option value='<?=$val ?>' <?  if($val==$data) echo "selected" ?> ><?=$val ?></option>								 
			 <?	
				}
			  ?>
	        </select>
		  </div></td>
    </tr>
		<tr>
		  <td ><div align="right">Nature of Business Code : </div></td>
		  <td colspan="2" ><div align="left">
		    <select name="esta_bus_code" id="esta_bus_code">
			  <?
			  	$data = $rs_esta["esta_bus_code"];
			  	foreach($arrbus_code as $key=>$val){ ?>
					<option value='<?=$val ?>' <?  if($val==$data) echo "selected" ?> ><?=$val ?></option>								 
			 <?	
				}
			  ?>
	        </select>
		  </div></td>
    </tr>
		<tr>
		  <td ><div align="right">Event Parameter Code : </div></td>
		  <td colspan="2" ><div align="left">
		    <select name="esta_param_code" id="esta_param_code">
			  <?
			  	$data = $rs_esta["esta_param_code"];
			  	foreach($arrparam_code as $key=>$val){ ?>
					<option value='<?=$val ?>' <?  if($val==$data) echo "selected" ?> ><?=$val ?></option>								 
			 <?	
				}
			  ?>
	        </select>
		  </div></td>
    </tr>
		<tr>
		  <td ><div align="right">Customer Source Code : </div></td>
		  <td colspan="2" ><div align="left">
		    <select name="esta_source_code" id="esta_source_code">
			  <?
			  	$data = $rs_esta["esta_source_code"];
			  	foreach($arrsource_code as $key=>$val){ ?>
					<option value='<?=$val ?>' <?  if($val==$data) echo "selected" ?> ><?=$val ?></option>								 
			 <?	
				}
			  ?>
	        </select>
		  </div></td>
    </tr>
		<tr>
		  <td ><div align="right">Room Use Code : </div></td>
		  <td colspan="2" ><div align="left">
		    <select name="esta_room_code" id="esta_room_code">
			  <?
			  	$data = $rs_esta["esta_room_code"];
			  	foreach($arrroom_code as $key=>$val){ ?>
					<option value='<?=$val ?>' <?  if($val==$data) echo "selected" ?> ><?=$val ?></option>								 
			 <?	
				}
			  ?>
	        </select>
		  </div></td>
    </tr>
	<!--  add new -->
		<tr>
		  <td ><div align="right">Client Group : </div></td>
		  <td colspan="2" ><div align="left">
		    <select name="esta_client_grp" id="esta_client_grp">
			  <?
			  	$data = $rs_esta["esta_client_grp"];
			  	foreach($arrclient_grp as $key=>$val){ ?>
					<option value='<?=$key ?>' <?  if($key==$data) echo "selected" ?> ><?=$val ?></option>								 
			 <?	
				}
			  ?>
	        </select>
		  </div></td>
    </tr>
	
		<tr>
		  <td height="27" ><div align="right"></div></td>
		  <td colspan="2" ><div align="left"></div></td>
    </tr>
		<tr>
		  <td ><div align="right">Initial Attendant : </div></td>
		  <td colspan="2" ><div align="left">
		    <input name="esta_ini_atten" type="text" id="esta_ini_atten" value="<?=$rs_esta["esta_ini_atten"];?>">
		  </div></td>
    </tr>
		<tr>
		  <td ><div align="right">Attendance Per Session : </div></td>
		  <td colspan="2" ><div align="left">
		    <input name="esta_atten" type="text" id="esta_atten" value="<?=$rs_esta["esta_atten"];?>">
		  </div></td>
    </tr>
		<tr>
		  <td ><div align="right">Number Sessions/Performances : </div></td>
		  <td colspan="2" ><div align="left">
		    <input name="esta_num_session" type="text" id="esta_num_session" value="<?=$rs_esta["esta_num_session"];?>">
		  </div></td>
    </tr>
		<tr>
		  <td height="25" ><div align="right"></div></td>
		  <td colspan="2" ><div align="left"></div></td>
    </tr>
		<tr>
		  <td ><div align="right">*Event Previously Held : </div></td>
		  <td colspan="2" ><div align="left">
		    <input name="esta_previous" type="radio" value="Y" <? if($rs_esta["esta_previous"]=='Y') echo 'checked'; ?> >
		    Yes&nbsp; 
		    <input name="esta_previous" type="radio" value="N" <? if($rs_esta["esta_previous"]=='N') echo 'checked'; ?> >
		  No</div></td>
    </tr>
		<tr>
		  <td ><div align="right">*Event Open to the Public : </div></td>
		  <td colspan="2" ><div align="left">
		    <input name="esta_open_pub" type="radio" value="Y" <? if($rs_esta["esta_open_pub"]=='Y') echo 'checked'; ?> >
Yes&nbsp;
<input name="esta_open_pub" type="radio" value="N" <? if($rs_esta["esta_open_pub"]=='N') echo 'checked'; ?> >
No</div></td>
    </tr>
		<tr>
		  <td ><div align="right">*Release Event to the Media : </div></td>
		  <td colspan="2" ><div align="left">
		    <input name="esta_media" type="radio" value="Y" <? if($rs_esta["esta_media"]=='Y') echo 'checked'; ?> >
Yes&nbsp;
<input name="esta_media" type="radio" value="N" <? if($rs_esta["esta_media"]=='N') echo 'checked'; ?> >
No</div></td>
    </tr>
		<tr>
		  <td ><div align="right">*Tax Exempt : </div></td>
		  <td colspan="2" ><div align="left">
		    <input name="esta_tax" type="radio" value="Y" <? if($rs_esta["esta_tax"]=='Y') echo 'checked'; ?> >
Yes&nbsp;
<input name="esta_tax" type="radio" value="N" <? if($rs_esta["esta_tax"]=='N') echo 'checked'; ?> >
No</div></td>
    </tr>
		<tr>
		  <td ><div align="right"></div></td>
		  <td colspan="2" ><div align="left"></div></td>
    </tr>
    <tr align="center" >
      <td height="29">	  	
	  	<div align="right">
	  	  <input name="Submit2" type="button" class="Button" value="&lt;= Back " onClick="window.location = 'ev_maintenance.php?id=<?=$evn_id?>'" >
	  	  <input name="Submit" type="submit" class="Button" value="   OK   "  <?=$disabled?> >
      </div></td>
      <td colspan="2"><div align="left">
        <input name="Button" type="button" class="Button" id="Button"  onClick="history.go(-1)" value="Cancel" >
        <input name="Submit22" type="button" class="Button" value="Next =&gt;" onClick="window.location = 'edbk_viewForm.php?id=<?=$evn_id?>'" >
      </div></td>
    </tr>
  </table>
</form>
<?

	//======================Begin Save Data==============================================
	//request data into varible
	$Submit = $_REQUEST["Submit"];
	if(!empty($Submit)){
		$a_book_status = $_REQUEST["bks_id"];
		$a_rate_code = $_REQUEST["rtc_id"];
		$a_event = $_REQUEST["esta_event"];
		$a_bus_code = $_REQUEST["esta_bus_code"];
		$a_param_code = $_REQUEST["esta_param_code"];
		$a_source_code = $_REQUEST["esta_source_code"];
		$a_room_code = $_REQUEST["esta_room_code"];
		$a_client_grp = $_REQUEST["esta_client_grp"];
		$a_ini_atten = $_REQUEST["esta_ini_atten"];
		$a_atten = $_REQUEST["esta_atten"];
		$a_num_session = $_REQUEST["esta_num_session"];
		$a_previous = $_REQUEST["esta_previous"];
		$a_open_pub = $_REQUEST["esta_open_pub"];
		$a_media = $_REQUEST["esta_media"];
		$a_tax = $_REQUEST["esta_tax"];
	/*	
		echo "
		submit = $Submit<br>
		evn_id =  $evn_id<br>
		a_book_status = $a_book_status<br> 
		a_rate_code = $a_rate_code<br>
		a_event = $a_event <br> 
		a_bus_code = $a_bus_code<br>
		a_param_code = $a_param_code <br>
		a_source_code = $a_source_code<br>
		a_room_code = $a_room_code <br>
		a_ini_atten = $a_ini_atten<br>
		a_atten = $a_atten<br>
		a_num_session = $a_num_session<br>
		a_previous = $a_previous <br>
		a_open_pub = $a_open_pub <br>
		a_media = $a_media <br>
		a_tax = $a_tax <br>
		";
		exit();
		*/
		//check duplicate data in table ev_statistics
		$sql = "SELECT evn_id FROM ev_statistics WHERE evn_id = '$evn_id'  ";
		//echo "$sql<br>";
		$result = getData($sql);
		$numrow = mysql_num_rows($result);
		$row = mysql_fetch_array($result);
		//echo "numrow = $numrow<br>";
		if ($numrow == 0 ){
				$action = "add";}
			else{
				$action = "edit";
		}
		//echo "action=$action<br>";
		
		function  checklist($value,$label,$field){
			global $resNull;	global $resData;global $flag; global $strPattern;
			$strPattern = "Booking Status Code|Rate Code|Nature of Event|
									  Nature of Business Code|Event Parameter Code|Customer Source Code|
									  Room Use Code|Client Group|Event Previously Held|Event Open to the Public|
									  Release Event to the Media|Tax Exempt|
									  ";									  
			if(empty($value)){
				if(ereg($strPattern,$label)){
					$flag = 1;
					$resNull[$label] = $value;
				} //if(ereg($strPattern,$label)){			
			} //if(empty($var)){
			$resData[$field] = $value;
		} //function checklist($var,$name){
		
		//checklist($evn_id,"","evn_id");
		checklist($a_book_status,"Booking Status Code","bks_id");
		checklist($a_rate_code,"Rate Code","rtc_id");
		checklist($a_event,"Nature of Event","esta_event");
		checklist($a_bus_code,"Nature of Business Code","esta_bus_code");
		checklist($a_param_code,"Event Parameter Code","esta_param_code");
		checklist($a_source_code,"Customer Source Code","esta_source_code");
		checklist($a_room_code,"Room Use Code","esta_room_code");
		checklist($a_client_grp,"Client Group","esta_client_grp");
		checklist($a_ini_atten,"Initial Attendance","esta_ini_atten");		
		checklist($a_atten,"Attendance Per Session","esta_atten");		
		checklist($a_num_session,"Number Session/Performances","esta_num_session");
		checklist($a_previous,"Event Previously Held","esta_previous");
		checklist($a_open_pub,"Event Open to the Public","esta_open_pub");
		checklist($a_media,"Release Event to the Media","esta_media");
		checklist($a_tax,"Tax Exempt","esta_tax");
		
		//echo "flag = $flag<br>";
		/*
		if($flag){
			$mesg = "Please input data in ";
			while(list($key,$value) = each($resNull)){
				if(empty($value)){
					if(!ereg($strPattern,$name))	
						$str .= "$key, ";
				}  //if(empty($value)){
			} //while(list($key,$value) = each($resNull)){
			$str = substr($str, 0, strlen($str) -2 ); 
			echo errmesg ("$mesg $str");			
			
		}	//if($flag){
		else
		*/
		{
			if($action=="add"){
				$resData["evn_id"] = $evn_id;
				$resData["usr_cre"] = $_SESSION["usr_name"];
				$resData["date_cre"] = date("Y/m/d  H:i:s");		
				
				$query = create_insert_query("ev_statistics",$resData);	
				//echo "$query<br>";
				mysql_query($query) or die("Insert error");						
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");
				//Show alert by javascript
				echo "<script>
						alert ('Insert complete');
						window.location = 'esta_updForm.php?id=$evn_id';
					  </script>";
				exit();
			}
			
			if($action=="edit"){
				$resData["usr_upd"] = $_SESSION["usr_name"];
				$resData["date_upd"] = date("Y/m/d  H:i:s");		
				
				$query = create_update_query("ev_statistics", $resData, $evn_id, "evn_id");				
				//echo "$query<br>";
				//exit();
				mysql_query($query) or die("Update error");		
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");
				$query = " UPDATE ev_location SET " ;
				$query .= "	bks_id = $a_book_status" ;
				$query .= "	WHERE evn_id = '$evn_id'";
				//echo "$query<br>";
				mysql_query($query) or die("Update error");		
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");
				//Show alert by javascript
				echo "<script>
						alert ('Update complete');
						window.location = 'esta_updForm.php?id=$evn_id' ;
					  </script>";
				exit();
			}
		} //else{

	} //if(!empty($Submit)){
	
	//======================End Save Data==============================================
?>
