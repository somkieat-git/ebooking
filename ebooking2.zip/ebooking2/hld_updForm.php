<?
	error_reporting(E_ALL ^E_NOTICE ^E_WARNING ^ E_DEPRECATED);
	ob_start();
	session_start();
	
	$hld_id = $_REQUEST["hld_id"];
	$hld_date = $_REQUEST["hld_date"];
	$hld_desc = $_REQUEST["hld_desc"];
	$hld_color = $_REQUEST["hld_color"];
	$hld_status = $_REQUEST["hld_status"];
	$hld_used = $_REQUEST["hld_used"];
	$id = $_REQUEST["id"];
	$action = $_REQUEST["a"];
	$Submit = $_REQUEST["Submit"];
	/*
	echo "
		\$id = $id <br>
		\$action = $action <br>
		\$Submit = $Submit <br>
		\$hld_date = $hld_date <br>		
	";
	*/
	$cap_name = array();
	$cap_name = array("#","Date","Description","Color");
			   
	define("viewForm","flexigrid/hld_vfrm.php");
	define("updSave","hld_updForm.php");
	define("tableName","holiday");
	define("menuName","Holiday");
	define("field_id","hld_id");
	define("action",$action);
	define("id",$id);	
	define("beg_id",1);	
	define("end_id",3);	
	include_once("func/updForm.func.php");	
	include_once("func/sql.func.php");	
	
	function checklist($var,$name){
		global $data;
		global $flag;

		if(empty($var)){
			if(ereg("hld_date|hld_desc",$name))
				$flag = 1;
		}  //if(empty($var)){
		$data[$name] = $var;
	} //function checklist($var,$name){
	
	if(!empty($Submit)){
		$hld_date = chgDateToDb($hld_date);
		checklist($hld_date,"hld_date");
		checklist($hld_desc,"hld_desc");
		checklist($hld_color,"hld_color");
		if($flag){
			$mesg = "Please input data in ";
			while(list($key,$value) = each($data)){
				if(empty($value)){
				if(!ereg("hld_date|hld_desc",$name))
						$str .= "$key,";
				}  //if(empty($value)){
			}
			echo errmesg ("$mesg $str");			
		}	//if($flag){
		else{
			if ($action=="a"){
				$data["hld_id"] = "";
				$data["usr_cre"] = $_SESSION["usr_name"];				
				$data["date_cre"] = date("Y/m/d  H:i:s");				
				$query = create_insert_query($table_name,$data);				
				//echo "$query<br>";
				//exit();
				mysql_query($query) or die("Insert error");		
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");			
				//Show alert by javascript
				echo "<script>
						alert ('Insert complete');
						window.location = 'hld_updForm.php?a=a';
					  </script>";
				exit();
			} //if ($action=="a"){
			
			if ($action=="e"){
				$data["usr_upd"] = $_SESSION["usr_name"];
				$data["date_upd"] = date("Y/m/d  H:i:s");				
				$query = create_update_query($table_name, $data, $id, $field_id);				
				//echo "$query<br>";
				//exit();
				mysql_query($query) or die("Update error");	
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");				
				//Show alert by javascript
				echo "<script>
						alert ('Update complete');
						window.location = '".viewForm."';
					  </script>";
				exit();
			}  //if ($action=="e"){
			
			if ($action=="d"){
				$query = "DELETE FROM $table_name WHERE $field_id = $id " ;
				//echo "$query<br>";
				//exit();
				
				mysql_query($query) or die("Delete error");	
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");				
				//Show alert by javascript
				echo "<script>
						alert ('Delete complete');
						window.location = '".viewForm."';
					  </script>";
				exit();
			}  //if ($action=="e"){
						
		}  //else{ of if($flag){
	}  //if(!empty($Submit)){
	
?>
<script language="javascript">
	function validate() 
	{
		if(frm.hld_date.value=="")
		{
			alert('Please input data in Date');
			frm.hld_date.focus()
			return false;
		}

		if(frm.hld_desc.value=="")
		{
			alert('Please input data in Description');
			frm.hld_desc.focus()
			return false;
		}
		
	}
</script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</body>
</html>
