<?php 
	ob_start();
	session_start();
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	
	$arrOldData = $_SESSION["arrOldData"] ;
	$evn_id = $_REQUEST["id"];	
	$edbk_item = $_REQUEST["id2"];
	$new_loc_id = $_REQUEST["new_loc_id"];	
	$submit = $_REQUEST["Submit"];	
	

if($submit){

	##########################################
	$hdd_radio_name = $_REQUEST["hdd_radio_name"];
	$hdd_sel_name = $_REQUEST["hdd_sel_name"];

		foreach( $hdd_radio_name as $key => $value ){
			list( , $r_eesv_id , $type1) = explode("_" , $value);
			$$value = $_REQUEST[$value];
			if( $$value == "edit" ){
				foreach( $hdd_sel_name as $kSel => $vSelect ){
					list( , $s_eesv_id , $type2) = explode("_" , $vSelect);
					if( ($r_eesv_id == $s_eesv_id) && ($type1 == $type2) ){
						$$vSelect = $_REQUEST["$vSelect"]; 	
						list( $eloc_id , $loc_id ) = explode("|" , $$vSelect);	
										  
						if($type2 == "equip"){
							$table_name = "ev_equip_serv";
						}else{
							$table_name = "ev_food_serv";
						}
			
						$query2 = "UPDATE $table_name ";
						$query2 .=" SET eloc_id = '". $eloc_id ."' , loc_id = '". $loc_id ."'";
						$query2 .=" WHERE eesv_id = $r_eesv_id ";
						$query2 .=" AND evn_id = '$evn_id'";
//						echo "\$query2= $query2<hr>"; //exit();
						$result2 = getData($query2);
						$SaveLog2 = updLog($_SESSION['username'], "edbk_chgForm.php", $query2); 
					}								 
				}// foreach( $hdd_sel_name as $kSel => $vSelect ){
		
			}else if( $$value == "del" ){
				if($type == "equip"){
					$table_name = "ev_equip_serv";
				}else{
					$table_name = "ev_food_serv";
				}
		
				$query2 = "DELETE FROM $table_name ";
				$query2 .=" WHERE eesv_id = $r_eesv_id";
				$query2 .=" AND evn_id = '$evn_id'";
//				echo "\$query2 for DELETE $table_name= $query2<hr>"; //exit();
				$result2 = getData($query2);
				$del_rev2 = delRevenue("",$r_eesv_id);
				$SaveLog2 = updLog($_SESSION['username'], "edbk_chgForm.php", $query2);
			
			} // if( $$value == "edit" ){		
		}//foreach( $hdd_radio_name as $key => $value ){
	
	//Show alert by javascript
	echo "<script>
			alert ('Update completed');
			window.location = 'edbk_viewForm.php?id=$evn_id&id2=$edbk_item';
		  </script>";
	$_SESSION["arrOldData"] = "" ;
	exit();


} //if($submit){	

	
#####   GET Location For Select Block   #####
$sql = " SELECT loc.loc_id , loc.loc_shortname , eloc.eloc_id ";
$sql .= " FROM location loc , ev_location eloc ";
$sql .= " WHERE eloc.evn_id = $evn_id ";
$sql .= " AND loc.loc_id IN($new_loc_id) ";
$sql .= " AND eloc.loc_id = loc.loc_id ";
$sql .= " ORDER BY loc.loc_id ";
$result = getData($sql);
$arrLocName = array();
$sh_locName = array();
while( $rs = mysql_fetch_array($result) ){
	$locName["eloc_id"] = $rs["eloc_id"];
	$locName["loc_id"] = $rs["loc_id"];
	$locName["loc_shortname"] = $rs["loc_shortname"];
	
	$arrLocName[] = $locName;
}	

foreach($arrOldData as $key => $arrValue){
	foreach($arrValue as $key2 => $value){
		$sh_locName[$value["loc_shortname"]] = $value["loc_shortname"];
	}
}
is_array($sh_locName) ? $str_locName = implode(" , " , $sh_locName) : 0 ;
//echo "\$arrOldData= <pre>"; print_r($arrOldData); echo "<hr>"; //exit();
	


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="css/format.css.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.style1 {
	font-size: 14px;
	font-weight: bold;
}
.style2 {font-size: 16px}
-->
</style>
</head>

<body>
<form action="edbk_chgForm.php" method="post" name="frm" id="frm">
<div align="center" class="style1 style2" style="height:15px;"><span>Change Location / Delete </span></div>
 <table width="100%" border="1" align="center" cellpadding="0" cellspacing="0" class="BorderGreen">
<!-- 	<tr style="background-color: #339900; color: White; font-size:14px;">
	  <th colspan="12" align="center">
	  	<php 
			$sql = "SELECT evn_id , evn_shortname FROM eventname WHERE evn_id = $evn_id";
			$result = getData($sql);
			$rs = mysql_fetch_array($result);
			echo $evn_shortname = $rs["evn_id"] . " - " . $rs["evn_shortname"];
		?>
	  </th>
	</tr>-->
	<?php 
	foreach($arrOldData as $type => $arrValues){ 
		
		if($type == "Equip") {
			$title = "Equipment / Service" ;
			$subfix = "equip";
			//if( sizeof($arrValues) == 0 ) continue; 
		}else{ 
			$title = "Food / Service" ; 
			$subfix = "food";
			$br= "<br /><br />";
			//if( sizeof($arrValues) == 0 ) break;
		} 
		if( sizeof($arrValues) == 0 ) continue;
					
	?>
<?php echo $br ; ?>
<div align="left" style="height:25px;font-size:14px;font-style:italic">of <?php echo $title ;?></div>
	<table width="100%" border="1" align="center" cellpadding="0" cellspacing="0" class="BorderGreen">
		<tr style="background-color: #339900; color: White;">
		   <th>Beg Date</th>
		   <th>End Date</th>
		   <th width="20%"><?php echo $title ; ?></th>
		   <th>Qty</th>
		   <th>Days</th>
		   <th>@</th>
		   <th>Total</th>
		   <th>Adj</th>
		   <th>Net</th>
		   <th>From Room</th>
		   <th>Change To </th>
		   <th>Delete</th>
		</tr>
		<?php foreach($arrValues as $key => $value){ ?>
		<tr height="29" >
		   <td bgcolor="#FFFFFF"><?php echo $value["eesv_beg_date"]; ?></td>
		   <td bgcolor="#FFFFFF"><?php echo $value["eesv_end_date"]; ?></td>
		   <td bgcolor="#FFFFFF"><?php echo $value["esv_name"]; ?></td>
		   <td bgcolor="#FFFFFF"><?php echo $value["eesv_qty"]; ?></td>
		   <td bgcolor="#FFFFFF"><?php echo $value["days"]; ?></td>
		   <td bgcolor="#FFFFFF"><?php echo $value["eesv_amt"]; ?></td>
		   <td bgcolor="#FFFFFF"><?php echo $value["eesv_total"]; ?></td>
		   <td bgcolor="#FFFFFF"><?php echo $value["eesv_adj"]; ?></td>
		   <td bgcolor="#FFFFFF"><?php echo $value["eesv_net"]; ?></td>
		   <td bgcolor="#FFFFFF" align="center"><?php echo $value["loc_shortname"]; ?></td>
		   <td bgcolor="#FFFFFF" width="15%" align="center">
	 <input type="radio" name="radio_<?php echo $value["eesv_id"]; ?>_<?php echo $subfix ; ?>" id="radio<?php echo $value["eesv_id"]; ?>" value="edit" onclick="document.getElementById('selLoc_<?php echo $value["eesv_id"]; ?>_<?php echo $subfix ; ?>').disabled = false;" checked="checked" />
	 <select name="selLoc_<?php echo $value["eesv_id"]; ?>_<?php echo $subfix ; ?>" 
	 id="selLoc_<?php echo $value["eesv_id"]; ?>_<?php echo $subfix ; ?>">
		<?php 
			foreach($arrLocName as $k => $vLocation){ 
			  $val = $vLocation["eloc_id"] . "|" . $vLocation["loc_id"];
		?>
		<option value="<?php echo $val; ?>"><?php echo $vLocation["loc_shortname"]; ?></option>
		<?php } ?>
	 </select>
	 <input type="hidden" name="hdd_sel_name[]" id="hdd_sel_name[]" 
	 value="selLoc_<?php echo $value["eesv_id"]; ?>_<?php echo $subfix ; ?>" />		   </td>
		   <td bgcolor="#FFFFFF" width="5%" align="center">
			 <input type="radio" name="radio_<?php echo $value["eesv_id"]; ?>_<?php echo $subfix ; ?>" id="radio<?php echo $value["eesv_id"]; ?>" value="del" onclick="document.getElementById('selLoc_<?php echo $value["eesv_id"]; ?>_<?php echo $subfix ; ?>').disabled = true ;" />
			 <input type="hidden" name="hdd_radio_name[]" id="hdd_radio_name[]"
			 value="radio_<?php echo $value["eesv_id"]; ?>_<?php echo $subfix ; ?>" />		   </td>
		</tr>
		<?php } ?>
	</table><br />
	<?php
		} 	
	?>
</table>
<br />
	<div align="center" style="height:5%">
<!--		<input name="Submit2" type="button" class="Button" value="&lt;= Back " onClick="window.location = 'esta_updForm.php?id=<=$evn_id?>'" >
-->        <input name="Submit" type="submit" class="Button" value="      OK      "  <?=$disabled;?> >
<!--        <input name="Button2" type="button" class="Button" id="Button"  onClick="history.go(-1)" value="Cancel" >-->
<!--        <input name="Submit22" type="button" class="Button" value="Next =&gt;" onClick="window.location = 'ecus_updForm.php?id=<=$evn_id?>'" >
-->        <input name="id" type="hidden" id="evn_id" value="<?php echo $evn_id; ?>">
		<input name="id2" type="hidden" id="edbk_item" value="<?php echo $edbk_item; ?>">
<!--		<input name="old_loc_id" type="hidden" id="old_loc_id" value="<php echo $old_loc_id; ?>">
		<input name="new_loc_id" type="hidden" id="new_loc_id" value="<php echo $new_loc_id; ?>">
-->	</div>
</form>
</body>
</html>

