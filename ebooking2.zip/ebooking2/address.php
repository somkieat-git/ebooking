<?php 
ob_start(); session_start(); 
include_once("db/connect.db.php");
include_once("func/sql.func.php");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Address In Thailand</title>
<link href="css/viewfrmBlue.css" rel="stylesheet" type="text/css">
<script>var winMain=window.opener;</script>
<script type="text/javascript" language="JavaScript">

	function doOk(obj,l)
	{
		//alert(obj);
		opener.setAddress(obj,l);
		window.close();						
	}

</script>	
</head>

<body>
<fieldset>
<?php 
$fieldName = $_REQUEST["f"];
$te = $_REQUEST["l"];
$fieldValue = $_REQUEST["v"];
//echo "mb_detect=";
//echo mb_detect_encoding($fieldValue); // UTF-8


$fieldValue= str_replace("*","%",$fieldValue);
//echo "<br>\$fieldValue=$fieldValue<br>";


$arrAddress = array();
if( $te == "th" ){
	$arrAddHead = array("แขวง/ตำบล" , "เขต/อำเภอ" , "จังหวัด" , "รหัสไปรษณีย์" ,);
	$sql = " SELECT add_id as add_id , add_ttambol as tambol , add_tdistrict as district , add_tprovince as province , add_tcountry as country , add_postcode as postcode ";
}else{
	$arrAddHead = array("Tambol" , "District" , "Province" , "Postcode" ,);
	$sql = " SELECT as add_id , add_etambol as tambol , add_edistrict as district , add_eprovince as province , add_ecountry as country , add_postcode as postcode ";
}
$sql .= " FROM address ";
$sql .= " WHERE add_show = 1 ";
$fieldValue ? $sql .= " and $fieldName like '$fieldValue%' " : 0 ;
$sql .= " ORDER BY $fieldName, add_seq, add_id ";

//echo "$sql<hr>";  
//exit();
	$rstAdd = getData($sql);
	while($rsAdd = mysql_fetch_array($rstAdd)){
		$add_id = $rsAdd["add_id"];
		$add_tambol = $rsAdd["tambol"];
		$add_district = $rsAdd["district"];
		$add_province = $rsAdd["province"];
		$add_country = $rsAdd["country"];
		$add_postcode = $rsAdd["postcode"];
		$arrAddress[] = array($add_tambol,$add_district,$add_province,$add_country,$add_postcode);
	} //while($rsQue = fetch_array($dbtype, $rstQue)){
?>
<table width="98%"  border="0" cellspacing="2" cellpadding="0" class="lst_Border" align="center">
	<tr class="lst_BorderHead"> 
	  <?
		foreach($arrAddHead as $hKey => $hValue){
			echo "<th scope=\"col\" align=\"left\">$hValue</th>";		
		} //foreach($arrAddHead as $hKey => $hValue){
	  ?>
	 </tr>
  <?
  	foreach($arrAddress as $dKey => $dValue){
		$bgcolor == "#E7F0F8" ? $bgcolor="#F5F9FC" : $bgcolor="#E7F0F8" ;		
		echo "<tr bgcolor=\"$bgcolor\" 
					onMouseOver=\"this.style.backgroundColor='#ACE2EE'\" 
					onMouseOut=\"this.style.backgroundColor='$bgcolor'\" $class>";
							
		$aValue = implode("|",$dValue);
		//echo "<td><a href=\"javascript:doOk('$aValue');\">$dValue[0]</a></td>";		
		for($i=0;$i<count($dValue);$i++){
			//echo "<td>$dValue[$i]</td>";
			if($i != 3 ) echo "<td><a href=\"javascript:doOk('$aValue','$te');\">$dValue[$i]</a></td>"  ;		
		} //for($i=0;$i<count($dValue);$i++){
		echo "</tr>";
	} //foreach($arrAddHead as $hKey => $hValue){
  ?>
</table></fieldset><br>
<div align="center">
    <input name="btnClose" type="button" id="btnClose" value="Close" onClick="window.close();">
  </div>
</body>
</html>
