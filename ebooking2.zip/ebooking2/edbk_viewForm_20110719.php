<?	
	include("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	//include "./cfg/config.cfg.php";
	$sysName = "Event Date ";
	$evn_id = $_REQUEST["id"];
	$edbk_item = $_REQUEST["id2"];
	$bk18 = $_SESSION["bk18"]; // By Kae
	//$presix = prefix ;
	if(empty($edbk_item)) $edbk_item = 0;
	//echo "evn_id = $evn_id<br>edbk_item=$edbk_item<br>";
	
	if(!empty($evn_id)){
		$sql = "SELECT * FROM eventname WHERE evn_id = '$evn_id'  ";
		$res = getData($sql);
		$rs = mysql_fetch_array($res);
		$disabled = "";
		//if($rs[3] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;
		if($rs["evn_used"] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;
		$evn_name = $rs[1];
		
		$sql = "SELECT edbk_in_date, edbk_out_date				
					FROM ev_dateblock 
					WHERE evn_id = '$evn_id'
					AND edbk_item = $edbk_item
					";
		//echo "$sql<hr>";
		//exit();
		$rs_edbk = getResult($sql,"");	
		$in_date = $rs_edbk[0] ;
		$out_date = $rs_edbk[1] ;
		//echo "\$rs_edbk[0] = $rs_edbk[0]<br> \$rs_edbk[1] = $rs_edbk[1]<br>";
		//exit();
		
		$query = "
					SELECT distinct loc.loc_id, loc.loc_shortname 
					FROM ev_location eloc, eventname evn, bookingstatus bks, location loc
					WHERE eloc.evn_id = evn.evn_id
					AND eloc.bks_id = bks.bks_id
					AND eloc.loc_id = loc.loc_id
					AND ( eloc.eloc_in_date >= $in_date  AND eloc.eloc_in_date <= $out_date
					 OR ( eloc.eloc_event_date >= $in_date  AND eloc.eloc_event_date <= $out_date )
					 OR ( eloc.eloc_end_date >= $in_date  AND eloc.eloc_end_date <= $out_date )
					 OR ( eloc.eloc_out_date >= $in_date  AND eloc.eloc_out_date <= $out_date )	)
					ORDER BY  loc.loc_shortname
					";		
		//echo "$query<hr>";
		//exit();		
		$rs_dup = getData($query);	

		#Input value in view dateblock		
		$query = "SELECT `edbk_item`,`edbk_in_date`,`edbk_in_time`,`edbk_ev_begdate`,
					`edbk_ev_begtime`,`edbk_ev_enddate`,`edbk_ev_endtime`,`edbk_out_date`,
					`edbk_out_time`
					FROM `ev_dateblock` 
					WHERE evn_id = '$evn_id' ";
		//echo "$query";
		$rs_edbk = getData($query);	
		/*
		$query = " 
					SELECT distinct (eloc.loc_id), loc.loc_shortname				
					FROM ev_location eloc, location loc, `ev_dateblock`  edbk
					WHERE  eloc.loc_id = loc.loc_id
					AND  edbk.evn_id = '$evn_id'
					AND edbk.edbk_item = '$edbk_item'				
					
					ORDER BY loc.loc_shortname 
					";
		echo "$query";
		$rs_dup = getData($query);	
		//exit();
	*/	
	} //if(!empty($ev_id)){	
?>
	
<html>
<head>
<title>edbk_updForm.php</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">
<script type="text/javascript">
	function move(fbox, tbox) {
		 var arrFbox = new Array();
		 var arrTbox = new Array();
		 var arrLookup = new Array();
		 var i;
		 for(i=0; i<tbox.options.length; i++) {
			  arrLookup[tbox.options[i].text] = tbox.options[i].value;
			  arrTbox[i] = tbox.options[i].text;
		 }
		 var fLength = 0;
		 var tLength = arrTbox.length
		 for(i=0; i<fbox.options.length; i++) {
			  arrLookup[fbox.options[i].text] = fbox.options[i].value;
			  if(fbox.options[i].selected && fbox.options[i].value != "") {
				   arrTbox[tLength] = fbox.options[i].text;
				   tLength++;
			  } else {
				   arrFbox[fLength] = fbox.options[i].text;
				   fLength++;
			  }
		 }
		 arrFbox.sort();
		 arrTbox.sort();
		 fbox.length = 0;
		 tbox.length = 0;
		 var c;
		 for(c=0; c<arrFbox.length; c++) {
			  var no = new Option();
			  no.value = arrLookup[arrFbox[c]];
			  no.text = arrFbox[c];
			  fbox[c] = no;
		 }
		 for(c=0; c<arrTbox.length; c++) {
			var no = new Option();
			no.value = arrLookup[arrTbox[c]];
			no.text = arrTbox[c];
			tbox[c] = no;
		 }
	}
	
	function selectAll(tbox) {
		var arrLoc = new Array();
		 for(var i=0; i<tbox.length; i++) {
		 //tbox[i].selected = true;
		 arrLoc[i] = tbox[i].value;		  
		 }
		 document.frm.hd_loc_id.value = arrLoc ;		
	}
	
	function chkdup(loc_name) {
		//alert(loc_name);
		var evn_id = document.frm.id.value ;
		//alert(evn_id);
		var edbk_item = document.frm.id2.value ;
		//alert(edbk_item);
		var chkname;
		var chkid ;
		var i , j ;
		j = document.frm.dup_name.length;
		//alert(j);
		if(j){ 
			for(i=0; i < j; i++) {
				chkname = document.frm.dup_name[i].value;					
				if (chkname == loc_name){
					//alert ("Duplicate");
					chkid = document.frm.dup_id[i].value;				
					Winopen(chkid,evn_id,edbk_item);
				} // if (chkname == loc_name){
			}//for(i=0; i<chkname.options.length; i++) {				
		} // if(j){
	}
	
	function Winopen(loc_id,evn_id,edbk_item) {
		//alert(evn_id);
		var url = "show_duplicate.php" ;
		var msg ;
		url += "?loc_id=" + loc_id+ "&id=" + evn_id + "&id2=" + edbk_item ;
		msq = open(url,"DisplayWindow","toolbar=no,directories=no,menubar=no,scrollbars=yes,resize=no,width=700,hight=200");
		//,width=500,hight=400
	}
	
</script>
</head>
<body>
<form name="frm" method="post" action="edbk_updForm.php">
  <table border="0" cellpadding="1" cellspacing="1" class="BorderGreen" >
    <tr><td class="mandatory" colspan=10><?=$sysName ." - ". $evn_id ." - ". $evn_name ;?>&nbsp;&nbsp; 
		<input name="id" type="hidden" id="id" value="<?=$evn_id?>">
      	<input name="id2" type="hidden" id="id2" value="<?=$edbk_item?>" >
	</td>
	</tr>
    <tr style="background-color: #339900; color: White;">
    <td  font-weight:bold;><div align="center"></div></td>
	<td  font-weight:bold;>#</td>
    <td  font-weight:bold;>In Date </td>
    <td  font-weight:bold;>In Time </td>
    <td  font-weight:bold;>Event Date </td>
    <td  font-weight:bold;>Beg Time </td>
    <td  font-weight:bold;>Last Date </td>
    <td  font-weight:bold;>End Time </td>
    <td  font-weight:bold;>Out Date </td>
    <td  font-weight:bold;>Out Time </td>
	</tr>
	<?
		while($row=mysql_fetch_array($rs_edbk)){ 
			if ($color == "#F0F0F0")
				$color = "#FFFFFF" ;
			else
				$color = "#F0F0F0" ;			
				
				$item = $row[0];
				$in_date = chgDate($row[1]);
				$in_time = chgTime($row[2]);
				$evn_date =chgDate($row[3]);
				$beg_time = chgTime($row[4]);
				$last_date =chgDate($row[5]);
				$end_time = chgTime($row[6]);
				$out_date = chgDate($row[7]);
				$out_time = chgTime($row[8]);											
	?>
	<tr bgcolor='<?=$color?>' >
	  	<td><a href="dbk_updForm.php?a=u&id=<?=$evn_id;?>&id2=<?=$item;?>">
			<img src='images/b_edit.png' alt='Update' border='0'></a>
		</td>
		<a href="edbk_viewForm.php?id=<?=$evn_id;?>&id2=<?=$item?>">
		<td><a href="edbk_viewForm.php?id=<?=$evn_id;?>&id2=<?=$item?>"><?=$item;?></td></a>		
		<td><?=$in_date;?></td>		
		<td><?=$in_time;?></td>		
		<td><?=$evn_date;?></td>		
		<td><?=$beg_time;?></td>		
		<td><?=$last_date;?></td>		
		<td><?=$end_time;?></td>		
		<td><?=$out_date;?></td>		
		<td><?=$out_time;?></td>		
		</a>
    </tr>
	<? 
		} //while($row=mysql_fetch_array($result)){ 
		$count_dup = mysql_num_rows($rs_dup);
		while ($dup = mysql_fetch_array($rs_dup)){
			echo '<input name="dup_id" type="hidden" id="dup_id"  value = "'.$dup[0].'" >';	
			echo '<input name="dup_name" type= "hidden" id="dup_name" value= "'.$dup[1] .'">';	
		}	//while ($rs_dup = mysql_fetch_array($result){
		
	?>	
  </table>
  
  <br>
  <input name="Button" type="button" class="Button_dateblock" value="Add Date block"  onClick="window.location= 'dbk_updForm.php?a=a&id=<?=$evn_id?>' ;">  
  <br>
  <br>
  <table border="0" cellpadding="0" cellspacing="4" class="BorderGreen">
    <tr>
      <td height="25" colspan="3" ><div align="center"># <?=$edbk_item;?>
       - DblClick location from 'Choose' to 'Selected' </div></td>
    </tr>
    <tr class="mandatory">
      <td style="background-color: #339900; color: White;">
	  	<div align="center">Choose</div>
	  </td>
      <td align="center" valign="middle">&nbsp;</td>
      <td style="background-color: #339900; color: White;">
	 	 <div align="center">Selected</div>
	  </td>
    </tr>
    <tr>
      <td rowspan="2"  class="mandatory">
		<span class="style1">
		<?
			if(isset($evn_id) && isset($edbk_item)){
				$sql = "SELECT loc_id FROM ev_dateblock  WHERE evn_id = '$evn_id' 
							AND edbk_item = '$edbk_item' ";
				//echo "$sql<hr>";
				$result = getData($sql);
				$rs_dateblock = mysql_fetch_array($result);
				//echo "cnt_edbk=$cnt_edbk<br>";
				$sql = "SELECT loc.loc_id, loc.loc_shortname, loc.loc_fullname	FROM location loc";
				if ($rs_dateblock[0])
					$sql .= 	" WHERE loc.loc_id not in (" .$rs_dateblock[0].")";
					$sql.=  " ORDER BY loc.loc_shortname ";
				//echo "$sql<hr>";				
				$rs_loc = getData($sql);				
					/*
					while ($row = mysql_fetch_array($rs_loc)){
						$locID = $row[0]; $locName = $row[1];
						echo "\$locID=$locID,\$locName=$locName<br>";				
					} //while ($row = mysql_fetch_array($rs_loc)){
				   */
			}
		?>
        <select name="list1" size="10" multiple  style="width:200"  
		onDblClick="move(document.frm.list1,document.frm.list2)"  
		<?
			if($count_dup){
		?>
			onChange="chkdup(document.frm.list1.options(selectedIndex).text)">
		  <?
		   } // if($count_dup)
			while ($row = mysql_fetch_array($rs_loc)){
				$locID = $row[0]; 
				$locName = $row[1];
				echo "<javascript>alert(".$locName.");</javascript>";
				echo "<option value=".$locID.">".$locName."</option>";		
				$loc_id .= $locID.",";
			}
			$loc_id = substr($loc_id,0,strlen($loc_id) -1);
		?>
        </select>
        </span></td>
      <td height="83" align="center" valign="middle">
        <input name=button2 type="button" class="Button" id=button2 onClick="move(this.form.list1,this.form.list2)" value="-->">
      </td>
      <td rowspan="2" class="mandatory">
	  <span class="style1">
	  <?
			$sql = "SELECT loc.loc_id, loc.loc_shortname, loc.loc_fullname	FROM location loc";
			if ($loc_id){
				$sql .= 	" WHERE loc.loc_id not in (" .$loc_id.")";
			}
			$sql .=  " ORDER BY loc.loc_shortname ";
			//echo "$sql<hr>";				
			$rs_eloc = getData($sql);				
	  ?>
        <select name="list2" size="10" multiple style="width:200" 
		onDblClick="move(document.frm.list2,document.frm.list1)">
	      <?			
			while ($row = mysql_fetch_array($rs_eloc)){
				echo "<option value=".$row[0].">".$row[1]."</option>";				
			}
		?>
        </select>
       </span></td>
    </tr>
    <tr>
      <td height="75" align="center" valign="middle"><input name=button1 type="button" class="Button" id=button12 onClick="move(this.form.list2,this.form.list1)" value="<--"></td>
    </tr>
    <tr>
      <td height="35" colspan="3" align="center"><input name="Submit2" type="button" class="Button" value="&lt;= Back " onClick="window.location = 'esta_updForm.php?id=<?=$evn_id?>'" >
        <input name="Submit" type="submit" class="Button" value="   OK   "  <?=$disabled;?> 	onClick="selectAll(document.frm.list2);" >
        <input name="Button2" type="button" class="Button" id="Button"  onClick="history.go(-1)" value="Cancel" >
		<?php 
			if( $bk18 == "Yes" ){ // By Kae
				$link = "ecus_updForm2.php?id=$evn_id";
			}else{
				$link = "ecus_updForm.php?id=$evn_id";
			}
		?>
        <input name="Submit22" type="button" class="Button" value="Next =&gt;" onClick="window.location = '<?=$link?>'" >
        <input name="hd_loc_id" type="hidden" id="hd_loc_id">
	  </td>
    </tr>
  </table>
</form>
<?
include("db/disconnect.db.php");	
?>