<?
	ob_start(); 
	session_start();
	include "ql/inc/config.php";
	include "ql/inc/auth.php";
	include "ql/inc/function.php";
?>
<html>
<head>
<script>
<!--

/*By JavaScript Kit
http://javascriptkit.com
Credit MUST stay intact for use
*/

function show2(){
if (!document.all&&!document.getElementById)
return
thelement=document.getElementById? document.getElementById("tick2"): document.all.tick2
var Digital=new Date()

var year=Digital.getYear()
if (year < 1000)
year+=1900
var day=Digital.getDay()
var month=Digital.getMonth()
var daym=Digital.getDate()
if (daym<10)
daym="0"+daym
var dayarray=new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday")
var montharray=new Array("January","February","March","April","May","June","July","August","September","October","November","December")

var hours=Digital.getHours()
var minutes=Digital.getMinutes()
var seconds=Digital.getSeconds()
var dn="PM"
if (hours<12)
dn="AM"
if (hours>12)
hours=hours-12
if (hours==0)
hours=12
if (minutes<=9)
minutes="0"+minutes
if (seconds<=9)
seconds="0"+seconds
var cdate = dayarray[day]+", "+daym+" - "+ montharray[month]+" - "+ year
var ctime=hours+":"+minutes+":"+seconds+" "+dn
thelement.innerHTML="<b style='font-size:9;color:#339900;'>"+ " [ "+cdate + "  : "+ctime+" ] </b>"
setTimeout("show2()",1000)
}
window.onload=show2
//-->
</script>


	<title>Style 02 (Dark Olive Green) - Menu by Apycom.com</title>	
	<link rel="stylesheet" href="css/format.css.css" type="text/css">
	<link rel='StyleSheet' href='ql/css/style.css'>
	
    <link type="text/css" href="menu/menu.css" rel="stylesheet" />
    <script type="text/javascript" src="menu/jquery.js"></script>
    <script type="text/javascript" src="menu/menu.js"></script>
	

<meta http-equiv="Content-Type" content="text/html; charset=utf-8"><style type="text/css">

<!--
body {
	background-color: #FFFFFF;
}
div#menu {
    margin:30px auto;
    width:80%;
}

-->
</style>


</head>

<body style="margin-left:0px;">
<table width="99%" border="0" cellpadding='0' cellspacing='0' align='center'>
<tr>
	<td><img src='ql/img/j_header_left.png'></td>
	<td background='ql/img/j_header_middle.png' width='50%' valign='middle' class='title'><?=APP_NAME?></td>
	<td background='ql/img/j_header_middle.png' width='50%' valign='middle'  align='right' class='title_right'>
	<span  id=tick2></span>&nbsp;user : <?=$_SESSION["usr_name"]; ?></td>
	<td><img src='ql/img/j_header_right.png'></td>
</tr>
</table>
<table width="99%"  >
	<tr style="color:#339900; font-weight:bold;" >
		<td >
		<div id="menu" >
			<ul class="menu">
				<li><a href="fra_booking.php" target="main_Frame" class="parent"><span>Booking<span class="subtext">Booking</span></span></a></li>
				<li><a href="#"><span>Calendar<span class="subtext">ԷԹ</span></span></a></li>
				<li><a href="fra_maintenance.php" target="main_Frame"><span>Master<span class="subtext">ѡ</span></span></a></li>
				<li><a href="signout.php" target="_parent"><span>Logout<span class="subtext">͡</span></span></a></li>
			</ul>
		</div>		
		</td>
	</tr>
</table>
<div id="copyright">Copyright &copy; 1998-2010 <a href="http://apycom.com/">Apycom</a> (menus)</div>
<br>
</body>
</html>