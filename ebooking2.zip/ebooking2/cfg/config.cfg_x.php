<?
	define("progname",progname);
	define("version",version);
	define("dbname",dbname);
	define("hostname",hostname);
	define("username",username);
	define("password",password);
	
	define("bchEname",bchEname);
	define("bchTname",bchTname);

?>