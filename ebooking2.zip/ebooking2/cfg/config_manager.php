<?
	define("progname","Thebook System");
	define("version","1.8");	
	
	session_start();
	$site=$_SESSION["site"];
	
	switch ($site) {
	case "tspc":
		echo "i equals 0";
		break;
	case "gjc":
		echo "i equals 1";
		break;
	case "psuic":
		echo "i equals 2";
		break;
	default:
		define("dbname","test");
		define("hostname","localhost");
		define("username","thebook");
		define("password","thebook");
		
		define("bchEname","Golden Jubilee Convention Center (GJC)");
		define("bchTname","ศูนย์ประชุมอเนกประสงค์กาญจนาภิเษก");	
		 
	}

?>