<?php
	error_reporting(E_ALL ^E_NOTICE ^E_WARNING ^ E_DEPRECATED);
	if(!isset($_SESSION)){
		ob_start();  
		session_start();
	}//if(!isset($_SESSION)){
		
	define("progname","Thebook System");
	define("version","1.8");	
	define("hostname","8192.168.1.199:3333"); 
	//define("hostname","xxx_mysql");	
	define("dbtype","mysql");
	$_SESSION["lang"]==""?$_SESSION["lang"]="th":0;
	//define("prefix",$site);
	
	
	$site=$_SESSION["site"];	
	if($site==""){
		$site="ebooking";
		$_SESSION["site"]=$site;
	}
	
	define("prefix",$site);
	
	switch ($site) {
	case "tspc":
		define("dbname","booking18_tspc");
		define("username","thebook");
		define("password","thebook");		
		define("bchEname","Thailand Science Park Convention Center");
		define("bchTname","ศูนย์ประชุมอุทยานวิทยาศาสตร์ประเทศไทย");		
		define("rpt_set_eloc","rpt_set_eloc.php");
		break;
	case "gjc":
		define("dbname","booking18_gjc");
		define("username","thebook");
		define("password","thebook");		
		define("bchEname","Golden Jubilee Convention Center (GJC)");
		define("bchTname","ศูนย์ประชุมอเนกประสงค์กาญจนาภิเษก");	
		define("rpt_set_eloc","rpt_set_eloc_novat.php");
		define("default_begin_month" , "01");
		define("default_end_month" , "12");
		break;
	case "psu":
		define("dbname","booking18_psu");
		define("username","appteam");
		define("password","app2010");		
		define("bchEname","The 60th Anniversary of His Majesty The King's Accession to the Throne International Convention Center");
		define("bchTname","ศูนย์ประชุมนานาชาติฉลองสิริราชสมบัติครบ 60 ปี");	
		define("rpt_set_eloc","rpt_set_eloc.php");
		define("default_begin_month" , "10");
		define("default_end_month" , "09");
		break;
	default:
		// define("hostname","ass.in.th");
		// define("dbname","assinth_ors");   //ebooking
		// define("username","assinth_ors");  //appteam
		// define("password","assinthors");  //app2010

		define("dbname","1ncc_ebk");  
		define("username","appteam");  
		define("password","app2010"); 

		define("bchEname","Samyan Mitrtown ");
		define("bchTname","สามย่านมิตรทาวน์");	
		define("rpt_set_eloc","rpt_set_eloc.php");
		define("default_begin_month" , "10");
		define("default_end_month" , "09");	
	}

?>