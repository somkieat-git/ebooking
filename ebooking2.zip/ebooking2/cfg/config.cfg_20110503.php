<?
	//ob_start();
	session_start();
	define("progname","Thebook System");
	define("version","1.8");	
	define("hostname","localhost");
	define("dbtype","mysql");
	$_SESSION["lang"]==""?$_SESSION["lang"]="th":0;
	//define("prefix",$site);
	
	
	$site=$_SESSION["site"];	
	if($site==""){
		$site="gjc";
		$_SESSION["site"]=$site;
	}
	
	define("prefix",$site);
	
	switch ($site) {
	case "tspc":
		define("dbname","booking_tspc");
		define("username","thebook");
		define("password","thebook");		
		define("bchEname","Thailand Science Park Convention Center");
		define("bchTname","ศูนย์ประชุมอุทยานวิทยาศาสตร์ประเทศไทย");		
		define("rpt_set_eloc","rpt_set_eloc.php");
		break;
	case "gjc":
		define("dbname","booking_gjc");
		define("username","thebook");
		define("password","thebook");		
		define("bchEname","Golden Jubilee Convention Center (GJC)");
		define("bchTname","ศูนย์ประชุมอเนกประสงค์กาญจนาภิเษก");	
		define("rpt_set_eloc","rpt_set_eloc_novat.php");
		break;
	case "psu":
		define("dbname","booking_psu");
		define("username","thebook");
		define("password","thebook");		
		define("bchEname","The 60th Anniversary of His Majesty The King's Accession to the Throne International Convention Center");
		define("bchTname","ศูนย์ประชุมนานาชาติฉลองสิริราชสมบัติครบ 60 ปี");	
		define("rpt_set_eloc","rpt_set_eloc.php");
		break;
	default:
		define("dbname","test");
		define("username","thebook");
		define("password","thebook");		
		define("bchEname","Golden Jubilee Convention Center (GJC)");
		define("bchTname","ศูนย์ประชุมอเนกประสงค์กาญจนาภิเษก");
		define("rpt_set_eloc","rpt_set_eloc.php");
	}

?>