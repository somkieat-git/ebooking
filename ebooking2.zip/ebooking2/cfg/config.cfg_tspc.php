<?
	define("progname","Thebook System");
	define("version","1.8");
	define("dbname","thebook_tspc");
	define("hostname","localhost");
	define("username","thebook");
	define("password","thebook");
	
	define("bchEname","Thailand Science Park Convention Center");
	define("bchTname","ศูนย์ประชุมอุทยานวิทยาศาสตร์ประเทศไทย");
	
?>