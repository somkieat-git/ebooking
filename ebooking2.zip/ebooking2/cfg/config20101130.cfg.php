<?
	define("progname","Thebook System");
	define("version","1.6");	
	define("hostname","localhost");
	
	session_start();
	$site=$_SESSION["site"];	
	if($site==""){
		$site="gjc";
		$_SESSION["site"]=$site;
	}
	
	switch ($site) {
	case "tspc":
		define("dbname","thebook_tspc");
		define("username","thebook");
		define("password","thebook");		
		define("bchEname","Thailand Science Park Convention Center");
		define("bchTname","ศูนย์ประชุมอุทยานวิทยาศาสตร์ประเทศไทย");		
		define("rpt_set_eloc","rpt_set_eloc.php");		
		break;
	case "gjc":
		define("dbname","thebook_gjc");
		define("username","thebook");
		define("password","thebook");		
		define("bchEname","Golden Jubilee Convention Center (GJC)");
		define("bchTname","ศูนย์ประชุมอเนกประสงค์กาญจนาภิเษก");	
		define("rpt_set_eloc","rpt_set_eloc_novat.php");
		break;
	case "psu":
		define("dbname","thebook_psu");
		define("username","thebook");
		define("password","thebook");		
		define("bchEname","The 60th Anniversary of His Majesty The King's Accession to the Throne International Convention Center");
		define("bchTname","ศูนย์ประชุมนานาชาติฉลองสิริราชสมบัติครบ 60 ปี");	
		define("rpt_set_eloc","rpt_set_eloc.php");
		break;
	default:
		define("dbname","test");
		define("username","thebook");
		define("password","thebook");		
		define("bchEname","Golden Jubilee Convention Center (GJC)");
		define("bchTname","ศูนย์ประชุมอเนกประสงค์กาญจนาภิเษก");
		define("rpt_set_eloc","rpt_set_eloc.php");
	}

?>