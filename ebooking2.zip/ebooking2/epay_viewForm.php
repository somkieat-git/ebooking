<?
	ob_start(); 
	session_start();
	include("db/chksession.db.php");
	$evn_id = $_REQUEST["id"];
	define("sysName","Event Payment");
	define("tableName","pay_adj");
	$type = "pay";
	define("viewForm","epay_viewForm.php");
	define("updForm","epay_updForm.php");	
	define("addForm","epay_updForm.php");	
	define("field_id","pay_id");	
	define("beg_id",1);	
	define("end_id",8);		
	
	$sql = "SELECT pad.pay_id, stt.stt_name,
			pad.str1, pad.str2, pad.tran_date, 
			pad.exc_vat, pad.vat, pad.inc_vat ,
			pad.remark
			FROM settle_cat as stt, pay_adj as pad
			WHERE stt.stt_id = pad.stt_id
			AND pad.evn_id = '$evn_id' 
			AND type = '$type'
			ORDER BY pad.tran_date
	";
	//echo "$sql"; exit();
	define("query","$sql");
		
	$cap_name = array();
	$cap_name = array("#","Settlement Category","Reason for Payment","Payment Control Number","Payment Date","Exc.Vat","Vat","Inc.Vat","Remark");
	
	//=============check authorize================
	$key = array_keys($_SESSION["sec_add"], viewForm); 
	if($key[0])
		define("insert",1);		
	else
		define("insert",0);			
		
	$key = array_keys($_SESSION["sec_edit"], viewForm); 
	if($key[0])
		define("edit",1);		
	else
		define("edit",0);			
		
	$key = array_keys($_SESSION["sec_del"], viewForm); 
	if($key[0])
		define("del",1);		
	else
		define("del",0);			
		
	include("func/ev_viewForm.func1.php");
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</body>
</html>
