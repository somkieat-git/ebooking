<?	
	if(!isset($_SESSION)){
		ob_start();  
		session_start();
	}//if(!isset($_SESSION)){
		
	//include("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	define("updSave","dpd_viewForm.php");
	$sysName = "Dailyperday ";
	//$evn_id = '06010004';
	$evn_id = $_REQUEST["id"];
	$dpd_id = $_REQUEST["id2"];	
		if(empty($dpd_id)) $dpd_id = 1 ;
	$Submit = $_REQUEST["Submit"];	
	//echo "dpd_id = $dpd_id<br>Submit = $Submit<br>";
	
		if(!empty($evn_id)){
			$sql = "SELECT * FROM eventname WHERE evn_id = '$evn_id'  ";
			//echo "$sql<br>";
			//exit();
			$result = getData($sql);
			$row = mysql_fetch_array($result);
			//echo "<pre>"; print_r($row);
			$disabled = "";
			if($row["evn_used"] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;
			$evn_name = $row["evn_shortname"];
		} //if(!empty($ev_id)){	
	
	#Input value in view dailyperday
	$sql = "SELECT * FROM dailyperday WHERE dpd_code <> '0' ";
	$rs_dpd = getData($sql);
		
?>
	
<html>
<head>
<title>dpd_viewForm.php</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">
</head>
<body>
<form name="frm" method="post" action="dpd_viewForm.php?id=<?=$evn_id?>&id2=<?=$dpd_id?>">
  <table border="0" cellpadding="1" cellspacing="1" class="BorderGreen" >
    <tr>
	  <td colspan="4" class="mandatory"><div align="center"><?=$sysName ;?> - <?=$evn_id." - " .$evn_name ?></div>
	  </td>
    </tr>
    <tr style="background-color: #339900; color: White;">
    <td  font-weight:bold;></td>
	<td  font-weight:bold;>#</td>
    <td  font-weight:bold;>Code</td>
    <td  font-weight:bold;>Name</td>
    </tr>
	<?
		while($row=mysql_fetch_array($rs_dpd)) { 
			if ($color == "#F0F0F0")
				$color = "#FFFFFF" ;
			else
				$color = "#F0F0F0" ;			
				
				$id = $row["dpd_id"];
				$dpd_code = $row["dpd_code"];
				$dpd_name = $row["dpd_name"];
	?>
	<tr bgcolor="<?=$color?>" >
	  	<td><a href="dpd_updForm.php?a=u&id=<?=$id?>"><img src='images/b_edit.png' alt='Update' border='0'></a></td>
		<a href="dpd_viewForm.php?id=<?=$evn_id?>&id2=<?=$id?>">
		<td><?=$id;?></td>		
		<td><a href="dpd_viewForm.php?id=<?=$evn_id?>&id2=<?=$id?>"><?=$dpd_code;?></a></td>		
		<td><?=$dpd_name;?></td>		
		</a>
    </tr>
	<? 
		} //while($row=mysql_fetch_array($result)){ 
	?>	
  </table>  
  <br>
  <input name="Button" type="button" class="Button_dateblock" value="Add Daily Event" onClick="window.location= 'dpd_updForm.php?a=a&id2=<?=$dpd_id?>' ;">
  <br>
  <br>
  
  <?
  	if(empty($dpd_id)){
		exit();
	}		
	$sql = "SELECT edbk_ev_begdate ,edbk_ev_enddate ,edbk_item 
					FROM ev_dateblock 
					WHERE  evn_id = $evn_id  
					AND edbk_item = 0
					 ";
		//echo "$sql<br>";	
		$result = getData($sql);
		$rs_edbk = mysql_fetch_array($result);
		$numrow = mysql_num_rows($result);

		$dd=substr($rs_edbk["edbk_ev_begdate"],6,2);
		$mm=substr($rs_edbk["edbk_ev_begdate"],4,2);
		$yy=substr($rs_edbk["edbk_ev_begdate"],0,4);
		$day=$rs_edbk["edbk_ev_enddate"]-$rs_edbk["edbk_ev_begdate"];
	
		$sql = "SELECT * 
					FROM ev_dailyperday  
					WHERE evn_id = $evn_id  
					AND dpd_id = $dpd_id";
		//echo "$sql<br>";
		$result = getData($sql);
		$numrow = mysql_num_rows($result);
		if ($numrow==0){
			#insert data to ev_dailyperday
			$action = "a";
			$arr_edpd=array();
		}//if ($numrow==0){
		else{
			#show data from ev_dailyperday
			$action = "e";
			$arr_edpd = array();
			$i = $dd;
			while($rs_edpd = mysql_fetch_array($result)){
				$arr_edpd[$i] = $rs_edpd["edpd_date"].",".$rs_edpd["edpd_person"];
				$i++;
			}	//while($rs_edpd = mysql_fetch_array($result)){
		}		
		$sql = "SELECT dpd_code, dpd_name FROM dailyperday WHERE dpd_code <> '0' 
					AND dpd_id = $dpd_id";
		$rs_dpd = getData($sql);
		$row=mysql_fetch_array($rs_dpd);
		$dpd_name = $row["dpd_code"]." - ".$row["dpd_name"];
	
  ?>  
  <table border="0" cellpadding="0" cellspacing="0" class="BorderGreen">
    <tr>
	  <td height="26" colspan="5" class="mandatory"><div align="center">Sub 
	    <?=$sysName ;?> 
	    of :  <?=$dpd_name?></div></td>
    </tr>
    <tr>
      <td height="22" style="background-color: #339900; color: White;"><div align="left">Day</div></td>
      <td style="background-color: #339900; color: White;"><div align="left">Date</div></td>
      <td colspan="2" style="background-color: #339900; color: White;"><div align="left">Attendance / Person 's Name </div>        <div align="left"></div></td>
    </tr>
	<?
		for($date=$dd; $date<=($dd+$day); $date++){ 				
				$showweek = date("l", mktime(0, 0, 0, $mm,$date,$yy));
				$showdate = date("d/m/Y", mktime(0, 0, 0, $mm,$date,$yy));
				$valdate = date("Ymd", mktime(0, 0, 0, $mm,$date,$yy)); 
				
				if ($color == "#F0F0F0")
					$color = "#FFFFFF" ;
				else
					$color = "#F0F0F0" ;			
	?>
    <tr bgcolor="<?=$color?>">
      <td><input name="edpd_day[]" type="text" id="edpd_day[]" size="15" maxlength="15" value="<?=$showweek?>"  readonly >
	  <input name="edpd_id[]" type="hidden" value="<?=edpd_id?>"></td>
      <td><input name="edpd_date[]" type="text" id="edpd_date[]" size="15" maxlength="15" value="<?=$showdate?>"  readonly >
	  <input name="hd_date[]" type="hidden" value="<?=$valdate?>"></td>
      <td><input name="edpd_person[]" type="text" id="edpd_person[]" size="35" maxlength="35" value="<?
		  list($a,$b)=explode(",",$arr_edpd[$date]);
			 if($a==$valdate) echo $b; else echo 0;	 
		  ?>" >
		</td>
    </tr>
	<? 
		} 	//for($date=$dd; $date<($dd+$txtScroll); $date++)
	?>
    <tr>
      <td height="35" colspan="6" align="center">        
			<input name="Submit2" type="button" class="Button" value="&lt;= Back " onClick="window.location = 'eckl_viewForm.php?id=<?=$evn_id?>'" >
			<input name="Submit" type="submit" class="Button" value="   OK   "  <?=$disabled ;?> >
			<input name="Button2" type="button" class="Button" id="Button" onClick="history.go(-1)"  value="Cancel" >
			<input name="Submit22" type="button" class="Button" value="Next =&gt;" onClick="window.location = 'esch_viewForm.php?id=<?=$evn_id?>'" >		  
	  </td>
    </tr>
  </table>
  <?
	#begin Save data
	if ($Submit){			
		$dpd_id = $_REQUEST["id2"];
		$evn_id =$_REQUEST["id"];
		$edpd_date = $_REQUEST["edpd_date"];
		$val_date = $_REQUEST["hd_date"];
		$edpd_person =  $_REQUEST["edpd_person"];
		$usr_upd = $_SESSION["usr_name"];
		$date_upd = date("Y/m/d  H:i:s");		
		
		/*
		$edpd_date =  implode(",",$_REQUEST["edpd_date"]);
		$val_date =  implode(",",$_REQUEST["hd_date"]);
		$edpd_person =  implode(",",$_REQUEST["edpd_person"]);		
		
		echo "dpd_id = $dpd_id<br>evn_id = $evn_id<br>edpd_date = $edpd_date<br>val_date=$val_date<br>edpd_person = $edpd_person<hr>";
		echo "action = $action<br>";
		//exit();
		*/
		
		if($action =="a"){
				$usr_cre = $_SESSION["usr_name"];
				$date_cre = date("Y/m/d  H:i:s");		
			//	for ($a=0;$a<count($day);$a++){
				
			for($date=$dd,$i=0; $date<=($dd+$day),$i<count($val_date); $date++,$i++){ 	
					$showweek = date("l", mktime(0, 0, 0, $mm,$date,$yy));
					$showdate = date("d/m/Y", mktime(0, 0, 0, $mm,$date,$yy));
					$valdate = date("Ymd", mktime(0, 0, 0, $mm,$date,$yy)); 
					$val = $val_date[$i];
					$person = $edpd_person[$i];
				
					$sql = "INSERT INTO ev_dailyperday(dpd_id, evn_id, edpd_date, edpd_person, usr_cre,date_cre) ";
					$sql.="	VALUES($dpd_id, '$evn_id', '$val','$person','$usr_cre', '$date_cre')" ;								
					//echo "$sql<br>";		
					mysql_query($sql) or die("Insert error");	
					$SaveLog=updLog($_SESSION['username'], updSave, "$sql");	
				}	//for ($i=0;$i<count($val_date);$i++){		
				//Show alert by javascript
				echo "<script>
					alert ('Insert complete');
					window.location = 'dpd_viewForm.php?id=$evn_id&id2=$dpd_id' ;
				  </script>";
				exit();									
			}	//	if($action =="a"){
	
		if($action=="e"){
		for ($i=0;$i<count($val_date);$i++){		
				$sql = "UPDATE `ev_dailyperday`  SET ";
				$sql.= " edpd_person = '$edpd_person[$i]',";
				$sql.= " usr_upd = '$usr_upd',";
				$sql.= " date_upd = '$date_upd'";
				$sql.= " WHERE dpd_id = $dpd_id ";
				$sql.= " AND evn_id = '$evn_id'";
				$sql.= " AND edpd_date = '$val_date[$i]'";
				//echo "[$i] = $sql<br>";		
				mysql_query($sql) or die("Update error !");				
				$SaveLog=updLog($_SESSION['username'], updSave, "$sql");
			}	//for ($i=0;$i<count($val_date);$i++){						
			//exit();
		
		
		//Show alert by javascript
		echo "<script>
				alert ('Update complete');
				window.location = 'dpd_viewForm.php?id=$evn_id&id2=$dpd_id' ;
			  </script>";
		exit();					
		} //if($action=="e"){
		
	}   //if ($Submit){
	include("db/disconnect.db.php");	
  ?>
</form>
