function addOption()
{
tf=false;
ind=document.frm.event_contact.selectedIndex;
text=document.frm.event_contact.options[ind].text;
optionA=new Option(text, frm.event_contact_list.length);
for(Some=0;Some<frm.event_contact_list.length;Some++){
	if(document.frm.event_contact_list.options[Some].text==optionA.text){tf=true;}
}
if(tf==false){
//eval("frm.event_contact_list.options[frm.event_contact_list.length]=optionA");
document.frm.event_contact_list.options.add(optionA);
hidd=document.getElementById('sel_list');
hidd.value+=text+",";
if(hidd.value=="NaN"){hidd.value="";}
document.frm.event_contact.options.remove(ind);}
}

function removeOption()
{
tf=false;
ind=document.frm.event_contact_list.selectedIndex;
text=document.frm.event_contact_list.options[ind].text;
optionA=new Option(text, frm.event_contact.length);
for(Some=0;Some<frm.event_contact.length;Some++){
	if(document.frm.event_contact.options[Some].text==optionA.text){tf=true;}
}
if(tf==false){
document.frm.event_contact.options.add(optionA);
//eval("frm.event_contact.options[frm.event_contact.length]=optionA");
}
hidd=document.getElementById('sel_list');

posit=hidd.value.indexOf(text);
leng=text.length;
negat=posit+leng;
first=hidd.value.substring (0,posit);
end=hidd.value.substring (negat+1,hidd.value.length);
if(hidd.value=="NaN"){hidd.value="";}
hidd.value=first+end;

document.frm.event_contact_list.options.remove(ind);
}

//document.frm.event_contact_list
//add_btn  //addOption()
//del_btn  //removeOption()
//document.frm.event_contact   10 7 3