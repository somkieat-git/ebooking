function clockJAVA() {
if (!document.layers && !document.all) return;
var digital = new Date();
var days = digital.getDate();
var month = digital.getMonth()+1;
var year = digital.getYear();
var hours = digital.getHours();
var minutes = digital.getMinutes();
var seconds = digital.getSeconds();
var amOrPm = "";
<!--VAR=[AmPmFunction]-->
if (minutes <= 9) minutes = "0" + minutes;
if (seconds <= 9) seconds = "0" + seconds;
dispTime = <!--VAR=[DTFORMAT]--> + "&nbsp;/&nbsp;"+hours + ":" + minutes + " "+ amOrPm;
if (document.layers) {
document.layers.pendule.document.write(dispTime);
document.layers.pendule.document.close();
}
else
if (document.all)
pendule.innerHTML = dispTime;
setTimeout("clock()", 1000);
}