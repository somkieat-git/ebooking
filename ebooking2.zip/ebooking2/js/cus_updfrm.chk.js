// JavaScript Document
window.onload = function(){
		showOnLoad();
	}

function btnEnable(){		
	var act = document.forms[0].hddAction.value;		
	act != "d" ? document.forms[0].btnSubmit.disabled = false : 0 ;
} //function btnEnable(){		

function btnDisable(){
	var act = document.forms[0].hddAction.value;		
	act == "d" ? document.forms[0].btnSubmit.disabled = true  : 0 ;		
	//act == "d" ? document.forms[0].btnDelete.disabled = true  : 0 ;		
	document.forms[0].btnSubmit.disabled = true;
} 

function Conf(object){
		if(confirm("ยืนยันต้องการลบ ? \nDo you want to delete ?")== true){			
			var url  = "" ; 
			url =  "<?=$viewFrom ;?>?t=<?=$t ;?>&p=<?=$nsr ;?>&a=d&id=<?=$id ;?>";
			//alert(url);
			window.location =  url  ;
			return true;
		}
		return false;
}

function BrowseAddress(obj,fname,l){
	var fieldN = fname;
	var fieldValue = document.getElementById(obj).value;
	//alert(fieldValue);
	fieldValue = Url.encode(fieldValue); // Encode & Decode Value Thai
	//alert(fieldValue);
	url="address.php?f="+fieldN +"&v="+fieldValue+"&l="+l;
	option = "width=500,height=300,status=no,menubar=no,resizable=no,scrollbars=yes,top=200,left=400" ;
	//alert(url);
	
	window.open(url,"BrowseAddress",option);		

}

function setAddress(obj,l){
//alert(obj);
	var string = obj;
	arrAdd  =  string.split("|");
	tambol = arrAdd[0];
	district = arrAdd[1];
	province = arrAdd[2];
	country = arrAdd[3];
	postcode = arrAdd[4];		
	
	if (l =="th"){
		document.frm.pro_ttambol.value = tambol ;
		document.frm.pro_tdistrict.value = district ;
		document.frm.pro_tprovince.value = province ;
		document.frm.pro_tcountry.value = country ;
		document.frm.pro_tpostcode.value = postcode ;		
	}
	else{
		document.frm.pro_etambol.value = tambol ;
		document.frm.pro_edistrict.value = district ;
		document.frm.pro_eprovince.value = province ;
		document.frm.pro_ecountry.value = country ;
		document.frm.pro_epostcode.value = postcode ;		
	}
} //function setAddress(obj,l){


function birthday (){
	//calculate years of age (input string: YYYY-MM-DD)
	//var birthdate;
	var now = new Date();
	var year_diff; var month_diff; var day_diff;
	var year; var month; var day ; var lang;
	var birthdate; var formatChar = "/";
	birthdate = document.frm.pro_birthdate.value;
	//alert(birthdate);	
    dateVal = birthdate.split(formatChar);
	year = dateVal[2];
	month =  dateVal[1];
	day =  dateVal[0];
	//alert('day = '+day+',month = '+month+',year = '+year);
	//year = document.frm.selYear.value;
	//month =  document.frm.selMonth.value;
	//day =  document.frm.selDay.value;
	//lang = document.frm.pro_lang.value;
	//lang == 'th' ? year-=543: 0;
    year_diff  = now.getFullYear() - year;
    month_diff = (now.getMonth() + 1) - month;
    day_diff   = now.getDate() - day;
	//alert ("day_diff="+day_diff);
	//alert ("month_diff="+month_diff);
	//if ( day_diff < 0 && month_diff = 0) year_diff--;
	if ( month_diff < 0){
		year_diff--;
	}			
	else{
		if(month_diff = 0 || day_diff < 0) year_diff--;
		//alert("else");
	}
		//alert("year_diff="+year_diff);
		document.frm.txtAge.value = year_diff;		
  } //function birthday (birthday){


function comregis (){
	//calculate years of age (input string: YYYY-MM-DD)
	//var birthdate;
	var now = new Date();
	var year_diff; var month_diff; var day_diff;
	var year; var month; var day ; var lang;
	var comregis; var formatChar = "/";
	comregis = document.frm.pro_com_regis.value;
	//alert(comregis);
	alert(comregis);
	dateVal = comregis.split(formatChar);
	year = dateVal[2];
	month =  dateVal[1];
	day =  dateVal[0];
	year_diff  = now.getFullYear() - year;
	month_diff = (now.getMonth() + 1) - month;
	day_diff   = now.getDate() - day;
	if ( month_diff < 0){
		year_diff--;
	}
	else{
		if(month_diff = 0 || day_diff < 0) year_diff--;
		//alert("else");
	}
		//document.frm.txtAge.value = year_diff;
  } //function comregis (comregis){
	  
	  
	  
var p; var p1 ;
function ValidatePhone(){
	p=p1.value;	
	
	el = p1;
	if(p.length==1){
		pp=p;
		d5=p.indexOf('-');		
		if(d5==-1){
			pp=pp+"-";
		}
		el.value = "";
		el.value =pp;
	}
	
	if(p.length>2 ){
		d1=p.indexOf('-');
		//d2=p.indexOf('-',3)
		if (d1==-1){
			l30=p.length;
			p30=p.substring(0,1);
			//alert(p30);
			p30=p30+"-"
			p31=p.substring(7,l30);
			pp=p30+p31;
			//alert(p31);
		el.value = "";
		el.value =pp;
		} //if (d2==-1){
	}
	
	if(p.length>5){
		p10=p.substring(0,6)+"-";
		l11=p.length
		p11=p.substring(7,l11);
			
		pp=p10+p11;
		el.value = "";
		el.value =pp;
	}
	//}
	setTimeout(ValidatePhone,100)
} //function ValidatePhone(){


var m; var m1 ;
function ValidateMobile(){
	m=m1.value;
	el = m1;
	if(m.length==2){
		pp=m;
		d5=m.indexOf('-');		
		if(d5==-1){
			pp=pp+"-";
		}
		el.value = "";
		el.value =pp;
		//document.frm.pro_ttel.value="";
		//document.frm.pro_ttel.value=pp;
	}
	
	if(m.length>3 ){
		d1=m.indexOf('-');
		//d2=p.indexOf('-',3)
		if (d1==-1){
			l30=m.length;
			p30=m.substring(0,1);
			//alert(p30);
			p30=p30+"-"
			p31=m.substring(7,l30);
			pp=p30+p31;
			//alert(p31);
		el.value = "";
		el.value =pp;
		} //if (d2==-1){
	}
	
	if(m.length>6){
		p10=m.substring(0,7)+"-";
		l11=m.length
		p11=m.substring(8,l11);
			
		pp=p10+p11;
		el.value = "";
		el.value =pp;
	}
	//}
	setTimeout(ValidateMobile,100)
} //function ValidateMobile(){

function getIt(obj,type){
	if(type=='t'){
		p1=obj;
		 ValidatePhone();
	}
	
	if(type=='m'){
		m1= obj;
		 ValidateMobile();
	}
}

function displayOccCm(value , occupatCm){
	
	document.getElementById('pro_occupatCm').value = occupatCm ;	
	document.getElementById('div_occ_cm').style.display = "none" ;
	
	if(value == 8){
		document.getElementById("div_occ_cm").style.display = "";
	}else{
		document.getElementById('pro_occupatCm').value = "";
		document.getElementById('div_occ_cm').style.display = "none";
	}
}

function displayChoice(cho_id , que_id , ans_comment){
	//alert(cho_id + " " + que_id);
	
	if(cho_id == 18 || cho_id == 70){
		document.getElementById("txt"+que_id).style.display = "";
		document.getElementById("ans_comments["+que_id+"]").value = ans_comment ;
	}else{
		document.getElementById("ans_comments["+que_id+"]").value = "" ;
		document.getElementById("txt"+que_id).style.display = "none";
	}
}


function showOnLoad(){

	// --------  OccupatCm   -------- //
	var pro_occupatCm = document.getElementById('pro_occupatCm').value;
	if( pro_occupatCm.length > 0 ){
		document.getElementById("div_occ_cm").style.display = "";
	}
	
	// -------  Question   -------- //
	var hddqKey = document.getElementById('hddqKey').value;
	var hddComment = document.getElementById('hddComment').value;
	//alert(hddComment);
	
	var string_k = hddqKey;
	arrqKey  =  string_k.split("|");
	//alert(arrqKey.length);
	
	var string_c = hddComment;
	arrComment  =  string_c.split("|");
	//alert(arrComment.length);
	
	var arrVal = new Array();
	for(var i=0 ; i<arrqKey.length; i++){
		var qKey = parseInt(arrqKey[i]); 
		var comment = arrComment[i];	
		//alert(typeof(qKey));
		if( comment.length > 0 ){
			document.getElementById("txt"+qKey).style.display = "";
		}	
		//alert("arrVal["+qKey+"] = "+comment+ " => " + typeof(comment));
	}
}

function onKeyDown() { 
   var keycode;
   if (window.event) keycode = window.event.keyCode;
   if (keycode == 13) {
      window.event.keyCode = 9;
   }
   return true;
}
document.onkeydown = onKeyDown;


/*function isNumeric(elem, helperMsg)
{
        var numericExpression = /^[0-9.]+$/;
        if(elem.value.match(numericExpression)){
                return true;
        }else{
                alert(helperMsg);
                //elem.value=elem.value.substr(0,elem.value.length-1);
                elem.focus();
                return false;
        }
}*/


