function reloadAll(params){
parent.mainz.location.href='main.frame.php'+params;
parent.calendarz.location.href='calend.frame.php'+params;
parent.panelz.location.href='panel.frame.php'+params;
}
function reloadExport(params){
parent.mainz.location.href=params;
parent.calendarz.location.href=params;
parent.panelz.location.href=params;
}

