// JavaScript Document  // jQuery Popup Calendar
$(function() {
	
	// Set field pro_com_regis ( Thai ) == field pro_com_regis ( Eng )
	jQuery('#pro_com_regis_th').datepick({onSelect: function(dates) { 
        jQuery('#pro_com_regis_en').val(jQuery(this).val()); 
    }});
	
	
	// Set field pro_com_regis ( Eng ) == field pro_com_regis ( Thai )
	jQuery('#pro_com_regis_en').datepick({onSelect: function(dates) { 
        jQuery('#pro_com_regis_th').val(jQuery(this).val()); 
    }});
	
	
	// Calculate Birth Date
	jQuery('#pro_birthdate').datepick({onSelect: birthday});
	
		
	//jQuery('#inlineDatepicker').datepick({onSelect: showDate});
	
	
});

/*function showDate(date) {
	alert('The date chosen is ' + date);
}*/
