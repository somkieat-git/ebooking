var k='';

function set_del_file(file_name) 
{
//    document.all.img_delete.value=file_name;
//	alert(document.all.img_delete.value);
}

function delete_row(message)
{
    if (confirm(message)==true) {
    return true;
    } else return false;
}

var form_cancel=false;


function set_form_cancel() 
{
    form_cancel=true;
}


function is_valid_form_data() 
{

	if(k == "delete") {
		return true;
	}

	if (form_cancel)
	{
		return true;   
	}

	if (document.getElementById('them').value == "") { alert('Title not set'); return false;}

	var formd = document.frm;
	curtime = document.getElementById('start_time').value;
	curtime = curtime.split(":");

	cd = new Date();
	sd = new Date(formd.date_year.value, eval(formd.date_mes.value - 1 ), formd.date_day.value,curtime[0],curtime[1]);

	if(cd.getTime() > sd.getTime()) {
		if(confirm("Time that you set is in past !!\n    Continue")) {	} else { return false; }
	}

	end_date = formd.rep_end_date.value;

	if(end_date != "" && !formd.rep_end_date.disabled) {
		end_date_h = end_date.split(" ");
		end_y = end_date_h[0].split("-");
		end_h = end_date_h[1].split(":");

		sd = new Date(end_y[0],(end_y[1] - 1), end_y[2], end_h[0], end_h[1]);

		if(cd.getTime() > sd.getTime()) {
			if(confirm("Time that you set is in past !!(END DATE)\n     Continue ?")) {} else {return false;}
		}
	}

	if(document.getElementById('interval_val').disabled == false && document.getElementById('interval_val').value == "")  {
		if(confirm("Recuring Event, but without interval\n     Continue ?")) {} else { return false; }
	}

/*	alert(curdate.getTime() + " : " + seldate.getTime() + "\n"
	+  curdate.getFullYear() + " : " + seldate.getFullYear()  + "\n"
	+ curdate.getMonth() + " : " + seldate.getMonth()  + "\n"
	+ curdate.getDate() + " : " + seldate.getDate()  + "\n"
	+ curdate.getHours() + " : " + seldate.getHours());
*/

	with(window.event.srcElement)
	{
		for (k in elements.tags('input'))
		{
			if (elements[k].title!='')
			{

				if (elements[k].is_null=="") 
				{
					if (elements[k].value=="") return false;
				}


				if(elements[k].title=="EMAIL")
				{
					if (!is_valid_mail(elements[k].value)) return false;
				}

				if((elements[k].title=="float")) 
				{
					if (elements[k].value!="") elements[k].value=parseFloat(elements[k].value);								    								
				}
				if (elements[k].title=="date") 
				{
					if (elements[k].value=="") return false;								    
					elements[k].disabled=false;
				}

				if((elements[k].title=="int")) 
				{
					if (elements[k].value!="") elements[k].value=parseInt(elements[k].value);
				}
				if(elements[k].title=="url")
				{
					if (!is_valid_url(elements[k].value)) return false;
				}

			}
		}

		for (k in elements.tags('select'))
		{
			if (elements[k].is_null=="") 
			{
				if (elements[k].value=="") return false;
			}
		}
	}

	return true;
}

/*
function delete_row()
{
    if (confirm('Are you sure you want to delete this row?')==true) {
    //document.frm_page.id.value=id;
    //document.frm_page.flag.value='delete_row';
    document.forms[0].submit();
    return true;
    } else return false;
}
*/
////////////////////////////////////////////////////////////////////////////////

	function is_valid_mail(mail) 
	{
		var valid=false;
		if (mail.length==0) return true;
		if (mail.indexOf("@")!=-1&&mail.indexOf(".")!=-1&&mail.indexOf(".")!=(mail.length-1)&&mail.indexOf(" ")==-1&&mail.length>0) valid=true;
		return valid;
	}

	function is_valid_url(url_val) 
	{
		var valid=false;
		if (url_val.indexOf("http://")!=-1&&url_val.indexOf(".")!=-1&&url_val.indexOf(".")!=(url_val.length-1)&&url_val.indexOf(" ")==-1&&url_val.length>0) valid=true;
		return valid;
	}

	function prepare_data() 
	{
		var k='';
		with(document.dict_form)
		{
			for (k in elements.tags('input'))
			{
					if (elements[k].title!='')
					{
						if(elements[k].title=="float")
						{
							elements[k].value=parseFloat(elements[k].value);
						}
						if((elements[k].title=="int")&(elements[k].value!=""))
						{
							elements[k].value=parseInt(elements[k].value);
						}

					}
			}
		}
		return true;
	}

		    
