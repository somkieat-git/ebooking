<!--
// menu settings & events

var DropDownMenu = new FSMenu('DropDownMenu', true, 'display', 'block', 'none');
DropDownMenu.showDelay = 0;
DropDownMenu.switchDelay = 125;
DropDownMenu.hideDelay = 100;
DropDownMenu.cssLitClass = 'highlighted';

var fsmOL = window.onload;
window.onload = function() {
	if (fsmOL) fsmOL();
	activateMenu("DropDownMenu", "DropDownMenuMain");
}

function activateMenu(objName, id) {
	if (!isDOM) return;
	var a, ul, mRoot = getRef(id), nodes, count = 1;
	var items = mRoot.getElementsByTagName('li');
	for (var i = 0; i < items.length; i++) {
		nodes = items[i].childNodes;
		if (!nodes) continue;
		a = ul = null;
		if (nodes) for (var n = 0; n < nodes.length; n++) {
			if (!nodes[n].nodeName || (nodes[n].nodeType != 1)) continue;
				if (nodes[n].nodeName == 'A') a = nodes[n];
				if (nodes[n].nodeName == 'UL') ul = nodes[n];
				if (a && ul) {
				var menuID = objName + '-id-' + count++,
				mOver = new Function(objName + '.show("' + menuID + '", this)'),
				mOut = new Function(objName + '.hide("' + menuID + '")');
				ul.setAttribute('id', menuID);
				///alert(menuID.length);
				if (a.addEventListener) {
					a.addEventListener('mouseover', mOver, false);
					a.addEventListener('mouseout', mOut, false);
				} else {
					a.onmouseover = mOver;
					a.onmouseout = mOut;
				}
				var subI = document.createElement ? document.createElement('span') : 0;
				/*if (subI) {
					subI.appendChild(document.createTextNode('>'));
					subI.className = 'subind';
					a.insertBefore(subI, a.firstChild);
				}*/
				var subImg = document.createElement ? document.createElement('img') : 0;
				if (subImg) {
					subImg.setAttribute("src", "images/menu/bullet2.gif");
					subImg.setAttribute("width", "7");
					subImg.setAttribute("height", "9");
					subImg.setAttribute("border", "0");
					//subImg.setAttribute("align", "right");
					subImg.className = 'subind';
					a.insertBefore(subImg, a.firstChild);
				}
			}
		}
	}
}

//-->