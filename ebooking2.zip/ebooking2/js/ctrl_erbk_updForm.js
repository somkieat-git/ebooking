// JavaScript Document
var temp = 0;

function enableLink(eItem , chk_value)
{
	if( chk_value == "N" ){
		temp +=1 ;
		document.getElementById('chk_'+eItem).value = "Y" ;
		document.getElementById('chk_item_'+eItem).value = eItem+"_Y" ;
		document.getElementById('edit_event_'+eItem).disabled = false ;
			
	}else {
		temp -=1 ;
		document.getElementById('chk_'+eItem).value = "N" ;
		document.getElementById('chk_item_'+eItem).value = eItem+"_N" ;
		document.getElementById('edit_event_'+eItem).disabled = true ;
	}
	//alert(temp);
}

function checkValueOnSubmit(){
	
	//alert(temp);
	if(document.getElementById("bks_id").value == 1){
		alert ('Pleasee!! Select Booking Status Code');
		return false;
	}
	
	//val = frm.txtBox.value ;
	if(temp == 0){
		alert('Please select value first ! ');
		return false;
	}
	
	
}



function editEventDate(action , eItem , event_id )
{
	//alert( typeof(eItem) );
	//alert(action + "  "+ eItem + "   " + event_id );
	var hdd_item = document.getElementById("hdd_item").value ;
	//alert( hdd_item );
	if( action == "a"){
		if(hdd_item == "") hdd_item = 0 ;
		items = parseInt(hdd_item) + parseInt(eItem);
		document.getElementById("hdd_item").value = items ;
		//alert(items);
	}else{
		items = parseInt(eItem);
	}
	
	var url = "dbk_updForm.php?a="+action+"&a_r=e&id="+event_id+"&id2="+items;
	//alert(url);
	open(url,"editEventDate","width=550,height=280,status=no,menubar=no,resizable=no,scrollbars=yes,top=50,left=100");
		
}


function setLabelValue(value_all , edbk_item , action , event_id) 
{
	
	if( action == "a" ){
		//insertRow(  edbk_item , event_id ); // INSERT ROW IN TABLE
		addRow("myTable" , edbk_item , event_id ); // INSERT ROW IN TABLE
	}
	
	
	var d = document;
	var string = value_all;
	arrVal =  string.split("|");
	in_date = arrVal[0];
	in_time = arrVal[1];
	ev_date = arrVal[2];
	beg_time = arrVal[3];
	last_date = arrVal[4];
	end_time = arrVal[5];
	out_date = arrVal[6];
	out_time = arrVal[7];
	loc_id = arrVal[8];
	//alert(loc_id);
	//alert(in_date + "| in_date_" + edbk_item);
	
	
	var el_in_date = "in_date_"+edbk_item;
	var el_out_date = "out_date_"+edbk_item;
	var hdd_indate = "hdd_indate_" + edbk_item ;
	var hdd_outdate = "hdd_outdate_" + edbk_item ;
	var el_in_time = "in_time_"+edbk_item ;
	var el_out_time = "out_time_"+edbk_item ;
	
	var el_begdate = "begdate_"+edbk_item ;
	var el_enddate = "enddate_"+edbk_item ;
	var hdd_begdate = "hdd_begdate_" + edbk_item ;
	var hdd_enddate = "hdd_enddate_" + edbk_item ;
	var el_begtime = "begtime_"+edbk_item ;
	var el_endtime = "endtime_"+edbk_item ;
	var el_loc = "hdd_loc_"+edbk_item ;
	
	
	d.getElementById(el_in_date).innerHTML = in_date ;
	d.getElementById(el_out_date).innerHTML = out_date ;
	d.getElementById(hdd_indate).value = in_date ;
	d.getElementById(hdd_outdate).value = out_date ;
	d.getElementById(el_in_time).value = in_time ;
	d.getElementById(el_out_time).value = out_time ;	
	
	d.getElementById(el_begdate).innerHTML = ev_date ;
	d.getElementById(el_enddate).innerHTML = last_date ;
	d.getElementById(hdd_begdate).value = ev_date ;
	d.getElementById(hdd_enddate).value = last_date ;	
	d.getElementById(el_begtime).value = beg_time ;
	d.getElementById(el_endtime).value = end_time ;
	if(loc_id != ""){
		d.getElementById(el_loc).value = loc_id ;
	}
	
	window.close();
}


// INSERT ROW IN TABLE //
/*function insertRow( edbk_item , event_id )
{
	// SET ELEMENT ID //
	var chk_id = "chk_"+edbk_item ;
	var hdd_chk = "chk_item_" + edbk_item ;
	var lb_in_date = "in_date_" + edbk_item ;
	var lb_out_date = "out_date_" + edbk_item ;
	var hdd_indate = "hdd_indate_" + edbk_item ;
	var hdd_outdate = "hdd_outdate_" + edbk_item ;
	var hdd_in_time = "in_time_" + edbk_item ;
	var hdd_out_time = "out_time_" + edbk_item ;
	var lb_begdate = "begdate_" + edbk_item ;
	var lb_enddate = "enddate_" + edbk_item ;
	var hdd_begdate = "hdd_begdate_" + edbk_item ; 
	var hdd_enddate = "hdd_enddate_" + edbk_item ;
	var hdd_begtime = "begtime_" + edbk_item ;
	var hdd_endtime = "endtime_" + edbk_item ;
	var btn_edit_event = "edit_event_" + edbk_item ;
	var hdd_loc = "hdd_loc_"+edbk_item ;
	document.getElementById("hdd_item").value = edbk_item ;
	
	
	var myTable = document.getElementById('myTable');
	var count_row = myTable.getElementsByTagName("TR").length;
	var	insert_row = myTable.insertRow(count_row);
		
	
	var cell_0 = insert_row.insertCell(0);
	var cell_1 = insert_row.insertCell(1);
	var cell_2 = insert_row.insertCell(2);
	var cell_3 = insert_row.insertCell(3);
	var cell_4 = insert_row.insertCell(4);
	
	cell_0.innerHTML= "<input type='checkbox' id='"+chk_id+"' name='chk[]' value='N' onclick='javascript:enableLink( "+edbk_item+" , this.value);' /><input type='hidden' name='chk_item[]' id='"+hdd_chk+"' value='"+edbk_item+"_N' />";

	cell_1.innerHTML= edbk_item + "<input type='hidden' name='"+hdd_loc+"' id='"+hdd_loc+"' />" ; 
	
	cell_2.innerHTML= "<label id='"+lb_in_date+"'></label> - <label id='"+lb_out_date+"'></label><input type='text' name='"+hdd_indate+"' id='"+hdd_indate+"' /><input type='hidden' name='"+hdd_outdate+"' id='"+hdd_outdate+"' /><input type='hidden' name='"+hdd_in_time+"' id='"+hdd_in_time+"' /><input type='hidden' name='"+hdd_out_time+"' id='"+hdd_out_time+"' />";
	
	cell_3.innerHTML= "<label id='"+lb_begdate+"' ></label> - <label id='"+lb_enddate+"' ></label><input type='hidden' name='"+hdd_begdate+"' id='"+hdd_begdate+"' /><input type='hidden' name='"+hdd_enddate+"' id='"+hdd_enddate+"' /><input type='hidden' name='"+hdd_begtime+"' id='"+hdd_begtime+"' /><input type='hidden' name='"+hdd_endtime+"' id='"+hdd_endtime+"' />";
	
	cell_4.innerHTML= "<input type='button' name='"+btn_edit_event+"' id='"+btn_edit_event+"' class='Button' value='Change' disabled='disabled' onclick=\"javascript:editEventDate( 'e' , "+edbk_item+" , "+event_id+");\" />";
	
	
	
	
}*/


// INSERT ROW IN TABLE //
function addRow(tableID , edbk_item , event_id ) {
 
 	var table = document.getElementById(tableID);

	var rowCount = table.rows.length;
	var row = table.insertRow(rowCount);


	var cell1 = row.insertCell(0);
	var element1 = document.createElement("input");
	element1.type = "checkbox";
	element1.name = "chk[]";
	element1.id = "chk_"+edbk_item;
	element1.value = "N";
	element1.onclick = function(){enableLink(edbk_item , element1.value)};
	cell1.appendChild(element1);
	
	
	var element1_2 = document.createElement("input");
	element1_2.type = "hidden";
	element1_2.name = "chk_item[]";
	element1_2.id = "chk_item_"+edbk_item;
	element1_2.value = edbk_item+"_N";
	cell1.appendChild(element1_2);
	


	var cell2 = row.insertCell(1);
	var element2 = document.createElement("input");
	element2.type = "hidden" ;
	element2.name = "hdd_loc_"+edbk_item ;
	element2.id = "hdd_loc_"+edbk_item ;
	cell2.innerHTML = edbk_item;
	cell2.appendChild(element2);



	var cell3 = row.insertCell(2);
	var element3 = document.createElement("label");
	element3.setAttribute("id","in_date_"+edbk_item);
	element3.setAttribute("for","hdd_indate_"+edbk_item);
	cell3.appendChild(element3);
	
	
	var element3_1 = document.createElement("input");
	element3_1.type = "hidden" ;
	element3_1.name = "hdd_indate_"+edbk_item ;
	element3_1.id = "hdd_indate_"+edbk_item ;
	cell3.appendChild(element3_1);
	
	var element3_2 = document.createElement("input");
	element3_2.type = "hidden" ;
	element3_2.name = "in_time_"+edbk_item ;
	element3_2.id = "in_time_"+edbk_item ;
	cell3.appendChild(element3_2);
	
	
	
	var cell4 = row.insertCell(3);
	var element4 = document.createElement("label");
	element4.setAttribute("id","begdate_"+edbk_item);
	element4.setAttribute("for","hdd_begdate_"+edbk_item);
	cell4.appendChild(element4);
	
	
	var element4_1 = document.createElement("input");
	element4_1.type = "hidden" ;
	element4_1.name = "hdd_begdate_"+edbk_item ;
	element4_1.id = "hdd_begdate_"+edbk_item ;
	cell4.appendChild(element4_1);
	
	
	var element4_2 = document.createElement("input");
	element4_2.type = "hidden" ;
	element4_2.name = "begtime_"+edbk_item ;
	element4_2.id = "begtime_"+edbk_item ;
	cell4.appendChild(element4_2);
	
	
	
	var cell5 = row.insertCell(4);
	var element5 = document.createElement("label");
	element5.setAttribute("id","enddate_"+edbk_item);
	element5.setAttribute("for","hdd_enddate_"+edbk_item);
	cell5.appendChild(element5);
	
	
	var element5_1 = document.createElement("input");
	element5_1.type = "hidden" ;
	element5_1.name = "hdd_enddate_"+edbk_item ;
	element5_1.id = "hdd_enddate_"+edbk_item ;
	cell5.appendChild(element5_1);
	
	
	var element5_2 = document.createElement("input");
	element5_2.type = "hidden" ;
	element5_2.name = "endtime_"+edbk_item ;
	element5_2.id = "endtime_"+edbk_item ;
	cell5.appendChild(element5_2);
	
	
	
	var cell6 = row.insertCell(5);
	var element6 = document.createElement("label");
	element6.setAttribute("id","out_date_"+edbk_item);
	element6.setAttribute("for","hdd_outdate_"+edbk_item);
	cell6.appendChild(element6);
	
	
	var element6_1 = document.createElement("input");
	element6_1.type = "hidden" ;
	element6_1.name = "hdd_outdate_"+edbk_item ;
	element6_1.id = "hdd_outdate_"+edbk_item ;
	cell6.appendChild(element6_1);
	
	
	var element6_2 = document.createElement("input");
	element6_2.type = "hidden" ;
	element6_2.name = "out_time_"+edbk_item ;
	element6_2.id = "out_time_"+edbk_item ;
	cell6.appendChild(element6_2);
	
	
	
	var cell7 = row.insertCell(6);
	var element7 = document.createElement("input");
	element7.type = "button" ;
	element7.name = "edit_event_"+edbk_item ;
	element7.id = "edit_event_"+edbk_item ;
	element7.value = "Change";
	element7.onclick = function(){editEventDate("u" , edbk_item  , event_id)};
	element7.className = "Button";
	element7.disabled = true ;
	cell7.appendChild(element7);

}