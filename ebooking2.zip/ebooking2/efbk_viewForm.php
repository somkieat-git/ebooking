<?	
	include("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	$sysName = "Food Services";
	$status = "F";
	$updSave = "efbk_viewFormS.php";
	$evn_id = $_REQUEST["id"];
	$loc_id = $_REQUEST["id2"];
	//echo "evn_id = $evn_id<br>loc_id=$loc_id<br>";
	
	if(!empty($evn_id)){
		$sql = "SELECT * FROM eventname WHERE evn_id = '$evn_id'  ";
		$res = getData($sql);
		$rs = mysql_fetch_array($res);
		$disabled = "";
		if($rs["evn_used"] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;
		$evn_name = $rs["evn_shortname"];		
	} //if(!empty($ev_id)){	
?>
	
<html>
<head>
<title>edbk_updForm.php</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">
<script type="text/javascript">
	function move(fbox, tbox) {
		 var arrFbox = new Array();
		 var arrTbox = new Array();
		 var arrLookup = new Array();
		 var i;
		 for(i=0; i<tbox.options.length; i++) {
			  arrLookup[tbox.options[i].text] = tbox.options[i].value;
			  arrTbox[i] = tbox.options[i].text;
		 }
		 var fLength = 0;
		 var tLength = arrTbox.length
		 for(i=0; i<fbox.options.length; i++) {
			  arrLookup[fbox.options[i].text] = fbox.options[i].value;
			  if(fbox.options[i].selected && fbox.options[i].value != "") {
				   arrTbox[tLength] = fbox.options[i].text;
				   tLength++;
			  } else {
				   arrFbox[fLength] = fbox.options[i].text;
				   fLength++;
			  }
		 }
		 arrFbox.sort();
		 arrTbox.sort();
		 fbox.length = 0;
		 tbox.length = 0;
		 var c;
		 for(c=0; c<arrFbox.length; c++) {
			  var no = new Option();
			  no.value = arrLookup[arrFbox[c]];
			  no.text = arrFbox[c];
			  fbox[c] = no;
		 }
		 for(c=0; c<arrTbox.length; c++) {
			var no = new Option();
			no.value = arrLookup[arrTbox[c]];
			no.text = arrTbox[c];
			tbox[c] = no;
		 }
	}
	
	function selectAll(tbox) {
		var arrLoc = new Array();
		 for(var i=0; i<tbox.length; i++) {
		 //tbox[i].selected = true;
		 arrLoc[i] = tbox[i].value;		  
		 }
		 document.frm.hd_esv_id.value = arrLoc ;		
	}
	
</script>
</head>
<body>
<form name="frm" method="post" action="<?=$updSave ;?>">
  <table border="0" cellpadding="1" cellspacing="1" class="BorderGreen" >
    <tr><td colspan=6 class="mandatory"><?=$sysName ." - ". $evn_id ." - ". $evn_name ;?>&nbsp;&nbsp; 
	</td>
    </tr>
    <tr style="background-color: #339900; color: White;">
    <td  font-weight:bold;><div align="center"></div></td>
	<td  font-weight:bold;>Room</td>
    <td  font-weight:bold;>Beg Date </td>
    <td  font-weight:bold;>Beg Time </td>
    <td  font-weight:bold;>End Date </td>
    <td  font-weight:bold;>End Time </td>
    </tr>
	<?
		#Select value in view ev_eesv_block
		$sql1 = "SELECT loc.loc_id as loc_id, 
						loc.loc_shortname as loc_shortname, 
						loc.loc_fullname as loc_fullname,
						eebk.*				
					FROM ev_eesv_block eebk, location loc
					WHERE eebk.loc_id = loc.loc_id 
					AND eebk.evn_id = '$evn_id' 
					AND eebk.eebk_status = '$status'				
					";
		//echo "$query<br>";	
		$cnt_eebk = getNumRow($sql1);
		//echo "\$cnt_eebk = $cnt_eebk<br>";
		if ($cnt_eebk == 0){
			$sql = "SELECT eloc.eloc_id as eloc_id, 
							loc.loc_id as loc_id,
							loc.loc_shortname as loc_shortname, 
							loc.loc_fullname as loc_fullname, 
							eloc.eloc_in_date as eloc_in_date, 
							eloc.eloc_out_date as eloc_out_date,
							eloc.eloc_in_time as eloc_in_time, 
							eloc.eloc_out_time as eloc_out_time
						FROM location loc, ev_location eloc
						WHERE loc.loc_id = eloc.loc_id 
						AND eloc.evn_id = '$evn_id'  
						ORDER BY eloc.eloc_in_date, eloc.eloc_in_time,  loc.loc_shortname
						";
			//echo "$sql<br>";
			//exit();
			$cnt_eloc = getNumRow($sql);			
			//echo "\$cnt_eloc = $cnt_eloc<br>";					
			//exit();
			if($cnt_eloc == 1 ){
				$rs_eloc = getResult($sql,"");
				$loc_id = $rs_eloc["loc_id"];
				$beg_date =  $rs_eloc["eloc_in_date"];
				$beg_time = $rs_eloc["eloc_in_time"];
				$end_date =  $rs_eloc["eloc_out_date"];
				$end_time = $rs_eloc["eloc_out_time"];
				
				$resData["evn_id"] = $evn_id;
				$resData["loc_id"] = $loc_id;
				$resData["eebk_beg_date"] = $beg_date;
				$resData["eebk_beg_time"] = $beg_time;
				$resData["eebk_end_date"] = $end_date;
				$resData["eebk_end_time"] = $end_time;
				$resData["eebk_status"] = $status;
				$resData["usr_cre"] = $_SESSION["usr_name"];
				$resData["date_cre"] = date("Y/m/d  H:i:s");		
				
				$query = create_insert_query("ev_eesv_block",$resData);	
				//echo "$query<br>";
				//exit();
				mysql_query($query) or die("Insert ev_eesv_block error");									
			} //if($cnt_eloc == 1 ){
		}	//if ($cnt_eebk == 0){
		
		//echo "$sql1<br>";		
		//exit();
		$rs_eebk = getData($sql1);			
		while($row=mysql_fetch_array($rs_eebk)){ 
			if ($color == "#F0F0F0")
				$color = "#FFFFFF" ;
			else
				$color = "#F0F0F0" ;			
				
				$id = $row["loc_id"];
				$loc_name = $row["loc_shortname"] . " - " . $row["loc_fullname"];				
				$beg_date = chgDate($row["eebk_beg_date"]);
				$beg_time = chgTime($row["eebk_beg_time"]);
				$end_date =chgDate($row["eebk_end_date"]);
				$end_time = chgTime($row["eebk_end_time"]);
				if(empty($loc_id)) $loc_id = $id ;
	?>
	
	<tr bgcolor='<?=$color?>' >
	  	<td><a href="efbk_updForm.php?a=u&id=<?=$evn_id;?>&id2=<?=$id;?>">
			<img src='images/b_edit.png' alt='Update' border='0'></a>
		</td>
		<a href="efbk_viewForm.php?id=<?=$evn_id;?>&id2=<?=$id?>">
		<td><?=$loc_name;?></td>		
		<td><?=$beg_date;?></td>		
		<td><?=$beg_time;?></td>		
		<td><?=$end_date;?></td>		
		<td><?=$end_time;?></td>		
		</a>
    </tr>
	<? 
		} //while($row=mysql_fetch_array($result)){ 
	?>	
  </table>
  
  <br>
  <input name="Button" type="button" class="Button" value="Add"  onClick="window.location= 'efbk_updForm.php?a=a&id=<?=$evn_id?>' ;">  
  <br>
  <span class="mandatory">
  <input name="id" type="hidden" id="id" value="<?=$evn_id?>">
  <input name="id2" type="hidden" id="id2" value="<?=$loc_id?>">
  </span><br>
  <?
  		//echo "\$evn_id = $evn_id, \$loc_id = $loc_id<br>";
		if(isset($evn_id) && isset($loc_id)){
			$query = "SELECT loc.loc_id as loc_id, 
							 loc.loc_shortname as loc_shortname, 
							 loc.loc_fullname as loc_fullname,
							 eebk.*				
						FROM ev_eesv_block eebk, location loc
						WHERE eebk.loc_id = loc.loc_id 
						AND eebk.evn_id = '$evn_id' 
						AND eebk.eebk_status = '$status'				
						AND eebk.loc_id = $loc_id
						";
			//echo "$query<br>";	
			
			$rs_eebk = getData($query);		
		while($row=mysql_fetch_array($rs_eebk)){ 
				$id = $row["loc_id"];
				$loc_id = $id;
				$loc_name = $row["loc_shortname"] . " - " . $row["loc_fullname"];				
				$beg_date = chgDate($row["eebk_beg_date"]);
				$beg_time = chgTime($row["eebk_beg_time"]);
				$end_date =chgDate($row["eebk_end_date"]);
				$end_time = chgTime($row["eebk_end_time"]);
		} //while($row=mysql_fetch_array($rs_eebk)){ 
  ?>
  <table border="0" cellpadding="0" cellspacing="4" class="BorderGreen">
    <tr>
      <td height="25" colspan="3" ><div align="center">Room : <?=$loc_name;?>
       </div></td>
    </tr>
    <tr class="mandatory">
      <td style="background-color: #339900; color: White;">
	  	<div align="center">Choose</div>
	  </td>
      <td align="center" valign="middle">&nbsp;</td>
      <td style="background-color: #339900; color: White;">
	 	 <div align="center">Selected</div>
	  </td>
    </tr>
    <tr>
      <td rowspan="2"  class="mandatory">		
		<?
				$sql = "SELECT esv_id 
							FROM ev_eesv_block  WHERE evn_id = '$evn_id' 
							AND loc_id = '$loc_id' 
							AND eebk_status = '$status'
							";
				//echo "$sql<hr>";
				//exit();
				$result = getData($sql);
				$rs_eebk = mysql_fetch_array($result);
				//echo "cnt_edbk=$cnt_edbk<br>";
				$sql = "SELECT esv.esv_id as esv_id, esv.esv_name as esv_name	FROM equip_serv esv
							WHERE esv_status = '$status'
							";
				if ($rs_eebk["esv_id"]){
					$sql .= 	" AND esv.esv_id not in (" .$rs_eebk["esv_id"].")";
				}					
				$sql .= " ORDER BY esv.esv_name ";
				//echo "$sql<hr>";				
				//exit();
				$rs_esv = getData($sql);				
			
		?>
        <select name="list1" size="10"  multiple  style="width:250"   onDblClick="move(document.frm.list1,document.frm.list2)">
		  <?
			while ($row = mysql_fetch_array($rs_esv)){
				echo "<option value=".$row["esv_id"].">".$row["esv_name"]."</option>";				
				$esv_id .= $row["esv_id"].",";
			}
			$esv_id = substr($esv_id,0,strlen($esv_id)-1);
		?>
        </select>
      </td>
      <td height="83" align="center" valign="middle">
        <input name=button2 type="button" class="Button" id=button2 onClick="move(this.form.list1,this.form.list2)" value="-->">
      </td>
      <td rowspan="2" class="mandatory">
	  
	  <?
			$sql = "SELECT esv.esv_id as esv_id, esv.esv_name as esv_name	FROM equip_serv esv
						WHERE esv_status = '$status'
						";
			if ($esv_id){
				$sql .= 	" AND esv.esv_id not in (" .$esv_id.")";
			}			
			$sql .= " ORDER BY esv.esv_name ";
			//echo "$sql<hr>";				
			//exit();
			$rs_eesv = getData($sql);				
	  ?>
        <select name="list2" size="10"  multiple style="width:250" 
		onDblClick="move(document.frm.list2,document.frm.list1)">
	      <?			
			while ($row = mysql_fetch_array($rs_eesv)){
				echo "<option value=".$row["esv_id"].">".$row["esv_name"]."</option>";				
			}
		?>
        </select>
      </td>
    </tr>
    <tr>
      <td height="75" align="center" valign="middle"><input name=button1 type="button" class="Button" id=button12 onClick="move(this.form.list2,this.form.list1)" value="<--"></td>
    </tr>
    <tr>
      <td height="35" colspan="3" align="center"><input name="Submit2" type="button" class="Button" value="&lt;= Back " onClick="window.location = 'esta_updForm.php?id=<?=$evn_id?>'" >
        <input name="Submit" type="submit" class="Button" value="   OK   "   <?=$disabled ;?>
		onClick="selectAll(document.frm.list2);" >
        <input name="Button2" type="button" class="Button" id="Button"  onClick="history.go(-1)" value="Cancel" >
        <input name="Submit22" type="button" class="Button" value="Next =&gt;" onClick="window.location = 'ecus_updForm.php?id=<?=$evn_id?>'" >
        <input name="hd_esv_id" type="hidden" id="hd_esv_id">
	  </td>
    </tr>
  </table>
</form>
<?
	} //if(isset($evn_id) && isset($loc_id)){
include("db/disconnect.db.php");	
?>