<?	
	ob_start();
	session_start();
	include("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	define("updSave","ecus_updForm.php");
	$evn_id = $_REQUEST["id"];
	$action =  $_REQUEST["a"];
	$ecus_item = $_REQUEST["id2"];
	
	//======================Begin prepare stand data======================================
		
	if(!empty($evn_id)){
		$sql = "SELECT * FROM eventname WHERE evn_id = '$evn_id'  ";
		$rs_ev = getData($sql);
		$row = mysql_fetch_array($rs_ev);
		$disabled = "";
		//if($row[3] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;
		if($row["evn_used"] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;
		$evn_name = $row[1];
	} //if(!empty($ev_id)){		
	
	$sql = "SELECT * FROM miscode  
				WHERE  mis_type ='client' ";
	//echo "$sql<hr>";
	$rs_miscode = getData($sql);	
	$arr_miscode= array();
	while( $row = mysql_fetch_array($rs_miscode)){
		$arr_miscode[] = $row["mis_name"];
		//echo "rs_miscode  => ".$row["mis_name"]."<br> ";
	} //while( $row = mysql_fetch_array($resmiscode)){
	/*
	$sql = "SELECT cus.cus_id, cus.cus_name , nif.*  FROM customer cus LEFT JOIN nameinfo nif
				ON cus.cus_id = nif.nif_id 
				WHERE nif.nif_type = 'client' ";
	*/
	$sql = "SELECT  nif.nif_id, nif.nif_firstname, nif.nif_lastname
				FROM nameinfo nif
				WHERE nif.nif_type = 'client'
				";
				
	//echo "$sql<hr>";
	$rs_customer = getData($sql);		
	$arr_customer = array();
	while( $row = mysql_fetch_array($rs_customer)){
		 $arr_customer["$row[0]"]  = $row[1] . "  " . $row[2];
		 //echo " rs_customer = $row[0] => $row[1]  -  $row[5]<br> ";
	} //while( $row = mysql_fetch_array($resmiscode)){
	
	//======================End prepare stand data========================================

	
	
	//======================Begin select data from ev_customer===============================
	
	if (!empty($evn_id)){
		$sql = "SELECT * FROM ev_customer WHERE evn_id = '$evn_id'  ";
		//echo "$sql<hr>";
		$rs_ecus = getData($sql);
		$arr_ecus = array();
		$numrow = mysql_num_rows($rs_ecus);
		
		while( $row = mysql_fetch_array($rs_ecus)){
			 $arr_ecus[]  =  $row[2].",".$row[1] ;
			 //echo " rs_ecus = $row[2] => $row[1]<br> ";
		} //while( $row = mysql_fetch_array($rs_ecus)){
		
	} //if (!empty($evn_id)){
	
?>
<html>
<script language="javascript">
	function validate() 
	{
		if(frm.ecus0.value == 1 )
		{
			alert('Please input data in Main Contact');
			frm.ecus0.focus()
			return false;
		}
		if(frm.ecus1.value == 1 )
		{
			alert('Please input data in Lease Contact');
			frm.ecus1.focus()
			return false;
		}
		if(frm.ecus2.value == 1)
		{
			//Ϳ.ػó.value
			alert('Please input data in Invoice/Bill to Contact');
			frm.ecus2.focus()
			return false;
		}
	}
</script>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">
</head>
	
<body>
<form action="<?=$updSave ?>?id=<?=$evn_id?>" method="post" name="frm"  id="frm" onSubmit="return validate();">
  <table border="0" class="BorderGreen">
    <tr class="BorderSilver">
      <td colspan="4" style="background-color:#339900;font-weight:bold;color:White;">
	  	<div align="center"><strong >Client - <?=$evn_id." - " .$evn_name ?></strong></div>
	  </td>
    </tr>
	<tr>
	  <td height="27" colspan="4">
        <div align="center"><a href="cus_updForm.php?a=a">Add Client</a>              <input name="evn_id" type="hidden" id="evn_id" value="<?=$evn_id ?>">
          </div></td></tr>		
		<?
			foreach($arr_miscode as $miskey=>$misval){
				//echo "$misval<br>";
				echo "<tr><td ><div align='right'>$misval :</div></td>"; 	
	    ?>
						  
		  <td colspan="2">		
		  
		    <select name="ecus<?=$miskey?>" id="ecus<?=$miskey?>">			
			<?
				foreach($arr_customer as $cuskey=>$cusval){
				
					foreach($arr_ecus as $ecuskey=>$ecusval){
						$ecusval1 = substr($ecusval,0,strpos($ecusval,","));
						$ecusval2 = substr($ecusval,strpos($ecusval,",")+1);
						//echo "ecusval1 = $ecusval1,ecusval2=$ecusval2<br>";
						
			//			echo " misval =$misval<br>ecusval2 =$ecusval2<br>cuskey= $cuskey<br>ecuskey1=$ecusval1<br>";
						
						if($misval==$ecusval2 && $cuskey==$ecusval1){						
							$select =1;
							break;
						}
						else{
							$select =0;
							//continue;
						}
					} //foreach($arr_ecus as $ecuskey=>$ecusval){
					
					if($select==1)
						echo "<option value=$cuskey  selected > $cusval </option>";
					else
						echo "<option value=$cuskey > $cusval </option>";					
				} //foreach($arr_customer as $cuskey=>$cusval){
			?>		
	        </select>
			<?
				if(!$disabled) {
			?>
		    <a href="ecus_updForm.php?a=d&id=<?=$evn_id ?>&id2=<?=$misval ?>"  
			onClick = "return confirm(' ต้องการลบ <?=$misval ?> ออกจากระบบจริงหรือไม่ ? ') "	>
			<img src="images/b_drop.png" width="16" height="16" border="0"></a>
			<?
				} //if($disabled) {
			?>
		  
		  </td>
    	</tr>
		<?
			} //foreach($arr_miscode as $key=>$val){
		?>
	
		<tr>
		  <td height="20" ><div align="right"></div></td>
		  <td colspan="2" ><div align="left"></div></td>
    </tr>
    <tr align="center" >
      <td colspan="3">	  	
	  	<div align="center">
			<input name="Submit2" type="button" class="Button" value="&lt;= Back " onClick="window.location = 'edbk_viewForm.php?id=<?=$evn_id?>'" >
			<input name="Submit" type="submit" class="Button" value="   OK   "  <?=$disabled?> >
			<input name="Button" type="button" class="Button" id="Button"  onClick="history.go(-1)" value="Cancel" >
			<input name="Submit22" type="button" class="Button" value="Next =&gt;" onClick="window.location = 'estf_updForm.php?id=<?=$evn_id?>'" >		  
        </div></td>
    </tr>
  </table>
</form>

<?
	//======================Begin Save Data==============================================
	//request data into varible
	$Submit = $_REQUEST["Submit"];
	if(!empty($Submit)){
		$ecus0 = $_REQUEST["ecus0"];
		$ecus1 = $_REQUEST["ecus1"];
		$ecus2 = $_REQUEST["ecus2"];
		$ecus3 = $_REQUEST["ecus3"];
		$ecus4 = $_REQUEST["ecus4"];
		$ecus5 = $_REQUEST["ecus5"];
		/*
		echo "
		submit = $Submit<br>
		evn_id =  $evn_id<br>
		ecus0 = $ecus0<br> 
		ecus1 = $ecus1<br>
		ecus2 = $ecus2 <br> 
		ecus3 = $ecus3<br>
		ecus4 = $ecus4 <br>
		ecus5 = $ecus5<br>
		";
		*/
		//check duplicate data in table ev_customer
		function  checklist($value,$label,$field,$evn_id){
			global $resNull; global $resData; global $flag; global $strPattern; global $query; 
			global $arrquery ;
			$strPattern = "Main Contact|Lease Contact|Invoice/Bill to Contact| ";
			if($value ==1){
				if(ereg($strPattern,$label)){
					$flag = 1;
					$resNull[] = $label;
				} //if(ereg($strPattern,$label)){			
			} //if($value==1){
			else{
				$usr =  $_SESSION["usr_name"];
				$d = date("Y/m/d  H:i:s");
				$sql = "SELECT * FROM ev_customer 
							 WHERE evn_id = '$evn_id'
							 AND $field = '$label' ";
				//echo "$sql<hr>";
				$result = getData($sql);
				$numrow = mysql_num_rows($result);
				$row = mysql_fetch_array($result);
				//echo "numrow = $numrow<br>";
				if ($numrow == 0 ){
						$query = " INSERT INTO ev_customer (evn_id, ecus_item, cus_id, usr_cre, date_cre )";
						$query .= "	VALUES( '$evn_id', '$label', $value,'$usr','$d' );";
						//echo "$query<hr>";			
						$arrquery[] = $query;
				}
				else{
						$query = " UPDATE ev_customer SET";
						$query .= "	cus_id = $value,";
						$query .= "	usr_upd = '$usr',";
						$query .= "	date_upd = '$d'";
						$query .= "	WHERE evn_id = 	'$evn_id'";
						$query .= "	AND ecus_item = '$label';";
						//echo "$query<hr>";					
						$arrquery[] = $query;
				} //else{ if ($numrow == 0 ){
			} //else{ if($value==1){	
		} //function checklist($var,$name){
		
		//checklist($evn_id,"","evn_id");
		checklist($ecus0,"Main Contact","ecus_item",$evn_id);
		checklist($ecus1,"Lease Contact","ecus_item",$evn_id);
		checklist($ecus2,"Invoice/Bill to Contact","ecus_item",$evn_id);
		checklist($ecus3,"Alternate Contact","ecus_item",$evn_id);
		checklist($ecus4,"Decorator","ecus_item",$evn_id);
		checklist($ecus5,"Referrals","ecus_item",$evn_id);
		foreach($arrquery as $key=>$val) {
			mysql_query($val) or die("query error");	
			$SaveLog=updLog($_SESSION['username'], updSave, "$val");					
		}
		
		//Show alert by javascript				
		echo "<script>
				alert ('Update complete');
				window.location = 'ecus_updForm.php?id=$evn_id';
			  </script>";
		exit();
	} //if(!empty($Submit)){
	if($action == 'd'){
		$sql = "DELETE FROM ev_customer";
		$sql .=" WHERE evn_id = '$evn_id'";
		$sql .=" AND ecus_item = '$ecus_item'";
		//echo "$sql<br>"; exit();
		mysql_query($sql) or die("Delete error");	
		$SaveLog=updLog($_SESSION['username'], updSave, "$sql");					
		//exit();
		//Show alert by javascript				
		echo "<script>
				alert ('Delete complete');
				window.location = 'ecus_updForm.php?id=$evn_id';
			  </script>";
		exit();		
	} // if($action == 'd'){
	
	//======================End Save Data==============================================
include("db/disconnect.db.php");
?>