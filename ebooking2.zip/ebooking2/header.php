<?
	ob_start(); 
	session_start();
	include("db/chksession.db.php");
	include "ql/inc/config.php";
	include "./cfg/config.cfg.php";
	//include "ql/inc/auth.php";
	include "ql/inc/function.php";
	$prefix = prefix;
	//$_SESSION["usr_id"];
	//echo "\$UsrId=" . $UsrId = $_SESSION["UsrID"];
	
?>

<html>
<head>


<script>
<!--

/*By JavaScript Kit
http://javascriptkit.com
Credit MUST stay intact for use
*/

function show2(){
if (!document.all&&!document.getElementById)
return
thelement=document.getElementById? document.getElementById("tick2"): document.all.tick2
var Digital=new Date()

var year=Digital.getYear()
if (year < 1000)
year+=1900
var day=Digital.getDay()
var month=Digital.getMonth()
var daym=Digital.getDate()
if (daym<10)
daym="0"+daym
var dayarray=new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday")
var montharray=new Array("January","February","March","April","May","June","July","August","September","October","November","December")

var hours=Digital.getHours()
var minutes=Digital.getMinutes()
var seconds=Digital.getSeconds()
var dn="PM"
if (hours<12)
dn="AM"
if (hours>12)
hours=hours-12
if (hours==0)
hours=12
if (minutes<=9)
minutes="0"+minutes
if (seconds<=9)
seconds="0"+seconds
var cdate = dayarray[day]+", "+daym+" - "+ montharray[month]+" - "+ year
var ctime=hours+":"+minutes+":"+seconds+" "+dn
thelement.innerHTML="<b style='font-size:9;color:#339900;'>"+ " [ "+cdate + "  : "+ctime+" ] </b>"
setTimeout("show2()",1000)
}
window.onload=show2
//-->
</script>


	<title></title>	
	<link rel="stylesheet" href="css/format.css.css" type="text/css">
	<link rel='StyleSheet' href='ql/css/style.css'>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8"><style type="text/css">

<!--
body {
	background-color: #FFFFFF;
}
-->
</style>

</head>

<body style="margin-left:0px;">
<table width="99%" border="0" cellpadding='0' cellspacing='0' align='center'>
<tr>
	<td><img src='ql/img/j_header_left.png'></td>
	<td background='ql/img/j_header_middle.png' width='100%' valign='middle' class='title'><?=APP_NAME?></td>
	<td><img src='ql/img/j_header_right.png'></td>
</tr>
</table>
<table width="99%" align="center"  >
	<tr style="color:#339900; font-weight:bold;">	
		<td width="50%" height="26" align="left" valign="bottom" >&nbsp;user : <?=$_SESSION["usr_name"];?><span  id=tick2></span></td>
		<td  width="50%" >
	      <table  border="0" align="right" cellpadding="1">
            <tr align="right">
				<td>
					<?php //$prefix == "psu" ? $width = 40 : $width = 70 ; ?>
					<?php //$pic_name = $prefix . ".png" ?>
					<?php 
						// UPDATE 2010-12-01
						if( ereg( "psu" , $prefix )){
							$width = 25 ; 
							$pic_name = $prefix . "_resize.png" ; 
						}else{
							$width = 70 ;
							$pic_name = $prefix . ".png";
						}								
					?>
					<img src="images/logo/<?php echo $pic_name ; ?>" width="<?php echo $width ;?>" height="25" />					
				</td>
              <td  valign="bottom" >
              <a href="fra_booking.php" target="main_Frame"
		onMouseOver="document.booking.src='images/icon_old/icon-booking.gif'"
		onMouseOut="document.booking.src='images/icon-booking.gif'">		
		<img src="images/icon-booking.gif"   name="booking" width="80" height="24" border="0"></a></td>
		  
		<?
		$calendarID="47";
		$view="0";
		$view = array_key_exists($calendarID,$_SESSION["sec_view"]);
		if($view){		
		?>
		
		<td   valign="bottom" ><a href="calendar" target="main_Frame"
		onMouseOver="document.calendar.src='images/icon_old/icon-calendar.gif'"
		onMouseOut="document.calendar.src='images/icon-calendar.gif'">		
		<img src="images/icon-calendar.gif" name="calendar" width="80" height="24" border="0"></a></td>		
		
		<?
		}//if($view){		
		?>
		
		<td   valign="bottom" ><a href="fra_maintenance.php" target="main_Frame"
		onMouseOver="document.master.src='images/icon_old/icon-master.gif'"
		onMouseOut="document.master.src='images/icon-master.gif'">		
		<img src="images/icon-master.gif" name="master" width="80" height="24" border="0"></a></td>		  	  
		  
		<td   valign="bottom" ><a href="logout.php" target="_parent"
		onMouseOver="document.logout.src='images/icon_old/icon-logout.gif'"
		onMouseOut="document.logout.src='images/icon-logout.gif'">		
		<img src="images/icon-logout.gif" name="logout" width="80" height="24" border="0"></a></td>
            </tr>
          </table>
        </td>
	</tr>
</table>

<br>
</body>
</html>