﻿<?	
	error_reporting(E_ALL ^E_NOTICE ^E_WARNING ^ E_DEPRECATED);
	//ob_start();		
	$esv_id = $_REQUEST["esv_id"];
	$esv_name = $_REQUEST["esv_name"];
	$esv_dept = $_REQUEST["esv_dept"];
	$stt_id = $_REQUEST["stt_id"];
	$esv_qty = $_REQUEST["esv_qty"];
	$esv_amt = $_REQUEST["esv_amt"];
	$esv_status = $_REQUEST["esv_status"];
	$$esv_include_vat = $_REQUEST["esv_include_vat"];

	$id = $_REQUEST["id"];
	$action = $_REQUEST["a"];
	$Submit = $_REQUEST["Submit"];
	$cap_name = array();
	$cap_name = array("#","Name","Department","Settlement Group","Quantity","Amount","Status","Include Vat");
	
/*	echo "frm_id = $frm_id<br>
			   frm_name= $frm_name<br>
			   frm_status = $frm_status<br>
			   id = $id<br>
			   action = $action<br>
			   Submit = $Submit <hr>";
*/			   
	define("viewForm","flexigrid/esv_vfrm.php");
	define("updSave","esv_updForm.php");
	define("tableName","equip_serv");
	define("menuName","Equipment");
	define("field_id","esv_id");
	define("action",$action);
	define("id",$id);	
	define("beg_id",1);	
	define("end_id",7);	
	include_once("func/updForm.func.php");	
	include_once("func/sql.func.php");	
	
	//จุดที่ต้องแก้ไข 2.รับค่าข้อมูลที่จะ Write ลง DB
	function checklist($var,$name){
		global $data;
		global $flag;

		if(empty($var)){
			//จุดที่ต้องแก้ไข 3.บันทึกรายชื่อ Field ที่ต้องกรอกให้ครบ
			if(ereg("esv_name|esv_dept|stt_id|esv_qty|esv_amt",$name))
				$flag = 1;
		}  //if(empty($var)){
		$data[$name] = $var;
	} //function checklist($var,$name){
	
	if(!empty($Submit)){
		//จุดที่ต้องแก้ไข 4.เช็คข้อมูลที่จำเป็นต้องกรอกให้ครบถ้วน Write ลง DB
		checklist($esv_name,"esv_name");
		checklist($esv_dept,"esv_dept");
		checklist($stt_id,"stt_id");
		checklist($esv_qty,"esv_qty");
		checklist($esv_amt,"esv_amt");
		checklist($esv_status,"esv_status");
		checklist($esv_include_vat,"esv_include_vat");
		if($flag){
			$mesg = "Please input data in ";
			while(list($key,$value) = each($data)){
				if(empty($value)){
					//จุดที่ต้องแก้ไข 5.copy ในจุดที่ 3 มาไว้บรรทัดนี้ด้วย
				if(!ereg("esv_name|esv_dept|stt_id|esv_qty|esv_amt",$name))
						$str .= "$key,";
				}  //if(empty($value)){
				//$str = substr( $str, strlen($str)-1, 1 );
			}
			echo errmesg ("$mesg $str");			
		}	//if($flag){
		else{
			//จุดที่ต้องแก้ไข 6 เตรียมWrite ลง DB ตามเงื่อนไข Action
			session_start();
			if ($action=="a"){
				$data["esv_id"] = "";
				$data["usr_cre"] = $_SESSION["usr_name"];
				$data["date_cre"] = date("Y/m/d  H:i:s");				
				$query = create_insert_query($table_name,$data);				
				//echo "$query<br>";
				mysql_query($query) or die("Insert error");		
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");			
				//Show alert by javascript
				echo "<script>
						alert ('Insert complete');
						window.location = 'esv_updForm.php?a=a';
					  </script>";
				exit();
			} //if ($action=="a"){
			
			if ($action=="e"){
				$data["usr_upd"] = $_SESSION["usr_name"];
				$data["date_upd"] = date("Y/m/d  H:i:s");				
				$query = create_update_query($table_name, $data, $esv_id, $field_id);				
				//echo "$query<br>"; exit();
				mysql_query($query) or die("Update error");	
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");				
				//Show alert by javascript
				echo "<script>
						alert ('Update complete');
						window.location = '".viewForm."';
					  </script>";
				exit();
			}  //if ($action=="e"){
			
			if ($action=="d"){
				//$data["usr_upd"] = "tan";
				//$data["date_upd"] = date("Y/m/d  H:i:s");				
				//$query = create_update_query($table_name, $data, $id, $field_id);				
				$query = "DELETE FROM $table_name WHERE $field_id = $id " ;
			//	echo "$query<br>";
				//exit();
				
				mysql_query($query) or die("Delete error");	
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");				
				//Show alert by javascript
				echo "<script>
						alert ('Delete complete');
						window.location = '".viewForm."';
					  </script>";
				exit();
			}  //if ($action=="e"){
						
		}  //else{ of if($flag){
	}  //if(!empty($Submit)){
	
?>
<script language="javascript">
	function validate() 
	{
		if(frm.esv_name.value=="")
		{
			alert('Please input data in Name');
			frm.esv_name.focus()
			return false;
		}

		if(frm.esv_dept.value=="")
		{
			alert('Please input data in Department');
			frm.esv_dept.focus()
			return false;
		}
		if(frm.stt_id.value=="")
		{
			alert('Please input data in Settlement Group');
			frm.stt_id.focus()
			return false;
		}

		if(frm.esv_qty.value=="" || frm.esv_qty.value=="0" )
		{
			alert('Please input data in Quantity');
			frm.esv_qty.focus()
			return false;
		}
		if(frm.esv_amt.value=="" || frm.esv_amt.value=="0")
		{
			alert('Please input data in Amount');
			frm.esv_amt.focus()
			return false;
		}
		if(frm.esv_status.value=="")
		{
			alert('Please input data in Status');
			frm.esv_status.focus()
			return false;
		}	
		if(frm.esv_include_vat.value=="")
		{
			alert('Please input data in Include Vat');
			frm.esv_include_vat.focus()
			return false;
		}	
	}
</script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</body>
</html>
