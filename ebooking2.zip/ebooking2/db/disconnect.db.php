<? // Close connection
	mysql_close($connect);
?>