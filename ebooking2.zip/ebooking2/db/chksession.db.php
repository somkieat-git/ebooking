<?
	if(!isset($_SESSION)){
		ob_start();  
		session_start();
	}//if(!isset($_SESSION)){
		
	//echo "UsrID= " . $_SESSION["UsrID"];
	
	/*if(!empty($_SESSION["UsrID"])){
		$_SESSION["id"] = $_SESSION["UsrID"];
	}*/
	
	if (empty($_SESSION["UsrID"]) || empty($_SESSION["site"])){	
		echo "<script>
						alert('Please login first');
					    window.open('signout.php','_parent');
				   </script>";
		exit();
	}
?>
