<?

function connect($host,$login,$pwd) 
{
    $res_connect = false;
    $res_connect = @mysql_connect($host,$login,$pwd);
    
	Return $res_connect;
}

function select_db($db,$res_connect=false) 
{
    $result=@mysql_select_db($db); 
	mysql_query("SET NAMES 'utf8'",$res_connect);
    Return $result;
}

/*
Function :	get_table_fields
Purpose  :	���������� ����� ����� ��� �������
Arguments:
Returns  : 
Comments : 
*/

function get_table_fieldname($table_name) 
{
	$arr_fields = @mysql_list_fields(dbname, $table_name);
	$columns_num = @mysql_num_fields($arr_fields);

	$arr_field_name = array();
	for ($i = 0; $i < $columns_num; $i++) 
	{
		$arr_field_name[$i] = @mysql_field_name($arr_fields, $i);
	}	

	Return $arr_field_name;
}

/*
Function : 
Purpose  : 
Arguments:
Returns  : 
Comments : 
*/

function table_data2assoc($table_name, $name_field, $id_field, $condition) 
{
	$myquery = "SELECT $name_field, $id_field FROM $table_name $condition";	
	$r = mysql_query($myquery);

	for($i=0; $i<mysql_num_rows($r); $i++) 
	{
		$f = mysql_fetch_array($r);		
		$result[$f[$id_field]] = $f[$name_field];
	}

	Return $result;
}

/*
Function : 
Purpose  : 
Arguments:
Returns  : 
Comments : 
*/

function get_field_array($table_name, $field_name, $condition) 
{
	$myquery = "SELECT $field_name FROM $table_name $condition";	
	$r = mysql_query($myquery);
	
	if($r) 
	{
		for($i=0; $i<mysql_num_rows($r); $i++) 
		{
			$f = mysql_fetch_array($r);		
			$result[$i] = $f[$field_name];
		}		
	}


	Return $result;
}

/*
Function :	is_foreign_key
Purpose  : 
Arguments:
Returns  : 
Comments : 
*/

function is_foreign_key($field_name) 
{
	if(strstr($field_name, "_ID")) 
	{
		Return true;
	}
	Return false;
}

/*
Function : 
Purpose  : 
Arguments:
Returns  : 
Comments : 
*/

function get_foreign_table_name($field_name) 
{
	$info = explode("_", $field_name);	

	Return $info[0];
}

/*
Function :	result2array_idx
Purpose  :	����������� ������ � ������  ����
			array 
			(
				[id] = name-value
			)
Arguments:	$result - mysql-result, 
			$dict_field_name - ��� ����������� ���� 
			$id_field_name - ��� ���� ����������� id
Returns  :	array 
			(
				[id] = name-value
			)
Comments : 
*/

function result2array_idx($result, $dict_field_name="name", $id_field_name="id") 
{
	$arr_res = array();
	for($i=0; $i<mysql_num_rows($result); $i++) 
	{
		$f = mysql_fetch_assoc($result);
		$arr_res[$f[$id_field_name]] = $f[$dict_field_name];
	}	

	Return $arr_res;
}

?>