<?
/******************************************************************

Module Name 	: 
Purpose 	:
Description 	:
Author 		: Sergey Suzdalcew

	(C) 2003 By Sergey Suzdalcew

********************************************************************/

include_once("cfg/config.cfg.php");
include_once("db/mysql.db.php");

//for db working
$connect = connect(hostname, username, password);
if(!$connect) 
{
	echo("failed to connect");
}
$db = select_db(dbname,$connect);



?>