<?
	ob_start();  
	session_start();
	if (empty($_SESSION["id"])){	
		echo "<script>
						alert('Please login first');
					    window.location='login.php';
				   </script>";
		exit();
	}

?>
<html>
<head>
<title>chksession</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>

<body>

</body>
</html>
