<?
	error_reporting(E_ALL ^E_NOTICE ^E_WARNING ^ E_DEPRECATED);
	ob_start();
	session_start();	
	
	$evn_id = $_REQUEST["evn_id"];
	$evn_shortname = $_REQUEST["evn_shortname"];
	$evn_fullname = $_REQUEST["evn_fullname"];
	$evn_thainame = $_REQUEST["evn_thainame"];
	$evn_used = strtolower($_REQUEST["evn_used"]);

	$id = $_REQUEST["id"];
	$action = $_REQUEST["a"];
	$Submit = $_REQUEST["Submit"];
	$cap_name = array();
	$cap_name = array("#","Event Name","Event FullName","Event ThaiName","Print","Status");
	
	/*echo "frm_id = $frm_id<br>
			   frm_name= $frm_name<br>
			   frm_status = $frm_status<br>
			   id = $id<br>
			   action = $action<br>
			   Submit = $Submit <hr>";*/
			   
	define("viewForm","flexigrid/evn_vfrm.php");
	define("updSave","evn_updForm.php");
	define("tableName","eventname");
	define("menuName","Event Name");
	define("field_id","evn_id");
	define("action",$action);
	define("id",$id);	
	define("beg_id",1);	
	define("end_id",5);	
	include_once("func/updForm.func.php");	
	include_once("func/sql.func.php");	
	
	function checklist($var,$name){
		global $data;
		global $flag;

		if(empty($var)){
			if(ereg("evn_shortname|evn_fullname",$name))
				$flag = 1;
		}  //if(empty($var)){
		$data[$name] = $var;
	} //function checklist($var,$name){
	
	if(!empty($Submit)){
		checklist($evn_fullname,"evn_fullname");
		checklist($evn_shortname,"evn_shortname");
		checklist($evn_thainame,"evn_thainame");
		checklist($evn_print,"evn_print");
		checklist($evn_used,"evn_used");
		if($flag){
			$mesg = "Please input data in ";
			while(list($key,$value) = each($data)){
				if(empty($value)){
				if(!ereg("evn_shortname|evn_fullname",$name))
						$str .= "$key,";
				}  //if(empty($value)){
				//$str = substr( $str, strlen($str)-1, 1 );
			}
			echo errmesg ("$mesg $str");			
		}	//if($flag){
		else{
			if ($action=="a"){
				$data["evn_id"] = "";
				$data["usr_cre"] = $_SESSION["usr_name"];
				$data["date_cre"] = date("Y/m/d  H:i:s");				
				$query = create_insert_query($table_name,$data);				
				//echo "$query<br>";
				mysql_query($query) or die("Insert error");		
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");			
				//Show alert by javascript
				echo "<script>
						alert ('Insert complete');
						window.location = 'evn_viewForm.php';
					  </script>";
				exit();
			} //if ($action=="a"){
			
			if ($action=="e"){
				$data["usr_upd"] = $_SESSION["usr_name"];
				$data["date_upd"] = date("Y/m/d  H:i:s");				
				$query = create_update_query($table_name, $data, $id, $field_id);				
				//echo "$query<br>";
				mysql_query($query) or die("Update error");		
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");			
				//Show alert by javascript
				echo "<script>
						alert ('Update complete');
						window.location = '".viewForm."';
					  </script>";
				exit();
			}  //if ($action=="e"){
			
			if ($action=="d"){
				$query = "DELETE FROM $table_name WHERE $field_id = $id " ;
				//echo "$query<br>";
				//exit();
				
				mysql_query($query) or die("Delete error");		
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");			
				//Show alert by javascript
				echo "<script>
						alert ('Delete complete');
						window.location = '".viewForm."';
					  </script>";
				exit();
			}  //if ($action=="e"){
						
		}  //else{ of if($flag){
	}  //if(!empty($Submit)){
	
?>
<script language="javascript">
	function validate() 
	{
		if(frm.evn_shortname.value=="")
		{
			alert('Please input data in Event Name');
			frm.evn_shortname.focus()
			return false;
		}

		if(frm.evn_fullname.value=="")
		{
			alert('Please input data in Event Fullname');
			frm.evn_fullname.focus()
			return false;
		}		
	}
</script>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</body>
</html>
