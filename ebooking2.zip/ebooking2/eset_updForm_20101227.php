<?	
	ob_start();
	session_start();
	//include_once("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	//define("updSave","esch_updForm.php");
	$viewForm = "eset_viewForm.php";
	$updSave = "eset_updForm.php";
	$table_name = "ev_setup";
	$field_id = "eset_id";
	$action = $_REQUEST["a"];
    $evn_id = $_REQUEST["id"];
	$id2 = $_REQUEST["id2"];
	$sd_ed = $_REQUEST["id3"];
	if ($sd_ed) 	list($stDate,$enDate,$stTime,$enTime) = explode(",",$sd_ed);
	if ($stDate) $stDate = chgDate($stDate);
	if ($enDate) $enDate = chgDate($enDate);
	if ($stTime) $stTime = chgTime($stTime);
	if ($enTime) $enTime = chgTime($enTime);

	//echo "\$stDate =$stDate<br>\$enDate = $enDate<br>";
	/*
	echo "
		\$action = $action<br> 
		\$viewForm  = $viewForm <br>
		\$updSave = $updSave<br>
		\$table_name = $table_name<br>
		\$field_id = $field_id<br>
		\$id2 = $id2<br>
	";
	*/
	if ($action == "a"){
		$caption = "Insert  "  ;
		$button = "Save";
	}
	if ($action == "e"){
		$caption = "Edit  "  ;
		$button = "Update";
	}
	if ($action == "d"){
		$caption = "Delete  "  ;
		$button = "Delete";
	}
	
	//======================Begin prepare standard data======================================
		
	if(!empty($evn_id)){
		$sql = "SELECT * FROM eventname WHERE evn_id = '$evn_id'  ";
		//echo "$sql<br>";
		//exit();
		$result = getData($sql);
		$row = mysql_fetch_array($result);
		$disabled = "";
		//if($row[3] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;
		if($row["evn_used"] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;
		$evn_name = $row["evn_shortname"];
	} //if(!empty($ev_id)){	

		$sql = "SELECT dep_id, dep_code , dep_name  FROM department 
					ORDER BY dep_code ";
		//echo "$sql<br>";
		//exit();
		$reseset_dep_id = getData($sql);	
		
		$sql = "SELECT loc.loc_id, loc.loc_shortname, loc.loc_fullname,
					eloc.eloc_event_date, eloc.eloc_event_time, eloc.eloc_end_date, eloc.eloc_end_time
					FROM location loc, ev_location eloc 
					WHERE loc.loc_id = eloc.loc_id
					AND eloc.evn_id = '$evn_id'  					
					ORDER BY loc.loc_id
					";
		//echo "$sql<br>";
		$reseset_loc_id= getData($sql);	
		
	//======================End prepare stand data========================================


	//======================Begin select data from ev_setup===============================
	if (!empty($evn_id) && !empty($id2)){
		$sql = "SELECT * FROM $table_name WHERE evn_id = '$evn_id'  
					 AND $field_id = '$id2' ";
		//echo "$sql<br>";
		//exit();
		$result = getData($sql);
		$numrow = mysql_num_rows($result);
		$rs_eset = mysql_fetch_array($result);	
		
		$eset_beg_date = $rs_eset["eset_beg_date"];
		$eset_end_date = $rs_eset["eset_end_date"];
		$eset_beg_time = $rs_eset["eset_beg_time"];
		$eset_end_time = $rs_eset["eset_end_time"];
		$eset_dep_id = $rs_eset["eset_dep_id"];
		$eset_loc_id = $rs_eset["eset_loc_id"];
		$eset_dest = $rs_eset["eset_dest"];

		//echo "$rs_esta[2]<br>";
	} //if (!empty($evn_id)){
	
	
	
?>
<html>
<script language="javascript">
	function validate() 
	{
		if(frm.eset_beg_date.value=="")
		{
			alert('Please input data in Begin Date');
			frm.eset_beg_date.focus()
			return false;
		}
		
		if(frm.eset_end_date.value=="")
		{
			alert('Please input data in End Date');
			frm.eset_end_date.focus()
			return false;
		}
		if(frm.eset_beg_time.value=="")
		{
			alert('Please input data in Start Time');
			frm.eset_beg_time.focus()
			return false;
		}
		if(frm.eset_end_time.value=="")
		{
			alert('Please input data in End Time');
			frm.eset_end_time.focus()
			return false;
		}
		if(frm.eset_dep_id.value=="")
		{
			alert('Please input data in Department');
			frm.eset_dep_id.focus()
			return false;
		}
		if(frm.eset_loc_id.value=="")
		{
			alert('Please input data in Location');
			frm.eset_loc_id.focus()
			return false; 
		}
		var chkdesc = frm.eset_dest.value;
		if(trimAll(chkdesc)=="" )
		{
			alert('Please input data in Description');
			frm.eset_dest.focus();
			return false;
		}			
	}
	
	function trimAll( strValue ) {
	 var objRegExp = /^(\s*)$/;
		//check for all spaces
		if(objRegExp.test(strValue)) {
		   strValue = strValue.replace(objRegExp, '');
		   if( strValue.length == 0)
			  return strValue;
		}
	
	   //check for leading & trailing spaces
	   objRegExp = /^(\s*)([\W\w]*)(\b\s*$)/;
	   if(objRegExp.test(strValue)) {
		   //remove leading and trailing whitespace characters
		   strValue = strValue.replace(objRegExp, '$2');
		}
	  return strValue;
	}
	
	function chkDateTime() {
		if(document.frm.eset_beg_date.value == ""){
			var Digital=new Date() ;			
			var yyyy = Digital.getYear() ;
			var mm = Digital.getMonth()+1;
			var dd= Digital.getDate();
			document.frm.eset_beg_date.value = dd + "/" + mm + "/" + yyyy ;			
			return false;
		}		
		
		if(document.frm.eset_end_date.value == ""){
			var Digital=new Date() ;			
			var yyyy = Digital.getYear() ;
			var mm = Digital.getMonth()+1;
			var dd= Digital.getDate();
			document.frm.eset_end_date.value = dd + "/" + mm + "/" + yyyy ;			
			return false;
		}		
		
		if(document.frm.eset_beg_time.value == ""){
			document.frm.eset_beg_time.value = "08:00";			
			return false;
		}		
		
		if(document.frm.eset_end_time.value == ""){
			document.frm.eset_end_time.value = "18:00";
			return false;
		}				
	}
	function cancel(val) 
	{
		window.open(val,"frame_details");
	}
</script>

<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">
<script language="javascript" type="text/javascript" src="datetimepicker.js"></script>

</head>
	
<body >
<form action="<?=$updSave ?>?a=<?=$action ;?>&id=<?=$evn_id?>&id2=<?=$id2?>" method="post" name="frm"  id="frm"onSubmit="return validate();">
  <table border="0" class="BorderGreen">
    <tr class="BorderSilver">
      <td colspan="4" style="background-color:#339900;font-weight:bold;color:White;">
	  	<div align="center"><strong >
	  	  <?=$caption ;?>
  	    Setup Instructions Maintenance  - <?=$evn_id." - " .$evn_name ?></strong></div>
	  </td>
    </tr>
	<tr>
	  <td height="27" colspan="4"><div align="center">
        <input name="eset_id" type="hidden" id="eset_id" value="<?=$evn_id ?>">
	  </div></td>
    </tr>		
		<tr>
		  <td width="213" ><div align="right">Start Date : </div></td>
		  <td width="339" colspan="2"><div align="left">
		    <input name="eset_beg_date" type="text" id="eset_beg_date"  onBlur="chkDateTime();"
			value="<? if($eset_beg_date) echo chgDate($eset_beg_date); else echo $stDate ;?>" size="10" maxlength="10">		    
		    <a href="javascript:NewCal('eset_beg_date','ddmmyyyy',false,12)">
			<img src="images/cal.gif" width="16" height="16" border="0" alt="Pick a date"></a></div></td>
    </tr>
		<tr>
		  <td height="21" ><div align="right">End Date : </div></td>
		  <td colspan="2" ><input name="eset_end_date" type="text" id="eset_end_date" onBlur="chkDateTime();"
		  value="<? if($eset_end_date) echo chgDate($eset_end_date); else echo $enDate ;?>" size="10" maxlength="10">
	      <a href="javascript:NewCal('eset_end_date','ddmmyyyy',false,12)">
		  <img src="images/cal.gif" width="16" height="16" border="0" alt="Pick a date"></a></td>
    </tr>
		<tr>
		  <td ><div align="right">Start Time : </div></td>
		  <td colspan="2" ><div align="left">
		    <input name="eset_beg_time" type="text" id="eset_beg_time" 
			value="<? if($eset_beg_time) echo chgTime($eset_beg_time); else echo $stTime ;?>" 
			size="5" maxlength="5" onBlur="chkDateTime();"></div></td>
    </tr>
		<tr>
		  <td ><div align="right">End Time : </div></td>
		  <td colspan="2" ><input name="eset_end_time" type="text" id="eset_end_time" 
			value="<? if($eset_end_time) echo chgTime($eset_end_time); else echo $enTime ;?>" 
		  size="5" maxlength="5" onBlur="chkDateTime();"></td></tr>
		<tr>
		  <td ><div align="right">Department : </div></td>
		  <td colspan="2" ><div align="left">
		    <select name="eset_dep_id" id="eset_dep_id">
			<?			
			  	$data = $eset_dep_id;
			  	while($eset_dep_id  =  mysql_fetch_array($reseset_dep_id)){
					$val_eset_dep_id = "$eset_dep_id[dep_code] - $eset_dep_id[dep_name]"; ?>				
					<option value=' <?=$eset_dep_id["dep_id"]?>'  <?  if($eset_dep_id["dep_id"]==$data) echo "selected" ?> 
					><?=$val_eset_dep_id ?></option>				
			  <?	
				}
			  ?>
	        </select>
		  </div></td>
    </tr>
		<tr>
		  <td ><div align="right">Location : </div></td>
		  <td colspan="2" ><div align="left">
		    <select name="eset_loc_id" id="eset_loc_id">
			  <?
			  	$data = $eset_loc_id;
				while($eset_loc_id  =  mysql_fetch_array($reseset_loc_id)){
					$val_eset_loc_id = "$eset_loc_id[loc_shortname] - $eset_loc_id[loc_fullname]"; ?>
					<option value='<?=$eset_loc_id["loc_id"]?>' <?  if($eset_loc_id["loc_id"]==$data) echo "selected" ?> 
					><?=$val_eset_loc_id ?></option>										 
			 <?	
				}
			  ?>
	        </select>
		  </div></td>
    </tr>
		<tr>
		  <td height="27" ><div align="right">Description :
	      </div>		    
		    <div align="right"></div></td>
		  <td colspan="2" ><div align="left">
		    <textarea name="eset_dest" cols="65" rows="5" id="eset_dest" value="<?=($eset_dest);?>"><?=$eset_dest;?>
		    </textarea>
			
		  </div></td>
    </tr>
		<tr>
		  <td ><div align="right"></div></td>
		  <td colspan="2" ><div align="left"></div></td>
    </tr>
    <tr align="center" >
      <td colspan="3">	  	
  	    <div align="center">
			<input name="Submit2" type="button" class="Button" value="&lt;= Back " onClick="window.location = 'esch_viewForm.php?id=<?=$evn_id?>'" >
			<input name="Submit" type="submit" class="Button" value="<?=$button?>" <?=$disabled ;?> >
			<input name="Button" type="button" class="Button" id="Button"  onClick="cancel('eset_viewForm.php?id=<?=$evn_id ;?>');"  value="Cancel" >
          </div></td>
    </tr>
  </table>
</form>
<?

	//======================Begin Save Data==============================================
	//request data into varible
	$Submit = $_REQUEST["Submit"];
	//$eset_id = $_REQUEST["id2"];
	if(!empty($Submit)){
		$a_eset_dep_id = $_REQUEST["eset_dep_id"];
		$a_eset_beg_date = chgDateToDb($_REQUEST["eset_beg_date"]);
		$a_eset_end_date = chgDateToDb($_REQUEST["eset_end_date"]);
		$a_eset_beg_time = chgTimeToDb($_REQUEST["eset_beg_time"]);
		$a_eset_end_time = chgTimeToDb($_REQUEST["eset_end_time"]);
		$a_eset_loc_id = $_REQUEST["eset_loc_id"];
		$a_eset_dest = $_REQUEST["eset_dest"];
		$a_eset_dest = htmlspecialchars($a_eset_dest);
		
	/*	echo "
		eset_id = $eset_id<br>
		submit = $Submit<br>
		evn_id =  $evn_id<br>
		a_eset_dep_id = $a_eset_dep_id<br> 
		a_eset_beg_date = $a_eset_beg_date<br>
		a_eset_end_date = $a_eset_end_date <br> 
		a_eset_beg_time = $a_eset_beg_time<br>
		a_eset_end_time = $a_eset_end_time<br>
		a_eset_loc_id = $a_eset_loc_id<br>
		a_eset_dest = $a_eset_dest <br>
		";*/
		/*
		//check duplicate data in table ev_setup
		$sql = "SELECT evn_id FROM ev_setup WHERE evn_id = '$evn_id'  AND  eset_id = '$eset_id' ";
		echo "$sql<br>";
		
		$result = getData($sql);
		$numrow = mysql_num_rows($result);
		$row = mysql_fetch_array($result);
		//echo "numrow = $numrow<br>";
		if ($numrow == 0 ){
				$action = "add";}
			else{
				$action = "edit";
		}
		//echo "action=$action<br>";
		*/
		function  checklist($value,$label,$field){
			global $resNull;	global $resData;global $flag; global $strPattern;
			$strPattern = "Department|Start Date|End Date|StartTime|End Time|
									  Location|Detail| ";									  
			if(empty($value)){
				if(ereg($strPattern,$label)){
					$flag = 1;
					$resNull[$label] = $value;
				} //if(ereg($strPattern,$label)){			
			} //if(empty($var)){
			$resData[$field] = $value;
		} //function checklist($var,$name){
		
		//checklist($evn_id,"","evn_id");
		checklist($a_eset_dep_id,"Department","eset_dep_id");
		checklist($a_eset_beg_date,"Start Date","eset_beg_date");
		checklist($a_eset_end_date,"End Date","eset_end_date");
		checklist($a_eset_beg_time,"StartTime","eset_beg_time");
		checklist($a_eset_end_time,"End Time","eset_end_time");
		checklist($a_eset_loc_id,"Location","eset_loc_id");
		checklist($a_eset_dest,"Detail","eset_dest");
		
	//	echo "flag = $flag<br>";
		/*
		if($flag){
			$mesg = "Please input data in ";
			while(list($key,$value) = each($resNull)){
				if(empty($value)){
					if(!ereg($strPattern,$name))	
						$str .= "$key, ";
				}  //if(empty($value)){
			} //while(list($key,$value) = each($resNull)){
			$str = substr($str, 0, strlen($str) -2 ); 
			echo errmesg ("$mesg $str");			
			
		}	//if($flag){
		else
		*/
		{
			if($action=="a"){
				$resData["evn_id"] = $evn_id;
				$resData["usr_cre"] = $_SESSION["usr_name"];
				$resData["date_cre"] = date("Y/m/d  H:i:s");		
				
				$query = create_insert_query("$table_name",$resData);	
				//echo "$query<br>";
				mysql_query($query) or die("Insert  $table_name error");	
				//$SaveLog=updLog($_SESSION['username'], $updSave, "$query");					
				//Show alert by javascript
				echo "<script>
						alert ('Insert $table_name complete');
						window.location = '$updSave?a=a&id=$evn_id&id3=$a_eset_beg_date,$a_eset_end_date,$a_eset_beg_time,$a_eset_end_time';
					  </script>";
				exit();
			} // if($action=="a"){
			
			if($action=="e"){
				$resData["usr_upd"] = $_SESSION["usr_name"];
				$resData["date_upd"] = date("Y/m/d  H:i:s");		
				
				$query = create_update_query("$table_name", $resData, $evn_id, "evn_id");				
				$query .= " AND $field_id = $id2 ";
				//echo "$query<br>";
				//exit();
				mysql_query($query) or die("Update $table_name error");		
				//$SaveLog=updLog($_SESSION['username'], $updSave, "$query");
				//Show alert by javascript
				echo "<script>
						alert ('Update $table_name complete');
						window.location = '$viewForm?id=$evn_id' ;
					  </script>";
				exit();
			} // if($action=="e"){
			
			if ($action=="d"){
				$query = "DELETE FROM $table_name WHERE $field_id = $id2 " ;
				//echo "$query<br>";
				//exit();
				
				mysql_query($query) or die("Delete $table_name error");	
				$SaveLog=updLog($_SESSION['username'], $updSave, "$query");	
				//Show alert by javascript
				echo "<script>
						alert ('Delete $table_name complete');
						window.location = '$viewForm?id=$evn_id' ;
					  </script>";
				exit();
			}  //if ($action=="d"){
			
		} //else{

	} //if(!empty($Submit)){
	
	//======================End Save Data==============================================
?>
