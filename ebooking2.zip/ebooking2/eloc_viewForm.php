<?
	ob_start(); 
	session_start();
	//include("db/chksession.db.php");
	$evn_id = $_REQUEST["id"];
	define("sysName","Location");
	define("tableName","ev_location");
	define("viewForm","eloc_viewForm.php");
	define("updForm","eloc_updForm.php");	
	define("addForm","edbk_viewForm.php");	
	define("field_id","eloc_id");	
	define("beg_id",2);	
	define("end_id",8);		
	
	$sql = "SELECT eloc.eloc_id, loc.loc_id,loc.loc_shortname, loc.loc_fullname, 
				eloc.eloc_in_date, eloc.eloc_out_date,
				eloc.eloc_g_total, eloc.eloc_g_adjust, eloc.eloc_g_net
				FROM location loc, ev_location eloc
				WHERE loc.loc_id = eloc.loc_id 
				AND eloc.evn_id = '$evn_id'  
				ORDER BY eloc.eloc_in_date, eloc.eloc_in_time,  loc.loc_shortname
				";
	//echo "$sql";
	//exit();
	define("query","$sql");
		
	$cap_name = array();
	$cap_name = array("#","Loc id","Room","Location","In Date","Out Date","Rental Amt","Rate Adj","Net");
	
	//=============check authorize================
	$key = array_keys($_SESSION["sec_add"], viewForm); 
	if($key[0])
		define("insert",1);		
	else
		define("insert",0);			
		
	$key = array_keys($_SESSION["sec_edit"], viewForm); 
	if($key[0])
		define("edit",1);		
	else
		define("edit",0);			
		
	$key = array_keys($_SESSION["sec_del"], viewForm); 
	if($key[0])
		define("del",0);		
	else
		define("del",0);			
		
	include("func/ev_viewForm.func1.php");
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</body>
</html>
