<?	
	session_start();
	include_once("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	
	$show = $_REQUEST["s"];

	
	
	$arrOption=$_SESSION[searchOption];
	$arrUsr=$_SESSION[arrUsr];
	$arrContact=$_SESSION[arrContact];
	$arrComp=$_SESSION[arrComp];
	$arr_bks=$_SESSION[arr_bks];
//	echo "arr_bks=<pre>";print_r($arr_bks); //exit();
//	echo "arrOption=<pre>";print_r($arrOption); //exit();
	$cboFrMonth = $arrOption[cboFrMonth];
	$cboFrYear = $arrOption[cboFrYear];
	$cboToMonth = $arrOption[cboToMonth];
	$cboToYear = $arrOption[cboToYear];
	$rdoSumby = $arrOption[rdoSumby];
	$bus_code =  $arrOption[bus_code];
	$src_code = $arrOption[src_code];
	$chkSaleName= $arrOption[chkSaleName];
	$usr_id = $arrOption[usr_id];
	$chkContactName= $arrOption[chkContactName];
	$contact = $arrOption[contact];
	$chkComName= $arrOption[chkComName];
	$company = $arrOption[company];
	$chkBkgStatus = $arrOption[chkBkgStatus];
	$bks_id = $arrOption[bks_id];
	$chkIn = $arrOption[chkIn];
	$chkShow = $arrOption[chkShow];
	$chkOut = $arrOption[chkOut];
	
	$month = array('January','February','March','April','May','June','July','August','September','October','November','December')  ;
	if($rdoSumby=="Nature of Event")	{$chkfield = "esta_event"; $chkValue=$bus_code;}
	if($rdoSumby=="Nature of Business Code")	 {$chkfield = "esta_bus_code"; $chkValue=$src_code;}
	
	if($cboFrMonth){
		$strFrMonth = $cboFrMonth ;		
		if (strlen($cboFrMonth) == 1) $strFrMonth = '0'.$cboFrMonth ;		
	}	
	if($cboToMonth){
		$strToMonth = $cboToMonth ;		
		if (strlen($cboToMonth) == 1) $strToMonth = '0'.$cboToMonth ;		
	}		
	
	
	###########  Default Date  ##############
	$default_begMonth = default_begin_month;
	$default_endMonth = default_end_month;
	//echo "\$default_begMonth=$default_begMonth<hr>";
	if($default_begMonth){
		$begFrYear = $cboFrYear - 1 ;
		$begMonth = $default_begMonth ;
	}else{
		$begFrYear = $cboToYear ;
		$begMonth = 01 ;
	}//if($default_begMonth){
	
	
		#get value from miscode
		$sql =  "SELECT mis_code, mis_name,mis_name					
					FROM miscode
					WHERE  mis_type = '$rdoSumby'";				
		if($chkValue) $sql .=	" AND mis_code in ($chkValue)";
		$sql.=" ORDER BY mis_name ";
//		echo "$sql<hr>";
		//exit();
		$result = getData($sql);		
		$arr_mis = array();
		while($rs_mis = mysql_fetch_array($result)){
			$id = $rs_mis["mis_code"]." - ".$rs_mis["mis_name"];
			$arr_mis[$id] = $rs_mis["mis_name"] ;
		} // while($rs_mis = mysql_fetch_array($result)){
//		echo "\$arr_mis=<pre>" ; print_r($arr_mis); echo "<hr>";
		
		$arr_val = array('mtd','ytd');
		for($i = 0; $i <count($arr_val);$i++){
			## get Event ID ##
			$n = 0 ;		
			$evn_sql = "SELECT evn.evn_id , evn.evn_shortname , eloc.eloc_in_date , eloc.eloc_event_date ";
			$evn_sql .= " , eloc.eloc_end_date , eloc.eloc_out_date , esta.$chkfield ";
			$evn_sql .= " FROM eventname evn , ev_location eloc , ev_statistics esta ";
			$evn_sql .= " WHERE 1";
			$evn_sql .= " AND evn.evn_id = eloc.evn_id";
			$evn_sql .= " AND esta.evn_id = eloc.evn_id";
			$evn_sql .= " AND ( ";
			if($chkIn){
				if($n <> 0){$evn_sql .= "OR" ;}else{$evn_sql .= "";	$n +=1 ;}
				if($arr_val[$i]=='mtd'){
					$evn_sql .= " (left(eloc.eloc_in_date,6) >= '$cboFrYear$strFrMonth'";
					$evn_sql .= " 		AND left(eloc.eloc_in_date,6) <= '$cboToYear$strToMonth') ";
				}//if($arr_val[$i]=='mtd'){
				if($arr_val[$i]=='ytd'){
					$evn_sql .= " (left(eloc.eloc_in_date,6) >= '$begFrYear$begMonth'";
					$evn_sql .= " 		AND left(eloc.eloc_in_date,6) <= '$cboToYear$strToMonth') ";
				}//if($arr_val[$i]=='ytd'){
			}
			if($chkShow){
				if($n <> 0){$evn_sql .= "OR" ;}else{$evn_sql .= "";	$n +=1 ;}
				if($arr_val[$i]=='mtd'){
					$evn_sql .= " (left(eloc.eloc_event_date,6) >= '$cboFrYear$strFrMonth'";
					$evn_sql .= " 		AND left(eloc.eloc_end_date,6) <= '$cboToYear$strToMonth' ) ";
				}//if($arr_val[$i]=='mtd'){
				if($arr_val[$i]=='ytd'){
					$begFrYear = $cboFrYear - 1 ;
					$evn_sql .= " (left(eloc.eloc_event_date,6) >= '$begFrYear$begMonth'";
					$evn_sql .= " 		AND left(eloc.eloc_end_date,6) <= '$cboToYear$strToMonth' ) ";
				}//if($arr_val[$i]=='ytd'){
				
			}
			if($chkOut){
				if($n <> 0){$evn_sql .= "OR" ;}else{$evn_sql .= "";	$n +=1 ;}			
				if($arr_val[$i]=='mtd'){
					$evn_sql .= " (left(eloc.eloc_out_date,6) >= '$cboFrYear$strFrMonth'";
					$evn_sql .= " 		AND left(eloc.eloc_out_date,6) <= '$cboToYear$strToMonth' ) ";
				}//if($arr_val[$i]=='mtd'){
				if($arr_val[$i]=='ytd'){
					$evn_sql .= " (left(eloc.eloc_out_date,6) >= '$begFrYear$begMonth'";
					$evn_sql .= " 		AND left(eloc.eloc_out_date,6) <= '$cboToYear$strToMonth' ) ";
				}//if($arr_val[$i]=='ytd'){
			}
			$evn_sql .= " )";
			if($chkBkgStatus && $bks_id <> 0) $evn_sql .= " AND esta.bks_id in ($bks_id) ";	
			$evn_sql .= " GROUP BY evn.evn_id";
//			echo "\$evn_sql=$evn_sql<hr>";
			$evn_result = getData($evn_sql);					
			while($evn_rs = mysql_fetch_array($evn_result)){
				if($arr_val[$i]=='mtd'){
					$evnID[$evn_rs["evn_id"]] = "'" .$evn_rs["evn_id"] . "'";			
					$arr_mtd_count2[$evn_rs["evn_id"]] = $evn_rs[$chkfield];
					$arr_mtd_sum2[$evn_rs[$chkfield]] = 0 ;
				}//if($arr_val[$i]=='mtd'){
				
				if($arr_val[$i]=='ytd'){
					$evnID_ytd[$evn_rs["evn_id"]] = "'" .$evn_rs["evn_id"] . "'";			
					$arr_ytd_count3[$evn_rs["evn_id"]] = $evn_rs[$chkfield];
					$arr_ytd_sum2[$evn_rs[$chkfield]] = 0 ;
				}//if($arr_val[$i]=='ytd'){
			}//while($evn_id = mysql_fetch_array($evn_result)){
		}//for($i = 0; $i <count($arr_val);$i++){
		is_array($evnID) ? $strEvnID_mtd = implode(",",$evnID) : $strEvnID_mtd = "";
		is_array($evnID_ytd) ? $strEvnID_ytd = implode(",",$evnID_ytd) : $strEvnID_ytd = "";
		
		
		
//		echo "\$evnID=<pre>"; print_r($evnID); echo "<hr>";
//		echo "\$evnID_ytd=<pre>"; print_r($evnID_ytd); echo "<hr>";
//		echo "\$strEvnID_mtd=$strEvnID_mtd<hr>" ;
//		echo "\$strEvnID_ytd=$strEvnID_ytd<hr>" ;

			
			#get value from ev_revenue for Month to date & Year to date
			$arr_val = array('mtd','ytd');
			for($i = 0; $i <count($arr_val);$i++){
				//$sql = "";
				$sql =  "SELECT erev.evn_id , $chkfield , ";
				$sql .= " sum(erev.rev_total) as 'rental' ";
				$sql .= " FROM ev_revenue erev , ev_statistics esta ";
				$sql .= " WHERE erev.evn_id = esta.evn_id ";
				$sql .= " AND erev.rev_type like 'space%' ";
				if($chkBkgStatus && $bks_id <> 0) $sql .= " AND esta.bks_id in ($bks_id) ";		
				
				if ($arr_val[$i]=='mtd'){
					$sql .= " AND left(rev_date,6) >= '$cboFrYear$strFrMonth' ";
					$sql .= " AND left(rev_date,6) <= '$cboToYear$strToMonth' ";
				} // if ($arr_val[$i]=='mtd'){
				if ($arr_val[$i]=='ytd'){
					$sql .= " AND left(rev_date,6) >= '$begFrYear$begMonth' ";
					$sql .= " AND left(rev_date,6) <= '$cboToYear$strToMonth' ";
				} // if ($arr_val[$i]=='ytd'){
				$sql .= " AND rev_source in ('$chkIn','$chkShow','$chkOut')";
				$sql .= " GROUP BY $chkfield, erev.evn_id
							 ORDER BY erev.evn_id ASC , $chkfield
							";
	
	
				$sql_sum =  "SELECT $chkfield, sum(erev.rev_total) as 'rental' ";
				$sql_sum .= " FROM ev_revenue erev , ev_statistics esta 
							WHERE erev.evn_id = esta.evn_id				
							AND erev.rev_type like 'space%' ";
				if($chkBkgStatus && $bks_id <> 0) $sql_sum .= " AND esta.bks_id in ($bks_id) ";			
							
				if ($arr_val[$i]=='mtd'){
					$sql_sum .= " AND left(rev_date,6) >= '$cboFrYear$strFrMonth' ";
					$sql_sum .= " AND left(rev_date,6) <= '$cboToYear$strToMonth' ";
				} // if ($arr_val[$i]=='mtd'){
				if ($arr_val[$i]=='ytd'){
					$sql_sum .= " AND left(rev_date,6) >= '$begFrYear$begMonth' ";
					$sql_sum .= " AND left(rev_date,6) <= '$cboToYear$strToMonth' ";
				} // if ($arr_val[$i]=='ytd'){
				$sql_sum .= " AND rev_source in ('$chkIn','$chkShow','$chkOut')";
				$sql_sum .= " GROUP BY $chkfield
							 ORDER BY $chkfield
							";
//				echo "\$sql = <br>$sql<br>";
				//echo "\$sql_sum = <br>$sql_sum<br><br><br>";		
				//exit();
				$result = getData($sql);					
				$result_sum = getData($sql_sum);		
							
				#get detail 
				$arr_mtd_count = array();
				while($rs_val = mysql_fetch_array($result)){
					$id = $rs_val["evn_id"];
					$g_id = $rs_val[$chkfield];
									
//					echo "rental[$id] = " . $rs_val["rental"]; echo "<br>";

					#get value from mtd
					if ($arr_val[$i]=='mtd') {
						$arr_mtd[$id] = $rs_val["rental"] ;
						$arr_mtd_count[$id] = $rs_val[$chkfield] ;
						if ($id <> $o_id ) {
							$o_id = $id ;
							$mtd_id .= "'".$id."' ," ;
						} // if ($id <> $o_id ) {
					} // if ($arr_val[$i]=='mtd') {
				
					#get value from ytd
					if ($arr_val[$i]=='ytd') {
						$arr_ytd[$id] = $rs_val["rental"] ;
						$arr_ytd_count[$id] = $rs_val[$chkfield] ;
						if ($id <> $o_id ) {
							$o_id = $id ;
							$ytd_id .= "'".$id."' ," ;
						} // if ($id <> $o_id ) {
					} // if ($arr_val[$i]=='ytd') {
				} // while($rs_val = mysql_fetch_array($result)){			
				
				#get summary 
				while($rs_val_sum = mysql_fetch_array($result_sum)){
					$id = $rs_val_sum[$chkfield];
					#get value from mtd
					if ($arr_val[$i]=='mtd') {
						$arr_mtd_sum[$id] = $rs_val_sum["rental"] ;
					} // if ($arr_val[$i]=='mtd') {
					
					#get value from ytd
					if ($arr_val[$i]=='ytd') {
						$arr_ytd_sum[$id] = $rs_val_sum["rental"] ;
					} // if ($arr_val[$i]=='mtd') {
				} // while($rs_val_sum = mysql_fetch_array($result_sum)){
	
			} // for($i = 0; $i <count($arr_val);$i++){

			
			
			

		
			//#get value from ev_revenue for Month to date & Year to date  ------------ 2
//			$arr_val = array('mtd','ytd');
//			for($i = 0; $i <count($arr_val);$i++){
//				
//				$sql =  "SELECT erev.evn_id , $chkfield , sum(erev.rev_total) as 'rental' ";
//				$sql .= " FROM ev_revenue erev , ev_statistics esta";
//				$sql .= " WHERE 1";
//				$sql .= " AND erev.evn_id = esta.evn_id";
//				$sql .= " AND erev.rev_type like 'space%'";
//				if($chkBkgStatus && $bks_id <> 0) $sql .= " AND esta.bks_id in ($bks_id) ";		
//							
//				if ($arr_val[$i]=='mtd'){
//					$sql .= " AND left(rev_date,6) >= '$cboFrYear$strFrMonth' ";
//					$sql .= " AND left(rev_date,6) <= '$cboToYear$strToMonth' ";
//				} // if ($arr_val[$i]=='mtd'){
//				if ($arr_val[$i]=='ytd'){
//					$sql .= " AND left(rev_date,4) >= '$cboFrYear' ";
//					$sql .= " AND left(rev_date,6) <= '$cboToYear$strToMonth' ";
//				} // if ($arr_val[$i]=='ytd'){
//				$sql .= " AND rev_source in ('$chkIn','$chkShow','$chkOut')";
//				$sql .= " GROUP BY $chkfield, erev.evn_id
//							 ORDER BY $chkfield, erev.evn_id
//							";
//	
//	
//				$sql_sum =  "SELECT $chkfield, ";
//				if ($arr_val[$i]=='mtd'){
//					$sql_sum .= " if(erev.evn_id IN($strEvnID) , sum(erev.rev_total) , 0 ) as 'rental' ";
//				}
//				if ($arr_val[$i]=='ytd'){
//					$sql_sum .= "  sum(erev.rev_total) as 'rental' ";
//				}
//				$sql_sum .= " FROM ev_revenue erev , ev_statistics esta";
//				$sql_sum .= " WHERE erev.evn_id = esta.evn_id ";
//				$sql_sum .= " AND erev.rev_type like 'space%' ";
//				
//				if($chkBkgStatus && $bks_id <> 0) $sql_sum .= " AND esta.bks_id in ($bks_id) ";			
//							
//				if ($arr_val[$i]=='mtd'){
//					$sql_sum .= " AND left(rev_date,6) >= '$cboFrYear$strFrMonth' ";
//					$sql_sum .= " AND left(rev_date,6) <= '$cboToYear$strToMonth' ";
//				} // if ($arr_val[$i]=='mtd'){
//				if ($arr_val[$i]=='ytd'){
//					$sql_sum .= " AND left(rev_date,4) >= '$cboFrYear' ";
//					$sql_sum .= " AND left(rev_date,4) <= '$cboToYear' ";
//				} // if ($arr_val[$i]=='ytd'){
//				$sql_sum .= " AND rev_source in ('$chkIn','$chkShow','$chkOut')";
//				$sql_sum .= " GROUP BY $chkfield , erev.evn_id
//							 ORDER BY $chkfield
//							";
//				echo "\$sql = <br>$sql<br>";
//				echo "\$sql_sum = <br>$sql_sum<br><br><br>";		
//				//exit();
//				$result = getData($sql);					
//				$result_sum = getData($sql_sum);					
//				#get detail 
//				
//				while($rs_val = mysql_fetch_array($result)){
//					$id = $rs_val["evn_id"];
//					$g_id = $rs_val[$chkfield];
//									
//					//echo "rental = " . $rs_val["rental"]; echo "<br>";
//					
//					
//						#get value from mtd
//					if ($arr_val[$i]=='mtd') {
//						$arr_mtd[$id] = $rs_val["rental"] ;
//						$arr_mtd_count[$id] = $rs_val[$chkfield] ;
//						if ($id <> $o_id ) {
//							$o_id = $id ;
//							$mtd_id .= "'".$id."' ," ;
//						} // if ($id <> $o_id ) {
//					} // if ($arr_val[$i]=='mtd') {
//				
//					#get value from ytd
//					if ($arr_val[$i]=='ytd') {
//						$arr_ytd[$id] = $rs_val["rental"] ;
//						$arr_ytd_count[$id] = $rs_val[$chkfield] ;
//						if ($id <> $o_id ) {
//							$o_id = $id ;
//							$ytd_id .= "'".$id."' ," ;
//						} // if ($id <> $o_id ) {
//					} // if ($arr_val[$i]=='ytd') {
//						
//				} // while($rs_val = mysql_fetch_array($result)){			
//
//				
//				#get summary 
//				while($rs_val_sum = mysql_fetch_array($result_sum)){
//					$id = $rs_val_sum[$chkfield];
//					#get value from mtd
//					if ($arr_val[$i]=='mtd') {
//						$arr_mtd_sum[$id] += $rs_val_sum["rental"] ;
//						echo "$id => ".$rs_val_sum["rental"]."<br>";
//					} // if ($arr_val[$i]=='mtd') {
//					
//					#get value from ytd
//					if ($arr_val[$i]=='ytd') {
//						$arr_ytd_sum[$id] += $rs_val_sum["rental"] ;
//					} // if ($arr_val[$i]=='mtd') {
//				} // while($rs_val_sum = mysql_fetch_array($result_sum)){
//	
//			} // for($i = 0; $i <count($arr_val);$i++){
//		
		
########################################################################################		
//		#get value from ev_revenue for Month to date & Year to date
//		$arr_val = array('mtd','ytd');
//		for($i = 0; $i <count($arr_val);$i++){
//			//$sql = "";
//			$sql =  "SELECT erev.evn_id , $chkfield , sum(erev.rev_total) as 'rental' ";
//			/*$sql .= " FROM ev_revenue erev , ev_statistics esta, ev_staff estf, ev_customer ecus
//						WHERE erev.evn_id = esta.evn_id				
//						AND erev.evn_id=estf.evn_id  	
//						AND erev.evn_id=ecus.evn_id						
//						AND rev_type like 'space%' ";*/
//			$sql .= " FROM ev_revenue erev , ev_statistics esta ";
//			$sql .= " WHERE erev.evn_id = esta.evn_id ";
//			$sql .= " AND erev.rev_type like 'space%' ";
//			//if($chkSaleName){ $sql.=" AND estf.usr_id in ( $usr_id ) ";}
//			//if($chkContactName){ $sql.=" AND ecus.cus_id in ( $contact ) ";}						
//			//if($chkComName){ $sql.=" AND ecus.cus_id in ( $company ) ";}
//			//if($chkBkgStatus) $sql .= " AND esta.bks_id in ($bks_id) ";		
//			if($chkBkgStatus && $bks_id <> 0) $sql .= " AND esta.bks_id in ($bks_id) ";		
//						
//			if ($arr_val[$i]=='mtd'){
//				$sql .= " AND left(rev_date,6) >= '$cboFrYear$strFrMonth' ";
//				$sql .= " AND left(rev_date,6) <= '$cboToYear$strToMonth' ";
//			} // if ($arr_val[$i]=='mtd'){
//			if ($arr_val[$i]=='ytd'){
//				$sql .= " AND left(rev_date,4) >= '$cboFrYear' ";
//				$sql .= " AND left(rev_date,6) <= '$cboToYear$strToMonth' ";
//			} // if ($arr_val[$i]=='ytd'){
//			$sql .= " AND rev_source in ('$chkIn','$chkShow','$chkOut')";
//			$sql .= " GROUP BY $chkfield, erev.evn_id
//						 ORDER BY $chkfield, erev.evn_id
//						";
//
//
//			$sql_sum =  "SELECT $chkfield, sum(erev.rev_total) as 'rental' ";
//			/*$sql_sum .= " FROM ev_revenue erev , ev_statistics esta, ev_staff estf, ev_customer ecus
//						WHERE erev.evn_id = esta.evn_id				
//						AND erev.evn_id=estf.evn_id  	
//						AND erev.evn_id=ecus.evn_id						
//						AND rev_type like 'space%' ";*/
//			$sql_sum .= " FROM ev_revenue erev , ev_statistics esta 
//						WHERE erev.evn_id = esta.evn_id				
//						AND erev.rev_type like 'space%' ";
//			//if($chkSaleName){ $sql.=" AND estf.usr_id in ( $usr_id ) ";}
//			//if($chkContactName){ $sql.=" AND ecus.cus_id in ( $contact ) ";}						
//			//if($chkComName){ $sql.=" AND ecus.cus_id in ( $company ) ";}
//			//if($chkBkgStatus) $sql_sum .= " AND esta.bks_id in ($bks_id) ";	
//			if($chkBkgStatus && $bks_id <> 0) $sql_sum .= " AND esta.bks_id in ($bks_id) ";			
//						
//			if ($arr_val[$i]=='mtd'){
//				$sql_sum .= " AND left(rev_date,6) >= '$cboFrYear$strFrMonth' ";
//				$sql_sum .= " AND left(rev_date,6) <= '$cboToYear$strToMonth' ";
//			} // if ($arr_val[$i]=='mtd'){
//			if ($arr_val[$i]=='ytd'){
//				$sql_sum .= " AND left(rev_date,4) >= '$cboFrYear' ";
//				$sql_sum .= " AND left(rev_date,4) <= '$cboToYear' ";
//			} // if ($arr_val[$i]=='ytd'){
//			$sql_sum .= " AND rev_source in ('$chkIn','$chkShow','$chkOut')";
//			$sql_sum .= " GROUP BY $chkfield
//						 ORDER BY $chkfield
//						";
//			echo "\$sql = <br>$sql<br>";
//			//echo "\$sql_sum = <br>$sql_sum<br><br><br>";		
//			//exit();
//			$result = getData($sql);					
//			$result_sum = getData($sql_sum);					
//			#get detail 
//			while($rs_val = mysql_fetch_array($result)){
//				$id = $rs_val["evn_id"];
//				$g_id = $rs_val[$chkfield];
//								
//				//echo "rental = " . $rs_val["rental"]; echo "<br>";
//				
//				#get value from mtd
//				if ($arr_val[$i]=='mtd') {
//					$arr_mtd[$id] = $rs_val["rental"] ;
//					$arr_mtd_count[$id] = $rs_val[$chkfield] ;
//					if ($id <> $o_id ) {
//						$o_id = $id ;
//						$mtd_id .= "'".$id."' ," ;
//					} // if ($id <> $o_id ) {
//				} // if ($arr_val[$i]=='mtd') {
//			
//				#get value from ytd
//				if ($arr_val[$i]=='ytd') {
//					$arr_ytd[$id] = $rs_val["rental"] ;
//					$arr_ytd_count[$id] = $rs_val[$chkfield] ;
//					if ($id <> $o_id ) {
//						$o_id = $id ;
//						$ytd_id .= "'".$id."' ," ;
//					} // if ($id <> $o_id ) {
//				} // if ($arr_val[$i]=='ytd') {
//				
//			} // while($rs_val = mysql_fetch_array($result)){			
//			
//			#get summary 
//			while($rs_val_sum = mysql_fetch_array($result_sum)){
//				$id = $rs_val_sum[$chkfield];
//				#get value from mtd
//				if ($arr_val[$i]=='mtd') {
//					$arr_mtd_sum[$id] = $rs_val_sum["rental"] ;
//				} // if ($arr_val[$i]=='mtd') {
//				
//				#get value from ytd
//				if ($arr_val[$i]=='ytd') {
//					$arr_ytd_sum[$id] = $rs_val_sum["rental"] ;
//				} // if ($arr_val[$i]=='mtd') {
//			} // while($rs_val_sum = mysql_fetch_array($result_sum)){
//
//		} // for($i = 0; $i <count($arr_val);$i++){
########################################################################################

		$mtd_id = substr($mtd_id,0,-1);
		$ytd_id = substr($ytd_id,0,-1);


foreach($evnID as $key => $eValue){
	array_key_exists($key , $arr_mtd) ? $arr_mtd2[$key] = $arr_mtd[$key] : $arr_mtd2[$key] =  0 ;
}//foreach($evnID as $key => $eValue){
//echo "\$arr_mtd2=<pre>"; print_r($arr_mtd2);echo "<hr>";

foreach($evnID_ytd as $key => $eValue){
	array_key_exists($key , $arr_ytd) ? $arr_ytd2[$key] = $arr_ytd[$key] : $arr_ytd2[$key] =  0 ;
}//foreach($evnID_ytd as $key => $eValue){
//echo "\$arr_ytd2=<pre>"; print_r($arr_ytd2);echo "<hr>";

if(is_array($arr_mtd_count) && is_array($arr_mtd_count2)){
	$arr_mtd_count3 = $arr_mtd_count2 + $arr_mtd_count;
}//if(is_array($arr_mtd_count) && is_array($arr_mtd_count2)){

if(is_array($arr_ytd_count) && is_array($arr_ytd_count3)){
	$arr_ytd_count2 = $arr_ytd_count + $arr_ytd_count3;
}//if(is_array($arr_mtd_count) && is_array($arr_mtd_count2)){


//		echo "\$arr_mtd_count=<pre>"; print_r($arr_mtd_count);echo "<hr>";
//		echo "\$arr_mtd_count2=<pre>"; print_r($arr_mtd_count2);echo "<hr>";
//		echo "\$arr_mtd_count3=<pre>"; print_r($arr_mtd_count3);echo "<hr>";
//		echo "\$arr_ytd_count=<pre>"; print_r($arr_ytd_count);echo "<hr>";
//		echo "\$arr_ytd_count2=<pre>"; print_r($arr_ytd_count2);echo "<hr>";
//		echo "sizeof(\$arr_ytd_count)" . sizeof($arr_ytd_count); echo "<hr>";
//		echo "sizeof(\$arr_ytd_count2)" . sizeof($arr_ytd_count2); echo "<hr>";

//		echo "\$arr_mtd_count=<pre>"; print_r(array_count_values($arr_mtd_count)); echo "<br>";
//		echo "\$arr_mtd_count2=<pre>"; print_r(array_count_values($arr_mtd_count2)); echo "<br>";
//		echo "\$arr_mtd_count3=<pre>"; print_r(array_count_values($arr_mtd_count3)); echo "<br>";		
//		echo "\$arr_ytd_count=<pre>"; print_r(array_count_values($arr_ytd_count)); echo "<br>";
//		echo "\$arr_ytd_count2=<pre>"; print_r(array_count_values($arr_ytd_count2)); echo "<br>";
//		echo "\$arr_mtd_sum=<pre>" ; print_r($arr_mtd_sum); echo "<br>";
//		echo "\$arr_mtd_sum2=<pre>" ; print_r($arr_mtd_sum2); echo "<br>";
//		echo "\$arr_mtd_sum3=<pre>" ; print_r($arr_mtd_sum3); echo "<br>";
//		echo "\$arr_ytd_sum=<pre>" ; print_r($arr_ytd_sum); echo "<hr>";
//		echo "\$arr_mtd=<pre>"; print_r($arr_mtd);echo "<hr>";
//		echo "\$arr_ytd=<pre>"; print_r($arr_ytd);echo "<hr>" ;

//		exit();
		//$arr_mtd_sum = array();
		//$arr_ytd_sum = array();
		//$arr_mtd = array();
		//$arr_ytd = array();
		#count & summary mtd and ytd
		
		#get value from eventname, bookingstatus, ev_dateblock, ev_staff, user
		$sql = "SELECT 
						esta.evn_id, evn.evn_shortname,
						bks.bks_code,
						edbk.edbk_in_date, edbk.edbk_ev_begdate, 
						edbk.edbk_ev_enddate, edbk.edbk_out_date,
						$chkfield
					 FROM 
					 	eventname evn, 
					 	ev_statistics esta, 
					 	bookingstatus bks,
					 	ev_dateblock edbk
					 WHERE evn.evn_id = esta.evn_id
					 AND evn.evn_id = edbk.evn_id
					 AND esta.evn_id = edbk.evn_id	
					 AND esta.bks_id = bks.bks_id 
					 AND edbk_item = 0 					 
					  ";
		//if($mtd_id) 		
		if($show == "y"){$strEvnID = $strEvnID_ytd ;}else{$strEvnID = $strEvnID_mtd ;}
		if($strEvnID)
			$sql .= "AND evn.evn_id in ( $strEvnID ) ";
			$sql .= "ORDER BY esta.evn_id ";		
//		echo "\$sql=$sql<hr>";
		//exit();
		$result = getData($sql);		
		$arr_desc = array();
		while($rs_desc = mysql_fetch_array($result)){
			$id = $rs_desc["evn_id"];	
			if($show == "y"){$rental = $arr_ytd2[$id] ;}else{$rental = $arr_mtd2[$id] ;}
			$arr_desc[$id] = array($rs_desc["evn_shortname"],$rs_desc["bks_code"],$rs_desc["edbk_in_date"],$rs_desc["edbk_ev_begdate"],
				$rs_desc["edbk_ev_enddate"],$rs_desc["edbk_out_date"],$rs_desc[$chkfield] , $rental) ;			
		} // while($rs_desc = mysql_fetch_array($result)){
//		echo "<pre>"; print_r($arr_desc);
		//exit();

?>
	
<html>
<head>
<title>Show Event</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">

<style type="text/css">
<!--
body,td,th {
	font-size: xx-small;
}
.style1 {
	font-size: 12px;
	font-weight: bold;
}
.style2 {font-size: 12px}
-->
</style></head>
<body>
<form name="show_event.php" method="post" action="">
  <div align="center">    
    <table width="90%" border="0" bordercolor="#999999"  >
      <tr>
        <td colspan="12"  font-weight:bold;><div align="center" class="style1"><?=bchEname;?></div></td>
      </tr>
      <tr>
        <td colspan="12"  font-weight:bold;><div align="center" class="style2">Event Summary 
        </div></td>
      </tr>
      <tr>
        <td colspan="12"  font-weight:bold;><div align="center"><?=$month[$cboFrMonth -1]."  ".$cboFrYear. " - ".$month[$cboToMonth -1]."  ".$cboToYear?></div></td>
      </tr>
      <tr>
        <td colspan="12"  font-weight:bold;><table width="90%"  border="0" align="center">
          <tr>
            <td width="50%"><div align="right">Summary By :</div></td>
            <td width="50%"><div align="left">
              <?=$rdoSumby;?>
            </div></td>
          </tr>
          <? $styleSales='none'; if($chkSaleName) { $styleSales='display';}?>
          <tr id="Sales" style="display:<?=$styleSales;?>">
            <td><div align="right">Sales Name :</div></td>
            <td><div align="left">
              <?=multiID2str($usr_id,$arrUsr);?>
            </div></td>
          </tr>
          <? $styleContact='none'; if($chkContactName) { $styleContact='display';}?>
          <tr id="Contact" style="display:<?=$styleContact;?>">
            <td><div align="right">Contact Name :</div></td>
            <td><div align="left">
              <?=multiID2str($contact,$arrContact);?>
            </div></td>
          </tr>
          <? $styleCompany='none'; if($chkComName) { $styleCompany='display';}?>
          <tr id="Company" style="display:<?=$styleCompany;?>">
            <td><div align="right">Company Name :</div></td>
            <td><div align="left">
              <?=multiID2str($company,$arrComp);?>
            </div></td>
          </tr>
          <? $styleStatus='none'; if($chkBkgStatus) { $styleStatus='display';}?>
          <tr id="Status" style="display:<?=$styleStatus;?>">
            <td><div align="right">Booking Status :</div></td>
            <td><div align="left">
              <?=multiID2str($bks_id,$arr_bks);?>
            </div></td>
          </tr>
        </table></td>
      </tr>
      <tr style="background-color: #339900; color: White;">
        <!--<td colspan="8" rowspan="2"  font-weight:bold;><div align="left">Description [<a href="rpt_ev_summary_detail1.php">Hide</a> / <a href="rpt_ev_summary_detail1.php?s=y">Show</a>]</div></td>-->
		<td colspan="8" rowspan="2"  font-weight:bold;><div align="left">Description</div></td>
        <td colspan="2"  font-weight:bold;>
		<div align="center">(Month to Date) </div>
		<div align="center" style="font-size:10px;">[<a href="rpt_ev_summary_detail1.php">Hide</a> / <a href="rpt_ev_summary_detail1.php?s=m">Show</a>]</div>
        </td>
        <td colspan="2"  font-weight:bold;>
		<div align="center">(Year to Date)</div>       
        <div align="center" style="font-size:10px;">[<a href="rpt_ev_summary_detail1.php">Hide</a> / <a href="rpt_ev_summary_detail1.php?s=y">Show</a>]</div>
		</td>
      </tr>
      <tr style="background-color: #339900; color: White;">
        <td width="10%"  font-weight:bold;><div align="center">No. of Events</div></td>
        <td width="10%"  font-weight:bold;><div align="center">Total Revenue</div></td>
        <td width="10%"  font-weight:bold;><div align="center">No. of Events</div></td>
        <td width="10%"  font-weight:bold;><div align="center">Total Revenue</div></td>
      </tr>
	  <?
	  	if ($show){
	  ?>
      <tr style="background-color: #339900; color: White;">
        <td width="5%"  font-weight:bold;><div align="right">Event Id </div></td>
        <td  font-weight:bold;><div align="left">Event Name </div></td>
        <td width="5%"  font-weight:bold;><div align="left">BS</div></td>
        <td width="5%"  font-weight:bold;>In Date </td>
        <td width="5%"  font-weight:bold;>Event Date </td>
        <td width="5%"  font-weight:bold;>End Date </td>
        <td width="5%"  font-weight:bold;>Out Date </td>
        <td width="10%"  font-weight:bold;><div align="right">Rental</div></td>
        <td width="10%"  font-weight:bold;><div align="right"></div></td>
        <td width="10%"  font-weight:bold;><div align="right"></div></td>
        <td width="10%"  font-weight:bold;>&nbsp;</td>
        <td width="10%"  font-weight:bold;><div align="right"></div></td>
      </tr>
	  
      <? 
	  } // if ($show){
	if($arr_ytd_count) {
	foreach($arr_mis as $id=>$val) {
		$desc = $val ;
		$mtd = array_count_values($arr_mtd_count3); //$arr_mtd_count
		$mtd_count = $mtd[$id];
		$mtd_sum = $arr_mtd_sum[$id];
		$ytd = array_count_values($arr_ytd_count2); //$arr_ytd_count
		$ytd_count = $ytd[$id];
		$ytd_sum = $arr_ytd_sum[$id];
		
		$sum_mtd_count += $mtd_count ;
		$sum_mtd_sum += $mtd_sum ;
		$sum_ytd_count += $ytd_count ;
		$sum_ytd_sum += $ytd_sum ;
		
//		#prepare data to show
//		$s_mtd_count = chgNumber($mtd_count);
//		$s_mtd_sum = chgNumber($mtd_sum);
//		$s_ytd_count = chgNumber($ytd_count);
//		$s_ytd_sum = chgNumber($ytd_sum);
//		$s_sum_mtd_count = chgNumber($sum_mtd_count);
//		$s_sum_mtd_sum = chgNumber($sum_mtd_sum);
//		$s_sum_ytd_count = chgNumber($sum_ytd_count);
//		$s_sum_ytd_sum = chgNumber($sum_ytd_sum);
		
		
		#prepare data to show
		$s_mtd_count = number_format($mtd_count); //$s_mtd_count = chgNumber($mtd_count);
		$s_mtd_sum = chgNumber($mtd_sum);
		$s_ytd_count = number_format($ytd_count); //$s_ytd_count = chgNumber($ytd_count);
		$s_ytd_sum = chgNumber($ytd_sum);
		$s_sum_mtd_count = number_format($sum_mtd_count); //$s_sum_mtd_count = chgNumber($sum_mtd_count);
		$s_sum_mtd_sum = chgNumber($sum_mtd_sum);
		$s_sum_ytd_count = number_format($sum_ytd_count); //$s_sum_ytd_count = chgNumber($sum_ytd_count);
		$s_sum_ytd_sum = chgNumber($sum_ytd_sum);
		
		
		if($desc){  //ʴŷ
		//if($ytd_count){  //ʴ੾зբҹ
		
		if ($color == "#F0F0F0")
			$color = "#FFFFFF" ;
		else
			$color = "#F0F0F0" ;		
			
		
		?>
		  <tr bgcolor="<?=$color ?>"  >
			<td colspan="8" ><?=$desc ;?>			  <div align="right">
			    </div></td>
			<td ><div align="right"><?=$s_mtd_count ;?></div></td>
			<td ><div align="right"><?=$s_mtd_sum ;?></div></td>
			<td ><div align="right"><?=$s_ytd_count ;?></div></td>
			<td ><div align="right"><?=$s_ytd_sum ;?></div></td>
		  </tr>
	  <?
	  if ($show){
	  	if($show == "y"){ $arr_show = $arr_ytd2; }else{$arr_show = $arr_mtd2; }
		foreach($arr_show as $id1=>$val1) {		
			$evn_id = $id1 ;
			if ($arr_desc[$evn_id][6] == $id){
			$evn_name = $arr_desc[$evn_id][0] ;
			/*
			if(strlen($evn_name) > 15 ){
				$evn_name = substr($evn_name,0,12)."...";
			}
			*/
			$bs = $arr_desc[$id1][1] ;
			$in_date = chgDate($arr_desc[$evn_id][2]) ;
			$ev_date = chgDate($arr_desc[$evn_id][3]) ;
			$end_date = chgDate($arr_desc[$evn_id][4]) ;
			$out_date = chgDate($arr_desc[$evn_id][5]) ;
			$chk_field = $arr_desc[$evn_id][6] ;
			$rental = $arr_desc[$evn_id][7] ;
			$total = round($rental,2);
			
			$sum_rental += $rental ;
			$sum_total += $total ;
			
			$s_rental = chgNumber($rental);
			$s_total = chgNumber($total);
	  ?>
		  
		  <tr bgcolor="<?=$color ?>"  >
			<td ><div align="right">&nbsp;&nbsp;<?=$evn_id ;?></div></td>
			<td colspan="7" ><div align="left"><?=$evn_name ;?></div></td>
			<td > <div align="right"></div></td>
			<td ><div align="left"></div></td>
			<td ><div align="left"></div></td>
			<td ><div align="right"></div></td>
		  </tr>
		  <tr bgcolor="<?=$color ?>"  >
		    <td >&nbsp;</td>
		    <td >&nbsp;</td>
		    <td ><div align="left">
		      <?=$bs ;?>
		    </div></td>
		    <td ><div align="left">
		      <?=$in_date ;?>
		    </div></td>
		    <td ><div align="left">
		      <?=$ev_date ;?>
		    </div></td>
		    <td ><div align="left">
		      <?=$end_date ;?>
		    </div></td>
		    <td ><div align="left">
		      <?=$out_date ;?>
		    </div></td>
		    <td ><div align="right">
		      <?=$s_rental ;?>
		    </div></td>
		    <td >&nbsp;</td>
		    <td >&nbsp;</td>
		    <td >&nbsp;</td>
		    <td >&nbsp;</td>
      </tr>
		  <?
		  } // if($arr_ytd_count) {
		  } // if ($show){
		  } // if ($arr_mtd[$evn_id][0] == '$desc'){
		  } // foreach($arr_mis as $id=>$val) 
		  } // if($desc){
		} // foreach($arr_mis as $id=>$val) {
	  
		$s_sum_rental = chgNumber($sum_rental);
		$s_sum_equip = chgNumber($sum_equip);
		$s_sum_food = chgNumber($sum_food);
		$s_sum_total = chgNumber($sum_total);
	  
		if ($color == "#F0F0F0")
			$color = "#FFFFFF" ;
		else
			$color = "#F0F0F0" ;
	  
	 ?>
      <tr bgcolor="<?=$color ?>"  >
        <td colspan="8" ><div align="right" class="mandatory">
          <div align="right"><em>Total </em></div>
        </div>          <div align="right"></div></td>
        <td class="double_underline" ><div align="right"><?=$s_sum_mtd_count ;?></div></td>
        <td class="double_underline" ><div align="right"><?=$s_sum_mtd_sum ;?></div></td>
        <td class="double_underline" ><div align="right"><?=$s_sum_ytd_count ;?></div></td>
        <td class="double_underline" ><div align="right"><?=$s_sum_ytd_sum ;?></div></td>
      </tr>
    </table>
  </div>
</form>
