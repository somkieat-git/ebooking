<?	
	ob_start();
	session_start();
	include_once("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	//include "./cfg/config.cfg.php";
	//$presix = prefix ;
	define("updSave","estf_updForm.php");
	
	global $action;
	$evn_id = $_REQUEST["id"];
	$action =  $_REQUEST["a"];
	$estf_item = $_REQUEST["id2"];
	$bk18 = $_SESSION["bk18"];  // By Kae
	
	//====================== Begin prepare stand data ======================================
		
	if(!empty($evn_id)){
		$sql = "SELECT * FROM eventname WHERE evn_id = '$evn_id'  ";
		$rs_ev = getData($sql);
		$row = mysql_fetch_array($rs_ev);
		$disabled = "";
		//if($row[3] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;
		if($row["evn_used"] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;
		$evn_name = $row["evn_shortname"];
	} //if(!empty($ev_id)){	
	
	
	$sql = "SELECT * FROM miscode  
				WHERE  mis_type ='staff' ";
	//echo "$sql<hr>";
	$rs_miscode = getData($sql);	
	$arr_miscode= array();
	while( $row = mysql_fetch_array($rs_miscode)){
		$arr_miscode[] = $row["mis_name"];
		//echo "rs_miscode  => ".$row["mis_name"]."<br> ";
	} //while( $row = mysql_fetch_array($resmiscode)){
	/*
	$sql = "SELECT usr.usr_id, usr.usr_name , nif.*  FROM user usr LEFT JOIN nameinfo nif
				ON usr.usr_id = nif.nif_id 
				WHERE nif.nif_type = 'staff' ";
	*/
	$sql = "SELECT usr.usr_id, usr.usr_name
				FROM user usr				
				WHERE usr.usr_used = 'Y'
				";
				
	//echo "$sql<hr>";
	$rs_staff = getData($sql);		
	$arr_staff = array();
	while( $row = mysql_fetch_array($rs_staff)){
		 $arr_staff["$row[usr_id]"]  = $row["usr_name"] ;
		 //echo " rs_customer = $row[0] => $row[1]  -  $row[5]<br> ";
	} //while( $row = mysql_fetch_array($resmiscode)){
	
	
	//echo "<pre>"; print_r($arr_staff); exit(); // Staff Name
	//======================End prepare stand data========================================

	
	
	//======================Begin select data from ev_customer===============================
	
	if (!empty($evn_id)){
		$sql = "SELECT * FROM ev_staff WHERE evn_id = '$evn_id'  ";
		//echo "$sql<hr>";
		$rs_estf = getData($sql);
		$arr_estf = array();
		$numrow = mysql_num_rows($rs_estf);
		
		while( $row = mysql_fetch_array($rs_estf)){
			 $arr_estf[]  =  $row["usr_id"].",".$row["estf_item"] ;
			 //echo " rs_ecus = $row[2] => $row[1]<br> ";
		} //while( $row = mysql_fetch_array($rs_ecus)){
		
		//echo "<pre>"; print_r($arr_estf); exit(); // Result
		
	} //if (!empty($evn_id)){
	
?>
<html>
<script language="javascript">
	function validate() 
	{
		if(frm.estf0.value == 1 )
		{
			//Ϳ.ػó.value
			alert('Please input data in Sales Person ');
			frm.estf0.focus()
			return false;
		}
	}
</script>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">
</head>
	
<body>
<form action="<?=$updSave ?>?a=u&id=<?=$evn_id?>" method="post" name="frm"  id="frm" onSubmit="return validate();">
  <table border="0" class="BorderGreen" >
    <tr class="BorderSilver">
      <td colspan="4" style="background-color:#339900;font-weight:bold;color:White;">
	  	<div align="center"><strong >Staff - <?=$evn_id." - " .$evn_name ?></strong></div>
	  </td>
    </tr>
	<tr>
	  <td height="27" colspan="4"><div align="center">
	    <a href="usr_updForm.php?a=a">Add Staff</a>	    
	    <input name="evn_id" type="hidden" id="evn_id" value="<?=$evn_id ?>">
      </div></td>
    </tr>		
		<?
			//echo "<pre>"; print_r($arr_miscode); exit();
			foreach($arr_miscode as $miskey=>$misval){
				//echo "$misval<br>";
				echo "<tr><td ><div align='right'>$misval :</div></td>"; 	
	    ?>
						  
		  <td colspan="2">		
		  	<select name="estf<?=$miskey?>" id="estf<?=$miskey?>">			
			<?
				
				foreach($arr_staff as $stfkey=>$stfval){
				
					foreach($arr_estf as $estfkey=>$estfval){
						$estfval1 = substr($estfval,0,strpos($estfval,","));
						$estfval2 = substr($estfval,strpos($estfval,",")+1);
						//echo "ecusval1 = $ecusval1,ecusval2=$ecusval2<br>";
						//echo " misval =$misval<br>estfval2 =$estfval2<br>stfkey= $stfkey<br>estfval1=$estfval1<br>";
						
						if(( trim($misval) == trim($estfval2)) && ($stfkey == $estfval1)){						
							$select =1;
							break;							
						}else{
							$select =0;
							//continue;
						}
					} //foreach($arr_ecus as $ecuskey=>$ecusval){
					
					if($select==1){
						echo "<option value=$stfkey  selected > $stfval </option>";
					}else{
						echo "<option value=$stfkey > $stfval </option>";					
					}
				} //foreach($arr_customer as $cuskey=>$cusval){
			?>		
	        </select>			
			<?
				if(!$disabled) {
			?>
		    <a href="estf_updForm.php?a=d&id=<?=$evn_id ?>&id2=<?=$misval ?>"  
			onClick = "return confirm(' ต้องการลบ <?=$misval ?> ออกจากระบบจริงหรือไม่ ? ') "	>
			<img src="images/b_drop.png" width="16" height="16" border="0"></a>
			<?
				} //if($disabled) {
			?>
		  </td>
    	</tr>
		<?
			} //foreach($arr_miscode as $key=>$val){
		?>
	
		<tr>
		  <td height="20" ><div align="right"></div></td>
		  <td colspan="2" ><div align="left"></div></td>
    </tr>
    <tr align="center" >
      <td colspan="3">	  	
  	    <div align="center">
		<?php 
			if( $bk18 == "Yes" ){ // By Kae
				$link = "ecus_updForm2.php?id=$evn_id";
			}else{
				$link = "ecus_updForm.php?id=$evn_id";
			}
		?>
			<input name="Submit2" type="button" class="Button" value="&lt;= Back " onClick="window.location = '<?=$link?>'" >
			<input name="Submit" type="submit" class="Button" value="   OK   " <?=$disabled ;?> >
			<input name="Button" type="button" class="Button" id="Button"  onClick="history.go(-1)" value="Cancel" >
			<input name="Submit22" type="button" class="Button" value="Next =&gt;" onClick="window.location = 'eloc_viewForm.php?id=<?=$evn_id?>'" >		  
		  </div></td>
    </tr>
  </table>
</form>

<?
	//======================Begin Save Data==============================================
	//request data into varible
	$Submit = $_REQUEST["Submit"];
	if(!empty($Submit)){
		$estf0 = $_REQUEST["estf0"];
		$estf1 = $_REQUEST["estf1"];
		$estf2 = $_REQUEST["estf2"];
		$estf3 = $_REQUEST["estf3"];
		
		/*echo "
		submit = $Submit<br>
		action = $action<br>
		evn_id =  $evn_id<br>
		estf0 = $estf0<br> 
		estf1 = $estf1<br>
		estf2 = $estf2 <br> 
		estf3 = $estf3<br>
		";*/
		
		//check duplicate data in table ev_customer
		function  checklist($value,$label,$field,$evn_id){
			
			//echo "\$action=$action"; exit();
			global $action ;
			global $resNull; global $resData; global $flag; global $strPattern; global $query; 
			global $arrquery ;
			$strPattern = "Sales| ";
			if($value ==1){
				if(ereg($strPattern,$label)){
					$flag = 1;
					$resNull[] = $label;
				} //if(ereg($strPattern,$label)){			
			} //if($value==1){
			else{
				$usr =  $_SESSION["usr_name"];
				$d = date("Y/m/d  H:i:s");
				$sql = "SELECT * FROM ev_staff 
							 WHERE evn_id = '$evn_id'
							 AND $field = '$label' ";
				//echo "$sql<hr>";
				$result = getData($sql);
				$numrow = mysql_num_rows($result);
				$row = mysql_fetch_array($result);
				//echo "numrow = $numrow<br>";				
				if ($numrow == 0 ){
					$query = " INSERT INTO ev_staff (evn_id, estf_item, usr_id, usr_cre, date_cre )";
					$query .= " VALUES( '$evn_id', '$label', $value,'$usr','$d' );";
					//echo "$query<hr>";			
					$arrquery[] = $query;					
				} // if ($numrow == 0 ){
				else{
					if($action == "u"){
						$query = " UPDATE ev_staff SET usr_id = $value,	usr_upd = '$usr',date_upd = '$d' ";
						$query .= " WHERE evn_id = 	'$evn_id'";
						$query .= "	AND estf_item = '$label';";						
						//echo "\$query=$query<hr>";		exit();			
						$arrquery[] = $query;
					} // if($action == 'u'){
				} //else{ if ($numrow == 0 ){
			} //else{ if($value==1){	
		} //function checklist($var,$name){
		
		//checklist($evn_id,"","evn_id");
		checklist($estf0,"Sales Person ","estf_item",$evn_id);
		checklist($estf1,"Event Manager","estf_item",$evn_id);
		checklist($estf2,"Event Attendance","estf_item",$evn_id);
		checklist($estf3,"Food Person","estf_item",$evn_id);		
		{		
				foreach($arrquery as $key=>$val) {
					mysql_query($val) or die("query error");	
					$SaveLog=updLog($_SESSION['username'], updSave, "$val");					
				}				
				//Show alert by javascript				
				echo "<script>
						alert ('Update complete');
						window.location = 'estf_updForm.php?id=$evn_id';
					  </script>";
				exit();
		} //else{
	} //if(!empty($Submit)){
	if($action == 'd'){
		$sql = "DELETE FROM ev_staff WHERE evn_id = '$evn_id' AND estf_item = '$estf_item'";
		//echo "$sql<br>";
		mysql_query($sql) or die("Delete error");	
		$SaveLog=updLog($_SESSION['username'], updSave, "$sql");					
		//exit();
		//Show alert by javascript				
		echo "<script>
				alert ('Delete complete');
				window.location = 'estf_updForm.php?id=$evn_id';
			  </script>";
		exit();		
	} // if($action == 'd'){
	
	//======================End Save Data==============================================
include("db/disconnect.db.php");
?>