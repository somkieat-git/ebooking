<?	
	ob_start();
	session_start();
	//include("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	define("updSave","epay_updForm.php");
	$type = "pay";
	$action = $_REQUEST["a"];
	$evn_id = $_REQUEST["id"];
	$pay_id =  $_REQUEST["id2"];	
	//echo "\$action=$action<br>\$evn_id=$evn_id<br>\$pay_id=$pay_id<br>\$type=$type";
	if ($action == "a"){
		$caption = "Insert  "  ;
		$button = "Save";
	}
	if ($action == "e"){
		$caption = "Edit  "  ;
		$button = "Update";
	}
	if ($action == "d"){
		$caption = "Delete  "  ;
		$button = "Delete";
	}
	//======================Begin prepare standard data======================================
		
	if(!empty($evn_id)){
		$sql = "SELECT * FROM eventname WHERE evn_id = '$evn_id'  ";
		$result = getData($sql);
		$row = mysql_fetch_array($result);
		$disabled = "";
		//if($row[3] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;
		if($row["evn_used"] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;
		$evn_name = $row["evn_shortname"];
	} //if(!empty($ev_id)){	
		
		//$sql = "SELECT stt_id, stt_name  FROM settle_cat 
		//			ORDER BY stt_name ";		
  	
		$arr_stt = array();
		#Select value from ev_location
		$sql = "
			SELECT distinct stt.stt_id, stt.stt_name
			FROM settle_cat stt, location loc, ev_location eloc, ratecode rtc
			WHERE stt.stt_id = loc.stt_id
			AND loc.loc_id = eloc.loc_id
			AND eloc.evn_id = '$evn_id'
			AND eloc.rtc_id = rtc.rtc_id
			GROUP BY rtc.rtc_status, stt.stt_id
			ORDER BY  rtc.rtc_status, stt.stt_name
			";
			//echo "<br>1=$sql <hr>";
			//exit();
			$result = getData($sql);			
			while($res_stt = mysql_fetch_array($result)){
				$arr_stt[$res_stt["stt_id"]] = $res_stt["stt_name"]; 
			}
			
/*			#Select value from ev_location
			$arr_val = array('ev_equip_serv','ev_food_serv');
			for($i = 0; $i < count($arr_val);$i++){		
			$sql = "
				SELECT distinct stt.stt_id, stt.stt_name
				FROM settle_cat stt,  equip_serv esv, $arr_val[$i] eesv
				WHERE stt.stt_id = esv.stt_id
				AND eesv.esv_id = esv.esv_id
				AND eesv.evn_id = '$evn_id'
				GROUP BY stt.stt_id
				ORDER BY stt.stt_name
				";
				echo "2=$sql <hr>";
				//exit();
				$result = getData($sql);			
				while($res_stt = mysql_fetch_array($result)){
					$arr_stt[$res_stt[0]] = $res_stt[1]; 
				} // 
			} // for($i = 0; $i < count($arr_val);$i++){
*/			
			//print_r($arr_stt);echo "<hr>";
			//exit();
	//======================End prepare stand data========================================

	//======================Begin select data from ev_location===============================
	
	if ($action != 'a'){	
		#Show pay_adj
		$sql = "SELECT * FROM pay_adj ";
		$sql .=" WHERE pay_id = $pay_id";
		//echo "$sql<br>";
		$result = getData($sql);
		$rs_pad = mysql_fetch_array($result);	
		$id = $rs_pad["pay_id"];
		$str1 = $rs_pad["str1"];
		$str2= $rs_pad["str2"];
		$tran_date = chgDate($rs_pad["tran_date"]);
		$exc_vat= $rs_pad["exc_vat"];
		$vat= $rs_pad["vat"];
		$inc_vat= $rs_pad["inc_vat"];		
		$remark= $rs_pad["remark"];		
		
		$s_exc_vat= chgNumber($exc_vat);
		$s_vat= chgNumber($vat);
		$s_inc_vat= chgNumber($inc_vat);
		
	} //if ($action != 'a'){	
	
?>
<html>
<script language="javascript">
	function validate() {
		if(frm.str1.value==""){
			alert('Please input data in Reason for Payment');
			frm.str1.focus()
			return false;
		}
		if(frm.str2.value==""){
			alert('Please input data in Payment Control Number');
			frm.str2.focus()
			return false;
		}
		if(frm.tran_date.value==""){
			alert('Please input data in Payment Date');
			frm.tran_date.focus()
			return false;
		}
		if(frm.exc_vat.value==""){
			alert('Please input data in Exclude Vat');
			frm.exc_vat.focus()
			return false;
		}
		if(frm.vat.value==""){
			alert('Please input data in Vat');
			frm.vat.focus()
			return false;
		}
		if(frm.inc_vat.value==""){
			alert('Please input data in Include Vat');
			frm.inc_vat.focus()
			return false;
		}
	}
	
	function cancel(val) 
	{
		window.open(val,"frame_details");
	}
	
	function calculate() {	
		var x1, x2 , x3 ;
		var b4v = 0, vat = 0, a2v = 0;
		x1 = document.frm.exc_vat.value ;
		x2 = document.frm.vat.value ;
		x3 = document.frm.inc_vat.value ;
		//alert(x1);
		if(x1){			
			b4v = Number(x1.replace(",","")) ;
			sb4v = Number(b4v).toFixed(2) ;					
			vat = Number(b4v * 7 / 100) ;
			svat = Number(b4v * 7 / 100).toFixed(2) ;		
			a2v = Number(b4v + vat) ;
			sa2v = Number(b4v + vat).toFixed(2) ;								
		}		
		
		 document.frm.exc_vat.value = sb4v ;
		 document.frm.vat.value = svat ;
		 document.frm.inc_vat.value = sa2v ;		 
	}
	
</script>

<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">
<script language="javascript" type="text/javascript" src="datetimepicker.js"></script>
</head>
	
<body >
<form action="<?=updSave?>?a=<?=$action?>&id=<?=$evn_id?>&id2=<?=$pay_id?>" method="post" name="frm"  id="frm" onSubmit="return validate();" >
  <table border="0" class="BorderGreen" >
    <tr class="BorderSilver">
      <td colspan="2" style="background-color:#339900;font-weight:bold;color:White;">
	  	<div align="center"><strong >Event Payment  - <?=$evn_id." - " .$evn_name ?></strong></div>
	  </td>
    </tr>
		
		<tr>
		  <td width="180" ><div align="right"></div></td>
          <td width="172" >&nbsp;</td>
	</tr>
		<tr>
		  <td ><div align="right">*Settlement Category : </div></td>
		  <td ><div align="left">
		    <select name="stt_id" id="stt_id">
			<?
				foreach($arr_stt as $stt_id=>$stt_name) {
			?>
		      <option value="<?=$stt_id ?>"<? if($stt_id==$id) echo ' selected' ;?>><?=$stt_name ;?></option>
			  <?
			  } // foreach($arr_stt as $stt_id=>$stt_name) {
			  ?>
	        </select>
		    <input name="pay_id" type="hidden" id="pay_id" value="<?=$pay_id?>">
		  </div></td>
    </tr>
		<tr>
		  <td ><div align="right">*Reason for Payment : </div></td>
		  <td ><div align="left">
		    <input name="str1" type="text" id="str1" value="<?=$str1 ;?>">
		  </div></td>
    </tr>
		<tr>
		  <td ><div align="right">*Payment Control Number : </div></td>
		  <td ><div align="left">
		    <input name="str2" type="text" id="str2" value="<?=$str2 ;?>">
		  </div></td>
    </tr>
		<tr>
		  <td ><div align="right">*Payment Date : </div></td>
		  <td ><div align="left">
			<input name="tran_date" type="text" id="tran_date" value="<? if($action=='a') echo date("d/m/Y"); else  echo $tran_date ;?>" size="10" maxlength="10">
		  <a href="javascript:NewCal('tran_date','ddmmyyyy',false,12)">
		  <img src="images/cal.gif" width="16" height="16" border="0" alt="Pick a date"></a>
		  </div>		  
		  </td>
    </tr>
		<tr>
		  <td ><div align="right">*Exclude Vat: </div></td>
		  <td ><div align="left">
		    <input name="exc_vat" type="text" id="exc_vat" value="<?=$s_exc_vat ;?>">
		  </div></td>
    </tr>
		<tr>
		  <td ><div align="right">*Vat:</div></td>
		  <td ><div align="left">
		    <input name="vat" type="text" id="vat" value="<?=$s_vat ;?>">
            <a href="javascript:calculate();"><img src="images/slot.gif" alt="Calculate Vat Auto" width="16" height="16" border="0"></a> </div></td>
    </tr>
		<tr>
		  <td ><div align="right">*Include Vat:</div></td>
		  <td ><div align="left">
		    <input name="inc_vat" type="text" id="inc_vat" value="<?=$s_inc_vat ;?>">
		  </div></td>
    </tr>
		<tr>
		  <td ><div align="right">Remark:</div></td>
		  <td ><div align="left">
		    <input name="remark" type="text" id="remark" value="<?=$remark ;?>">
		  </div></td>
    </tr>
		<tr>
		  <td >&nbsp;</td>
		  <td >&nbsp;</td>
    </tr>
    <tr align="center" >
      <td colspan="2">	 	
          <input name="Submit" type="submit" class="Button" value="<?=$button?>" <?=$disabled ;?> >
          <input name="Cancel" type="button" class="Button" id="Cancel"  onClick="cancel('epay_viewForm.php?id=<?=$evn_id ;?>');" value="Cancel" >      </td>
    </tr>
  </table>
</form>
<?
	//======================Begin Save Data==============================================
	//request data into varible
	$Submit = $_REQUEST["Submit"];
	if(!empty($Submit)){
		$pay_id = $_REQUEST["pay_id"];
		$stt_id = $_REQUEST["stt_id"];
		$str1 = $_REQUEST["str1"];
		$str2 = $_REQUEST["str2"];
		$tran_date = chgDateToDb($_REQUEST["tran_date"]);
		$exc_vat = chgNumberToDb($_REQUEST["exc_vat"]);
		$vat = chgNumberToDb($_REQUEST["vat"]);
		$inc_vat = chgNumberToDb($_REQUEST["inc_vat"]);
		$remark = $_REQUEST["remark"];
		/*
		echo "
		\$id = $id<br>
		\$str1 = $str1<br>
		\$str2 = $str2<br>
		\$tran_date = $tran_date<br>
		\$exc_vat = $exc_vat<br>
		\$vat = $vat<br>
		\$inc_vat = $inc_vat<br>
		\$remark = $remark<br>
		";
		*/
		function  checklist($value,$label,$field){
			global $resData;
			$resData[$field] = $value;
		} //function checklist($var,$name){
		
		//checklist($evn_id,"","evn_id");
		
		checklist($stt_id,"","stt_id");		
		checklist($str1,"","str1");
		checklist($str2,"","str2");
		checklist($tran_date,"","tran_date");
		checklist($exc_vat,"","exc_vat");
		checklist($vat,"","vat");
		checklist($inc_vat,"","inc_vat");
		checklist($remark,"","remark");

			if($action=="a"){
				$resData["evn_id"] = $evn_id;
				$resData["type"] = $type;
				$resData["usr_cre"] = $_SESSION["usr_name"];
				$resData["date_cre"] = date("Y/m/d  H:i:s");		
				
				$query = create_insert_query("pay_adj",$resData);	
				//echo "$query<br>";
				//exit();
				mysql_query($query) or die("Insert error");		
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");				
				//Show alert by javascript
				echo "<script>
						alert ('Insert complete');
						window.location = 'epay_updForm.php?a=a&id=$evn_id' ;
					  </script>";
				exit();
			}
			
			if($action=="e"){
				$resData["usr_upd"] = $_SESSION["usr_name"];
				$resData["date_upd"] = date("Y/m/d  H:i:s");		
				
				$query = create_update_evquery("pay_adj", $resData, $evn_id, "evn_id",$id,"pay_id");				
				//echo "$query<br>";				
				//exit();
				mysql_query($query) or die("Update error");	
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");	
				//Show alert by javascript
				echo "<script>
						alert ('Update complete');
						window.location = 'epay_viewForm.php?id=$evn_id' ;
					  </script>";
				exit();
			} // if($action=="e"){
			
			if ($action=="d"){
				$query = "DELETE FROM pay_adj WHERE  pay_id = $pay_id " ;
				$query .= " AND evn_id = '$evn_id' ";
				$query .= " AND type = '$type' ";
				//echo "$query<br>";
				//exit();
				
				mysql_query($query) or die("Delete pay_adj error");	
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");	
				//Show alert by javascript
				echo "<script>
						alert ('Delete complete');
						window.location = 'epay_viewForm.php?id=$evn_id' ;
					  </script>";
				exit();
			}  //if ($action=="d"){

	} //if(!empty($Submit)){
	
	//======================End Save Data==============================================
?>
