<?
	ob_start(); 
	session_start();
	define("tableName","nameinfo");
	define("viewForm","nif_viewForm.php");
	define("updForm","nif_updForm.php");
	define("field_id","nif_id");
	define("beg_id",2);	
	define("end_id",19);	
	$sql = "SELECT *
				FROM nameinfo
				";
	//echo "$sql";
	//exit();
	define("query","$sql");
	
	$cap_name = array();
	$cap_name = array("#","Type","Initial","First Name","Last Name","Title","Company","No","Soi","Road",
		"Tumbol","District","Province","Zip Code","Telephone","Fax","Mobile","email","website","remark",
		"used","used create","date create","user upd","date upd");
	
	$key = array_keys($_SESSION["sec_add"], viewForm); 
	//print_r(array_keys($_SESSION["sec_add"], viewForm));
	if($key[0])
		define("insert",1);		
	else
		define("insert",0);			
	//echo "insert = ".insert."<br>";
		
	$key = array_keys($_SESSION["sec_edit"], viewForm); 
	//print_r(array_keys($_SESSION["sec_edit"], viewForm));
	if($key[0])
		define("edit",1);		
	else
		define("edit",0);			
	//echo "edit = ".edit."<br>";
	
	$key = array_keys($_SESSION["sec_del"], viewForm); 
	//print_r(array_keys($_SESSION["sec_del"], viewForm));
	if($key[0])
		define("del",1);		
	else
		define("del",0);			
	//echo "del = ".del."<hr>";
	
	include("func/viewForm.func.php");
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</body>
</html>
