<?php
	ob_start();
	session_start();
	$arrErev=$_SESSION["arrData"];	
	
	header("Content-Type: application/vnd.ms-excel");
	header('Content-Disposition: attachment; filename="EventRevenue.xls"');	
?>
<html xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:x="urn:schemas-microsoft-com:office:excel"
xmlns="http://www.w3.org/TR/REC-html40">
<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</HEAD><BODY>

<table width="100%" align="center">
	<?
	$cntCol=0;$showTD="";
	while (list($key, $val) = each($arrErev[0])) {
		$Title=$val["Title"];
		$Show=$val["Show"];
		if($Show=="Yes"){
			$cntCol++;
			$showTitle.="<td><div align='center'>$Title</div></td>";
		}//if($Show=="Yes"){
	}//while (list($key, $val) = each($arrData[0])) {
	
	if($cntCol){
		$showExport="<tr><td colspan=\"$cntCol\"> [&nbsp;<a href=\"rpt_erev.php$urlString\">Hide</a> / <a href=\"rpt_erev.php$urlString&s=y\">Show</a>&nbsp;]";
		$showExport.="<a href=\"export_erev.php\">&nbsp;Export To Excel </a></td>";
	}else{
		$showExport="";
	}//if($cntCol){							
	//echo "$showExport";
	?>		  
	
	<tr class="lst_BorderHead" ><?=$showTitle;?></tr>
	
	<?
		$showDetails="Yes";
		if($showDetails){
			echo "<tr bgcolor=\"$bgcolor\"><td colspan='2'>&nbsp;</td><td colspan='5'>";
				echo " <table width=\"100%\" align=\"left\">";									
					echo " <tr align=\"left\">";
						echo " <td width=\"20%\" align=\"left\">Date</td>";
						echo " <td width=\"20%\" align=\"left\">LocName</td>";
						echo " <td width=\"20%\" align=\"left\">Space</td>";
						echo " <td awidth=\"20%\" lign=\"left\">Equip</td>";
						echo " <td width=\"20%\" align=\"left\">Food</td>";																		
					echo " </tr>";				
				echo " </table>";
			echo "</td><td  colspan=\"".($cntCol-7)."\">&nbsp;</tr>";
		}//if($showDetails){
		
		while (list($key, $val) = each($arrErev)) {
			$bgcolor == "#E7F0F8" ? $bgcolor="#F5F9FC" : $bgcolor="#E7F0F8" ;
			echo "<tr bgcolor=\"$bgcolor\">";
			while (list($subKey, $subVal) = each($val)) {
				$Title="";$Value="";$Show="";
				$Title=$subVal["Title"];
				$Value=$subVal["Value"];
				$Show=$subVal["Show"];
				//echo "\$Title=$Title,\$Value=$Value,\$Show=$Show<hr>";	
				
				if($Show=="Yes"){
					echo "<td>$Value</td>";
				}//if($Show=="Yes"){
				
				if($Title=="Details"){
					$cntArrDetail=count($Value);
					//echo "Details=$cntArrDetail<br>";
					//echo "ArrDetail=<pre>";print_r($Value);echo "<hr>";
					
					if($cntArrDetail && !$showDetails){
						echo "</tr>";
							
							$DetailsHTML="<tr bgcolor=\"$bgcolor\">";
							$DetailsHTML.="<td colspan=\"2\">&nbsp;</td>";
							$DetailsHTML.="<td colspan=\"5\">";
							$DetailsHTML.="<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">";									
								$OldRavDate="";								
								while (list($dateKey, $dateVal) = each($Value)) {
									$showDate=chgDate($dateKey);
									$RavDate=$dateKey;
									
									$DetailsHTML.="<tr>";
									$DetailsHTML.="<td width=\"20%\"><div align=\"left\">$showDate</div></td>";	
																							  
									$OldLocID="";
									while (list($locKey, $locVal) = each($dateVal)) {
										$showLocName=$arrLocName[$locKey];
										$LocID=$locKey;												
										
										if($RavDate!=$OldRavDate){
											$OldRavDate=$RavDate;
											$DetailsHTML.="<td width=\"20%\"><div align=\"left\">$showLocName</div></td>";
										}else{
											if($LocID!=$OldLocID){
												$LocID=$OldLocID;
												
												$DetailsHTML.="<tr>";
												$DetailsHTML.="<td width=\"20%\"><div align=\"left\">&nbsp;</div></td>";
												$DetailsHTML.="<td width=\"20%\"><div align=\"left\">$showLocName</div></td>";	
																									
											}//if($LocID!=$OldLocID){																										
										}//if($RavDate!=$OldRavDate){											
										
										$amtSpace=0;$amtEquip=0;$amtFood=0;		
										while (list($typeKey, $typeVal) = each($locVal)) {																									
											switch ($typeKey) {
												case "equip":
													$amtEquip=chgNumber($typeVal);															
													break;
												case "food":
													$amtFood=chgNumber($typeVal);
													break;
												default:
													$amtSpace=chgNumber($typeVal);
											}//end switch ($typeKey) {	
																			
										}//while (list($typeKey, $typeVal) = each($locVal)) {	
										
										$DetailsHTML.="<td width=\"20%\"><div align=\"left\">$amtSpace</div></td>";
										$DetailsHTML.="<td width=\"20%\"><div align=\"left\">$amtEquip</div></td>";
										$DetailsHTML.="<td width=\"20%\"><div align=\"left\">$amtFood</div></td>";
																		
										$DetailsHTML.="</tr>";												
										
									}//while (list($locKey, $locVal) = each($dateVal)) {											
																				
								}//while (list($locKey, $locVal) = each($Value)) {																		
							
						
						$DetailsHTML.="</table>";
						$DetailsHTML.="</td>";
						$DetailsHTML.="<td colspan=\"".($cntCol-7)."\">&nbsp;</td>";
						$DetailsHTML.="</tr>";	
						
						echo "$DetailsHTML";					
						
						
					}//if($cntArrDetail && $showDetails){
				}//if($Title=="Details"){					
			}//while (list($subKey, $subVal) = each($val)) {
			
			//----------
			if($cntArrDetail && $showDetails){
				echo "";
			}else{
				echo "</tr>";
			}//if($cntArrDetail && $showDetails){
						
			
		} //while (list($key, $val) = each($arrData)) {
	?>
</table>

</BODY>
</HTML>