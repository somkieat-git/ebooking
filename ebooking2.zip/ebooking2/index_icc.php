<?
	ob_start();
	session_start();
	$_SESSION["site"]="psu";
?>
<script>
window.location='ql/index.php';
</script>
