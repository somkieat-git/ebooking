<?	
	ob_start();
	session_start();
	include("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	define("updSave","eadj_updForm.php");
	$type = "adj";
	$action = $_REQUEST["a"];
	$evn_id = $_REQUEST["id"];
	$stt_id =  $_REQUEST["id2"];	
	//echo "\$action=$action<br>\$evn_id=$evn_id<br>\$stt_id=$stt_id<br>\$type=$type";
	
	//======================Begin prepare standard data======================================
		
	if(!empty($evn_id)){
		$sql = "SELECT * FROM eventname WHERE evn_id = '$evn_id'  ";
		$result = getData($sql);
		$row = mysql_fetch_array($result);
		$disabled = "";
		if($row["evn_used"] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;
		$evn_name = $row["evn_shortname"];
	} //if(!empty($ev_id)){	

		$sql = "SELECT stt_id, stt_name  FROM settle_cat 
					ORDER BY stt_name ";
		$res_stt = getData($sql);			

	//======================End prepare stand data========================================

	//======================Begin select data from ev_location===============================
	
	if ($action != 'a'){	
		#Show pay_adj
		$sql = "SELECT * 
					FROM pay_adj 
					WHERE evn_id = '$evn_id'  
					AND stt_id = '$stt_id'
					AND type ='$type'
					";
		//echo "$sql<br>";
		$result = getData($sql);
		$rs_pad = mysql_fetch_array($result);	
		$id = $rs_pad["evn_id"];
		$str1 = $rs_pad["str1"];
		$str2= $rs_pad["str2"];
		$tran_date = chgDate($rs_pad["tran_date"]);
		$amt= $rs_pad["exc_vat"];

	} //if ($action != 'a'){	
	
?>
<html>
<script language="javascript">
	function validate() {
		if(frm.str1.value==""){
			alert('Please input data in Reason for Payment');
			frm.str1.focus()
			return false;
		}
		if(frm.str2.value==""){
			alert('Please input data in Payment Control Number');
			frm.str2.focus()
			return false;
		}
		if(frm.tran_date.value==""){
			alert('Please input data in Payment Date');
			frm.tran_date.focus()
			return false;
		}
		if(frm.amt.value==""){
			alert('Please input data in Amount');
			frm.amt.focus()
			return false;
		}

	}
	
</script>

<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">
<script language="javascript" type="text/javascript" src="datetimepicker.js"></script>
</head>
	
<body >
<form action="<?=updSave?>?a=<?=$action?>&id=<?=$evn_id?>&id2=<?=$stt_id?>" method="post" name="frm"  id="frm" onSubmit="return validate();" >
  <table border="0" class="BorderGreen" >
    <tr class="BorderSilver">
      <td colspan="2" style="background-color:#339900;font-weight:bold;color:White;">
	  	<div align="center"><strong >Manual Adjustment  - <?=$evn_id." - " .$evn_name ?></strong></div>
	  </td>
    </tr>
		
		<tr>
		  <td width="180" ><div align="right"></div></td>
          <td width="172" >&nbsp;</td>
	</tr>
		<tr>
		  <td ><div align="right">*Settlement Category : </div></td>
		  <td ><div align="left">
		    <select name="stt_id" id="stt_id">
			<? 
				while($result  =  mysql_fetch_array($res_stt)){				
			?>
		      <option value="<?=$result["stt_id"]?>"<? if($result["stt_id"]==$id) echo ' selected' ;?>><?=$result["stt_name"] ;?></option>
			  <?
			  }
			  ?>
	        </select>
		  </div></td>
    </tr>
		<tr>
		  <td ><div align="right">*Name of item being changed: </div></td>
		  <td ><div align="left">
		    <input name="str1" type="text" id="str1" value="<?=$str1 ;?>">
		  </div></td>
    </tr>
		<tr>
		  <td ><div align="right">*Description (desc / time /etc): </div></td>
		  <td ><div align="left">
		    <input name="str2" type="text" id="str2" value="<?=$str2 ;?>">
		  </div></td>
    </tr>
		<tr>
		  <td ><div align="right">*Transaction Date : </div></td>
		  <td ><div align="left">
			<input name="tran_date" type="text" id="tran_date" value="<? if($action=='a') echo date("d/m/Y"); else  echo $tran_date ;?>" size="10" maxlength="10">
		  <a href="javascript:NewCal('tran_date','ddmmyyyy',false,12)">
		  <img src="images/cal.gif" width="16" height="16" border="0" alt="Pick a date"></a>
		  </div>		  
		  </td>
    </tr>
		<tr>
		  <td ><div align="right">*Amount : </div></td>
		  <td ><div align="left">
		    <input name="amt" type="text" id="amt" value="<?=$amt ;?>">
		  </div></td>
    </tr>
		<tr>
		  <td >&nbsp;</td>
		  <td >&nbsp;</td>
    </tr>
    <tr align="center" >
      <td colspan="2">	 	
	  	  <input name="Submit" type="submit" class="Button" value="   OK   " <?=$disabled ;?> >
          <input name="Delete" type="button" class="Button" id="Delete"   value="Delete" <? if($action=='a') echo 'disabled' ; ?>>
          <input name="Cancel" type="button" class="Button" id="Cancel"  onClick="history.go(-1)" value="Cancel" >
        </td>
    </tr>
  </table>
</form>
<?
	//======================Begin Save Data==============================================
	//request data into varible
	$Submit = $_REQUEST["Submit"];
	if(!empty($Submit)){
		$id = $_REQUEST["stt_id"];
		$str1 = $_REQUEST["str1"];
		$str2 = $_REQUEST["str2"];
		$tran_date = chgDateToDb($_REQUEST["tran_date"]);
		$amt = $_REQUEST["amt"];
		
		echo "
		\$id = $id<br>
		\$str1 = $str1<br>
		\$str2 = $str2<br>
		\$tran_date = $tran_date<br>
		\$amt = $amt<br>
		";
				
		function  checklist($value,$label,$field){
			global $resData;
			$resData[$field] = $value;
		} //function checklist($var,$name){
		
		//checklist($evn_id,"","evn_id");
		
		checklist($id,"","stt_id");
		checklist($str1,"","str1");
		checklist($str2,"","str2");
		checklist($tran_date,"","tran_date");
		checklist($amt,"","amt");

			if($action=="a"){
				$resData["evn_id"] = $evn_id;
				$resData["type"] = $type;
				$resData["usr_cre"] = $_SESSION["usr_name"];
				$resData["date_cre"] = date("Y/m/d  H:i:s");		
				
				$query = create_insert_query("pay_adj",$resData);	
				echo "$query<br>";
				//exit();
				mysql_query($query) or die("Insert error");		
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");				
				//Show alert by javascript
				echo "<script>
						alert ('Insert complete');
						window.location = 'eadj_updForm.php?a=a&id=$evn_id' ;
					  </script>";
				exit();
			}
			
			if($action=="e"){
				$resData["usr_upd"] = $_SESSION["usr_name"];
				$resData["date_upd"] = date("Y/m/d  H:i:s");		
				
				$query = create_update_evquery("pay_adj", $resData, $evn_id, "evn_id",$stt_id,"stt_id");				
				$query .= " AND type = '$type' ";
				//echo "$query<br>";				
				//exit();
				mysql_query($query) or die("Update error");		
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");
				//Show alert by javascript
				echo "<script>
						alert ('Update complete');
						window.location = 'eadj_viewForm.php?id=$evn_id' ;
					  </script>";
				exit();
			}

	} //if(!empty($Submit)){
	
	//======================End Save Data==============================================
?>
