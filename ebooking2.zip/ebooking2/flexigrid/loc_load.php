<?

#########Edit Zone ###############
$tblName="location";
$fldID="loc_id";
$fldURL="loc_shortname";
$updForm="loc_updForm.php";
#########Edit Zone ###############

include_once("connection.php");
$sql=" select * from $tblName";
$result = runSQL($sql);
$i = 0;
$arrFields=array();
while ($i < mysql_num_fields($result)) {    
    $meta = mysql_fetch_field($result, $i);
	$arrFields[]=$meta->name;	
    $i++;
} //while ($i < mysql_num_fields($result)) {
mysql_free_result($result);

$sql=" select ";
$strFldname=implode(",",$arrFields);
$sql.= " $strFldname ";
$sql.=" FROM $tblName " ;
$sql.=" $where $sort $limit";
$result = runSQL($sql);
$total = countRec("$fldID","$tblName $where");

header("Expires: Mon, 26 Jul 1997 05:00:00 GMT" ); 
header("Last-Modified: " . gmdate( "D, d M Y H:i:s" ) . "GMT" ); 
header("Cache-Control: no-cache, must-revalidate" ); 
header("Pragma: no-cache" );
header("Content-type: text/x-json");
$json = "";
$json .= "{\n";
$json .= "page: $page,\n";
$json .= "total: $total,\n";																																																																																																
$json .= "rows: [";																																																																																																
$rc = false;																																																																																								
while ($row = mysql_fetch_array($result)) {	
	if ($rc) $json .= ",";	
	$json .= "\n{";		
	$json .= "cell:[ ";		
	$sp=false;
	foreach($arrFields as $key=>$val){
		if ($sp) $json .= ",";
		if ($val==$fldURL) {
			$row[$val]= "<a href=\"../$updForm?a=e&id=".$row[$fldID]."\">".$row[$val]."</a>";
		}	
		$json .= "'".addslashes($row[$val])."'";		
		$sp = true;
	}//foreach($arrFields as $key=>$val){
	$json .= "]}";
	$rc = true;		
} //while ($row = mysql_fetch_array($result)) {

$json .= "]\n";
$json .= "}";
echo $json;
?>