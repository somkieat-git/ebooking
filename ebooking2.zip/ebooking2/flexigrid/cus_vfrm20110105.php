<?
$t = $_REQUEST["t"];
$f = $_REQUEST["f"];

	#########Edit Zone ###############	
	$loadUrl="cus_load.php?t=" . $t . "&f=" . $f ;
	$updForm="cus_updForm.php";
	$f != "" ? $hide = ", hide: true" : $hide = "";
	$colModel= "
			colModel : [
				{display: 'Action', name : 'action', width : 42, align: 'left' $hide }
				,{display: 'ID', name : 'pro_id', width : 50, sortable : true, align: 'center'}
				,{display: 'Code', name : 'pro_code', width : 100, sortable : true, align: 'left'}
				,{display: 'Title(Th)', name : 'pro_ttitle', width : 50, sortable : true, align: 'left'}
				,{display: 'Title(En)', name : 'pro_etitle', width : 50, sortable : true, align: 'left'}
				,{display: 'First Name(Th)', name : 'pro_tfname', width : 80, sortable : true, align: 'left'}
				,{display: 'First Name(En)', name : 'pro_efname', width : 80, sortable : true, align: 'left'}
				,{display: 'Last Name(Th)', name : 'pro_tlname', width : 80, sortable : true, align: 'left'}
				,{display: 'Last Name(En)', name : 'pro_elname', width : 80, sortable : true, align: 'left'}
				,{display: 'Pro Tprefix', name : 'pro_tprefix', width : 80, sortable : true, align: 'left', hide: true}
				,{display: 'Pro Eprefix', name : 'pro_eprefix', width : 80, sortable : true, align: 'left', hide: true}
				,{display: 'Compary Name(Th)', name : 'pro_tcname', width : 150, sortable : true, align: 'left'}
				,{display: 'Compary Name(En)', name : 'pro_ecname', width : 150, sortable : true, align: 'left'}
				,{display: 'Pro Tsuffix', name : 'pro_tsuffix', width : 80, sortable : true, align: 'left', hide: true}
				,{display: 'Pro Esuffix', name : 'pro_esuffix', width : 80, sortable : true, align: 'left', hide: true}
				],

			searchitems : [
                {display: 'ID', name : 'pro_id'}				
				,{display: 'Pro Code', name : 'pro_code'}
				,{display: 'Pro Title(Th)', name : 'pro_ttitle'}
				,{display: 'Pro Title(En)', name : 'pro_etitle'}
				,{display: 'First Name(Th)', name : 'pro_tfname'}			
				,{display: 'First Name(En)', name : 'pro_efname'}
				,{display: 'Last Name(Th)', name : 'pro_tlname'}				
				,{display: 'Last Name(En)', name : 'pro_elname'}
				,{display: 'Pro Tprefix', name : 'pro_tprefix'}
				,{display: 'Pro Eprefix', name : 'pro_eprefix'}
				,{display: 'Pro Tcname', name : 'pro_tcname'}
				,{display: 'Pro Ecname', name : 'pro_ecname'}
				,{display: 'Pro Tsuffix', name : 'pro_tsuffix'}
				,{display: 'Pro Esuffix', name : 'pro_esuffix'}
				],

			title: 'Customer',
			sortname: 'pro_id'
	";
	
	#########Edit Zone ###############
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Flexigrid</title>
<link rel="stylesheet" type="text/css" href="css/flexigrid/flexigrid.css" />
<script type="text/javascript" src="lib/jquery/jquery.js"></script>
<script type="text/javascript" src="lib/flexigrid.js"></script>
<style>

	body
		{
		font-family: Arial, Helvetica, sans-serif;
		font-size: 12px;
		}
		
	.flexigrid div.fbutton .add
		{
			background: url(css/images/add.png) no-repeat center left;
		}	

	.flexigrid div.fbutton .delete
		{
			background: url(css/images/close.png) no-repeat center left;
		}	

		
</style>
</head>

<body>

<table id="flex1" style="display:none"></table>
<script>var winMain=window.opener;</script>
<script type="text/javascript">

			jQuery("#flex1").flexigrid
			(
			{
			url: '<?=$loadUrl;?>',
			dataType: 'json',
			<?=$colModel;?>,
			buttons : [
                 <?php if(!isset($f) || $f == ""): ?>
				{name: 'Add', bclass: 'add', onpress : fncClick},
				//{name: 'Delete', bclass: 'delete', onpress : fncClick},
                <?php endif;?>
				{separator: true}
				],			
			sortorder: "desc",
			usepager: true,
			useRp: true,
			//rpOptions: [5,10,15,20,30,50,100,1000,2000],
			//rp: 15,
			//showTableToggleBtn: true,
			//width: 750,
			//onSubmit: addFormData,
			height: 300		
			
			}
			);
			
			
function fncClick(com,grid)
{
//alert(com);
	if (com=='Delete')
		{			
			var answer = confirm('Delete ' + jQuery('.trSelected',grid).length + ' items?');
		}
	else if (com=='Add')
		{
			window.open ("../<?=$updForm;?>?a=a", "frame_details" );
		}			
}		

function goTo(pro_id , pro_name , obj , link_cus){		
	//alert(pro_id+" , "+pro_name+" , "+ obj+" , "+link_cus);
	opener.setCustomer(pro_id , pro_name , obj , link_cus);
	window.close();
}
	
</script>
</body>
</html>

