<?
$t = $_REQUEST["t"];
$f = $_REQUEST["f"];

#########Edit Zone ###############
$tblName="profile";
$fldID="pro_id";
$fldURL="pro_code";

if( !isset($f) || $f == ""){
	$updForm="cus_updForm.php";
}else{
	$updForm = "ecus_updForm.php" ;
}
#########Edit Zone ###############

include_once("connection.php");
$sql = " SELECT pro_id , pro_code , pro_ttitle , pro_etitle , pro_tfname , pro_efname " ;
$sql .= ", pro_tlname , pro_elname , pro_tprefix , pro_eprefix , pro_tcname , pro_ecname ";
$sql .= ", pro_tsuffix , pro_esuffix ";
$sql .= "from $tblName";
$result = runSQL($sql);
$i = 0;
$arrFields=array(); 
$arrShow = array("action" , "pro_id" , "pro_code" , "tname" , "ename" , "com_tname" , "com_ename");
while ($i < mysql_num_fields($result)) {    
    $meta = mysql_fetch_field($result, $i);
	$arrFields[]=$meta->name;	
	//$arrShow[]=$meta->name;
	$i++;
} //while ($i < mysql_num_fields($result)) {
mysql_free_result($result);




$sql=" select ";
$strFldname=implode(",",$arrFields);
$sql.= " $strFldname ";
$sql.=" FROM $tblName " ;
$sql.=" $where $sort $limit";
$result = runSQL($sql);
$total = countRec("$fldID","$tblName $where");

header("Expires: Mon, 26 Jul 1997 05:00:00 GMT" ); 
header("Last-Modified: " . gmdate( "D, d M Y H:i:s" ) . "GMT" ); 
header("Cache-Control: no-cache, must-revalidate" ); 
header("Pragma: no-cache" );
header("Content-type: text/x-json");
$json = "";
$json .= "{\n";
$json .= "page: $page,\n";
$json .= "total: $total,\n";																																																																																																
$json .= "rows: [";																																																																																																
$rc = false;																																																																																								
while ($row = mysql_fetch_array($result)) {	
	if ($rc) $json .= ",";	
	$json .= "\n{";		
	$json .= "cell:[ ";		
	$sp=false;
	foreach($arrShow as $key=>$val){
		if ($sp) $json .= ",";
		if(!isset($f) || $f == ""){
			if ($val=="action") {
				$row[$val]= "<a href=\"../$updForm?a=e&id=".$row[$fldID]."\"><img src=\"../images/b_edit.png\" border=\"0\" /></a>";
				$row[$val].= "&nbsp;<a href=\"../$updForm?a=d&id=".$row[$fldID]."\"><img src=\"../images/b_drop.png\" border=\"0\" /></a>";			
			}
		}else{
			if ($val==$fldURL) {
				$link_js = "javascript:goTo(".$row[$fldID].",\"". $row["pro_efname"] . ":" 
							. $row["pro_elname"] . "\",".$f.",\"Y\");";
				$row[$val] = "<a href='". $link_js ."'>" . $row[$val] . "</a>";
			}
		}
		
		if( $val == "tname" ){
			$row[$val]= $row["pro_ttitle"] . $row["pro_tfname"] . "  " . $row["pro_tlname"];
		}else if( $val == "ename" ){
			$row[$val]= $row["pro_etitle"] . $row["pro_efname"] . "  " . $row["pro_elname"];
		}else if( $val == "com_tname" ){
			$row[$val]= $row["pro_tprefix"] . "  " . $row["pro_tcname"] . "  " . $row["pro_tsuffix"];
		}else if( $val == "com_ename" ){
			$row[$val]= $row["pro_eprefix"] . "  " . $row["pro_ecname"] . "  " . $row["pro_esuffix"];
		}
		
		$json .= "'".addslashes($row[$val])."'";		
		$sp = true;
	}//foreach($arrFields as $key=>$val){
	$json .= "]}";
	$rc = true;		
} //while ($row = mysql_fetch_array($result)) {

$json .= "]\n";
$json .= "}";
echo $json;
?>

