<?
$t = $_REQUEST["t"];
$f = $_REQUEST["f"];

	#########Edit Zone ###############	
	//$loadUrl="cus_load.php";
	$loadUrl="cus_load.php?t=" . $t . "&f=" . $f ;
	$updForm="cus_updForm.php";
	$colModel= "
			colModel : [
				{display: 'ID', name : 'nif_id', width : 50, sortable : true, align: 'center'}				
				,{display: 'Type', name : 'nif_type', width : 180, sortable : true, align: 'left'}
				,{display: 'Initial', name : 'nif_initial', width : 120, sortable : true, align: 'left'}			
				,{display: 'First Name', name : 'nif_firstname', width : 130, sortable : true, align: 'left'}
				,{display: 'Last Name', name : 'nif_lastname', width : 80, sortable : true, align: 'left'}
				,{display: 'Title', name : 'nif_title', width : 80, sortable : true, align: 'left'}
				,{display: 'Company', name : 'nif_company', width : 80, sortable : true, align: 'left'}
				,{display: 'No', name : 'nif_no', width : 80, sortable : true, align: 'left'}
				,{display: 'Soi', name : 'nif_soi', width : 80, sortable : true, align: 'left'}
				,{display: 'Road', name : 'nif_road', width : 80, sortable : true, align: 'left'}
				,{display: 'Tumbol', name : 'nif_tumbol', width : 80, sortable : true, align: 'left'}
				,{display: 'District', name : 'nif_amphur', width : 80, sortable : true, align: 'left'}
				,{display: 'Province', name : 'nif_province', width : 80, sortable : true, align: 'left'}
				,{display: 'Zip Code', name : 'nif_zipcode', width : 80, sortable : true, align: 'left'}
				,{display: 'Telephone', name : 'nif_tel', width : 80, sortable : true, align: 'left'}
				,{display: 'Fax', name : 'nif_fax', width : 80, sortable : true, align: 'left'}
				,{display: 'Mobile', name : 'nif_mobile', width : 80, sortable : true, align: 'left'}
				,{display: 'email', name : 'nif_email', width : 80, sortable : true, align: 'left'}
				,{display: 'Website', name : 'nif_website', width : 80, sortable : true, align: 'left'}
				,{display: 'Remark', name : 'nif_remark', width : 80, sortable : true, align: 'left'}
				,{display: 'Used', name : 'nif_used', width : 80, sortable : true, align: 'left'}
				,{display: 'User Create', name : 'usr_cre', width : 80, sortable : true, align: 'left', hide: true}
				,{display: 'Date Create', name : 'date_cre', width : 80, sortable : true, align: 'left', hide: true}
				,{display: 'User Update', name : 'usr_upd', width : 80, sortable : true, align: 'left', hide: true}
				,{display: 'Date Update', name : 'date_upd', width : 80, sortable : true, align: 'left', hide: true}
				],
				
			searchitems : [				
				{display: 'ID', name : 'nif_id'}				
				,{display: 'Type', name : 'nif_type'}
				,{display: 'Initial', name : 'nif_initial'}			
				,{display: 'First Name', name : 'nif_firstname'}
				,{display: 'Last Name', name : 'nif_lastname'}
				,{display: 'Title', name : 'nif_title'}
				,{display: 'Company', name : 'nif_company'}
				,{display: 'No', name : 'nif_no'}
				,{display: 'Soi', name : 'nif_soi'}
				,{display: 'Road', name : 'nif_road'}
				,{display: 'Tumbol', name : 'nif_tumbol'}
				,{display: 'District', name : 'nif_amphur'}
				,{display: 'Province', name : 'nif_province'}
				,{display: 'Zip Code', name : 'nif_zipcode'}
				,{display: 'Telephone', name : 'nif_tel'}
				,{display: 'Fax', name : 'nif_fax'}
				,{display: 'Mobile', name : 'nif_mobile'}
				,{display: 'email', name : 'nif_email'}
				,{display: 'Website', name : 'nif_website'}
				,{display: 'Remark', name : 'nif_remark'}
				,{display: 'Used', name : 'nif_used'}
				,{display: 'User Create', name : 'usr_cre'}
				,{display: 'Date Create', name : 'date_cre'}
				,{display: 'User Update', name : 'usr_upd'}
				,{display: 'Date Update', name : 'date_upd'}
				],
				
			title: 'Customer',
			sortname: 'nif_id'
	";
	
	#########Edit Zone ###############
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Flexigrid</title>
<link rel="stylesheet" type="text/css" href="css/flexigrid/flexigrid.css">
<script type="text/javascript" src="lib/jquery/jquery.js"></script>
<script type="text/javascript" src="lib/flexigrid.js"></script>
<style>

	body
		{
		font-family: Arial, Helvetica, sans-serif;
		font-size: 12px;
		}
		
	.flexigrid div.fbutton .add
		{
			background: url(css/images/add.png) no-repeat center left;
		}	

	.flexigrid div.fbutton .delete
		{
			background: url(css/images/close.png) no-repeat center left;
		}	

		
</style>
</head>

<body>


<table id="flex1" style="display:none"></table>

<script type="text/javascript">

			$("#flex1").flexigrid
			(
			{
			url: '<?=$loadUrl;?>',
			dataType: 'json',
			<?=$colModel;?>,
			buttons : [
				{name: 'Add', bclass: 'add', onpress : fncClick},
				//{name: 'Delete', bclass: 'delete', onpress : test},
				{separator: true}
				],			
			sortorder: "asc",
			usepager: true,
			useRp: true,
			//rpOptions: [5,10,15,20,30,50,100,1000,2000],
			//rp: 15,
			//showTableToggleBtn: true,
			//width: 750,
			//onSubmit: addFormData,
			height: 300		
			
			}
			);
			
			
function fncClick(com,grid)
{
	if (com=='Delete')
		{			
			confirm('Delete ' + $('.trSelected',grid).length + ' items?')
		}
	else if (com=='Add')
		{
			window.open ("../<?=$updForm;?>?a=a", "frame_details" );
		}			
}		

function goTo(pro_id , pro_name , obj , link_cus){		
	//alert(pro_id+" , "+pro_name+" , "+ obj+" , "+link_cus);
	opener.setCustomer(pro_id , pro_name , obj , link_cus);
	window.close();
}
	
</script>
</body>
</html>

