<?
include_once("../cfg/config.cfg.php");
global $connect;

function connection(){
	global $connect;
	
	$db['default']['hostname'] = hostname;
	$db['default']['username'] = username;
	$db['default']['password'] = password;
	$db['default']['database'] = dbname;
	
	$db['live']['hostname'] = 'localhost';
	$db['live']['username'] = '';
	$db['live']['password'] = '';
	$db['live']['database'] = '';
	
	$active_group = 'default';
	
	$base_url = "http://".$_SERVER['HTTP_HOST'];
	$base_url .= str_replace(basename($_SERVER['SCRIPT_NAME']),"",$_SERVER['SCRIPT_NAME']);
	//if (strpos($base_url,'webplicity.net')) $active_group = "live";

	$connect = mysql_connect($db[$active_group]['hostname'],$db[$active_group]['username'],$db[$active_group]['password']) or die ("Error: could not connect to database");
	$db = mysql_select_db($db[$active_group]['database']);
	mysql_query("SET NAMES 'utf8'",$connect);
	
}

function runSQL($rsql) {

	connection();
	$result = mysql_query($rsql) or die ($rsql);
	
	return $result;
	disconnect();
}

function disconnect(){
	global $connect;
	mysql_close($connect);
}

/*function runSQL($rsql) {

	$db['default']['hostname'] = hostname;
	$db['default']['username'] = username;
	$db['default']['password'] = password;
	$db['default']['database'] = dbname;
	
	$db['live']['hostname'] = 'localhost';
	$db['live']['username'] = '';
	$db['live']['password'] = '';
	$db['live']['database'] = '';
	
	$active_group = 'default';
	
	$base_url = "http://".$_SERVER['HTTP_HOST'];
	$base_url .= str_replace(basename($_SERVER['SCRIPT_NAME']),"",$_SERVER['SCRIPT_NAME']);
	//if (strpos($base_url,'webplicity.net')) $active_group = "live";

	$connect = mysql_connect($db[$active_group]['hostname'],$db[$active_group]['username'],$db[$active_group]['password']) or die ("Error: could not connect to database");
	$db = mysql_select_db($db[$active_group]['database']);
	mysql_query("SET NAMES 'utf8'",$connect);
	$result = mysql_query($rsql) or die ($rsql);
	
	return $result;
	mysql_close($connect);
}
*/


function countRec($fname,$tname) {
	$sql = "SELECT count($fname) FROM $tname ";
	$result = runSQL($sql);
	while ($row = mysql_fetch_array($result)) {
		return $row[0];
	}
		
}

function get_table_fieldname($table_name) 
{
	connection();	
	$arr_fields = @mysql_list_fields(dbname, $table_name);
	$columns_num = @mysql_num_fields($arr_fields);

	$arr_field_name = array();
	for ($i = 0; $i < $columns_num; $i++) 
	{
		$arr_field_name[$i] = @mysql_field_name($arr_fields, $i);
	}	

	return $arr_field_name;
	disconnect();

}


$page = $_POST['page'];
$rp = $_POST['rp'];
$sortname = $_POST['sortname'];
$sortorder = $_POST['sortorder'];
//$fieldname = get_table_fieldname("nameinfo");

if (!$sortname) $sortname = 'name';
if (!$sortorder) $sortorder = 'desc';

$sort = "ORDER BY $sortname $sortorder";

if (!$page) $page = 1;
if (!$rp) $rp = 10;

$start = (($page-1) * $rp);

$limit = "LIMIT $start, $rp";

$query = $_POST['query'];
$qtype = $_POST['qtype'];

$where = " WHERE 1=1 ";
//if ($query) $where = " WHERE $qtype LIKE '%$query%' ";
if($qtype=="all"){
	
	$fieldname = get_table_fieldname($tblName) ;
	
	$where .=" AND ( ";
	foreach($fieldname as $fKey => $fVal){
		if($fKey == 0){
		 $where.=" $fVal like '%$query%'";
		}else{
		 $where.=" OR $fVal like '%$query%'";
		}		
	}
	$where.=" )";

	
	/*$where.=" 
		AND (
		nif_id like '%$query%'
		OR nif_type like '%$query%'
		OR nif_initial like '%$query%'
		OR nif_firstname like '%$query%' 
		OR nif_lastname like '%$query%'
		OR nif_title like '%$query%'
		OR nif_company like '%$query%'	
		OR nif_no like '%$query%'
		OR nif_soi like '%$query%'
		OR nif_road like '%$query%' 
		OR nif_tumbol like '%$query%'
		OR nif_amphur like '%$query%'
		OR nif_province like '%$query%'	
		OR nif_zipcode like '%$query%'
		OR nif_tel like '%$query%'
		OR nif_fax like '%$query%' 
		OR nif_mobile like '%$query%'
		OR nif_email like '%$query%'
		OR nif_website like '%$query%'	
		OR nif_remark like '%$query%'
		OR nif_used like '%$query%'
		OR usr_cre like '%$query%' 
		OR date_cre like '%$query%'
		OR usr_upd like '%$query%'
		OR date_upd like '%$query%'	 
		)";*/
}else{
	$where .= " AND $qtype LIKE '%$query%' ";
}


?>