<?
	#########Edit Zone ###############	
	$loadUrl="loc_load.php";
	$updForm="loc_updForm.php";
	$colModel= "
			colModel : [
				{display: 'ID', name : 'loc_id', width : 50, sortable : true, align: 'center'}				
				,{display: 'shortname', name : 'loc_shortname', width : 180, sortable : true, align: 'left'}
				,{display: 'fullname', name : 'loc_fullname', width : 120, sortable : true, align: 'left'}			
				,{display: 'sqm.', name : 'loc_sqm', width : 130, sortable : true, align: 'left'}
				,{display: 'Location Group', name : 'lgp_id', width : 80, sortable : true, align: 'right'}
				,{display: 'Seq.', name : 'loc_seq', width : 80, sortable : true, align: 'right'}
				,{display: 'Settlement Group', name : 'stt_id', width : 80, sortable : true, align: 'right'}
				,{display: 'User Create', name : 'usr_cre', width : 80, sortable : true, align: 'right', hide: true}
				,{display: 'Date Create', name : 'date_cre', width : 80, sortable : true, align: 'right', hide: true}
				,{display: 'User Update', name : 'usr_upd', width : 80, sortable : true, align: 'right', hide: true}
				,{display: 'Date Update', name : 'date_upd', width : 80, sortable : true, align: 'right', hide: true}
				],
				
			searchitems : [				
				{display: 'ID', name : 'loc_id'}				
				,{display: 'shortname', name : 'loc_shortname'}
				,{display: 'fullname', name : 'loc_fullname'}			
				,{display: 'sqm.', name : 'loc_sqm'}
				,{display: 'Location Group', name : 'lgp_id'}
				,{display: 'Seq.', name : 'loc_seq'}
				,{display: 'Settlement Group', name : 'stt_id'}
				,{display: 'User Create', name : 'usr_cre'}
				,{display: 'Date Create', name : 'date_cre'}
				,{display: 'User Update', name : 'usr_upd'}
				,{display: 'Date Update', name : 'date_upd'}
				,{display: 'All Fields', name : 'all', isdefault: true}
				],
				
			title: 'Location',
			sortname: 'loc_id'
	";
	
	#########Edit Zone ###############
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Flexigrid</title>
<link rel="stylesheet" type="text/css" href="css/flexigrid/flexigrid.css">
<script type="text/javascript" src="lib/jquery/jquery.js"></script>
<script type="text/javascript" src="lib/flexigrid.js"></script>
<style>

	body
		{
		font-family: Arial, Helvetica, sans-serif;
		font-size: 12px;
		}
		
	.flexigrid div.fbutton .add
		{
			background: url(css/images/add.png) no-repeat center left;
		}	

	.flexigrid div.fbutton .delete
		{
			background: url(css/images/close.png) no-repeat center left;
		}	

		
</style>
</head>

<body>


<table id="flex1" style="display:none"></table>

<script type="text/javascript">

			$("#flex1").flexigrid
			(
			{
			url: '<?=$loadUrl;?>',
			dataType: 'json',
			<?=$colModel;?>,
			buttons : [
				{name: 'Add', bclass: 'add', onpress : fncClick},
				//{name: 'Delete', bclass: 'delete', onpress : test},
				{separator: true}
				],			
			sortorder: "asc",
			usepager: true,
			useRp: true,
			//rpOptions: [5,10,15,20,30,50,100,1000,2000],
			//rp: 15,
			//showTableToggleBtn: true,
			//width: 750,
			//onSubmit: addFormData,
			height: 300		
			
			}
			);
			
			
function fncClick(com,grid)
{
	if (com=='Delete')
		{			
			confirm('Delete ' + $('.trSelected',grid).length + ' items?')
		}
	else if (com=='Add')
		{
			window.open ("../<?=$updForm;?>?a=a", "frame_details" );
		}			
}		

	
</script>
</body>
</html>

