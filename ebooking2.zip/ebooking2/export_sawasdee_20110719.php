<?php
	ob_start();
	session_start();
	$arrSawasdee=$_SESSION["arrData"];

	header("Content-Type: application/vnd.ms-excel");
	header('Content-Disposition: attachment; filename="Sawasdee.xls"');#ชื่อไฟล์	
?>
<html xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:x="urn:schemas-microsoft-com:office:excel"
xmlns="http://www.w3.org/TR/REC-html40">
<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</HEAD><BODY>

	  <table width="100%" align="center" x:str BORDER="1">
		<tr class="lst_BorderHead" >
		  <td><div align="center"><b>วันที่</b></div></td>
		  <td><div align="center"><b>เวลา</b></div></td>
		  <td><div align="center"><b>ชื่องาน</b></div></td>
		  <td><div align="center"><b>ผู้จัด</b></div></td>
		  <td><div align="center"><b>ผู้อบรม</b></div></td>
		  <td><div align="center"><b>สถานที่</b></div></td>
		  <td><div align="center"><b>ติดต่อ</b></div></td>
		  <td><div align="center"><b>เบอร์โทร</b></div></td>
		</tr>
		<?

		
			while (list($key, $val) = each($arrSawasdee)) {
//				foreach($arrData as $key=>$val){
				$bgcolor == "#E7F0F8" ? $bgcolor="#F5F9FC" : $bgcolor="#E7F0F8" ;
				$Date=$val["Date"];
				$Time=$val["Time"];
				$EventName=$val["EventName"];
				$Customer=$val["Customer"];
				$Atten=$val["Atten"];
				$Location=$val["Location"];
				$Contact=$val["Contact"];				
		?>
		<tr bgcolor="<?=$bgcolor ;?>">
		  <td><?=$Date;?></td>
		  <td><?=$Time;?></td>
		  <td><?=$EventName;?></td>
		  <td><?=$Customer;?></td>
		  <td><?=$Atten;?></td>
		  <td><?=$Location;?></td>
		  <td><?=$Contact;?></td>
		  <td><?=$Tel;?></td>
		</tr>
		<?
			} //foreach($arrData as $key=>$val){
		?>
	</table>

</BODY>
</HTML>