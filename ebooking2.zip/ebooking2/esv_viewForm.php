<?
	ob_start(); 
	session_start();
	define("tableName","equip_serv");
	define("viewForm","esv_viewForm.php");
	define("updForm","esv_updForm.php");
	define("field_id","esv_id");
	define("beg_id",1);	
	define("end_id",6);	
	$sql = "SELECT esv.esv_id, esv.esv_name, dep.dep_name, stt.stt_name,
				esv.esv_qty, esv.esv_amt, esv.esv_status, esv.esv_include_vat, esv.usr_cre,
				esv.date_cre, esv.usr_upd, esv.date_upd
				FROM equip_serv esv, department dep, settle_cat stt
				WHERE esv.esv_dept = dep.dep_id 
				AND esv.stt_id = stt.stt_id
				";
	//echo "$sql";
	//exit();
	define("query","$sql");	
	$cap_name = array();
	$cap_name = array("#","Name","Department","Settlement Group","Quantity","Amount","Status","Include Vat","used create","date create","user upd","date upd");
	
	$key = array_keys($_SESSION["sec_add"], viewForm); 
	//print_r(array_keys($_SESSION["sec_add"], viewForm));
	if($key[0])
		define("insert",1);		
	else
		define("insert",0);			
	//echo "insert = ".insert."<br>";
		
	$key = array_keys($_SESSION["sec_edit"], viewForm); 
	//print_r(array_keys($_SESSION["sec_edit"], viewForm));
	if($key[0])
		define("edit",1);		
	else
		define("edit",0);			
	//echo "edit = ".edit."<br>";
	
	$key = array_keys($_SESSION["sec_del"], viewForm); 
	//print_r(array_keys($_SESSION["sec_del"], viewForm));
	if($key[0])
		define("del",1);		
	else
		define("del",0);			
	//echo "del = ".del."<hr>";
	
	include("func/viewForm.func.php");
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</body>
</html>
