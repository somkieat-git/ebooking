<?
	ob_start(); 
	session_start();	
	define("tableName","checklist");
	define("viewForm","ckl_viewForm.php");
	define("updForm","ckl_updForm.php");
	define("field_id","ckl_id");
	define("beg_id",1);	
	define("end_id",3);	
	
	$sql = "SELECT ckl2.ckl_id, ckl2.ckl_name, ckl2.ckl_val, ckl1.ckl_name, ckl2.usr_cre,
				ckl2.date_cre, ckl2.usr_upd, ckl2.date_upd
				FROM checklist ckl1, checklist ckl2
				WHERE ckl1.ckl_id = ckl2.ckl_cnt_fr
				";
	//echo "$sql";
	//exit();
	define("query","$sql");
	
	$cap_name = array();
	$cap_name = array("#","Description","Value","From Desc","User create","Date create","User upd","Date upd");
	
	$key = array_keys($_SESSION["sec_add"], viewForm); 
	//print_r(array_keys($_SESSION["sec_add"], viewForm));
	if($key[0])
		define("insert",1);		
	else
		define("insert",0);			
	//echo "insert = ".insert."<br>";
		
	$key = array_keys($_SESSION["sec_edit"], viewForm); 
	//print_r(array_keys($_SESSION["sec_edit"], viewForm));
	if($key[0])
		define("edit",1);		
	else
		define("edit",0);			
	//echo "edit = ".edit."<br>";
	
	$key = array_keys($_SESSION["sec_del"], viewForm); 
	//print_r(array_keys($_SESSION["sec_del"], viewForm));
	if($key[0])
		define("del",1);		
	else
		define("del",0);			
	//echo "del = ".del."<hr>";
	
	include("func/viewForm.func.php");
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</body>
</html>
