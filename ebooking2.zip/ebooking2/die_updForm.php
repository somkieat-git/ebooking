<?
	//จุดที่ต้องแก้ไข 1.รับค่าข้อมูลที่จะ Write ลง DB
	ob_start();
	session_start();
	
	
	$die_id = $_REQUEST["die_id"];
	$evn_id = $_REQUEST["evn_id"];
	$die_date = $_REQUEST["die_date"];
	$die_desc = $_REQUEST["die_desc"];
	$die_person = $_REQUEST["die_person"];
	$die_used = $_REQUEST["die_used"];

	$id = $_REQUEST["id"];
	$action = $_REQUEST["a"];
	$Submit = $_REQUEST["Submit"];
	$cap_name = array();
	$cap_name = array("#","Event","Date","Desc","Person","Used");
	
	/*echo "frm_id = $frm_id<br>
			   frm_name= $frm_name<br>
			   frm_status = $frm_status<br>
			   id = $id<br>
			   action = $action<br>
			   Submit = $Submit <hr>";*/
			   
	define("updForm","die_updForm.php");
	define("updSave","die_updForm.php");
	define("tableName","daileevent");
	define("menuName","Daily Event");
	define("field_id","die_id");
	define("action",$action);
	define("id",$id);	
	define("beg_id",1);	
	define("end_id",5);	
	include_once("func/updForm.func.php");	
	include_once("func/sql.func.php");	
	
	//จุดที่ต้องแก้ไข 2.รับค่าข้อมูลที่จะ Write ลง DB
	function checklist($var,$name){
		global $data;
		global $flag;

		if(empty($var)){
			//จุดที่ต้องแก้ไข 3.บันทึกรายชื่อ Field ที่ต้องกรอกให้ครบ
			if(ereg("die_date|die_desc|die_person",$name))
				$flag = 1;
		}  //if(empty($var)){
		$data[$name] = $var;
	} //function checklist($var,$name){
	
	if(!empty($Submit)){
		//จุดที่ต้องแก้ไข 4.เช็คข้อมูลที่จำเป็นต้องกรอกให้ครบถ้วน Write ลง DB
		checklist($die_date,"die_date");
		checklist($die_desc,"die_desc");
		checklist($die_person,"die_person");

		if($flag){
			$mesg = "Please input data in ";
			while(list($key,$value) = each($data)){
				if(empty($value)){
					//จุดที่ต้องแก้ไข 5.copy ในจุดที่ 3 มาไว้บรรทัดนี้ด้วย
				if(!ereg("die_date|die_desc|die_person",$name))
						$str .= "$key,";
				}  //if(empty($value)){
				//$str = substr( $str, strlen($str)-1, 1 );
			}
			echo errmesg ("$mesg $str");			
		}	//if($flag){
		else{
			//จุดที่ต้องแก้ไข 6 เตรียมWrite ลง DB ตามเงื่อนไข Action		
			if ($action=="a"){
				$data["die_id"] = "";
				$data["usr_cre"] = $_SESSION["usr_name"];
				$data["date_cre"] = date("Y/m/d  H:i:s");				
				$query = create_insert_query($table_name,$data);				
				//echo "$query<br>";
				mysql_query($query) or die("Insert error");	
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");	
				//Show alert by javascript
				echo "<script>
						alert ('Insert complete');
						window.location = 'die_viewForm.php';
					  </script>";
				exit();
			} //if ($action=="a"){
			
			if ($action=="e"){
				$data["usr_upd"] = $_SESSION["usr_name"];
				$data["date_upd"] = date("Y/m/d  H:i:s");				
				$query = create_update_query($table_name, $data, $id, $field_id);				
				//echo "$query<br>";
				mysql_query($query) or die("Update error");	
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");	
				//Show alert by javascript
				echo "<script>
						alert ('Update complete');
						window.location = 'die_viewForm.php';
					  </script>";
				exit();
			}  //if ($action=="e"){
			
			if ($action=="d"){
				//$data["usr_upd"] = "tan";
				//$data["date_upd"] = date("Y/m/d  H:i:s");				
				//$query = create_update_query($table_name, $data, $id, $field_id);				
				$query = "DELETE FROM $table_name WHERE $field_id = $id " ;
				//echo "$query<br>";
				//exit();
				
				mysql_query($query) or die("Delete error");	
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");	
				//Show alert by javascript
				echo "<script>
						alert ('Delete complete');
						window.location = 'die_viewForm.php';
					  </script>";
				exit();
			}  //if ($action=="e"){
						
		}  //else{ of if($flag){
	}  //if(!empty($Submit)){
	
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</body>
</html>
