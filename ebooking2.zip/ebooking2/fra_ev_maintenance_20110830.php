<?
	ob_start(); 
	session_start();	
	include("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	$evn_id = $_REQUEST["id"];
?>
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>

<frameset cols="200,*" frameborder="NO" border="0" framespacing="0">
  <frame name="frame_menu"  src="left_ev_maintenance.php?id=<?=$evn_id?>" >
  <frame name="frame_details" src="ev_maintenance.php?id=<?=$evn_id?>" >
</frameset>
<noframes><body>
</body></noframes>
</html>
