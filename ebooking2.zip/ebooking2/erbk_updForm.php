<?php
	ob_start(); 
	session_start();
		

	include_once("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");	
	define("updSave","erbk_updForm.php");
	//$UsrId = $_SESSION["UsrID"];
	$evn_id = $_REQUEST["id"];
	$action = $_REQUEST["a"];

	
	if(!empty($evn_id)){
		$sql = "SELECT * FROM eventname WHERE evn_id = '$evn_id'  ";
		$result = getData($sql);
		$row = mysql_fetch_array($result);
		$evn_shortname = $row["evn_shortname"];
		$evn_fullname = $row["evn_fullname"];
		$evn_thainame = $row["evn_thainame"];		
	} //if(!empty($ev_id)){	
	
	
	
	// ==========  Booking Status Code  ================ //
	$sql = "SELECT * FROM bookingstatus ";
	$result = getData($sql);
	$bks_status = array();
	while( $row = mysql_fetch_array($result)){
		//$bks_status[$row["bks_id"]] = $row["bks_code"] . " - " . $row["bks_name"];
		$bks_status[$row["bks_id"]] = $row["bks_name"];
	}
	//echo "<pre>"; print_r($bks_status); exit();


	// ===========  GEN EVENT ID ============== //
	
	$cur_date = date("d/m/Y");
	list($dd, $mm, $yyyy) = explode('/',$cur_date);
	if(strlen($mm) < 2) $mm = '0' . $mm;
	$yymm = substr($yyyy,2,2).$mm;
	
	$sql = "SELECT MAX(evn_id) as id FROM eventname
				 WHERE evn_id like '$yymm%' ";
	//echo "\$sql=$sql<br>";
	//exit();
	
	$result = getData($sql);
	$row = mysql_fetch_array($result);
	
	//echo $row[0]; echo "<hr>";
	//echo "\$yymm=$yymm<br>";

	if(is_null($row["id"]))
		$evn_id_new =  "$yymm"."0001";
	else{
		//$evn_id = ($row[0]+1);
		$running = "99".substr($row["id"], 4)+1;
		$evn_id_new = "$yymm".substr($running, 2);
		//echo "runing=$running<br>"; 
	}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Rebook Event - <?php echo $evn_id . " - " . $evn_fullname ; ?></title>
<link href="css/format.css.css" rel="stylesheet" type="text/css">
<script type="text/javascript" src="js/ctrl_erbk_updForm.js"></script>

<!--------------  jQuery Datepick (Popup Calendra)  ---------------------->
	
	<link href="./css/jquery.datepick.css" type="text/css" rel="stylesheet" />
	<script type="text/javascript" src="lib/jquery.min.js"></script>	
	<script type="text/javascript" src="js/jquery.datepick.js"></script>
	
</head>

<body>
<br />
<form action="<?=$updSave ?>?id=<?php echo $evn_id ; ?>" method="post" name="frm"  id="frm" onsubmit="return checkValueOnSubmit();">

<table border="0" class="BorderGreen" width="530">
 <tr class="BorderSilver">
  <td width="474" colspan="4" style="background-color:#339900;font-weight:bold;color:White;">
	<div align="center"><strong >Rebook Event - <?php echo $evn_id . " - " . $evn_fullname ; ?></strong></div>
  </td>
 </tr>
 <tr>
  <td align="center" colspan="4">
   <table border="0" class="BorderGreen" width="530">
   <tr>
   	<td width="173" colspan="1" align="left">Full Event Name : </td>
	 <td width="279" colspan="3" align="left">
	 <input type="text" name="evn_fullname" size="30" id="evn_fullname" onkeyup="document.getElementById('evn_shortname').value = document.getElementById('evn_fullname').value" value="<?php echo $evn_fullname; ?>" />
	 </td>
   </tr>
   <tr>
   	<td width="173" colspan="1" align="left">Short Event Name : </td>
	 <td width="279" colspan="3" align="left">
	 <input type="text" name="evn_shortname" size="30" id="evn_shortname" value="<?php echo $evn_shortname; ?>" onfocus="document.getElementById('evn_shortname').value = document.getElementById('evn_fullname').value; if(document.getElementById('evn_fullname').value == '') alert('Please!! Insert Event FullName');" />
	 </td>
   </tr>
   <tr>
   	<td width="173" colspan="1" align="left">Thai Event Name : </td>
	 <td width="279" colspan="3" align="left">
	 <input type="text" name="evn_thainame" size="30" id="evn_thainame" value="<?php echo $evn_thainame; ?>" onfocus="if(document.getElementById('evn_shortname').value == '') alert('Please!! Insert Event Short Name');"/>
	 </td>
   </tr>
    <tr>
     <td width="173" colspan="1" align="left">Booking Status Code : </td>
	 <td width="279" colspan="3" align="left">
	 <!--<select name="bks_id" id="bks_id" onchange="javascript:chkDup(this.options(selectedIndex).text);">-->
	  <select name="bks_id" id="bks_id" 
	  onfocus="if(document.getElementById('evn_thainame').value == '') alert('Please!! Insert Event Thai Name');" >
	   <?php foreach( $bks_status as $bks_id => $bks_name ) :?>
	 	 <option value="<?php echo $bks_id ; ?>"><?php echo $bks_name; ?></option>
	   <?php endforeach;?>
	  </select>
	  <!--<input type="hidden" id="hdd_bks" name="hdd_bks" value="" />-->
	 </td>
	</tr>
	<tr>
	 <td colspan="4" align="left">Choose Event Date : </td>
	</tr>
	<tr>
	 <td colspan="4">
	  <table border="1" class="BorderGreen" width="530" id="myTable">
		<tr>
		 <td colspan="7" align="center">
		 	<a href="javascript:editEventDate('a' , 1 , '<?php echo $evn_id; ?>');">Add Date Block</a>
			<input type="hidden" name="hdd_item" id="hdd_item" />
		 </td>
		</tr>
		<tr>
		 <td width="20" style="background-color:#339900;font-weight:bold;color:White;"> </td>
		 <td width="27" style="background-color:#339900;font-weight:bold;color:White;">#</td>
		 <td width="87" style="background-color:#339900;font-weight:bold;color:White;">IN DATE</td>
		 <td width="96" style="background-color:#339900;font-weight:bold;color:White;">EVENT START</td>
		 <td width="96" style="background-color:#339900;font-weight:bold;color:White;">END DATE</td>
		 <td width="82" style="background-color:#339900;font-weight:bold;color:White;">OUT DATE</td>
		 <td width="76" style="background-color:#339900;font-weight:bold;color:White;"> </td>
		</tr>
		<?php 
			$sql = "SELECT * FROM ev_dateblock WHERE evn_id = '$evn_id' AND edbk_item > 0 ";
			$result = getData($sql);
			//echo "\$sql= $sql";
			while( $row = mysql_fetch_array($result) ): 
		 
				$item = $row["edbk_item"];
				$in_date = chgDate($row["edbk_in_date"]);
				$in_time = chgTime($row["edbk_in_time"]);
				$evn_date =chgDate($row["edbk_ev_begdate"]);
				$beg_time = chgTime($row["edbk_ev_begtime"]);
				$last_date =chgDate($row["edbk_ev_enddate"]);
				$end_time = chgTime($row["edbk_ev_endtime"]);
				$out_date = chgDate($row["edbk_out_date"]);
				$out_time = chgTime($row["edbk_out_time"]);	
				$loc_id = $row["loc_id"] ;
		 ?>
		<tr>
		 <td>
		  <input type="checkbox" name="chk[]" id="chk_<?php echo $row["edbk_item"]; ?>" 
		  value="N" onclick="javascript:enableLink(<?php echo $row["edbk_item"]; ?> , this.value);" />
		  <input type="hidden" name="chk_item[]" id="chk_item_<?php echo $row["edbk_item"]; ?>" 
		  value="<?php echo $row["edbk_item"]; ?>_N" />
		 </td>
		 <td>
		 <?php echo $item; ?>
		  <input type='hidden' name="hdd_loc_<?php echo $row["edbk_item"]; ?>" 
		  id="hdd_loc_<?php echo $row["edbk_item"]; ?>" value="<?php echo $loc_id; ?>" />
		 </td>
		 <td>
		  <label id="in_date_<?php echo $row["edbk_item"]; ?>" for="hdd_indate_<?php echo $row["edbk_item"]; ?>">
		   <?php echo $in_date; ?>
		  </label>
		  <input type="hidden" name="hdd_indate_<?php echo $row["edbk_item"]; ?>" 
		  id="hdd_indate_<?php echo $row["edbk_item"]; ?>" value="<?php echo $in_date; ?>" />
		  <input type="hidden" name="in_time_<?php echo $row["edbk_item"]; ?>" 
		  id="in_time_<?php echo $row["edbk_item"]; ?>" value="<?php echo $in_time; ?>" />
		 </td>
		 <td>
		  <label id="begdate_<?php echo $row["edbk_item"]; ?>" for="hdd_begdate_<?php echo $row["edbk_item"]; ?>">
		   <?php echo $evn_date ; ?>
		  </label>
		  <input type="hidden" name="hdd_begdate_<?php echo $row["edbk_item"]; ?>" 
		  id="hdd_begdate_<?php echo $row["edbk_item"]; ?>" value="<?php echo $evn_date; ?>" />
		  <input type="hidden" name="begtime_<?php echo $row["edbk_item"]; ?>" 
		  id="begtime_<?php echo $row["edbk_item"]; ?>" value="<?php echo $beg_time; ?>" />
		 </td>
		 <td>
		  <label id="enddate_<?php echo $row["edbk_item"]; ?>" for="hdd_enddate_<?php echo $row["edbk_item"]; ?>">
		   <?php echo $last_date ; ?>
		  </label>
		  <input type="hidden" name="hdd_enddate_<?php echo $row["edbk_item"]; ?>" 
		  id="hdd_enddate_<?php echo $row["edbk_item"]; ?>" value="<?php echo $last_date; ?>" />
		  <input type="hidden" name="endtime_<?php echo $row["edbk_item"]; ?>" 
		  id="endtime_<?php echo $row["edbk_item"]; ?>" value="<?php echo $end_time; ?>" />
		 </td>
		 <td>
		  <label id="out_date_<?php echo $row["edbk_item"]; ?>" for="hdd_outdate_<?php echo $row["edbk_item"]; ?>">
		   <?php echo $out_date; ?>
		  </label>
		  <input type="hidden" name="hdd_outdate_<?php echo $row["edbk_item"]; ?>" 
		  id="hdd_outdate_<?php echo $row["edbk_item"]; ?>" value="<?php echo $out_date; ?>"/>
		  <input type="hidden" name="out_time_<?php echo $row["edbk_item"]; ?>" 
		  id="out_time_<?php echo $row["edbk_item"]; ?>" value="<?php echo $out_time; ?>" />
		 </td>
         <td>
		  <input type="button" name="edit_event_<?php echo $row["edbk_item"]; ?>" 
		  id="edit_event_<?php echo $row["edbk_item"]; ?>" class="Button" value="Change" 
		  disabled="disabled" onclick="javascript:editEventDate('u' , '<?php echo $row["edbk_item"]; ?>' 
		  , '<?php echo $evn_id; ?>' );" />
		 </td>
		</tr>
		<?php endwhile; ?>
	  </table>
	 </td>
	</tr>
	<tr>
	 <td colspan="4">
	  <div align="center">
	   <input type="checkbox" name="upd_years" id="upd_years" value="u" />
	   <span style="color:#FF0000"><?php echo "  Update Years all select" ; ?></span>
	  </div>
	 </td>
	</tr>
	<tr align="center" >
	 <td colspan="4">	  	
	 <div align="center">
	  <input name="Submit2" type="button" class="Button" value="&lt;= Back " onClick="window.location = 'ecus_updForm.php?id=<?=$evn_id?>'" >
	  <input name="Submit" type="submit" class="Button" value="   OK   " <?=$disabled ;?> />
	  <input name="Button" type="button" class="Button" id="Button"  onClick="history.go(-1)" value="Cancel" >
	  <input name="Submit22" type="button" class="Button" value="Next =&gt;" onClick="window.location = 'eloc_viewForm.php?id=<?=$evn_id?>'" >		  
	  <input name="hdd_list" type="hidden" id="hdd_list" value="" />
	 </div>
	 </td>
	</tr>
   </table>
  </td>
 </tr>	
</table>

</form>


<?php 

// ========================  Save Rebook ================================= //

	$Submit = $_REQUEST["Submit"];
	//echo "\$Submit= " . $Submit ;
	
	if(!empty($Submit)){
	//exit();
		$evn_id = $_REQUEST["id"];
		$chk_item = $_REQUEST["chk_item"];
		$upd_years = $_REQUEST["upd_years"];
		
		//echo "<pre>"; print_r($chk_item); echo "<hr>"; exit();
	
		
		$arrChkItem = array();		
		$num = 0 ; // count check
		//$temp = 0;
		for( $i=0; $i<sizeof($chk_item); $i++ ){
			$cVal = $chk_item[$i];
			list($item , $status_item) = explode("_" , $cVal);
			
			if( $status_item == "Y" ){
			
				$num++;				
				$in_date = $_REQUEST["hdd_indate_$item"]; 
				$out_date = $_REQUEST["hdd_outdate_$item"];
				$begdate = $_REQUEST["hdd_begdate_$item"];
				$enddate = $_REQUEST["hdd_enddate_$item"];
				
				$in_time = $_REQUEST["in_time_$item"];
				$out_time = $_REQUEST["out_time_$item"];
				$begtime = $_REQUEST["begtime_$item"];
				$endtime = $_REQUEST["endtime_$item"];
				
				$loc_id = $_REQUEST["hdd_loc_$item"];
				
				
				## CHANGE DATE & TIME TO DATABASE ##
				if( $upd_years == "u" ){
					$in_date = chgAndUpdateDate($in_date);
					$out_date = chgAndUpdateDate($out_date);
					$begdate = chgAndUpdateDate($begdate);
					$enddate = chgAndUpdateDate($enddate);
				}else{
					$in_date = chgDateToDb($in_date);
					$out_date = chgDateToDb($out_date);
					$begdate = chgDateToDb($begdate);
					$enddate = chgDateToDb($enddate);
				}
				
				$in_time = chgTimeToDb($in_time); $out_time = chgTimeToDb($out_time);
				$begtime = chgTimeToDb($begtime); $endtime = chgTimeToDb($endtime);
				
				// Array Date for Search min date //
				$arrInDate[] = $in_date; $arrOutDate[] = $out_date;
				$arrDegdate[] = $begdate; $arrEndDate[] = $enddate;
				
				$arrInTime[] = $in_time; $arrOutTime[] = $out_time;
				$arrBegTime[] = $begtime; $arrEndTime[] = $endtime;
				
				
				$data["edbk_item"] = $num ;
				$data["edbk_in_date"] = $in_date ;
				$data["edbk_out_date"] = $out_date;
				$data["edbk_ev_begdate"] = $begdate;
				$data["edbk_ev_enddate"] = $enddate;
				$data["edbk_in_time"] = $in_time;
				$data["edbk_out_time"] = $out_time;
				$data["edbk_ev_begtime"] = $begtime;
				$data["edbk_ev_endtime"] = $endtime;
				$data["loc_id"] = $loc_id ;
				
				
				if( $loc_id != "" ){
					$arrLocID = explode( "," , $loc_id );
					$data["arrLocID"] = $arrLocID ;
				}else{
					$data["arrLocID"] = array() ;
				}
				
				$arrChkItem[0] = array();
				$arrChkItem[] = $data;
				
			}// if( $status_item == "Y" ){
			
			
		}// for( $i=0; $i<=sizeof($chk_item); $i++ ){
		
		## CHECK CHOOSE EVENT DATE ##
		/*if($num <= 0){
			echo "<script>
					alert ('Pleasee!! Choose Event Date');
				  </script>";				 
			exit();
		}*/
		
		//echo "\$temp= $temp";
	
		#########  SET EVENT DATE BLOCK NO.0  #########
		$min_inDate = min($arrInDate);
		$min_begDate = min($arrDegdate); 
		$max_endDate = max($arrEndDate);
		$max_outDate = max($arrOutDate);
		
		$min_inTime = min($arrInTime);
		$min_begTime = min($arrBegTime); 
		$max_endTime = max($arrEndTime);
		$max_outTime = max($arrOutTime);
		
		$arrChkItem[0] = array( "edbk_item" => 0 
								, "edbk_in_date" => $min_inDate 
								, "edbk_out_date" => $max_outDate
								, "edbk_ev_begdate" => $min_begDate
								, "edbk_ev_enddate" => $max_endDate
								, "edbk_in_time" => $min_inTime
								, "edbk_out_time" => $max_outTime
								, "edbk_ev_begtime" => $min_begTime
								, "edbk_ev_endtime" => $max_endTime
								, "loc_id" => "" 
								, "arrLocID" => array() ) ;
		
		
								
		
		//echo "\$num= $num" ;
		/*echo "<pre>"; print_r($arrChkItem); 
		exit();*/
		
		
		
		#########  SET DATA ALL  ###########
		
		/*if( isset($_REQUEST["bks_id"]) && $_REQUEST["bks_id"] != 1 ){
			$bks_id = $_REQUEST["bks_id"];
		}else{
			echo "<script>
					alert ('Pleasee!! Select Booking Status Code');
				  </script>";				 
			exit();
		}*/
		
		$bks_id = $_REQUEST["bks_id"];
		$evn_id_new = genEventID($min_begDate); 
		//echo "\$evn_id_new= $evn_id_new";
		$time = "0800";
		$valbegtime = "0800";
		$valendtime = "1800";
		$usr_cre = $_SESSION["usr_name"];
		$date_cre = date("Y/m/d  H:i:s");		
		$val_date_cre = date("d/m/Y");
		$evn_fullname = $_REQUEST["evn_fullname"];
		$evn_shortname = $_REQUEST["evn_shortname"];
		$evn_thainame = $_REQUEST["evn_thainame"];
		
		/*echo "\$evn_fullname= $evn_fullname<br>";
		echo "\$evn_shortname= $evn_shortname<br>";
		echo "\$evn_thainame= $evn_thainame<br>";
		exit();*/
		
		
		
		#########  ALL TABLE NAME  ###########
		$arrTable = array( "eventname" 
							, "ev_statistics" 
							, "ev_dateblock" 
							, "ev_customer" 
							, "ev_staff" 
							, "ev_location" 
							, "ev_equip_serv" 
							, "ev_food_serv" 
							, "ev_comment" 
							, "ev_checklist" 
							, "ev_dailyperday" 
							, "ev_schedule"
							, "ev_setup" );	 
							
							
						
								
		#########  GET DATA ALL  ###########		
		foreach( $arrTable as $key => $table_name ){
			
			if( $table_name == "ev_location" ){
				
				for( $i=0; $i<sizeof($arrLocID); $i++ ){
					$loc_id = $arrLocID[$i];
					$arrSql[$table_name][] = "SELECT * FROM $table_name WHERE evn_id = $evn_id AND loc_id = $loc_id ";
				} 			
			}else{
				$arrSql[$table_name][] = "SELECT * FROM $table_name WHERE evn_id = $evn_id";
			} 
		
		} // foreach( $arrTable as $key => $table_name ){
		
/*		echo "<pre>"; print_r($arrLocID); echo "<hr>";
		echo "<pre>"; print_r($arrSql); exit();*/
		
		$arrGetAllData = array();
		foreach( $arrSql as $table_name => $arrVal ){
		
			$arrGetAllValue = array();
			foreach( $arrVal as $key => $sql ){
				
				$result = getData($sql);
				while( $row = mysql_fetch_array($result) ){
					
					$arrValue = array();
					$field_name = get_table_fieldname($table_name);
					foreach( $field_name as $fKey => $fVal ){	
					
						$arrValue[$fVal] = $row[$fVal] ; 
						
					}// foreach( $field_name as $fKey => $fVal ){
						
					$arrGetAllValue[] = $arrValue; 
					
				} // while( $row = mysql_fetch_array($result) ){
			
			} // foreach( $arrVal as $key => $sql ){
			$arrGetAllData[$table_name] = $arrGetAllValue ; 
			$arrGetAllData["ev_dateblock"] = setEvDateblock( $evn_id_new , $arrChkItem );
		} // foreach( $arrSql as $table_name => $arrVal ){
		
/*		echo "<br />#########  GET DATA ALL  ###########<pre>"; 
		print_r($arrGetAllData); exit();*/
		
		
		
		
		#########  SET DATA ALL  ###########
		
		$arrSetAllData = array();
		
		foreach( $arrGetAllData as $tName => $allValue ){
			
			if( ereg( "ev_dateblock" , $tName )){
				$inDate = $allValue[0]["edbk_in_date"];
				$outDate = $allValue[0]["edbk_out_date"];
				$begDate = $allValue[0]["edbk_ev_begdate"];
				$endDate = $allValue[0]["edbk_ev_enddate"];
				
				$inTime = $allValue[0]["edbk_in_time"];
				$begTime = $allValue[0]["edbk_ev_begtime"];
				$endTime = $allValue[0]["edbk_ev_endtime"];
				$outTime = $allValue[0]["edbk_out_time"];
				$loc_id = $allValue[0]["loc_id"];
				
				$show_qty = calcDays($begDate,$endDate)+1 ;
				$in_qty = calcDays($inDate,$begDate) ;
				$out_qty = calcDays($endDate,$outDate); 
				$inout_qty = $in_qty + $out_qty ;
			}
			
			$setAllValue = array();
			for( $i=0; $i<sizeof($allValue); $i++ ){
				global $setValue;
				$arrValue = $allValue[$i];				
				$setValue = array();	
				$eckl_item = $arrValue["eckl_item"];			
				foreach( $arrValue as $fName => $data ){					
					$setValue[$fName] = $data;
					if( $tName == "ev_location" ){
						/*$loc_id = $arrValue["loc_id"];
						$setValue[$fName] = $data;
						$setValue["eloc_id"] =  genID( "eloc_id" , $tName ) + $i;
						setEvLocation( $arrChkItem , $loc_id , $fName );*/
						
						$loc_id = $arrValue["loc_id"];
						setEvLocation( $arrValue , $arrChkItem , $loc_id );
						
					}
					switch($fName){
						case "evn_id":
							$setValue["evn_id"] = $evn_id_new ;
							break;
							
						case "evn_fullname":
							$setValue["evn_fullname"] = $evn_fullname ;
							break;
							
						case "evn_shortname":
							$setValue["evn_shortname"] = $evn_shortname ;
							break;
							
						case "evn_thainame":
							$setValue["evn_thainame"] = $evn_thainame ;
							break;
							
						case "bks_id":
							$setValue["bks_id"] = $bks_id ;
							break;
							
						case "esta_show_day":
							$setValue["esta_show_day"] = $show_qty ;
							break;
							
						case "esta_inout_day" :
							$setValue["esta_inout_day"] = $inout_qty;
							break;
							
						case "eesv_beg_date" :
							$setValue["eesv_beg_date"] = $begDate;
							break;
							
						case "eesv_beg_time" :
							$setValue["eesv_beg_time"] = $begTime;
							break;
							
						case "eesv_end_date" :
							$setValue["eesv_end_date"] = $endDate;
							break;
							
						case "eesv_end_time" :
							$setValue["eesv_end_time"] = $endTime;
							break;
							
						case "eesv_day" :
							$setValue["eesv_day"] = $show_qty ;
							break;
							
						case "edpd_date" :
							$setValue["edpd_date"] = updateYear($data);	
							break;
							
						case "eckl_id" :
							$setValue["eckl_id"] = genID( "eckl_id" , $tName ) + $i ;	
							break;
							
						case "eckl_follow_date" :
							$chk_follow_date = chkFollowDate();
							foreach( $chk_follow_date as $name => $follow_date ){
								if( ereg( $name , $eckl_item ) ){
									$setValue["eckl_follow_date"] = $follow_date;
								}
							}
							break;
							
						case "ecmt_id" :
							$setValue["ecmt_id"] = genID( "ecmt_id" , $tName ) + $i ;	
							break;
							
						case "edpd_id" :
							$setValue["edpd_id"] = genID( "edpd_id" , $tName ) + $i ;	
							break;
							
						case "esch_id" :
							$setValue["esch_id"] = genID( "esch_id" , $tName ) + $i ;	
							break;
							
						case "esch_beg_date" :
							$setValue["esch_beg_date"] = $begDate;
							break;
						
						case "esch_beg_time" :
							$setValue["esch_beg_time"] = $begTime;
							break;
							
						case "esch_end_date" :
							$setValue["esch_end_date"] = $endDate;
							break;
							
						case "esch_end_time" :
							$setValue["esch_end_time"] = $endTime;
							break;
							
						case "eset_id" :
							$setValue["eset_id"] = genID( "eset_id" , $tName ) + $i ;	
							break;
							
						case "eset_beg_date" :
							$setValue["eset_beg_date"] = $begDate;
							break;
							
						case "eset_beg_time" :
							$setValue["eset_beg_time"] = $begTime;
							break;
							
						case "eset_end_date" :
							$setValue["eset_end_date"] = $endDate;
							break;
							
						case "eset_end_time" :
							$setValue["eset_end_time"] = $endTime;
							break;
						
						case "eesv_id" :
							if( ereg("ev_equip_serv" , $tName) ){
								$eesv_id = genID( "eesv_id" , $tName ) + $i ; 
							}elseif( ereg("ev_food_serv" , $tName) ){
								$eesv_id = genID( "eesv_id" , $tName ) + $i ;
							}
							$setValue["eesv_id"] = $eesv_id ;  							
							break;
							
						case "usr_cre" :
							$setValue["usr_cre"] = $usr_cre ;
							break;
							
						case "date_cre" :
							$setValue["date_cre"] = $date_cre ;
							break;
							
						case "usr_upd" :
							$setValue["usr_upd"] = "";
							break;
							
						case "date_upd" :
							$setValue["date_upd"] = "";
							break;
					
					} // switch($fName){
					
				} // foreach( $arrValue as $fName => $data ){
				
				//echo "<pre>"; print_r($setValue); echo "<hr>"; 
				$setAllValue[] = $setValue;
				
			} // for( $i=0; $i<sizeof($allValue); $i++ ){
			
			//echo "<pre>"; print_r($test); echo "<hr>"; 
			$arrSetAllData[$tName] = $setAllValue ;
			
		} // foreach( $arrGetAllData as $tName => $allValue ){
		
/*		echo "<br />#########  SET DATA ALL  ###########<pre>";
		echo "\$evn_id= $evn_id"; 
		echo "\$sub_rate= " . $sub_rate = getSubRatecodeByLocID( 2 , 1 , "show_amt" );
		echo "<pre>"; print_r($arrSetAllData); echo "<hr>";
		exit();*/
		
		// EVENT_ID_NEW = 11110001
		// EVENT_ID = 10110004
		
		
		#########  INSERT DATA ###########
		foreach( $arrSetAllData as $table => $allValue ){
			
			for( $i=0; $i<sizeof($allValue); $i++ ){
				//echo "\$i= $i";
				$query = create_insert_query( $table , $allValue[$i] );
				//echo "<br /><pre>\$query_$table= $query"; echo "<hr>";
				$insert = mysql_query($query) or die("<script>alert ('Insert error');</script>");
//				$insert = mysql_query($query) or die($query);
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");
				
				
			}
		} // foreach( $arrSetAllData as $table => $allValue ){
		
		if( $insert ){
			echo "<script>
					alert ('Rebook Complete!!');
					window.open('calendar','_parent');
				  </script>";
				  // window.location = 'calendar';
			exit();
		}
		
 	} // if(!empty($Submit)){



?>

</body>
</html>
