<?php
	ob_start();
	session_start();
	$arrContract=$_SESSION["arrData"];

	header("Content-Type: application/vnd.ms-excel");
	header('Content-Disposition: attachment; filename="Contract.xls"');#ชื่อไฟล์	
?>
<html xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:x="urn:schemas-microsoft-com:office:excel"
xmlns="http://www.w3.org/TR/REC-html40">
<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</HEAD><BODY>

	  <table width="100%" align="center" x:str BORDER="1">
            <tr class="lst_BorderHead" >
              <td><div align="center"><b>วันที่</b></div></td>
              <td><div align="center"><b>เลขที่งาน</b></div></td>
              <td><div align="center"><b>ชื่องาน</b></div></td>
              <td><div align="center"><b>ผู้จัดงาน</b></div></td>
              <td><div align="center"><b>ห้อง</b></div></td>
              <td><div align="center"><b>จำนวนคน</b></div></td>
              <td><div align="center"><b>จำนวนเงิน</b></div></td>
              <td><div align="center"><b>เวลาจัดงาน</b></div></td>
              <td><div align="center"><b>รวมเวลา(ชม.)</b></div></td>
            </tr>
			<?

			
				while (list($key, $val) = each($arrContract)) {
//				foreach($arrData as $key=>$val){
					$bgcolor == "#E7F0F8" ? $bgcolor="#F5F9FC" : $bgcolor="#E7F0F8" ;
					$EvnID=$val["EvnID"];
					$Date=$val["Date"];
					$Time=$val["Time"];
					$EventName=$val["EventName"];
					$Customer=$val["Customer"];
					$Atten=$val["Atten"];
					$Amt=$val["Amt"];
					$Location=$val["Location"];
					$Contact=$val["Contact"];			
					$diffTime=$val["diffTime"];			
			?>
            <tr bgcolor="<?=$bgcolor ;?>">
              <td><?=$Date;?></td>
              <td><?=$EvnID;?></td>
              <td><?=$EventName;?></td>
              <td><?=$Customer;?></td>
              <td><?=$Location;?></td>
              <td><?=$Atten;?></td>
              <td><?=$Amt;?></td>
              <td><?=$Time;?></td>
              <td><?=$diffTime;?></td>
            </tr>
			<?
				} //foreach($arrData as $key=>$val){
			?>
        </table>

</BODY>
</HTML>