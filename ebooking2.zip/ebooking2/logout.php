<?
	//Sign out
	
	session_start();
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");		
	$SaveLog=updLog($_SESSION['username'], 'signout.php', "logout");	
	$site=$_SESSION["site"];
	unset($_SESSION);
    session_destroy();	
	echo"<script>window.location='index.php?sys=$site';</script>";
	/*echo "<script>window.open('index_$site.php','_parent');</script>";*/
	exit();
	
?>
<html>
<head>
<title>Untitled Document</title>

</head>

<body>
</body>
</html>
