<?	
	//include("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	define("updSave","eebk_viewFormS.php");
	$sysName = "Equipment Services ";
	$status = "E";
	$evn_id = $_REQUEST["id"];
	$loc_id = $_REQUEST["id2"];
	$new_esv_id = $_REQUEST["hd_esv_id"];
	/*
	echo "
		evn_id = $evn_id<br>
		loc_id=$loc_id<br>
		new_esv_id=$new_esv_id<br>
	";
	*/
	if($evn_id){		
	
		#select loc_id from ev_eesv_block
		$query = "SELECT esv_id FROM ev_eesv_block 
							WHERE evn_id = '$evn_id'
							AND loc_id = $loc_id
							AND eebk_status = '$status'
						";
		//echo "$query<br>";
		//exit();
		$result = getData($query);
		$rs= mysql_fetch_array($result);
		$old_esv_id = $rs["esv_id"];
		
		#UPDATE value in ev_dateblock		
		$query = "UPDATE ev_eesv_block 
							SET esv_id = '$new_esv_id'
							WHERE evn_id = '$evn_id'
							AND loc_id = $loc_id
							AND eebk_status = '$status'
						";
		//echo "$query<hr>";
		$result = getData($query);			
		
		#begin add/delete data to ev_equip
		$arr_old = explode(",",$old_esv_id);
		$arr_new = explode(",",$new_esv_id);
		//echo "\$old_esv_id = $old_esv_id<br>\$new_esv_id = $new_esv_id<br>";
		
		if ($arr_new){
			$arr_add = array_diff($arr_new, $arr_old);
			$str_add = implode(",",$arr_add);
			if($str_add){
				//echo "arr_add<br>";					
				//exit();
				#get value from equip_serv
				$vatrate = 7;
				$sql = "SELECT esv_id, esv_amt,esv_include_vat FROM equip_serv WHERE esv_id in ( $str_add)";
				//echo "$sql<br>";	
				
				$result = getData($sql);
				while ($rs_esv = mysql_fetch_array($result)){
					$arr_esv[$rs_esv["esv_id"]] = array($rs_esv["esv_amt"],$rs_esv["esv_include_vat"]);
				}
							
				#get value from ev_eesv_block
				$query = "SELECT *
									FROM ev_eesv_block
									WHERE evn_id = '$evn_id'
									AND loc_id = $loc_id
									AND eebk_status = '$status'
								";
				//echo "$query<hr>";
				$result = getData($query);	
				$rs_eebk = mysql_fetch_array($result);
				$esv_id = $rs_eebk["esv_id"];
				$beg_date = $rs_eebk["eebk_beg_date"];
				$beg_time = $rs_eebk["eebk_beg_time"];
				$end_date = $rs_eebk["eebk_end_date"];
				$end_time = $rs_eebk["eebk_end_time"];	
				$eesv_day = ($end_date - $beg_date) + 1 ;
				
				foreach($arr_add as $key=>$val) {    
					$eesv_qty = 1;
					$eesv_amt = round($arr_esv[$val][0],2);
					$eesv_total = round($eesv_qty * $eesv_day * $eesv_amt,2);
					$eesv_adj = round(0,2) ;
					$eesv_net = round($eesv_total + $eesv_adj,2) ;
					$eesv_chk_vat =$arr_esv[$val][1];
					if ($eesv_chk_vat == "Y"){
						$eesv_vat = round(($eesv_net / (100 + $vatrate)) * $vatrate,2) ;
						$eesv_before_vat = round($eesv_net - $eesv_vat,2) ;
					}
					else {
						$eesv_vat = round($eesv_net * $vatrate,2) ;
						$eesv_before_vat = round($eesv_net,2) ;
					}				
					$eesv_include_vat = round($eesv_before_vat + $eesv_vat,2) ;
					
					$resData["eesv_id"] = "";
					$resData["evn_id"] = $evn_id;
					$resData["loc_id"] = $loc_id;
					$resData["esv_id"] = $val;
					$resData["eesv_qty"] = $eesv_qty;
					$resData["eesv_beg_date"] = $beg_date;
					$resData["eesv_beg_time"] = $beg_time;
					$resData["eesv_end_date"] = $end_date;
					$resData["eesv_end_time"] = $end_time;
					$resData["eesv_day"] = $eesv_day;
					$resData["eesv_amt"] = $eesv_amt;
					$resData["eesv_total"] = $eesv_total;
					$resData["eesv_adj"] = $eesv_adj;
					$resData["eesv_net"] = $eesv_net;
					$resData["eesv_chk_vat"] = $eesv_chk_vat;
					$resData["eesv_before_vat"] = $eesv_before_vat;
					$resData["eesv_vat"] = $eesv_vat;
					$resData["eesv_include_vat"] = $eesv_include_vat;				
					$resData["usr_cre"] = $_SESSION["usr_name"];
					$resData["date_cre"] = date("Y/m/d  H:i:s");		
					
					$query = create_insert_query("ev_equip_serv",$resData);	
					//echo "$query<br>";
					mysql_query($query) or die("Insert ev_equip_serv error");						
					$eesv_id = mysql_insert_id();
					$SaveLog=updLog($_SESSION['username'], updSave, "$query");
					$updRev = updRevenue("a","ev_equip_serv","eesv_id",$eesv_id);
				} //foreach($arr_add as $key=>$val) {
				//exit();
			} //if($add){
		}	//if ($arr_new){
		
		if ($arr_old){
			$arr_del = array_diff($arr_old,$arr_new);
			$str_del =  implode(",",$arr_del);
			if($str_del){		
				//echo "arr_del<br>";
				//exit();
				#delete from ev_equip_serv
				$query = "DELETE  FROM ev_equip_serv WHERE evn_id = '$evn_id' AND loc_id = $loc_id AND esv_id in ($str_del) ";
				//echo "$query<hr>";
				//exit();
				$rs_eebk = getData($query);	
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");
				$updRev = delRevenue2($evn_id,$str_del,"equip");
			} //if($del){
		}	//if ($arr_old){
		
		//Show alert by javascript
		echo "<script>
				alert ('Update data completed');
				window.location = 'eebk_viewForm.php?id=$evn_id&id2=$loc_id';
			  </script>";
	
	} //if($evn_id){		
	
	
include("db/disconnect.db.php");	
?>
	
<html>
<head>
<title>edbk_updForm.php</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">
</head>
<body>
</body>
</html>