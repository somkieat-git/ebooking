<?	
	include("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	define("updSave","edbk_updForm.php");
	$sysName = "Event Date ";
	$evn_id = $_REQUEST["id"];
	$edbk_item = $_REQUEST["id2"];
	$new_loc_id = $_REQUEST["hd_loc_id"];
	
	//echo "evn_id = $evn_id<br>edbk_item=$edbk_item<br>new_loc_id=$new_loc_id<br>";
	
	if($evn_id){		
		#select loc_id from ev_location 
		$query = "SELECT loc_id FROM ev_dateblock 
							WHERE evn_id = '$evn_id'
							AND edbk_item = $edbk_item
						";
		$result = getData($query);
		$rs= mysql_fetch_array($result);
		$old_loc_id = $rs["loc_id"];
		
		#Input value in ev_dateblock		
		$query = "UPDATE ev_dateblock ";
		$query .=" SET loc_id = '$new_loc_id'";
		$query .=" WHERE evn_id = '$evn_id'";
		$query .=" AND edbk_item = $edbk_item";
		//echo "$query<hr>";
		$result = getData($query);	
		$SaveLog=updLog($_SESSION['username'], "edbk_updForm.php", "$query");
		
		#get value FROM ev_dateblock edbk, ev_statistics esta
		$query = "SELECT edbk.*, esta.bks_id, esta.rtc_id, esta.esta_room_code ,
							esta.esta_atten, esta.esta_num_session
							FROM ev_dateblock edbk, ev_statistics esta 
							WHERE edbk.evn_id = esta.evn_id
							AND edbk.evn_id = '$evn_id'
							AND edbk.edbk_item = $edbk_item
						";
		//echo "$query<hr>";
		//exit();
		$result = getData($query);	
		$rs_edbk = mysql_fetch_array($result);
		$edbk_in_date = ($rs_edbk["edbk_in_date"]);
		$edbk_in_time = $rs_edbk["edbk_in_time"];
		$edbk_ev_begdate = ($rs_edbk["edbk_ev_begdate"]);
		$edbk_ev_begtime = $rs_edbk["edbk_ev_begtime"];
		$edbk_ev_enddate = ($rs_edbk["edbk_ev_enddate"]);
		$edbk_ev_endtime = $rs_edbk["edbk_ev_endtime"];
		$edbk_out_date = ($rs_edbk["edbk_out_date"]);
		$edbk_out_time = $rs_edbk["edbk_out_time"];
		$bks_id = $rs_edbk["bks_id"];
		$rtc_id = $rs_edbk["rtc_id"];
		$esta_room_code = $rs_edbk["esta_room_code"];	
		$esta_atten =  $rs_edbk["esta_atten"];	
		$esta_num_session =  $rs_edbk["esta_num_session"];				
		//$show_qty = ($edbk_ev_enddate - $edbk_ev_begdate)+1;
		$show_qty = calcDays(chgDate($edbk_ev_begdate),chgDate($edbk_ev_enddate))+1;
		//echo "$edbk_ev_begdate - $edbk_ev_enddate = ";
		//echo "\$show_qty = $show_qty<br>";
		$show_amt = 0;
		$show_total = 0;	
		
		if(($edbk_ev_begdate) == ($edbk_in_date) )
			$inout_qty =0;
		else	
			$inout_qty = calcDays(chgDate($edbk_in_date), chgDate($edbk_ev_begdate)) ;
			
		$inout_amt = 0;
		$inout_total = 0;
		
		if(($edbk_out_date) == ($edbk_ev_enddate) )
			$out_qty = 0;
		else	
			$out_qty = calcDays(chgDate($edbk_ev_enddate), chgDate($edbk_out_date));	
		$out_amt = 0;
		$out_total = 0;
		$grand_total = 0;					
	
		#begin add/delete data to ev_equip
		$arr_old = explode(",",$old_loc_id);
		$arr_new = explode(",",$new_loc_id);
		//echo "\$old_esv_id = $old_esv_id<br>\$new_esv_id = $new_esv_id<br>";
		
		if ($arr_new){
			$arr_add = array_diff($arr_new, $arr_old);
			$str_add = implode(",",$arr_add);
			if($str_add){
				//echo "\$str_add = $str_add<br>";					
				//exit();				
			
				foreach($arr_add as $key=>$val) {    
					$resData["evn_id"] = $evn_id;
					$resData["loc_id"] = $val;
					$resData["eloc_in_date"] = $edbk_in_date;
					$resData["eloc_in_time"] = $edbk_in_time;
					$resData["eloc_event_date"] = $edbk_ev_begdate;
					$resData["eloc_event_time"] = $edbk_ev_begtime;
					$resData["eloc_end_date"] = $edbk_ev_enddate;
					$resData["eloc_end_time"] = $edbk_ev_endtime;
					$resData["eloc_out_date"] = $edbk_out_date;
					$resData["eloc_out_time"] = $edbk_out_time;
					$resData["bks_id"] = $bks_id;
					$resData["rtc_id"] = $rtc_id;
					$resData["eloc_show_qty"] = $show_qty;
					$resData["eloc_show_amt"] = $show_amt;
					$resData["eloc_show_total"] = $show_total;					
					$resData["eloc_inout_qty"] = $inout_qty;
					$resData["eloc_inout_amt"] = $inout_amt;
					$resData["eloc_inout_total"] = $inout_total;
					$resData["eloc_out_qty"] = $out_qty;
					$resData["eloc_out_amt"] = $out_amt;
					$resData["eloc_out_total"] = $out_total;
					$resData["eloc_g_total"] = $grand_total;
					$resData["eloc_room_code"] = $esta_room_code;
					$resData["eloc_atten"] = $esta_atten;
					$resData["eloc_num_session"] = $esta_num_session;
					
					$resData["usr_cre"] = $_SESSION["usr_name"];
					$resData["date_cre"] = date("Y/m/d  H:i:s");		
					
					$query = create_insert_query("ev_location",$resData);	
					//echo "$query<br>";
					mysql_query($query) or die("Insert ev_location error");						
					$eloc_id = mysql_insert_id();
					$SaveLog=updLog($_SESSION['username'], updSave, "$query");
					$updRev = updRevenue("a","ev_location","eloc_id",$eloc_id);
				} //foreach($arr_add as $key=>$val) {
				//exit();
			} //if($add){
		}	//if ($arr_new){
		
		if ($arr_old){
			$arr_del = array_diff($arr_old,$arr_new);
			$str_del =  implode(",",$arr_del);
			if($str_del){		
				//echo "arr_del<br>";
				//exit();
				#delete from ev_location
				$query = "DELETE  FROM ev_location WHERE evn_id = '$evn_id' ";
				$query .=" AND loc_id in ($str_del) ";
				$query .=" AND eloc_in_date = '$edbk_in_date'";
				$query .=" AND eloc_in_time = '$edbk_in_time'";
				//echo "$query<hr>";
				//exit();
				$rs_edbk = getData($query);		
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");		
				$updRev = delRevenue2($evn_id,$str_del,"space");
			} //if($del){
		}	//if ($arr_old){	
	
	} //if($evn_id){		
	
	//Show alert by javascript
	echo "<script>
			alert ('Update completed');
			window.location = 'edbk_viewForm.php?id=$evn_id&id2=$edbk_item';
		  </script>";
	exit();
include("db/disconnect.db.php");	
?>
	
<html>
<head>
<title>edbk_updForm.php</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">
</head>
<body>
</body>
</html>