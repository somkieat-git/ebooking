<?
	ob_start(); 
	session_start();
	$evn_id = $_REQUEST["id"];
	//$evn_id = '06010001';
	define("sysName","Setup Instructions Maintenance");
	define("tableName","ev_setup");
	define("viewForm","eset_viewForm.php");
	define("addForm","eset_updForm.php");	
	define("updForm","eset_updForm.php");	
	define("field_id","eset_id");	
	define("beg_id",1);	
	define("end_id",7);		
	
/*	$sql = "SELECT `esta_book_status`,`esta_rate_code`,`esta_event`,
				`esta_bus_code`,`esta_param_code`,`esta_source_code`,`esta_room_code`,
				`esta_ini_atten`,`esta_atten`,`esta_num_session`,`esta_previous`,
				`esta_open_pub`,`esta_media`,`esta_tax`
				FROM `ev_statistics` 
				WHERE evn_id = '$evn_id' ";*/
	$sql = "SELECT eset_id , eset_beg_date ,  eset_end_date , eset_beg_time , eset_end_time , eset_loc_id , eset_dep_id , eset_dest 
				FROM ev_setup 
				WHERE evn_id='$evn_id' ";				
	//echo "$sql";
	//exit();
	define("query","$sql");
		
	$cap_name = array();
	$cap_name = array("#","Start Date", "End Date", "Start Time","End Time","Location","Department","Description");
	
	//=============check authorize================
	$key = array_keys($_SESSION["sec_add"], viewForm); 
	if($key[0])
		define("insert",1);		
	else
		define("insert",0);			
		
	$key = array_keys($_SESSION["sec_edit"], viewForm); 
	if($key[0])
		define("edit",1);		
	else
		define("edit",0);			
		
	$key = array_keys($_SESSION["sec_del"], viewForm); 
	if($key[0])
		define("del",1);		
	else
		define("del",0);			
		
	include("func/ev_viewForm.func1.php");
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</body>
</html>
