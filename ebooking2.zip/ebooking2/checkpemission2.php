	<?	
	ob_start();  
	//session_start();

	include("connect.php");
	$user = $_REQUEST["user"];
	$pass = $_REQUEST["pass"];
	//$sql = " select mem.* ,grp.grp_level
	//			from `group` grp , member mem
	//			where mem.mem_grp = grp.grp_id
	//			and mem.mem_status = 'Y'
	//			and mem.mem_user = '$user' ";
	//echo $sql;
	$sql = " select user.*, security. * from user , security 
				where user.usr_sec = security.sec_id 
				and user.usr_login = 'gatu' ";
	//echo $user , $pass ; 	
	//echo "$sql<br>" ;	
	//exit();
	$result = mysql_query($sql) or die("Select error");
	$count = mysql_num_rows($result);
	//echo $count;
	if ($count == 0) {	
		echo "<script> alert ('UserName Invalid');history.go(-1);</script>";
		exit();			
	}
	else{
		$row = mysql_fetch_array($result);
		if($pass != $row['usr_pass']){
			echo "<script> alert ('Password Invalid');history.go(-1);</script>";
			exit();			
		}
		else{
			$_SESSION["user"]=$user;
			$_SESSION["pass"]=$pass;
			$_SESSION["UsrID"]=$row["usr_id"];			
			$id = $row["usr_id"];			
			//红ŧ Logfile
			$log_ip = $_SERVER["REMOTE_ADDR"];
			$sql = "insert into logfile values(
				'',now(),'$user','$log_ip,'' ' 
				)";
			//echo $sql ;
			mysql_query($sql) or die ("Save logfile error");
			
			if ($row["sec_name"]=='admin')
				echo "page_admin";
			else
				echo "page_user";
		}		
	}
	include("disconnect.php");
?>
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>

<body>
</body>
</html>

