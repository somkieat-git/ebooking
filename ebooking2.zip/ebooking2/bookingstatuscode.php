<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</head>

<body>
<table width="90%"  border="0" cellspacing="0" cellpadding="0">
  <tr>
    <th width="26%" bgcolor="#FFFFFF" scope="col">CX</th>
    <th width="11%" scope="col"><div align="left"><strong></strong></div></th>
    <th width="39%" bgcolor="#FFFFFF" scope="col">&nbsp;</th>
    <th width="12%" scope="col">&nbsp;</th>
    <th width="12%" scope="col">&nbsp;</th>
  </tr>
  <tr>
    <th scope="row">CF</th>
    <td><div align="left"><strong></strong></div></td>
    <td bgcolor="#33FF99">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <th scope="row">D</th>
    <td><div align="left"><strong>ͧ</strong></div></td>
    <td bgcolor="#FFFF66">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <th scope="row">NO</th>
    <td><div align="left"><strong>Թ</strong></div></td>
    <td bgcolor="#6666CC">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <th scope="row">IQ</th>
    <td><div align="left"><strong></strong></div></td>
    <td bgcolor="#FFFFFF">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <th scope="row">LB</th>
    <td><div align="left"><strong></strong></div></td>
    <td bgcolor="#FF00FF">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <th scope="row">OO</th>
    <td><div align="left"><strong></strong></div></td>
    <td bgcolor="#FFFFFF">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <th scope="row">T</th>
    <td><div align="left"><strong></strong></div></td>
    <td bgcolor="#66FFFF">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <th scope="row">Tc</th>
    <td><div align="left"><strong>ᴧ</strong></div></td>
    <td bgcolor="#FF0066">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <th scope="row">WL</th>
    <td><div align="left"><strong></strong></div></td>
    <td bgcolor="#CCCCCC">&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>
