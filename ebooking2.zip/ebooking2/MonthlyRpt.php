<?
	ob_start();		
	session_start();
	
	$Month =$_REQUEST["month"];
	$Year =$_REQUEST["year"];
	/*
	if(empty($Month)) 
	{
		echo "<script> alert('˹͹ҡѺ 03');</script>";
		$Month = '03';
	}
	else
	{
		echo "<script> alert('ͧâ͹ $Month');</script>";
	}
	*/
?>	
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
"http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Monthly Report [Booking System]</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">

</head>
<?
// Function //

function repl_char($str,$num)
{
	$text = '';
	for($i=0;$i<$num;$i++)
	{
		$text .= $str;
	}
	return $text;
}

function string_format($format, $string, $placeHolder = "#")
{            
   $numMatches = preg_match_all("/($placeHolder+)/", $format, $matches);              
   foreach ($matches[0] as $match)
   {
       $matchLen = strlen($match);
       $format = preg_replace("/$placeHolder+/", substr($string, 0, $matchLen), $format, 1);
       $string = substr($string, $matchLen);
   }
   return $format;
} 


function format_number($str,$decimal_places='2',$decimal_padding="0"){
       /* firstly format number and shorten any extra decimal places */
       /* Note this will round off the number pre-format $str if you dont want this fucntionality */
       $str          =  number_format($str,$decimal_places,'.','');    // will return 12345.67
       $number      = explode('.',$str);
       $number[1]    = (isset($number[1]))?$number[1]:''; // to fix the PHP Notice error if str does not contain a decimal placing.
       $decimal    = str_pad($number[1],$decimal_places,$decimal_padding);
       return (float) $number[0].'.'.$decimal;
}


  function Number2String( $number )
    {
	$CharReturn = '';
	if($number>0)
		{
			$NumChar = strlen($number);		
			$Comma = 3;
				for($j=0;$j<=$NumChar;$j++)
				{
		        $Char = substr($number, $NumChar-$j, 1);
				$CharReturn = $Char . $CharReturn;
				if((($j % $Comma)==0) & ($j>0) & ($j<$NumChar)) 
					{
					$CharReturn =  "," .$CharReturn;
					}
		}
		$CharReturn .= ".00";
		}
	else
		{
		$CharReturn = '-';
		}
	return $CharReturn;
	}


// ҡ⨷ͧ͡ŵ͹лշ˹ 
	$QMonth = $Month;  //   'mm'
//	$QMonth = '03';  //   'mm'
	$QYear = $Year ;  //  'yyyy'

// Connect to database from MySql Server
//include('connect.php');
include_once("db/connect.db.php");


//sql : Location
	$sql = "select * from location order by loc_seq";
	$table = mysql_query($sql) or die("sql error");
//		echo $sql."<br>";
		$LocationCount = 0;
		while ($row = mysql_fetch_array($table)) 
		{
		$Location[$LocationCount] = $row['loc_shortname'];
		$LocationCount = $LocationCount + 1;
		}
		$Location[$LocationCount] = "Total";
//		// Show Location from array
//		for($j=0;$j<=$LocationCount;$j++)
//		{
//			echo $j."=".$Location[$j]."<br>";
//		}
		
		echo "<br>";
		// Initial Array Location per Day
//    	echo "Initial array for Monthly <br>";
		// ӹǹѹ٧ش͹ + Ѻ Total Column = 31 + 1 = 32
		$DayPerMonth = 32;
		for($i=0;$i<$DayPerMonth;$i++)
		{
			for($j=0;$j<=$LocationCount;$j++)
			{
				$MonthTable[$i][$j] = 0;
//				echo $i.'/'.$j.'='.$MonthTable[$i][$j].', ';
			}
			
//			echo "<br>";
		}
//		echo "<br>";
//  

//sql : ev_revenue, location
	$sql =  "SELECT right( rev_date, 2 ) AS 
DAY , location.loc_shortname as locname, sum( rev_total ) AS net
FROM ev_revenue, location
WHERE left(rev_type,5) = 'space' AND rev_total >0 AND 
	left( rev_date, 4 )  = $QYear AND left( right( rev_date, 4 ) , 2 ) = $QMonth AND  
	ev_revenue.loc_id = location.loc_id
GROUP BY 1 , 2";
	$table = mysql_query($sql) or die("sql error");
	if(mysql_num_rows($table)<=0) 
	{
		echo "<script> alert('բŷͧäѺ'); history.go(-1); </script>";
		exit();
	} 
	// Show result from Query
		//echo $sql."<br>";
		while ($row = mysql_fetch_array($table)) 
		{
//		echo "- Day=".
//			$row['DAY'].'  Location='. $row['locname'].' Net= '. $row['net']."<br>";

	// Search in Location array
			$LocationDay = 0;
			for($x=0;$x<=$LocationCount;$x++)
			{
				if ($row['locname']==$Location[$x])
				{
					$LocationDay = $x;
//					echo 'Check Location in array ='.$row['locname']."=".$Location[$x]."=".$x."<br>";
					break;
				}
			}
		//echo "<br>";

	// Transfer value into Array
			$PositionDay = $row['DAY']-1;
			$MonthTable[$PositionDay][$LocationDay] = $row['net'];
	// Total in Column
			$MonthTable[$DayPerMonth-1][$LocationDay] += $row['net'];
	// Total in Row
			$MonthTable[$PositionDay][$LocationCount] += $row['net'];


		}

	// Summary of GrandTotal
			for($x=0;$x<$LocationCount;$x++)
			{
				$MonthTable[$DayPerMonth-1][$LocationCount] += $MonthTable[$DayPerMonth-1][$x];
			}

	// Generating report form
//	echo "LocationCount=".$LocationCount."<br>";

	// Variable for Check Month of Year
		$M1  = $QMonth;
		$D1 = $M1."/01/".$QYear;

	echo "<U><B>Monthly Report (Space Revenue) [";
	echo date(' F ', strtotime($D1));
	echo " of ".$QYear."] </B></U>&nbsp;";
	echo "[ <a href='MonthlyRpt4.php?month=$Month&year=$Year'>Export to Excel</a> ]";
	echo "<table width='100%' height='100%' border='1' cellpadding='0' cellspacing='0' > ";
	echo "  <tr bgcolor='#FFFFCC'>";
	echo "    <th width='5%' height='10%' bgcolor='#FFFFCC' scope='col'><p>&nbsp;</p>";
	//
			for($x=0;$x<=$LocationCount;$x++)
			{
				echo "<th width='80'     scope='col'>";
				echo repl_char("_",10);
				echo "</th>";
			}
	echo "</tr>";
	//
	echo "  <tr bgcolor='#FFFFCC'>";
	echo "    <th width='5%' height='10%' bgcolor='#FFFFCC' scope='col'  >";
	echo "    <p>Day</p></th>";

	// Show Location name from Array
			for($x=0;$x<=$LocationCount;$x++)
			{
					$text =  "<td align='center'>";
					$text .= $Location[$x];
					$text .= "</td>";
					echo $text;
			}
	echo "</tr>";
	
	// Check number of day in the month
		$DayInMonth = date(' t ', strtotime($D1));
		
	// Show Month Table again
		for($i=0;$i<$DayInMonth;$i++)
		{
		echo "<tr>";
			$Day = $i+1;
			if($Day == $DayPerMonth) {$Day="Total ";}
					$text =  "<td bgcolor='#FFFFCC' align='Right' >";
					$text .= $Day;
					$text .= "</td>";
					echo $text;

			for($j=0;$j<=$LocationCount;$j++)
			{
					$text =  "<td align='Right'>";
					$num = Number2String($MonthTable[$i][$j]);
//					$text .= number_format($MonthTable[$i][$j]).".00";
					$text .= $num;
					$text .= "</td>";
					echo $text;
			}
		echo "</tr>";
		}

	// Total in Last Row
	echo "<tr>";
			$text =  "<td bgcolor='#FFFFCC'><strong>";
			$text .= "Total";
			$text .= "</strong></td>";
			echo $text;

			for($j=0;$j<=$LocationCount;$j++)
			{
					$text =  "<td align='Right'><strong>";
					$num = Number2String($MonthTable[$DayPerMonth-1][$j]);
					$text .= $num;
					$text .= "</strong></td>";
					echo $text;
			}
	echo "</tr>";
	//
	echo "'</Table>";

	//echo "<hr>";

//  
include('db/disconnect.db.php');

?>
<body>
</body>
</html>
