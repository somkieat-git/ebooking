<?php
	ob_start();
	session_start();	
	//include_once("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	//include_once("func/sql.func.customer.php");
	
	//$usr_id = $_SESSION["usr_id"];
	//$usr_name = $_SESSION["usr_name"];
	
	
	// SET Field Name For Request //
	$fieldname = get_table_fieldname($table_name);
	foreach( $fieldname as $fKey => $fVal ){
		$$fVal = $_REQUEST[$fVal];
	}
	
	$id = $_REQUEST["id"];
	$action = $_REQUEST["a"];
	$Submit = $_REQUEST["Submit"];
	
	$cap_name = array();
	$cap_name = array("#", "Code", "Main Address", "MailAd",
            "Title(Th)", "Title(En)", "*First Name(Th)", "*First Name(En)",
            "*Last Name(Th)", "*Last Name(En)", "Pro Tnname", "Pro Enname",
            "Prefix Com.Name(Th)", "Prefix Com.Name(En)", "Company Name(Th)", "Company Name(En)",
            "Suffix Com.Name(Th)", "Suffix Com.Name(Th)", "Com Regis", "Department(Th)",
            "Department(En)", "Position(Th)", "Position(En)", "Address1(Th)",
            "Address1(En)", "Address2(Th)", "Address2(En)", "Soi.(Th)",
            "Soi.(En)", "Road.(Th)", "Road.(En)", "Tambol(Th)", "Tambol(En)",
            "District(Th)", "District(En)", "Province(Th)", "Province(En)",
            "Country(Th)", "Country(En)", "Postcode(Th)", "Postcode(En)",
            "Telephone(Th)", "Telephone(En)", "Fax.(Th)", "Fax.(En)", "Mobile",
            "Website", "E-mail1", "E-mail2", "Birthdate",
            "Sex", "National", "Marital", "Occupation",
            "OccupatCm", "Industry", "IndustryCm", "Education",
            "Source", "Reject", "Remark", "Lang", "Seq",
            "Show", "User Create", "Date Create", "User Update", "Date Update");



	define("viewForm","flexigrid/cus_vfrm.php");
	define("updSave","cus_updForm.php");
	define("tableName","profile");
	define("menuName","Customer");
	define("short_menuname","cus");
	define("field_id","pro_id");
	define("action",$action);
	define("id",$id);	
	define("beg_id",2);	
	define("end_id",30);
	define("menu_navigate" , $set_navigate);
	define("usr_id",$usr_id);
	define("usr_name" , $usr_name);
	include_once("func/cus_updForm.func.php");	
	
	function duplicate($field,$value){
		global $dup;
			$sql = "select $field from profile
						where $field = '$value' ";
	
			$table = mysql_query($sql) or die ("Connect Err.");
			$row=mysql_fetch_array($table);
			if($row[$field]== $value){
				$dup[$field] = $value;
			}//if($row[$field]== $value){
	}//	function duplicate($field,$value){	
	
	
	function checklist($var,$name){
		global $data;global $flag;
		
	
		if( ereg("pro_com_regis" , $name ) ){
		
			list($d,$m,$y) = explode("/",$var);
			if($d!="0" || $m!="0" || $y!="200" ){
				$pro_com_regis = chgDateToDb($var);
				$data["pro_com_regis"] = $pro_com_regis;
			
			} 
			
		}else if( ereg("pro_birthdate" , $name ) ){
		
			if( $var != "" ){	
					
				list($d,$m,$y) = explode("/",$var);
				
				if($d!="0" || $m!="0" || $y!="200" ){
					$pro_birthdate = chgDateToDb($var);
					$data["pro_birthdate"] = $pro_birthdate;
				} //if($birthdate){
				
			}else{
			
				$data["pro_birthdate"] = "0000-00-00" ;
				
			}
			
		}else{
		
			$data[$name] = $var;
			
		}
		//echo "<pre>" ;echo "\$data[$name]=$data[$name]"; 

	} //function checklist($var,$name){

	
	if(!empty($Submit)){
		
		foreach( $fieldname as $fKey => $fVal ){
			if( !ereg("pro_id" , $fVal ) ){
				checklist($$fVal ,$fVal);
			}
		}
		
		
		$FieldsName2 = $_REQUEST["hddFieldsName2"];	
		$ans_comments = $_REQUEST["ans_comments"];
		$arrFieldsVal2 = array();
		$arrData2 = array();
		
		if($flag){
			$mesg = "Please input data in ";
			while(list($key,$value) = each($data)){
				if(empty($value)){
					if(!ereg("pro_efname|pro_elname",$name))
						$str .= "$key,";						
				}  //if(empty($value)){
				//$str = substr( $str, strlen($str)-1, 1 );
			}
			echo errmesg ("$mesg $str");			
		}	//if($flag){
		
		else{
		
			global $insertID;
			foreach($FieldsName2 as $key => $value ){	
				$arrFieldsVal2[$value] = $_REQUEST["$value"];
			} // foreach($FieldsName2 as $key => $value ){
			
				
			if ($action=="a"){
				## New concept insert code this area
				$run = "insert into run1 value('','1')";
				$updRun = query($dbtype, $link, $run);	
				
				$getID = mysql_insert_id($link);
				$number = '000000'.$getID;
				$year = date("y");
				$number = $pro_source.'/'.$year.'-'.substr($number,-6);
				

				$data["pro_id"] = "";
				$data["pro_code"] = $number ;
				$data["usr_cre"] = $_SESSION["usr_name"];
				$data["date_cre"] = date("Y/m/d  H:i:s");	
				
				$query = create_insert_query($table_name,$data);				
				//echo "$query<br>"; exit();
				mysql_query($query) or die("Insert error");		
				$insertID = mysql_insert_id($link);
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");			
				
			} //if ($action=="a"){
			
			
			if ($action=="e"){
				$data["usr_upd"] = $_SESSION["usr_name"];
				$data["date_upd"] = date("Y/m/d  H:i:s");	
				
				$query = create_update_query($table_name, $data, $id, $field_id);				
				//echo "$query<br>"; exit();
				mysql_query($query) or die("Update error");	
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");				
				
			}  //if ($action=="e"){
			
			if ($action=="d"){
				
				// DELETE PROFILE BY ID //
				$query = "DELETE FROM $table_name WHERE $field_id = $id " ;
				//echo "$query<br>"; exit();
				mysql_query($query) or die("Delete error");		
				
				
				
				// DELETE ANSWER BY ID //
				$query_ans = "DELETE FROM answer WHERE pro_id = $id " ;				
				//echo "\$query_ans=$query_ans"; exit();
				mysql_query($query_ans) or die("Delete Answer Error");		
				$SaveLog=updLog($_SESSION['username'], updSave, "$query_ans");
				
				echo "<script>
						alert ('Delete complete');
						window.location = '".viewForm."';
					  </script>";
				exit();
			}  //if ($action=="d"){
			

			
			# Update Answer				
					
				foreach($arrFieldsVal2 as $fieldsName2 => $value2 ){
			
					list($ansID,$proID,$queID) = explode("_",$fieldsName2);					
					if($action == "a" ) {
						$arrData2["pro_id"] =$insertID;
						$arrData2["usr_cre"] = $_SESSION["usr_id"];
						$arrData2["date_cre"] = date("Y/m/d  H:i:s");		
						$actionTemp = $action;
					}  else{
						## Check answer 
						$sql = "SELECT ans_id FROM answer ";
						$sql .= " WHERE pro_id =$proID ";
						$sql .= " AND que_id = $queID"; 
						//echo "$sql=$sql<hr>";
						$ans_id = getValue($dbtype, $dbname,$sql, $link);
						if($ans_id){
							$actionTemp = $action;
						}else{
							$arrData2["pro_id"] =$proID;
							$arrData2["usr_upd"] = $_SESSION["usr_id"];
							$arrData2["date_upd"] = date("Y/m/d  H:i:s");
							$actionTemp ="a";
						} //else{ if($ans_id){
					}	//else{ if($action == 'a' ) {
					
					$arrData2["que_id"] = $queID;
					$arrData2["cho_id"] = $value2;

					foreach( $ans_comments as $aKey => $aVal ){
						if( $queID == $aKey ){
							$arrData2["ans_comment"] = $aVal ;
							break;
						}
					}
						
					
					if($actionTemp == "a"){
						$query_ans = create_insert_query('answer', $arrData2) ;
						mysql_query($query_ans) or die("Insert Answer error");
						//$msg_error = ;
					}	
					
					if($actionTemp == "e"){
						$query_ans = create_update_query('answer', $arrData2, 'ans_id', $ansID) ;
						mysql_query($query_ans) or die("Update Answer error");
					}	
		
						
				} //foreach($arrFieldsVal2 as $fieldsName2 => $value2 ){
				
				
				if( $action == "a" ){
					echo "<script>
						alert ('Insert complete');
						window.location = '".viewForm."';
					  </script>";
					exit();
				}else{
					echo "<script>
						alert ('Update complete');
						window.location = '".viewForm."';
					  </script>";
					exit();
				}
						
		}  //else{ of if($flag){
	}  //if(!empty($Submit)){
	
?>

<script type="text/javascript" language="javascript">
	function validate() 
	{ //alert(frm.pro_tfname.value);
		
		var action = "<?=$action;?>";
		
		if(action != "d"){
			if(frm.pro_tfname.value=="")
			{
				alert('Please input data in First Name(Th)');
				frm.pro_tfname.focus()
				return false;
			}
	
			if(frm.pro_tlname.value=="")
			{
				alert('Please input data in Last Name(Th)');
				frm.pro_tlname.focus()
				return false;
			}
			
			if(frm.pro_efname.value=="")
			{
				alert('Please input data in First Name(En)');
				frm.pro_efname.focus()
				return false;
			}
	
			if(frm.pro_elname.value=="")
			{
				alert('Please input data in Last Name(En)');
				frm.pro_elname.focus()
				return false;
			}
		}
	}


</script>

</body>
</html>
