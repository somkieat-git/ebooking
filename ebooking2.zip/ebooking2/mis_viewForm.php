<?
	ob_start(); 
	session_start();
	define("tableName","miscode");
	define("viewForm","mis_viewForm.php");
	define("updForm","mis_updForm.php");
	define("field_id","mis_id");
	define("beg_id",1);	
	define("end_id",3);	
	$sql = "SELECT *
				FROM miscode
				";
	//echo "$sql";
	//exit();
	define("query","$sql");
	$cap_name = array();
	$cap_name = array("#","Type","Code","Name","used","user create","date create","user upd","date upd");
	
	$key = array_keys($_SESSION["sec_add"], viewForm); 
	//print_r(array_keys($_SESSION["sec_add"], viewForm));
	if($key[0])
		define("insert",1);		
	else
		define("insert",0);			
	//echo "insert = ".insert."<br>";
		
	$key = array_keys($_SESSION["sec_edit"], viewForm); 
	//print_r(array_keys($_SESSION["sec_edit"], viewForm));
	if($key[0])
		define("edit",1);		
	else
		define("edit",0);			
	//echo "edit = ".edit."<br>";
	
	$key = array_keys($_SESSION["sec_del"], viewForm); 
	//print_r(array_keys($_SESSION["sec_del"], viewForm));
	if($key[0])
		define("del",1);		
	else
		define("del",0);			
	//echo "del = ".del."<hr>";
	
	include("func/viewForm.func.php");
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</body>
</html>
