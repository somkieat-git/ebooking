<?	
	ob_start();
	session_start();
	//include("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	define("updSave","efbk_updForm.php");
	$status = "F";
	$action = $_REQUEST["a"];
	$evn_id = $_REQUEST["id"];
	$loc_id =  $_REQUEST["id2"];
	$room =  $_REQUEST["id3"];
	$Submit = $_REQUEST["Submit"];
	//echo "action=$action<br>evn_id= $evn_id<br>loc_id= $loc_id<br>room= $room<br>submit = $Submit<hr>";
	
	//======================Begin prepare standard data======================================
	if(!empty($evn_id)){
		$sql = "SELECT * FROM eventname WHERE evn_id = '$evn_id'  ";
		$result = getData($sql);
		$row = mysql_fetch_array($result);
		$disabled = "";
		if($row["evn_used"] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;
		$evn_name = $row["evn_shortname"];
	} //if(!empty($ev_id)){	
	
		$sql = "SELECT loc.loc_id, loc.loc_shortname, loc.loc_fullname,
					eloc.eloc_event_date, eloc.eloc_event_time, eloc.eloc_end_date, eloc.eloc_end_time
					FROM location loc, ev_location eloc 
					WHERE loc.loc_id = eloc.loc_id
					AND eloc.evn_id = '$evn_id'  					
					ORDER BY loc.loc_id
					";
		//echo "$sql<br>";
		$rs_eloc = getData($sql);
	//======================End prepare stand data========================================

	//======================Begin select data from ev_eesv_block===============================
	
	if($action != "a") {
			#Show ev_dateblock
			$sql = "SELECT *
						FROM ev_eesv_block 
						WHERE  evn_id = '$evn_id'
						AND loc_id  = $loc_id 
						AND eebk_status = '$status'
						";
		//echo "$sql<br>";
			$result = getData($sql);
			$rs_eebk = mysql_fetch_array($result);				
			$eebk_loc_id = $rs_eebk["loc_id"];
			$esv_id = $rs_eebk["esv_id"];
			$beg_date = chgDate($rs_eebk["eebk_beg_date"]);
			$beg_time = chgTime($rs_eebk["eebk_beg_time"]);
			$end_date =chgDate($rs_eebk["eebk_end_date"]);
			$end_time = chgTime($rs_eebk["eebk_end_time"]);
			/*
			echo "rs_eebk = $rs_eebk<br>
					esv_id = $esv_id<br>
					beg_date = $beg_date<br>
					beg_time = $beg_time<bt>
					end_date = $end_date<br>
					end_time = $end_time<br>
					";*/
			
		}	
	
?>
<html>
<script language="javascript">
	function validate() 
	{
		if(frm.beg_date.value=="")
		{
			alert('Please input data in Begin Date');
			frm.beg_date.focus()
			return false;
		}
		
		if(frm.beg_time.value=="")
		{
			alert('Please input data in Begin Time');
			frm.beg_time.focus()
			return false;
		}
		if(frm.end_date.value=="")
		{
			alert('Please input data in End Date');
			frm.end_date.focus()
			return false;
		}
		if(frm.end_time.value=="")
		{
			alert('Please input data in End Time');
			frm.end_time.focus()
			return false;
		}
	}	
	function click_select() {	
		var x1, x2 
		var y1, y2 
		var val1, val2, val3 
		var arr_y,arr_y0, arr_y1,arr_y2,arr_y3,arr_y4 ;
		x1 = document.frm.id2.selectedIndex ;
		//alert(x1);
		x2 = document.frm.id2[x1].value;		
		//alert(x2);
		y1 = document.frm.hd_qty.value;
		if (y1 == 1){
			y2 = document.frm.hd_temp.value;
		}
		else{
			y2 = document.frm.hd_temp[x1].value;
		}		
		//alert(y2);
		arr_y  =  y2.split(",");
		arr_y0 = arr_y[0];
		arr_y1 = arr_y[1];
		arr_y2 = arr_y[2];
		arr_y3 = arr_y[3];
		arr_y4 = arr_y[4];		
		if(document.frm.beg_date.value == ""){
			//alert("ok");
			document.frm.beg_date.value = arr_y1 ;
		}
		if(document.frm.beg_time.value == ""){
			document.frm.beg_time.value = arr_y2 ;
		}
		if(document.frm.end_date.value == ""){
			document.frm.end_date.value = arr_y3 ;
		}
		if(document.frm.end_time.value == ""){
			document.frm.end_time.value = arr_y4 ;
		}
	}
	
</script>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">
<script language="javascript" type="text/javascript" src="datetimepicker.js"></script>
</head>
	
<body >
<form action="<?=updSave?>?a=<?=$action ?>&id=<?=$evn_id?>&id2=<?=$loc_id?>" method="post" name="frm"  id="frm" onSubmit="return validate();" >
  <table border="0" class="BorderGreen" >
    <tr class="BorderSilver">
      <td colspan="4"  style="background-color:#339900;font-weight:bold;color:White;">
	  	<div align="center"><strong >Equipment / Services   - <?=$evn_id." - " .$evn_name ?></strong></div>
	  </td>
    </tr>
	<tr>
	  <td height="16" colspan="4" ><input name="hd_evn_id" type="hidden" id="hd_evn_id" value="<?=$evn_id ;?>">
      </td>
	</tr>
	<tr>
	  <td width="79" height="18" ><div align="right">Room : </div></td>
      <td colspan="3" >	  
	    <a href="javascript:NewCal('txt_in_date','ddmmyyyy',false,12)">	</a>   	 
		<select name="id2" id="id2" <? if($action=='u') echo 'disabled' ;?> 
		onChange="click_select();">
          <?
		  $cnt_loc = 0 ;
			while($row = mysql_fetch_array($rs_eloc)){
				$cnt_loc += 1;
				$id = $row[0];
				$loc_name = $row[1]." - ".$row[2];
		?>
          <option value=<?=$id;?> 
		  <? if($loc_id==$id) echo 'selected'; ?> >
          <?=$loc_name?>
          </option>
          <?
			}
				echo '<input name="hd_qty" type="hidden" id="hd_qty" value="'.$cnt_loc .'">';	
		?>
        </select>
		<?
			$sql = "SELECT loc_id, eloc_in_date, eloc_in_time,
					eloc_out_date, eloc_out_time
			FROM ev_location
			WHERE  evn_id = '$evn_id'
			ORDER BY loc_id
			 ";
			//echo "\$sql = <br> $sql<br>";
			$result = getData($sql);	
			
			while ($rs =  mysql_fetch_array($result)){
				$id = $rs["loc_id"];
				$val = $rs["loc_id"] .",".chgDate($rs["eloc_in_date"]).",".chgTime($rs["eloc_in_time"]).",".chgDate($rs["eloc_out_date"]).",".chgTime($rs["eloc_out_time"]);
				echo '<input name="hd_temp" type="hidden" id="hd_temp" value="'.$val .'">';	
				//echo "$val";
			}			
			?></td>
    </tr>
	<tr>
	  <td height="18" ><div align="right">Begin Date : </div></td>
	  <td width="144" ><input name="beg_date" type="text" id="beg_date" 
	  value="<?=$beg_date ;?>" size="10" maxlength="10" onBlur="return click_select()">
	  <a href="javascript:NewCal('beg_date','ddmmyyyy',false,12)">
	  <img src="images/cal.gif" width="16" height="16" border="0" alt="Pick a date"></a>
	  </td>
	  <td width="81" ><div align="right">Begin Time : </div></td>
	  <td width="170" ><input name="beg_time" type="text" id="beg_time" 
	  value="<?=$beg_time ;?>" onBlur="return click_select()"></td>
    </tr>
	<tr>
	  <td height="18" ><div align="right">End Date : </div></td>
	  <td ><input name="end_date" type="text" id="end_date" value="<?=$end_date ;?>" size="10" maxlength="10" onBlur="return click_select()">
	  <a href="javascript:NewCal('end_date','ddmmyyyy',false,12)">
	  <img src="images/cal.gif" width="16" height="16" border="0" alt="Pick a date"></a>
	  </td>
	  <td ><div align="right">End Time : </div></td>
	  <td ><input name="end_time" type="text" id="end_time" 
	  value="<?=$end_time ;?>" onBlur="return click_select()"> </td>
    </tr>
	<tr>
	  <td height="18" colspan="4" >&nbsp;</td>
    </tr>
	<tr>
	  <td height="18" colspan="4" ><div align="center">
        <input name="Submit" type="submit" class="Button" value="   OK   "  <?=$disabled ;?>
		onClick="return validate();" >
        <input name="btnDel" type="button" class="Button" id="btnDel"   value="Delete" <? if ($action=='a') echo "disabled"; else echo $disabled ;?> 
		onClick= "window.location = 'efbk_updForm.php?a=d&id=<?=$evn_id?>&id2=<?=$loc_id?>' " >
        <input name="btnCancel" type="button" class="Button" id="btnCancel"  onClick="history.go(-1)" value="Cancel" >
      </div></td>
    </tr>		
  </table>
</form>
<?

	//======================Begin Save Data==============================================
	//request data into varible
	if(!empty($Submit)){			
		$loc_id = $_REQUEST["id2"];
		
		$beg_date =  chgDateToDb($_REQUEST["beg_date"]);
		$beg_time =  chgTimeToDb($_REQUEST["beg_time"]);
		$end_date =  chgDateToDb($_REQUEST["end_date"]);
		$end_time =  chgTimeToDb($_REQUEST["end_time"]);
		/*
		echo "
		evn_id =  $evn_id<br>
		loc_id =   $loc_id<br>
		status = $status<br>
		beg_date =   $beg_date<br>
		beg_time =   $beg_time<br>
		end_date =   $end_date<br>
		end_time =   $end_time<br>
		";
		*/
		function  checklist($value,$label,$field){
			global $resData;
			$resData[$field] = $value;
		}		
		
		checklist($beg_date,"","eebk_beg_date");
		checklist($beg_time,"","eebk_beg_time");
		checklist($end_date,"","eebk_end_date");
		checklist($end_time,"","eebk_end_time");
		
		function  checklist2($value,$label,$field){
			global $resData2;
			$resData2[$field] = $value;
		}		
		checklist2($beg_date,"","eesv_beg_date");
		checklist2($beg_time,"","eesv_beg_time");
		checklist2($end_date,"","eesv_end_date");
		checklist2($end_time,"","eesv_end_time");


			if($action=="a"){				
				$resData["evn_id"] = $evn_id;
				$resData["loc_id"] = $loc_id;
				$resData["eebk_status"] = $status;
				$resData["usr_cre"] = $_SESSION["usr_name"];
				$resData["date_cre"] = date("Y/m/d  H:i:s");		
				
				$query = create_insert_query("ev_eesv_block",$resData);	
				//echo "$query<br>";
				//exit();
				mysql_query($query) or die("Insert ev_eesv_block error");		
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");			
				//Show alert by javascript
				echo "<script>
						alert ('Insert complete');
						window.location = 'efbk_viewForm.php?id=$evn_id&id2=$loc_id' ;
					  </script>";
				exit();
			} //if($action=="a"){				
			
			if($action=="u"){				
				//update ev_eesv_block
				$resData["usr_upd"] = $_SESSION["usr_name"];
				$resData["date_upd"] = date("Y/m/d  H:i:s");		
				
				$query = create_update_evquery("ev_eesv_block", $resData, $evn_id, "evn_id",$loc_id,"loc_id");				
				$query .= " AND eebk_status = '$status' ";
			    //echo "$query<br>";
				//exit();
				mysql_query($query) or die("Update ev_eesv_block error");	
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");	
				
				//update ev_equip_serv				
				$query = create_update_evquery("ev_food_serv", $resData2, $evn_id, "evn_id",$loc_id,"loc_id");				
			    //echo "$query<br>";
				//exit();
				mysql_query($query) or die("Update ev_food_serv error");	
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");	
				
				//Show alert by javascript
				echo "<script>
						window.location = 'efbk_viewForm.php?id=$evn_id&id2=$loc_id' ;
					  </script>";
				exit();
			} //if($action=="u"){
	} //if(!empty($Submit) && $action != "d"){			
			
			if($action=="d"){			
				#delete value in ev_dateblock			
				$sql = "DELETE  FROM ev_eesv_block  
							WHERE evn_id = '$evn_id' 
							AND loc_id = '$loc_id' 
							AND eebk_status = '$status'
							";
							
				//echo "$sql<br>";
				//exit();
				mysql_query($sql) or die("Delete ev_eesv_block error");		
				$SaveLog=updLog($_SESSION['username'], updSave, "$sql");		
				#delete value in ev_location			
				if($esv_id){
					$sql = "DELETE  FROM ev_food_serv 
								WHERE evn_id = '$evn_id' 
								AND loc_id = $loc_id
								AND esv_id in ($esv_id)";
					//echo "$sql<hr>";
					//exit();
					mysql_query($sql) or die("Delete ev_equip_serv error");
					$SaveLog=updLog($_SESSION['username'], updSave, "$sql");
				}
					//Show alert by javascript
					echo "<script>
							alert ('Delete complete');
							window.location = 'efbk_viewForm.php?id=$evn_id' ;
						  </script>";
					exit();				
			} //if($action=="d"){			
	
	//======================End Save Data==============================================
include("db/disconnect.db.php");	
?>
