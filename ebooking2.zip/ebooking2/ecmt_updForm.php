<?	
	ob_start();
	session_start();
	include_once("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	define("updSave","ecmt_updForm.php");
	
   	$evn_id =  $_REQUEST["id"];
	$ecmt_item =  $_REQUEST["id2"];
	$cmt_item =  $_REQUEST["cmt_item"];
	if ($ecmt_item == "") $ecmt_item = "0 - Event Comment";
	//echo "\$evn_id =$evn_id<br>\$ecmt_item = $ecmt_item<br>";	

	//======================Begin prepare standard data======================================
	if(!empty($evn_id)){
		$sql = "SELECT * FROM eventname WHERE evn_id = '$evn_id'  ";
		$result = getData($sql);
		$row = mysql_fetch_array($result);
		$disabled = "";
		//if($row[3] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;
		if($row["evn_used"] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;
		$evn_name = $row["evn_shortname"];
	} //if(!empty($ev_id)){	
	
		$comment = "Comment";
		$sql = "SELECT  * FROM miscode ";
		$sql.=" WHERE mis_type = '$comment'";
		$sql.=" AND mis_used not in ('N','n')";
		$sql.="	ORDER BY mis_type ASC,  mis_code ASC ";
		//echo "$sql<br>";
		//xit();
		$result = getData($sql);
		$arrcomment = array();
					
		while( $row = mysql_fetch_array($result)){
			if ($row["mis_type"] == $comment ){
				$arrcomment[] = $row["mis_code"]." - ".$row["mis_name"];
				$arrComType[] = $row["mis_name"];
			} //if ($row["mis_type"]=="$event "){
		} //while( $row = mysql_fetch_array($result)){
	//======================End prepare stand data========================================

	//======================Begin select data from ev_comment===============================
	if (!empty($evn_id)){
		if(empty($ecmt_item)){
			$ecmt_item ="$arrcomment[0]";
		} //if(empty($ecmt_item)){
		
		$sql = "SELECT * FROM ev_comment WHERE evn_id = '$evn_id' 
					AND ecmt_item like '$ecmt_item' 
					";
		//echo "$sql<br>";
		//exit();
		$result = getData($sql);
		$numrow = mysql_num_rows($result);
		$rs_ecmt= mysql_fetch_array($result);	
	} //if (!empty($evn_id)){
	
	?>
<html>
<script language="javascript">	
	function validate() 	
	{
		var chkdesc = frm.ecmt_desc.value;
		if(trimAll(chkdesc)=="" )
		{
			alert('Please input data in Description');
			frm.ecmt_desc.focus();
			return false;
		}			
	}
	
	function trimAll( strValue ) {
	 var objRegExp = /^(\s*)$/;
		//check for all spaces
		if(objRegExp.test(strValue)) {
		   strValue = strValue.replace(objRegExp, '');
		   if( strValue.length == 0)
			  return strValue;
		}
	
	   //check for leading & trailing spaces
	   objRegExp = /^(\s*)([\W\w]*)(\b\s*$)/;
	   if(objRegExp.test(strValue)) {
		   //remove leading and trailing whitespace characters
		   strValue = strValue.replace(objRegExp, '$2');
		}
	  return strValue;
	}
	
//-->
</script>


<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">


<!--<link rel="stylesheet" href="css/style.css" type="text/css" media="screen"/>
<script type="text/javascript" src="lib/jquery.min.js"></script>
<script type="text/javascript" src="js/sliding.form.js"></script>
-->

<!-- ####### Tab ####### -->
	<link rel="stylesheet" href="css/themes/base/jquery.ui.all.css">
	<script src="lib/jquery-1.5.js"></script>
	<script src="lib/ui/jquery.ui.core.js"></script>
	<script src="lib/ui/jquery.ui.widget.js"></script>
	<script src="lib/ui/jquery.ui.mouse.js"></script>
	<script src="lib/ui/jquery.ui.sortable.js"></script>
	<script src="lib/ui/jquery.ui.tabs.js"></script>
	<link rel="stylesheet" href="css/themes/demos.css">

<script>
	$(function() {
		var index = $("#sel_name").val();		
		$( "#tabs" ).tabs().find( ".ui-tabs-nav" ).sortable({ axis: "x" });
		if(index) $( "#tabs" ).tabs({ selected: index })
	});
</script>

<!-- ############## -->
<script type="text/javascript">
var temp_item1 = "";
var temp_item2 = "";
var temp_item3 = "";
var temp_item4 = "";
function chkTypeComment(type_cm , ecmt_item){
	//alert(type_cm);   hd_ecmt_item2
	document.getElementById('hd_ecmt_item').value = type_cm ;
}

function saveComplete(txt , evn_id , a_ecmt_item ){			
	//window.location = "ecmt_updForm.php?id="+evn_id+"&id2="+a_ecmt_item+"&cmt_item="+txt ;
	window.location.href = "ecmt_updForm.php?id="+evn_id+"&id2="+a_ecmt_item+"&cmt_item="+txt ;
}
</script>

</head>
<style>
*{
    margin:0px;
    padding:0px;
}
        span.reference{
            position:fixed;
            left:5px;
            top:5px;
            font-size:10px;
            text-shadow:1px 1px 1px #fff;
        }
        span.reference a{
            color:#555;
            text-decoration:none;
			text-transform:uppercase;
        }
        span.reference a:hover{
            color:#000;
            
        }
        h1{
            color:#ccc;
            font-size:36px;
            text-shadow:1px 1px 1px #fff;
            padding:20px;
        }
		
		#legend{
			text-align:left;
			background-color:#f0f0f0;
			color:#666;
			font-size:16px;
			text-shadow:1px 1px 1px #fff;
			font-weight:bold;
			float:left;
			width:650px;
			height:30px;
			padding:1px 0px 3px 10px;
			margin:1px 0px;
			margin-top:-5px;
			border-bottom:1px solid #fff;
			border-top:1px solid #d9d9d9;
		}
		h2{
			font-size:16px;
			color:#FFFFFF;
			background-color:#339900; /* No */
			width:690px;
			border-color:#339900;
			margin-bottom:1px;
			padding:3px 2px 3px  2px;
		}
		#content{
			text-align:center;
			width:690px;
			position:relative;
			height:100%;
			margin-left: 1px;
			border-color:#339900;
		}
    </style>
<body>
<div class="demo" id="content">
<h2 align="center">Comment - <?=$evn_id." - " .$evn_name ?></h2>
<div id="tabs" style="width:690px;border-color:#339900;">
	<?php $cmt_item != "" ? $div_display = "" : $div_display = "display:none;"; ?>
	<div id="div_complete" style="height:15px;<?php echo $div_display; ?>">
		<?php $txt = "Save  '" . $cmt_item . "' Complete.. " ;?>
		<span id="txt_complete" style="font-size:11px;font-weight:bold;color:#0000FF;"><?php echo $txt; ?></span>
	</div>
	<ul>
		<?php for($i=0;$i<count($arrcomment);$i++){ ?>
			<?php if(preg_match("/$cmt_item/" , $arrcomment[$i])){	list($index , ) = explode(" - ",$arrcomment[$i]); ?>
				<input type="hidden" id="sel_name" value="<?php echo $index; ?>" />
			<?php }	?>
			<li><a href="#tabs-<?php echo $i; ?>" onClick="javascript:chkTypeComment('<?php echo $arrcomment[$i] ;?>' , '<?php echo $ecmt_item ;?>');"><?php echo $arrcomment[$i] ; ?></a></li>
		<?php } ?>
	</ul>
	<form action="<?=updSave ?>?id=<?=$evn_id?>" method="post" name="frm"  id="frm"  onSubmit="return validate() ;" >
	<?php for( $i=0 ; $i<count($arrComType); $i++ ): ?>
	<?php 
		$sql = "SELECT * FROM ev_comment WHERE evn_id = '$evn_id' 
					AND ecmt_item like '$arrcomment[$i]' 
					";
		//echo "$sql<br>";
		//exit();
		$result = getData($sql);
		//$numrow = mysql_num_rows($result);
		$rw_ecmt= mysql_fetch_array($result);	
		$rw_ecmt["ecmt_desc"] <> "" ? $defDesc = $rw_ecmt["ecmt_desc"] : $defDesc = "$arrComType[$i] :    " ;
	?>
	<div id="tabs-<?php echo $i; ?>">
	 <span id="legend"><?php echo $arrComType[$i]; ?></span>
	  <p>
		<!--<textarea name="ecmt_desc_<?php echo $i ; ?>" cols="105" rows="15" wrap="OFF" id="ecmt_desc" value="<?=$arrComType[$i];?>"><?php echo $defDesc ; ?></textarea>-->
		<textarea name="ecmt_desc[<?php echo $i ; ?>]" cols="105" rows="15" wrap="OFF" id="ecmt_desc" value="<?=$arrComType[$i];?>"><?php echo $defDesc ; ?></textarea>
	  </p>
	  <p>
		<table align="center" border="0">
		 <tr>
			<td>
			 <input name="Submit2" type="button" class="Button" value="&lt;= Back " onClick="window.location = 'efsv_viewForm.php?id=<?=$evn_id ;?>'" >
			</td>
			<td>
			 <input name="Submit" type="submit" class="Button" value="   OK   "<?=$disabled ;?> />
			</td>
			<td>
			 <input name="Button" type="button" class="Button" id="Button"  onClick="history.go(-1)" value="Cancel" />
			</td>
			<td>
			 <input name="Submit22" type="button" class="Button" value="Next =&gt;" onClick="window.location = 'eckl_viewForm.php?id=<?=$evn_id?>'" />
			</td>
		 </tr>
		</table>
	  </p>
	</div>
	<?php endfor; ?>
	<input name="hd_ecmt_item" type="hidden" id="hd_ecmt_item" value="<?php echo $ecmt_item ;?>" />
	</form>
</div>

</div><!-- End demo -->


<?

	//======================Begin Save Data==============================================
	//request data into varible
	$Submit = $_REQUEST["Submit"];
	
	if(!empty($Submit)){		
		$arrEcmtItem = array();
		$arrComValue = array();
		$a_ecmt_item = $_REQUEST["hd_ecmt_item"];
		$arrEcmtItem = explode(" - " ,$a_ecmt_item);
		$arrEcmtDesc = $_REQUEST["ecmt_desc"];
		$item_code = $arrEcmtItem[0];
		$item_name = $arrEcmtItem[1];
		//echo "\$item_name=$item_name" ; echo "<hr>";
		//echo "\ecmt_desc=<pre>"; print_r($_REQUEST["ecmt_desc"]); echo "<hr/>";	exit();
	
		function  checklist($value,$label,$field){
			global $resData;
			$resData[$field] = $value;
		} //function checklist($var,$name){
		
		
		for( $i=0 ; $i<count($arrComType); $i++ ){
			//$a_ecmt_desc = $_REQUEST["ecmt_desc_$i"];
			$a_ecmt_desc = $arrEcmtDesc[$i];
			$arrComValue[$i] = explode(" : " ,$a_ecmt_desc);
			$comItem = $arrComValue[$i][0];
			$comValue = $arrComValue[$i][1];

			//if( $comItem == $item_name ){
			if(preg_match("/$item_name/" , $comItem)){
//				echo "\$comItem=$comItem" ; echo "<hr>";
//				echo "\$item_name=$item_name" ; echo "<hr>";
				$a_ecmt_desc = htmlspecialchars($a_ecmt_desc);
				checklist($a_ecmt_desc,"","ecmt_desc");
				break;
			}			
			
		} // for( $i=0 ; $i<count($arrComType); $i++ ){
		
		//echo "\$arrComValue=<pre>"; print_r($arrComValue); echo "<hr/>";
		/*echo "
		submit = $Submit<br>
		evn_id =  $evn_id<br>
		a_ecmt_item = $a_ecmt_item<br> 
		a_ecmt_desc = $a_ecmt_desc<br>
		";  
		//echo "ecmt_desc = <pre>"; print_r($ecmt_desc);
		exit();*/
		
		
		
		//check duplicate data in table ev_comment
		$sql = "SELECT * FROM ev_comment WHERE evn_id = '$evn_id' AND ecmt_item = '$a_ecmt_item'  ";
		//echo "$sql<br>";
		//exit();
		$result = getData($sql);
		$numrow = mysql_num_rows($result);
		$row = mysql_fetch_array($result);
		//echo "numrow = $numrow<br>";
		if ($numrow == 0 ){
				$action = "add";}
			else{
				$action = "edit";
		}
		//echo "action=$action<br>";
		//exit();
		
		
		
			if($action=="add"){
				$resData["ecmt_id"]="";
				$resData["ecmt_item"]="$a_ecmt_item";
				$resData["evn_id"] = $evn_id;
			
				$resData["usr_cre"] = $_SESSION["usr_name"];
				$resData["date_cre"] = date("Y/m/d  H:i:s");		
				
				$query = create_insert_query("ev_comment",$resData);	
				//echo "$query<br>";
				//exit();
				mysql_query($query) or die("Insert error");	
				//$SaveLog=updLog($_SESSION['username'], updSave, "$query");					
				//Show alert by javascript
				/*echo "<script>
						alert ('Insert complete');
						window.location = 'ecmt_updForm.php?id=$evn_id&id2=$a_ecmt_item';
					  </script>";
				exit();*/
				echo "<script type=\"text/javascript\">saveComplete(\"$item_name\" , $evn_id , \"$a_ecmt_item\" );</script>";
			}
			
			if($action=="edit"){
				$resData["usr_upd"] = $_SESSION["usr_name"];
				$resData["date_upd"] = date("Y/m/d  H:i:s");		
				
				$query = create_update_query("ev_comment", $resData, $evn_id, "evn_id");				
				$query .= " AND ecmt_item = '$a_ecmt_item' " ;
				//echo "$query<br>";
				mysql_query($query) or die("Update error");		
				//$SaveLog=updLog($_SESSION['username'], updSave, "$query");
				//Show alert by javascript
				/*echo "<script type='text/javascript'>
						alert ('Update complete');
						window.location = 'ecmt_updForm.php?id=$evn_id&id2=$a_ecmt_item' ;
					  </script>";
				exit();*/
				echo "<script type=\"text/javascript\">saveComplete(\"$item_name\" , $evn_id , \"$a_ecmt_item\" );</script>";
			}
			
			
		
//		} // for( $i=0 ; $i<count($arrComType); $i++ ){
	} //if(!empty($Submit)){
	
	//======================End Save Data==============================================
?>