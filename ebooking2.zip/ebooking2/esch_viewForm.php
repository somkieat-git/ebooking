<?
	ob_start(); 
	session_start();
	$evn_id = $_REQUEST["id"];
	//$evn_id = '06010001';
	define("sysName","Schedule");
	define("tableName","ev_schedule");
	define("viewForm","esch_viewForm.php");
	define("addForm","esch_updForm.php");	
	define("updForm","esch_updForm.php");	
	define("field_id","esch_id");	
	define("beg_id",1);	
	define("end_id",6);		
	
	$sql = "SELECT esch_id , esch_beg_date , esch_end_date , esch_beg_time , esch_end_time , esch_loc_id , esch_desc
				FROM ev_schedule
				WHERE evn_id = '$evn_id' ";				
	//echo "$sql";
	//exit();
	define("query","$sql");
		
	$cap_name = array();
	$cap_name = array("#","Start Date ","End Date","Start Time","End Time","Location","Item");
	
	//=============check authorize================
	$key = array_keys($_SESSION["sec_add"], viewForm); 
	if($key[0])
		define("insert",1);		
	else
		define("insert",0);			
		
	$key = array_keys($_SESSION["sec_edit"], viewForm); 
	if($key[0])
		define("edit",1);		
	else
		define("edit",0);			
		
	$key = array_keys($_SESSION["sec_del"], viewForm); 
	if($key[0])
		define("del",1);		
	else
		define("del",0);			
		
	include("func/ev_viewForm.func1.php");
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</body>
</html>
