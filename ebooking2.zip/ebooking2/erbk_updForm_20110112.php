<?php
	ob_start(); 
	session_start();
		

	include_once("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");	
	define("updSave","erbk_updForm.php");
	
	$evn_id = $_REQUEST["id"];
	$action = $_REQUEST["a"];

	
	if(!empty($evn_id)){
		$sql = "SELECT * FROM eventname WHERE evn_id = '$evn_id'  ";
		$result = getData($sql);
		$row = mysql_fetch_array($result);
		$evn_fullname = $row["evn_fullname"];
	} //if(!empty($ev_id)){	
	
	
	
	
	// ==========  Booking Status Code  ================ //
	$sql = "SELECT * FROM bookingstatus ";
	$result = getData($sql);
	$bks_status = array();
	while( $row = mysql_fetch_array($result)){
		//$bks_status[$row["bks_id"]] = $row["bks_code"] . " - " . $row["bks_name"];
		$bks_status[$row["bks_id"]] = $row["bks_name"];
	}
	//echo "<pre>"; print_r($bks_status); exit();


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Rebook Event - <?php echo $evn_id . " - " . $evn_fullname ; ?></title>
<link href="css/format.css.css" rel="stylesheet" type="text/css">

<!--------------  jQuery Datepick (Popup Calendra)  ---------------------->
	
	<link href="./css/jquery.datepick.css" type="text/css" rel="stylesheet" />
	<script type="text/javascript" src="lib/jquery.min.js"></script>	
	<script type="text/javascript" src="js/jquery.datepick.js"></script>
	<script type="text/javascript">
	$(function() {
		jQuery('#event_date').datepick({onSelect: removePeriods
		, yearRange: '1980:2025' 
		, showTrigger: '#calImg'});
		
		jQuery('#end_date').datepick({onSelect: addPeriods 
		, yearRange: '1980:2025' 
		, showTrigger: '#calImg'});
		
		jQuery('#addAmount,#addPeriod').change(addPeriods); 
		jQuery('#removeAmount,#addPeriod').change(removePeriods);
	});
	
	
	function removePeriods(){
		var date = new Date(jQuery('#event_date').datepick('getDate')[0].getTime()); 
			jQuery.datepick.add(date, jQuery('#removeAmount').val(), jQuery('#addPeriod').val());
			jQuery('#in_date').val(jQuery.datepick.formatDate(date)); 
	}
	
	function addPeriods() { 
		ctrlButtonAdd();
		var date = new Date(jQuery('#end_date').datepick('getDate')[0].getTime()); 
		jQuery.datepick.add(date, jQuery('#addAmount').val(), jQuery('#addPeriod').val()); 
		jQuery('#out_date').val(jQuery.datepick.formatDate(date)); 
	}
	
	
	 
	</script>
	
	<script type="text/javascript">
	
		window.onload = function(){
			document.getElementById('add').disabled = true;
			document.getElementById('remove').disabled = true;
		};
	
		function addOption( in_date ){
		
			var event_date = document.getElementById("event_date").value ;
			var end_date = document.getElementById("end_date").value ;
			var in_date = document.getElementById("in_date").value ;
			var out_date = document.getElementById("out_date").value ;
			var bStatus = document.getElementById("hdd_bks").value ;
			
			var opt_value = event_date +"|"+ end_date +"|"+ in_date +"|"+ out_date +"|"+ bStatus ;
			
			var elOptNew = document.createElement('option');
				elOptNew.text = event_date + " - " + end_date + "           " + bStatus ;
				elOptNew.value = opt_value ;
			 
			var elSel = document.getElementById("list");
				elSel.add(elOptNew);
					
			clearForm();
		}
		
		function removeOptionSelected(){
			var elSel = document.getElementById("list");
			var i;
			 for (i = elSel.length - 1; i>=0; i--) {
				if (elSel.options[i].selected) {
				  elSel.remove(i);
				}
			 }
			 clearForm();
		}
		
		function chkDup(text){
			document.getElementById("hdd_bks").value = text;
		}
		
		function clearForm(){
			document.getElementById("event_date").value = "" ;
			document.getElementById("end_date").value = "" ;
			document.getElementById("in_date").value = "" ;
			document.getElementById("out_date").value = "" ;
			
			document.getElementById("bks_id").selectedIndex = 0;
			document.getElementById("hdd_bks").value = "" ;	
			document.getElementById('add').disabled = true;		
			document.getElementById('remove').disabled = true;
		}
		
		function ctrlButtonAdd(){
			
			var in_date = document.getElementById("event_date").value ;
			if( in_date != "" ){
				document.getElementById('add').disabled = false;
			}else{
				document.getElementById('add').disabled = true;
			}
		}
		
		function ctrlButtonRemove(value){
			if(value != ""){
				document.getElementById('remove').disabled = false;
			}
		}

		function selectAll(list) {
			var arrList = new Array();
			for(var i=0; i<list.length; i++) {
				arrList[i] = list[i].value; // 09/01/2011|CF - Confirmed
				//alert(list[i].value);
			}
			 document.frm.hdd_list.value = arrList ;	
		}
		
		function showAmount(chk_value){
		//alert(chk_value);
			if( chk_value == 1 ){
				document.getElementById('show_amount').value = 0 ;
				document.getElementById('showAmount').style.display = "" ;
				
			}else{
				document.getElementById('show_amount').value = 1 ;
				document.getElementById('showAmount').style.display = "none" ;
			}
			
		}
		
	</script>

</head>

<body>
<br />
<form action="<?=$updSave ?>?id=<?php echo $evn_id ; ?>" method="post" name="frm"  id="frm" >
  <table border="0" class="BorderGreen" width="350">
    <tr class="BorderSilver">
      <td colspan="4" style="background-color:#339900;font-weight:bold;color:White;">
	  	<div align="center"><strong >Rebook Event - <?php echo $evn_id . " - " . $evn_fullname ; ?></strong></div>
	  </td>
    </tr>
	<tr>
		<td colspan="4">
			<table border="0" class="BorderGreen" width="450">
				<tr>
					<td colspan="2">Start Date : </td>
					<td width="284" colspan="2">
						<input type="text" name="event_date" id="event_date" value="" />
						<div style="display: none;"> 
							<img id="calImg" src="images/calendar.gif" alt="Pick a date" class="trigger" > 
						</div>
						<input type="hidden" name="addPeriod" id="addPeriod" value="d" />
						<input type="checkbox" name="show_amount" id="show_amount" value="1" onclick="javasctipt:showAmount(this.value);" />
						<div id="showAmount" style="display:none">
							<input type="text" name="removeAmount" id="removeAmount" value="" onkeyup="???????" />
						</div>
						<input type="hidden" name="hddremoveAmount" id="hddremoveAmount" value="" />
						<input type="hidden" name="in_date" id="in_date" value="" />
				  </td>
				</tr>
				<tr>
					<td colspan="2">End Date : </td>
					<td colspan="2">
						<input type="text" name="end_date" id="end_date" value="" />
						<div style="display: none;"> 
							<img id="calImg" src="images/calendar.gif" alt="Pick a date" class="trigger" > 
						</div>
						<input type="text" name="addAmount" id="addAmount" value="" />
						<input type="hidden" name="out_date" id="out_date" value="" />
					</td>
				</tr>
				<tr>
					<td colspan="2">Booking Status Code : </td>
					<td colspan="2" align="left">
						<select name="bks_id" id="bks_id" onchange="javascript:chkDup(this.options(selectedIndex).text);">
							<?php foreach( $bks_status as $bks_id => $bks_name ) :?>
								<option value="<?php echo $bks_id ; ?>"><?php echo $bks_name; ?></option>
							<?php endforeach;?>
						</select>
						<input type="hidden" id="hdd_bks" name="hdd_bks" value="" />
					</td>
				</tr>
				<tr>
					<td colspan="4">
						<div align="center">
							<input name="add" id="add" type="button" class="Button" value="Add" 
							onclick="javascript:addOption();" >
							<input name="remove" id="remove"  type="button" class="Button" value="Remove" 
							onclick="javascript:removeOptionSelected();" >
						</div>
					</td>
				</tr>
			</table>
		</td>
	</tr>	
	<tr>
		<td colspan="4">
			<select name="list" id="list" size="10" multiple style="width:450px;" 
			onClick="javascript:ctrlButtonRemove(this.value);" >
			</select>
		</td>
	</tr>
    <tr align="center" >
      <td colspan="3">	  	
  	    <div align="center">
			<input name="Submit2" type="button" class="Button" value="&lt;= Back " onClick="window.location = 'ecus_updForm.php?id=<?=$evn_id?>'" >
			<input name="Submit" type="submit" class="Button" value="   OK   " <?=$disabled ;?> onClick="selectAll(document.frm.list);" >
			<input name="Button" type="button" class="Button" id="Button"  onClick="history.go(-1)" value="Cancel" >
			<input name="Submit22" type="button" class="Button" value="Next =&gt;" onClick="window.location = 'eloc_viewForm.php?id=<?=$evn_id?>'" >		  
			<input name="hdd_list" type="hidden" id="hdd_list" value="" />

		  </div></td>
    </tr>
  </table>
</form>


<?php 

// ========================  Save Rebook ================================= //

	$Submit = $_REQUEST["Submit"];
	
	if(!empty($Submit)){
		$evn_id = $_REQUEST["id"];
		$hdd_list = $_REQUEST["hdd_list"];
		$time = "0800";
		$arrTable = array( "eventname" 
							, "ev_statistics" 
							, "ev_dateblock" 
							, "ev_customer" 
							, "ev_staff" 
							, "ev_location" 
							, "ev_equip_serv" 
							, "ev_food_serv" 
							, "ev_comment" 
							, "ev_checklist" 
							, "ev_dailyperday" 
							, "ev_schedule"
							, "ev_setup" );
		
		
		$sql = "SELECT edbk_out_date
				FROM ev_dateblock
				WHERE evn_id = '$evn_id'
				ORDER BY `edbk_out_date` DESC
				LIMIT 1 ;";
		$result = getData($sql);
		$row = mysql_fetch_array($result);
		$last_out_date = $row["edbk_out_date"];
		
		
		
		$lst_value = array();
		$lst_value = explode("," , $hdd_list); 
		// echo "<pre>"; print_r($lst_value); echo "<hr>"; 
		for($i=0; $i<sizeof($lst_value); $i++){
			//$data = explode("|" , $lst_value[$i]);
			
			list($event_date , $end_date , $in_date , $out_date , $bk_status) = explode("|" , $lst_value[$i]);
			
			list($dd_sh , $mm_sh , $yyyy_sh) = explode("/" , $event_date);
			$event_date = $yyyy_sh.$mm_sh.$dd_sh;
			echo "\$event_date= $event_date"; echo "<hr>";
			
			list($dd_out , $mm_out , $yyyy_out) = explode("/" , $end_date);
			$end_date = $yyyy_out.$mm_out.$dd_out;
			echo "\$end_date= $end_date"; echo "<hr>";
			//echo "\$bk_status= $bk_status"; echo "<hr>";
			
			
			
			
			// =========== GEN EVENT ID =============== //
			
			$valdate_in = chgDateToDb($in_date); 
			$valdate_out = chgDateToDb($out_date); 
			//echo "\$valdate= $valdate" ; echo "<hr>";
			$valbegtime = "0800";
			$valendtime = "1800";
			$usr_cre = $_SESSION["usr_name"];
			$date_cre = date("Y/m/d  H:i:s");		
			$val_date_cre = date("d/m/Y");
			
			list($dd, $mm, $yyyy) = explode('/',$in_date);
			if(strlen($mm) < 2) $mm = '0' . $mm;
			$yymm = substr($yyyy,2,2).$mm;
			
			$sql = "SELECT MAX(evn_id) as id FROM eventname
						 WHERE evn_id like '$yymm%' ";
			//echo "\$sql=$sql<br>";
			//exit();
			
			$result = getData($sql);
			$row = mysql_fetch_array($result);
			
			//echo $row[0]; echo "<hr>";
			//echo "\$yymm=$yymm<br>";
	
			if(is_null($row["id"]))
				$evn_id_new =  "$yymm"."0001";
			else{
				//$evn_id = ($row[0]+1);
				$running = "99".substr($row["id"], 4)+1;
				$evn_id_new = "$yymm".substr($running, 2);
				//echo "runing=$running<br>"; 
			}
			
			//echo "\$evn_id_new= $evn_id_new"; echo "<hr>";
			
			
			
			
			
			
			// ============= INSERT =============//
			
			foreach( $arrTable as $tKey => $tName ){
				//echo "\$tName= $tName"; echo "<hr>";
				
				if( ereg("ev_location" , $tName) ){
					$sql = "SELECT * FROM $tName WHERE evn_id = $evn_id ";
					$sql .= "AND eloc_event_date  = '$event_date' ";
				}else{
					$sql = "SELECT * FROM $tName WHERE evn_id = '$evn_id' " ;
				}
				$num_row = getNumRow($sql);
				$result = getData($sql);
				
				while( $row = mysql_fetch_array($result) ){
					//echo "\$num_row= $num_row";
					
					$value = array();
					$field_name = get_table_fieldname($tName);
					foreach( $field_name as $fKey => $fVal ){
						
						switch($fVal){
							case "evn_id" :
								$row[$fVal] = $evn_id_new ;
								break;
								
							/*case "edbk_in_date" :
								if( $row["edbk_item"] == 0 ){
									$row[$fVal] = $row[$fVal] ;
								}else{
									$row[$fVal] = $valdate_in ;
								}
								break;*/
								
							case "edbk_ev_begdate" :
								$row[$fVal] = $event_date ;
								break;
								
							case "edbk_ev_enddate" :
								$row[$fVal] = $end_date ;
								break;
								
							/*case "edbk_out_date" :
								if( $row["edbk_item"] == 0 ){
									$row[$fVal] = $valdate_out ;
								}
								break;*/
								
							case "eloc_event_date" :
								$row[$fVal] = $event_date ;
								break;
								
							case "eloc_end_date" :
								$row[$fVal] = $end_date ;
								break;
								
							case "bks_id" :
								$row[$fVal] = $bk_status ;
								break;
								
							case "usr_cre" :
								$row[$fVal] = $usr_cre ;
								break;
								
							case "date_cre" :
								$row[$fVal] = $date_cre ;
								break;
						
						}// switch($fVal){
						if( $row["edbk_item"] == 0 ){
							$row["edbk_out_date"] = $valdate_out ;
						}
						$value[$fVal] = $row[$fVal];
						
					}// foreach( $field_name as $fKey => $fVal ){
					$query = create_insert_query($tName , $value);
					
					if( $tName == "ev_dateblock"){
						echo "\$query_$tName= $query"; echo "<hr>";
					}
					//mysql_query($query) or die("Insert table $tName error");
				
					$num_row--;
				}
				
			}// foreach( $arrTable as $tKey => $tName ){
			
		} // for($i=0; $i<sizeof($lst_value); $i++){
	
 	} // if(!empty($Submit)){



?>

</body>
</html>
