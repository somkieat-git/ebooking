<?	
	ob_start();
	session_start();
	include("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	define("updSave","dbk_updForm.php");
	$action = $_REQUEST["a"];
	$evn_id = $_REQUEST["id"];
	$edbk_item =  $_REQUEST["id2"];	
	$a_rebook = $_REQUEST["a_r"];
	$Submit = $_REQUEST["Submit"];
	//echo "action=$action<br>evn_id= $evn_id<br>edbk_item= $edbk_item<br>submit = $Submit<hr>";
	
	//======================Begin prepare standard data======================================
		
	if(!empty($evn_id)){
		$sql = "SELECT * FROM eventname WHERE evn_id = '$evn_id'  ";
		$result = getData($sql);
		$row = mysql_fetch_array($result);
		$disabled = "";
		//if($row[3] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;
		if($row["evn_used"] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;
		//$evn_name = $row[1];
		$evn_name = $row["evn_shortname"];
	} //if(!empty($ev_id)){	
	
	//======================End prepare stand data======================

	//======================Begin select data from ev_dateblock===========

	if($action != "a" && $action != "e") {
		#Show ev_dateblock
		$sql = "SELECT *
					FROM ev_dateblock 
					WHERE  evn_id = '$evn_id'
					AND edbk_item  = $edbk_item 
					";
		//echo "$sql<br>";
		$result = getData($sql);
		$rs_edbk = mysql_fetch_array($result);				
		$show_in_date =  chgDate($rs_edbk["edbk_in_date"]);
		$show_in_time =  chgTime($rs_edbk["edbk_in_time"]);
		$show_ev_date =  chgDate($rs_edbk["edbk_ev_begdate"]);
		$show_beg_time =  chgTime($rs_edbk["edbk_ev_begtime"]);
		$show_last_date =  chgDate($rs_edbk["edbk_ev_enddate"]);
		$show_end_time =  chgTime($rs_edbk["edbk_ev_endtime"]);
		$show_out_date =  chgDate($rs_edbk["edbk_out_date"]);
		$show_out_time =  chgTime($rs_edbk["edbk_out_time"]);							
		$loc_id = $rs_edbk["loc_id"];
	}
	
	if( $a_rebook == "e" && $action == "a" ){
		
			$sql = "SELECT MAX(edbk_item) as id FROM ev_dateblock WHERE evn_id = '$evn_id' ";
			$result = getData($sql);
			$rs_id = mysql_fetch_array($result);
			
			if( $edbk_item == "" ){
				//$edbk_item = $rs_id[0]+1;
				$edbk_item = $rs_id["id"]+1;
			}else{
				$edbk_item +=1 ;
			}
	}
	
	
	
	
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<script>var winMain=window.opener;</script>
<script language="javascript">
	function validate() 
	{
		if(frm.txt_in_date.value=="")
		{
			alert('Please input data in In Date');
			frm.txt_in_date.focus();
			return false;
		}
		
		if(frm.txt_in_time.value=="")
		{
			alert('Please input data in In Time');
			frm.txt_in_time.focus();
			return false;
		}
		
		if(frm.txt_ev_date.value=="")
		{
			alert('Please input data in Event Date');
			frm.txt_ev_date.focus();
			return false;
		}
		if(frm.txt_beg_time.value=="")
		{
			alert('Please input data in Begin Time');
			frm.txt_beg_time.focus();
			return false;
		}
		if(frm.txt_last_date.value=="")
		{
			alert('Please input data in Last Date');
			frm.txt_last_date.focus();
			return false;
		}
		if(frm.txt_end_time.value=="")
		{
			alert('Please input data in End Time');
			frm.txt_end_time.focus();
			return false;
		}
		if(frm.txt_out_date.value=="")
		{
			alert('Please input data in Out Date');
			frm.txt_out_date.focus();
			return false;
		}
		if(frm.txt_out_time.value=="")
		{
			alert('Please input data in Out Time');
			frm.txt_out_time.focus();
			return false;
		}
	}
	
	function setEventDate( in_date,in_time,ev_date,beg_time,last_date,end_time,out_date,out_time,loc_id ){
	
		var hdd_eItem = document.getElementById("hdd_eItem").value ;
		var hdd_action = document.getElementById("hdd_action").value ;
		var ev_id = document.getElementById("hdd_event_id").value ;
		//alert(ev_id);
		var value_all = in_date + "|" + in_time + "|" + 
						ev_date + "|" + beg_time + "|" + 
						last_date + "|" + end_time + "|" + 
						out_date + "|" + out_time + "|" + loc_id;
		opener.setLabelValue(value_all , hdd_eItem , hdd_action , ev_id);
		window.close();
		
	}
	
</script>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">
<script language="javascript" type="text/javascript" src="datetimepicker.js"></script>

<!--------------  jQuery Datepick (Popup Calendra)  ---------------------->
	
	<link href="./css/jquery.datepick.css" type="text/css" rel="stylesheet" />
	<script type="text/javascript" src="lib/jquery.min.js"></script>	
	<script type="text/javascript" src="js/jquery.datepick.js"></script>
	<script type="text/javascript">
	$(function() {
		jQuery('#txt_in_date').datepick({showOnFocus: false , yearRange: 'c-10:c+10' , showTrigger: '#calImg'});
		jQuery('#txt_ev_date').datepick({showOnFocus: false , yearRange: 'c-10:c+10' , showTrigger: '#calImg'});
		jQuery('#txt_last_date').datepick({showOnFocus: false , yearRange: 'c-10:c+10' , showTrigger: '#calImg'});
		jQuery('#txt_out_date').datepick({showOnFocus: false , yearRange: 'c-10:c+10' , showTrigger: '#calImg'});
	});
	
	
	</script>
</head>
	
<body >
<form action="<?=updSave?>?a=<?=$action ?>&id=<?=$evn_id?>&id2=<?=$edbk_item?>" method="post" name="frm"  id="frm" onSubmit="return validate();" >
  <table border="0" class="BorderGreen" >
    <tr class="BorderSilver">
      <td colspan="4"  style="background-color:#339900;font-weight:bold;color:White;">
	  	<div align="center">
			<strong >Event Date  - 
				<?php 
					if( $a_rebook != "e" ){
						echo $evn_id." - " .$evn_name ;
					}else{
						echo $evn_name ;
					}
				?>
			</strong>
		</div>
	  </td>
    </tr>
	<tr>
	  <td height="16" colspan="4" ><input name="hd_evn_id" type="hidden" id="hd_evn_id" value="<?=$evn_id ;?>">
      <input name="loc_id" type="hidden" id="loc_id" value="<?=$loc_id ;?>"></td>
    </tr>
	<tr>
	  <td width="79" height="18" ><div align="right">In Date : </div></td>
      <td width="144" >	  
	  <input name="txt_in_date" type="text" id="txt_in_date" value="<?=$show_in_date ;?>" size="10" maxlength="10">
	  <div style="display: none;"> 
		<img id="calImg" src="images/calendar.gif" alt="Pick a date" class="trigger"> 
	  </div>
	  </td>
      <td width="81" ><div align="right">In Time : </div></td>
      <td width="170" ><input name="txt_in_time" type="text" id="txt_in_time" 
	  value="<? if ($show_in_time) echo $show_in_time ; else echo "08:00" ?>" ></td>
	</tr>
	<tr>
	  <td height="18" ><div align="right">Event Date : </div></td>
	  <td ><input name="txt_ev_date" type="text" id="txt_ev_date" value="<?=$show_ev_date ;?>" size="10" maxlength="10">
	  
	  </td>
	  <td ><div align="right">Begin Time : </div></td>
	  <td ><input name="txt_beg_time" type="text" id="txt_beg_time" value="<? if ($show_beg_time) echo $show_beg_time ; else echo "08:00" ?>"></td>
    </tr>
	<tr>
	  <td height="18" ><div align="right">Last Date : </div></td>
	  <td ><input name="txt_last_date" type="text" id="txt_last_date" value="<?=$show_last_date ;?>" size="10" maxlength="10">
	  <div style="display: none;"> 
		<img id="calImg" src="images/calendar.gif" alt="Pick a date" class="trigger"> 
	  </div>
	  </td>
	  <td ><div align="right">End Time : </div></td>
	  <td ><input name="txt_end_time" type="text" id="txt_end_time" value="<? if ($show_end_time) echo $show_end_time ; else echo "18:00" ?>"></td>
    </tr>
	<tr>
	  <td height="18" ><div align="right">Out Date : </div></td>
	  <td ><input name="txt_out_date" type="text" id="txt_out_date" value="<?=$show_out_date ;?>" size="10" maxlength="10">
	  <div style="display: none;"> 
		<img id="calImg" src="images/calendar.gif" alt="Pick a date" class="trigger"> 
	  </div>
	  </td>
	  <td ><div align="right">Out Time : </div></td>
	  <td ><input name="txt_out_time" type="text" id="txt_out_time" value="<? if ($show_out_time) echo $show_out_time ; else echo "18:00" ?>"></td>
    </tr>
	<tr>
	  <td height="18" colspan="4" >&nbsp;</td>
    </tr>
	<tr>
	  <td height="18" colspan="4" ><div align="center">
	  <?php if( $a_rebook == "e" ) :?>
	  
	  	<input type="hidden" name="hdd_eItem" id="hdd_eItem" value="<?php echo $edbk_item ; ?>" />
		<input type="hidden" name="hdd_action" id="hdd_action" value="<?php echo $action ; ?>" />
		<input type="hidden" name="hdd_event_id" id="hdd_event_id" value="<?php echo $evn_id ; ?>" />
	  	
		<input name="btn" type="button" class="Button" value="   OK   "  
		onClick="javascript:setEventDate( frm.txt_in_date.value , frm.txt_in_time.value 
		, frm.txt_ev_date.value , frm.txt_beg_time.value , frm.txt_last_date.value 
		, frm.txt_end_time.value , frm.txt_out_date.value , frm.txt_out_time.value , frm.loc_id.value );" />
		
	  <?php else :?>
	  
        <input name="Submit" type="submit" class="Button" value="   OK   "   <?=$disabled ;?>
		onClick="return validate();" >
        <input name="btnDel" type="button" class="Button" id="btnDel"   value="Delete" <? if ($action=='a') echo "disabled" ;else echo $disabled ;?> 
		onClick= "window.location = 'dbk_updForm.php?a=d&id=<?=$evn_id?>&id2=<?=$edbk_item?>' " >
        <input name="btnCancel" type="button" class="Button" id="btnCancel"  onClick="history.go(-1)" value="Cancel" >
     
	  <?php endif; ?></div>
	  </td>
    </tr>		
  </table>
</form>
<?

	//======================Begin Save Data==============================================
	//request data into varible
	if(!empty($Submit)){			
		$evn_id =  $_REQUEST["hd_evn_id"];
		$edbk_in_date =  chgDateToDb($_REQUEST["txt_in_date"]);
		$edbk_in_time =  chgTimeToDb($_REQUEST["txt_in_time"]);
		$edbk_ev_date =  chgDateToDb($_REQUEST["txt_ev_date"]);
		$edbk_beg_time =  chgTimeToDb($_REQUEST["txt_beg_time"]);
		$edbk_last_date =  chgDateToDb($_REQUEST["txt_last_date"]);
		$edbk_end_time =  chgTimeToDb($_REQUEST["txt_end_time"]);
		$edbk_out_date =  chgDateToDb($_REQUEST["txt_out_date"]);
		$edbk_out_time =  chgTimeToDb($_REQUEST["txt_out_time"]);
		$loc_id = $_REQUEST["loc_id"];
		/*
		echo "
		evn_id =  $evn_id<br>
		edbk_in_date =   $edbk_in_date<br>
		edbk_in_time =   $edbk_in_time<br>
		edbk_ev_date =   $edbk_ev_date<br>
		edbk_beg_time =   $edbk_beg_time<br>
		edbk_last_date =   $edbk_last_date<br>
		edbk_end_time =   $edbk_end_time<br>
		edbk_out_date =   $edbk_out_date<br>
		edbk_out_time =   $edbk_out_time<br>
		loc_id =   $loc_id<br>
		";
		*/
		
		function  checklist($value,$label,$field){
			global $resData;
			$resData[$field] = $value;
		}		
		
		checklist($edbk_in_date,"","edbk_in_date");
		checklist($edbk_in_time,"","edbk_in_time");
		checklist($edbk_ev_date,"","edbk_ev_begdate");
		checklist($edbk_beg_time,"","edbk_ev_begtime");
		checklist($edbk_last_date,"","edbk_ev_enddate");
		checklist($edbk_end_time,"","edbk_ev_endtime");
		checklist($edbk_out_date,"","edbk_out_date");
		checklist($edbk_out_time,"","edbk_out_time");		
		$usr_name =  $_SESSION["usr_name"];
		$day_name = date("Y/m/d  H:i:s");		

			if($action=="a"){				
				$sql = "SELECT MAX(edbk_item) as id FROM ev_dateblock WHERE evn_id = '$evn_id' ";
				$result = getData($sql);
				$rs_id = mysql_fetch_array($result);
				$edbk_item = $rs_id[0]+1;
				
				$resData["evn_id"] = $evn_id;
				$resData["edbk_item"] = $edbk_item;
				$resData["usr_cre"] = $usr_name;
				$resData["date_cre"] = $day_name;
				
				$query = create_insert_query("ev_dateblock",$resData);	
				//echo "$query<br>";
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");
				mysql_query($query) or die("Insert error");	
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");					
				//Show alert by javascript
				echo "<script>
						alert ('Insert complete');
						window.location = 'edbk_viewForm.php?id=$evn_id&id2=$edbk_item' ;
					  </script>";
				//exit();
			} //if($action=="a"){				
			
			if($action=="u"){				
				$resData["loc_id"] = $loc_id;
				$resData["usr_upd"] = $usr_name;
				$resData["date_upd"] = $day_name;
				
				$query = create_update_evquery("ev_dateblock", $resData, $evn_id, "evn_id",$edbk_item,"edbk_item");				
				//echo "$query<br>";
				//exit();			
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");	
				mysql_query($query) or die("Update ev_dateblock error");		
				
				//echo "\$edbk_item = $edbk_item<br>";
				if($edbk_item == 0){
					$esta_show_day = ($edbk_last_date - $edbk_ev_date) +1 ;
					$esta_inout_day = ($edbk_ev_date - $edbk_in_date) + ($edbk_out_date - $edbk_last_date) ;
					$sql = "
						UPDATE ev_statistics SET esta_show_day = $esta_show_day ,
						esta_inout_day = $esta_inout_day,
						usr_upd = '$usr_name', date_upd = '$day_name'
						WHERE evn_id = '$evn_id'
					";
					//echo "$sql<br>";
					//exit();
					mysql_query($sql) or die("Update ev_statistics error");
				}
				$SaveLog=updLog($_SESSION['username'], updSave, "$query");
				//Show alert by javascript
				echo "<script>
						window.location = 'edbk_updForm.php?id=$evn_id&id2=$edbk_item&hd_loc_id=$loc_id' ;
					  </script>";
				exit();
			} //if($action=="u"){
	} //if(!empty($Submit) && $action != "d"){			
			
			if($action=="d"){			
				#delete value in ev_dateblock			
				if($edbk_item != 0){
					$sql = "DELETE  FROM ev_dateblock  
								WHERE evn_id = '$evn_id' 
								AND edbk_item = '$edbk_item' ";
					//echo "$sql<br>";
					mysql_query($sql) or die("Delete error");		
					$SaveLog=updLog($_SESSION['username'], updSave, "$sql");		
					#delete value in ev_location			
					if($loc_id){
						$sql = "DELETE  FROM ev_location WHERE evn_id = '$evn_id' 
									AND loc_id in ($loc_id)";
						//echo "$sql<hr>";
						mysql_query($sql) or die("Delete error");
						$SaveLog=updLog($_SESSION['username'], updSave, "$sql");
					}
						
						//Show alert by javascript
						echo "<script>
								alert ('Delete complete');
								window.location = 'edbk_viewForm.php?id=$evn_id' ;
							  </script>";
						exit();				
				} //if($edbk_item != 0){
				else {
						echo "<script>
								alert ('Don\'t Delete # 0 ! ');
								window.location = 'edbk_viewForm.php?id=$evn_id' ;
							  </script>";
						exit();				
				}
				
			} //if($action=="d"){			
	
	//======================End Save Data==============================================
include("db/disconnect.db.php");	
?>
