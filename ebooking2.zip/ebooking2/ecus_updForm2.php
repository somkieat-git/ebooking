<?	
	ob_start();
	session_start();
	include("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	define("updSave","ecus_updForm.php");
	$evn_id = $_REQUEST["id"];
	$action =  $_REQUEST["a"];
	$ecus_item = $_REQUEST["id2"];
	
	
	
	//======= Begin prepare stand data ===========//
		
	if(!empty($evn_id)){
		$sql = "SELECT * FROM eventname WHERE evn_id = '$evn_id'  ";
		//echo "$sql<hr>";
		$rs_ev = getData($sql);
		$row = mysql_fetch_array($rs_ev);
		$disabled = "";
		if($row["evn_used"] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;
		$evn_name = $row["evn_shortname"];
	} //if(!empty($ev_id)){		
	
	$sql = "SELECT * FROM miscode WHERE  mis_type ='client' ";
	//echo "$sql<hr>";
	$rs_miscode = getData($sql);	
	$arr_miscode= array();
	while( $row = mysql_fetch_array($rs_miscode)){
		$arr_miscode[] = $row["mis_name"];
		//echo "rs_miscode  => ".$row["mis_name"]."<br> ";
	} //while( $row = mysql_fetch_array($resmiscode)){
	
	$sql = "SELECT  nif.nif_id, nif.nif_firstname, nif.nif_lastname , nif.nif_title ";
	$sql .= "FROM nameinfo nif ";
	$sql .= "WHERE nif.nif_type = 'client' ";
				
	//echo "$sql<hr>"; exit();
	$rs_customer = getData($sql);		
	$arr_customer = array();
	while( $row = mysql_fetch_array($rs_customer)){
	//while( $row = mysql_fetch_assoc($rs_customer)){	
		 $arr_customer["$row[nif_id]"]  = $row["nif_title"] . "  " . $row["nif_firstname"] . "  " . $row["nif_lastname"] ;
	
	} //while( $row = mysql_fetch_array($resmiscode)){
	
	//echo "<pre>"; print_r($arr_customer); exit();
	
	
	
	//======= Begin select data from ev_customer ======//
	//Column Left//
	if (!empty($evn_id)){
		$sql = "SELECT * FROM ev_customer WHERE evn_id = '$evn_id'  ";
		//echo "$sql<hr>"; exit();
		$rs_ecus = getData($sql);
		$arr_ecus = array();
		$arr_linkCus=array();
		$numrow = mysql_num_rows($rs_ecus);
		//print_r($arr_ecus);
		while( $row = mysql_fetch_array($rs_ecus)){
			 $arr_ecus[]  =  $row["cus_id"].",".$row["ecus_item"] . "," . $row["link_cus"] ;
			 $arr_linkCus[$row["ecus_item"]]=array("cus_id" => $row["cus_id"] , 
			 										"link_cus" => $row["link_cus"]) ;
			 //echo " rs_ecus = $row[cus_id] => $row[ecus_item]<br> ";
			 //echo "<pre>"; print_r($arr_linkCus); 
		} //while( $row = mysql_fetch_array($rs_ecus)){
		
	} //if (!empty($evn_id)){
	
	
	//echo "<pre>";print_r($arr_linkCus);
?>
<html>
<script language="javascript">
	function validate() 
	{
	
		if(frm.ecus0.value == 1 )
		{
			alert('Please input data in Main Contact');
			frm.ecus0.focus()
			return false;
		}
		if(frm.ecus1.value == 1 )
		{
			alert('Please input data in Lease Contact');
			frm.ecus1.focus()
			return false;
		}
		if(frm.ecus2.value == 1)
		{
			//Í¿.Ø»Ã³.value
			alert('Please input data in Invoice/Bill to Contact');
			frm.ecus2.focus()
			return false;
		}
	}
	
	
	function openList(obj){
		//url="ecus_proviewfrm.php?t=12&fname=" + obj;
		var url="flexigrid/cus_vfrm2.php?t=12&f=" + obj;
		//alert(url);
			
		open(url,"openList","width=800,height=500,status=no,menubar=no,resizable=no,scrollbars=yes,top=50,left=100");
		
	}
	
	function setCustomer( pro_id , pro_name , obj , link_cus ){
		
		//alert(pro_id + "  " + pro_name + "  " + obj + "  " + link_cus);
		var string = pro_name ;
		var name = string.replace(":","  ");
		
		document.getElementById('ecus'+obj).value = pro_id ;
		document.getElementById(obj).value = name ;
		document.getElementById('link_cus'+obj).value = link_cus ;
		//Dialog.closeInfo();
		
		window.close();
	}
	
</script>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">

<!--  Dialog -->
<script type="text/javascript" src="./js/windows_js_1.3/javascripts/prototype.js"> </script> 
<script type="text/javascript" src="./js/windows_js_1.3/javascripts/window.js"> </script>

<link href="./js/windows_js_1.3/themes/alphacube.css" rel="stylesheet" type="text/css" />
<link href="./js/windows_js_1.3/themes/default.css" rel="stylesheet" type="text/css" />
<!-- End Dialog -->


</head>
	
<body>
<form action="<?=$updSave ?>?id=<?=$evn_id?>" method="post" name="frm"  id="frm" onSubmit="return validate();">
  <table border="0" class="BorderGreen">
    <tr class="BorderSilver">
      <td colspan="4" style="background-color:#339900;font-weight:bold;color:White;">
	  	<div align="center"><strong >Client - <?=$evn_id." - " .$evn_name ?></strong></div>
	  </td>
    </tr>
	<tr>
	  <td height="27" colspan="4">
        <div align="center"><a href="cus_updForm2.php?a=a">Add Client</a>              
		<input name="evn_id" type="hidden" id="evn_id" value="<?=$evn_id ?>">
          </div></td></tr>
        <tr>
		<?
		//$num = 0 ;
		
		//print_r($arr_miscode);
			foreach($arr_miscode as $miskey=>$misval){
				//echo "\$miskey=$miskey, \$misval=$misval<br>";
				echo "<tr><td ><div align='right'>$misval :</div></td>"; 	
	    ?>
						  
		  <td colspan="2">		
		  <?php
		  //print_r($arr_customer);
		  //print_r($arr_ecus);
		 // $db1 = "thebook_gjc";
//		  $db2 = "customer";
			  
		  
		  //echo "<pre>";print_r($arr_linkCus); 
		  $cus_id = $arr_linkCus[$misval]["cus_id"];
		  $link_cus = $arr_linkCus[$misval]["link_cus"];
		  
		  
		  
			  if($link_cus == "N"){		
			  	$sql2 = "SELECT nif_id as id , nif_firstname as fname , ";
				$sql2 .= "nif_lastname as lname , nif_title as title ";
				$sql2 .= "FROM nameinfo ";
				$sql2 .= "WHERE nif_type = 'client' ";
				$sql2 .= "AND nif_id = $cus_id ";
				
			  }else if($link_cus == "Y"){
			 	$sql2 = "SELECT pro_id as id , 
								pro_efname as fname , 
								pro_elname as lname , 
								pro_etitle as title
						FROM profile ";
				$sql2 .= "WHERE pro_id = $cus_id " ;
			  
			  }else{
			  	$sql2 = "" ;
			  }
			  
			  
			  
			  if( isset($sql2) && $sql2 != "" ){
				 $rs = getData($sql2);
				  //echo "<pre>"; print_r($rs); exit();
				  while( $row = mysql_fetch_array($rs)){
					$key = $row["id"];	
					
					if(isset($row["title"]) && $row["title"] != "-"){
						$title = $row["title"];
					}else{
						$title = "";
					}
					
					$name = $title . $row["fname"] . "  " . $row["lname"] ;
				  }
			  }else{
			  	$name = "";
			  }
			
			
		  ?>
		  
		   <input type="text" name="<?php echo $miskey; ?>" id="<?php echo $miskey; ?>" size="40" value="<?=$name;?>" disabled="disabled" />
		   <input type="hidden" name="ecus<?=$miskey?>" id="ecus<?=$miskey?>" value="<?php echo $key ;?>" />
		   <input type="hidden" name="link_cus<?=$miskey?>" id="link_cus<?=$miskey?>" size="3" value="<?=$link_cus;?>" />
		   <input type="button" value="..." onClick="javascript:openList('<?php echo $miskey; ?>');" />
            <? if(!$disabled): ?>
		    <a href="ecus_updForm.php?a=d&id=<?=$evn_id ?>&id2=<?=$misval ?>"  
			onClick = "return confirm(' ต้องการลบ <?=$misval ?> ออกจากระบบหรือไม่ ? ') " >
			<img src="images/b_drop.png" width="16" height="16" border="0"></a>
			<?	endif; ?>
		  </td>
    	</tr>
		<?
		//$num++ ;
			
			} //foreach($arr_miscode as $key=>$val){ 
			
		?>
	
		<tr>
		  <td height="20" ><div align="right"></div></td>
		  <td colspan="2" ><div align="left"></div></td>
    </tr>
    <tr align="center" >
      <td colspan="3">	  	
	  	<div align="center">
			<input name="Submit2" type="button" class="Button" value="&lt;= Back " onClick="window.location = 'edbk_viewForm.php?id=<?=$evn_id?>'" >
			<input name="Submit" type="submit" class="Button" value="   OK   "  <?=$disabled?> >
			<input name="Button" type="button" class="Button" id="Button"  onClick="history.go(-1)" value="Cancel" >
			<input name="Submit22" type="button" class="Button" value="Next =&gt;" onClick="window.location = 'estf_updForm.php?id=<?=$evn_id?>'" >		  
        </div></td>
    </tr>
  </table>
</form>

<?
	//======================Begin Save Data==============================================
	//request data into varible
	$Submit = $_REQUEST["Submit"];
	if(!empty($Submit)){
		$ecus0 = $_REQUEST["ecus0"];
		$ecus1 = $_REQUEST["ecus1"];
		$ecus2 = $_REQUEST["ecus2"];
		$ecus3 = $_REQUEST["ecus3"];
		$ecus4 = $_REQUEST["ecus4"];
		$ecus5 = $_REQUEST["ecus5"];
		
		$link_cus0 = $_REQUEST["link_cus0"];
		$link_cus1 = $_REQUEST["link_cus1"];
		$link_cus2 = $_REQUEST["link_cus2"];
		$link_cus3 = $_REQUEST["link_cus3"];
		$link_cus4 = $_REQUEST["link_cus4"];
		$link_cus5 = $_REQUEST["link_cus5"];
		
		
		/* echo "
		submit = $Submit<br>
		evn_id =  $evn_id<br>
		ecus0 = $ecus0<br> 
		ecus1 = $ecus1<br>
		ecus2 = $ecus2 <br> 
		ecus3 = $ecus3<br>
		ecus4 = $ecus4 <br>
		ecus5 = $ecus5<br>
		";
		
		echo "
		submit = $Submit<br>
		link_cus0 = $link_cus0 ;
		link_cus1 = $link_cus1 ;
		link_cus2 = $link_cus2 ;
		link_cus3 = $link_cus3 ;
		link_cus4 = $link_cus4 ;
		link_cus5 = $link_cus5 ;
		";
		
		*/
		
		//check duplicate data in table ev_customer
		function  checklist($value,$link_cus,$label,$field,$evn_id){
			global $resNull; global $resData; global $flag; global $strPattern; global $query; 
			global $arrquery ;
			$strPattern = "Main Contact|Lease Contact|Invoice/Bill to Contact| ";
			if($value ==1){
				if(ereg($strPattern,$label)){
					$flag = 1;
					$resNull[] = $label;
				} //if(ereg($strPattern,$label)){			
			} //if($value==1){
			else{
				$usr =  $_SESSION["usr_name"];
				$d = date("Y/m/d  H:i:s");
				$sql = "SELECT * FROM ev_customer 
							 WHERE evn_id = '$evn_id'
							 AND $field = '$label' ";
				//echo "$sql<hr>";
				$result = getData($sql);
				$numrow = mysql_num_rows($result);
				$row = mysql_fetch_array($result);
				//echo "numrow = $numrow<br>";
				if ($numrow == 0 ){
						$query = " INSERT INTO ev_customer (evn_id, ecus_item, cus_id, link_cus , usr_cre, date_cre )";
						$query .= "	VALUES( '$evn_id', '$label', $value , '$link_cus' ,'$usr','$d' );";
						//echo "$query<hr>";			
						$arrquery[] = $query;
				}
				else{
						$query = " UPDATE ev_customer SET";
						$query .= "	cus_id = $value,";
						$query .= "	link_cus = '$link_cus',";
						$query .= "	usr_upd = '$usr',";
						$query .= "	date_upd = '$d'";
						$query .= "	WHERE evn_id = 	'$evn_id'";
						$query .= "	AND ecus_item = '$label';";
						//echo "$query<hr>";					
						$arrquery[] = $query;
				} //else{ if ($numrow == 0 ){
			} //else{ if($value==1){	
		} //function checklist($var,$name){
		
		//checklist($evn_id,"","evn_id");
		checklist($ecus0,$link_cus0,"Main Contact","ecus_item",$evn_id);
		checklist($ecus1,$link_cus1,"Lease Contact","ecus_item",$evn_id);
		checklist($ecus2,$link_cus2,"Invoice/Bill to Contact","ecus_item",$evn_id);
		checklist($ecus3,$link_cus3,"Alternate Contact","ecus_item",$evn_id);
		checklist($ecus4,$link_cus4,"Decorator","ecus_item",$evn_id);
		checklist($ecus5,$link_cus5,"Referrals","ecus_item",$evn_id);
		foreach($arrquery as $key=>$val) {
			mysql_query($val) or die("query error");	
			$SaveLog=updLog($_SESSION['username'], updSave, "$val");					
		}
		
		//Show alert by javascript				
		echo "<script>
				alert ('Update complete');
				window.location = 'ecus_updForm.php?id=$evn_id';
			  </script>";
		exit();
	} //if(!empty($Submit)){
	if($action == 'd'){
		$sql = "DELETE FROM ev_customer";
		$sql .=" WHERE evn_id = '$evn_id'";
		$sql .=" AND ecus_item = '$ecus_item'";
		//echo "$sql<br>"; exit();
		mysql_query($sql) or die("Delete error");	
		$SaveLog=updLog($_SESSION['username'], updSave, "$sql");					
		//exit();
		//Show alert by javascript				
		echo "<script>
				alert ('Delete complete');
				window.location = 'ecus_updForm.php?id=$evn_id';
			  </script>";
		exit();		
	} // if($action == 'd'){
	
	//======================End Save Data==============================================
include("db/disconnect.db.php");
?>