<?php
	ob_start();
	session_start();
	include_once("db/chksession.db.php");
	include_once("db/connect.db.php");
    include_once("func/sql.func.php");
    

    $txtEvn_date = $_REQUEST["txtEvn_date"];
    list($Evn_date, $locID, $PerDayID) = explode('-',$txtEvn_date);
    // $locID = substr($txtEvn_date, 8, strlen($txtEvn_date)-8);
    $evnYYYY = substr($Evn_date, 0, 4);
    $evnMM = substr($Evn_date, 4, 2);
    $evnDD = substr($Evn_date, 6, 2);
    //echo "Date=$evnDD.$evnMM.$evnYYYY<br>";
    $txtEvn_date = chgDateToSh("$evnYYYY-$evnMM-$evnDD");
    $txtFullname = $_REQUEST["txtFullname"];
    $txtShortname = $_REQUEST["txtShortname"];
//     //$txtThainame = $_REQUEST["txtThainame"];
    
    // echo "
    //     locID = $locID<br>
    //     txtEvn_date =  $txtEvn_date<br>
    //     txtFullname = $txtFullname<br> 
    //     txtShortname = $txtShortname<br>
    // ";		
    

    // //check duplicate data in table ev_statistics
    // $sql = "SELECT * FROM eventname   
    // WHERE evn_shortname = '$txtShortname' ";
    // //echo "$sql<hr>";
    // $result = getData($sql);
    // $numrow = mysql_num_rows($result);
    // //$row = mysql_fetch_array($result);
    // //echo "numrow = $numrow<br>";			

    // if ($numrow == 0 )
    //     $action = "add";
    // else{			
    //     echo "<script>
    //         alert ('Short Event Name is duplicate');
            
    //         </script>";			
    // }		
    // // history.go(-1);
    // echo "action=$action<br>";

    $action = "add";
    if($action=="add"){
        $valdate = chgDateToDb($txtEvn_date);				
        $valbegtime = "0800";
        $valendtime = "1800";
        list($dd, $mm, $yyyy) = explode('/',$txtEvn_date);
        if(strlen($mm) < 2) $mm = '0' . $mm;
        $yymm = substr($yyyy,2,2).$mm;

        $sql = "SELECT MAX(evn_id) as id FROM eventname
                WHERE evn_id like '$yymm%' ";
        //echo "\$sql=$sql<br>";
        //exit();

        $result = getData($sql);
        $row = mysql_fetch_array($result);

        //echo $row[0]; echo "<hr>";
        //echo "\$yymm=$yymm<br>";

        if(is_null($row["id"]))
            $evn_id =  "$yymm"."0001";
        else{
            //$evn_id = ($row[0]+1);
            $running = "99".substr($row["id"], 4)+1;
            $evn_id = "$yymm".substr($running, 2);
            // echo "EvenID=$evn_id<br>"; 
        }

        //echo "\$evn_id=$evn_id<br>"; exit();

        $usr_cre = $_SESSION["usr_name"];
        $date_cre = date("Y/m/d  H:i:s");		
        $val_date_cre = date("d/m/Y");						

        $query = "INSERT INTO eventname values(
            '$evn_id','$txtShortname','$txtFullname','$txtThainame','Y','$usr_cre','$date_cre','',''
        ) ";
        //echo "$query<br>";
        mysql_query($query) or die("Insert table eventname error");						

        #DateBlock-0#
        $query = "INSERT INTO ev_dateblock (evn_id, edbk_item,edbk_in_date, edbk_in_time, edbk_ev_begdate, edbk_ev_begtime, 
                    edbk_ev_enddate, edbk_ev_endtime, edbk_out_date, edbk_out_time, usr_cre, date_cre)
                    VALUES('$evn_id', 0,'$valdate','$valbegtime', '$valdate','$valbegtime',
                    '$valdate','$valendtime','$valdate','$valendtime','$usr_cre','$date_cre')
                    ";
        //echo "$query<br>";
        mysql_query($query) or die("Insert table ev_dateblock error");	

        #DateBlock-1#
        $query = "INSERT INTO ev_dateblock (evn_id, edbk_item,edbk_in_date, edbk_in_time, edbk_ev_begdate, edbk_ev_begtime, 
                    edbk_ev_enddate, edbk_ev_endtime, edbk_out_date, edbk_out_time, usr_cre, date_cre, loc_id)
                    VALUES('$evn_id', 1,'$valdate','$valbegtime', '$valdate','$valbegtime',
                    '$valdate','$valendtime','$valdate','$valendtime','$usr_cre','$date_cre', $locID)
                    ";
        //echo "$query<br>";
        mysql_query($query) or die("Insert table ev_dateblock error");	
        
        
        
        $query = "INSERT INTO ev_location (evn_id, loc_id, eloc_in_date, eloc_in_time, eloc_event_date, eloc_event_time, 
                    eloc_end_date, eloc_end_time, eloc_out_date, eloc_out_time, usr_cre, date_cre, bks_id, rtc_id, eloc_show_qty)
                    VALUES('$evn_id', $locID,'$valdate','$valbegtime', '$valdate','$valbegtime',
                    '$valdate','$valendtime','$valdate','$valendtime','$usr_cre','$date_cre',9,5,1)
                    ";
        //echo "$query<br>";
        mysql_query($query) or die("Insert table ev_location error");
        

        $query = "INSERT INTO ev_statistics (evn_id, bks_id, rtc_id, esta_atten, esta_num_session,usr_cre, date_cre)
        VALUES('$evn_id', 9,1,1,1,'$usr_cre','$date_cre')
        ";
        //echo "$query<br>";
        mysql_query($query) or die("Insert table ev_statistics error");	

        #insert default checklist to ev_checklist
        list($dd, $mm, $yy) = explode('/',$val_date_cre);
        $start_date = date("Ymd", mktime(0, 0, 0, $mm,$dd,$yy));

        $sql = "SELECT * FROM checklist  
                ORDER BY ckl_name
                ";
        //echo "$sql<br>";				
        $result = getData($sql);
        $arr_ckl = array();
        $arr_tmp = array();
        while ($rs_ckl = mysql_fetch_array($result)){
        $ckl_id = $rs_ckl["ckl_id"];
        $ckl_name = $rs_ckl["ckl_name"];
        $ckl_val = $rs_ckl["ckl_val"];
        $ckl_cnt_fr  = $rs_ckl["ckl_cnt_fr"];

        if ($ckl_cnt_fr == 0 ) {
            $follow_date = date("Ymd", mktime(0, 0, 0, $mm,$dd,$yy));
            $d = date("d", mktime(0, 0, 0, $mm,$dd,$yy));
        }
        else {
            $dd = $arr_tmp[$ckl_cnt_fr] + $ckl_val ; 
            $follow_date = date("Ymd", mktime(0, 0, 0, $mm,$dd,$yy));
            $d = date("d", mktime(0, 0, 0, $mm,$dd,$yy));
        }  

        $arr_ckl[$ckl_id] = $follow_date.",".$ckl_name; 
        $arr_tmp[$ckl_id] = $d; 

        } //while ($rs_ckl = mysql_fetch_array($result)){
        for($i=2;$i <= count($arr_ckl);$i++){
        list($eckl_follow_date, $eckl_item) = explode(',',$arr_ckl[$i]);
        $query = "INSERT INTO ev_checklist (eckl_id, evn_id, eckl_follow_date, eckl_item, eckl_fperson, 
                        eckl_complete_date, eckl_cperson, usr_cre, date_cre, usr_upd, date_upd )
                        VALUES('','$evn_id','$eckl_follow_date','$eckl_item','$usr_cre',
                        '','','$usr_cre','$date_cre','',''  
                        )
        ";
        //echo "$query<br>";
        mysql_query($query) or die("Insert table ev_checklist error");										
        } //for($i=2;$i <= count($arr_ckl);$i++){      
        echo "$evn_id";
        
    }


?>