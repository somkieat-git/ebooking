<?
	ob_start(); 
	session_start();	
	include("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	$evn_id = $_REQUEST["id"];
	//$usr_id = $_SESSION["usr_id"];
	$usr_id = $_SESSION["UsrID"];
	$show = $_REQUEST["s"];	
	//print_r(array_keys($menu));
	if($show){
		list($b,$e,$r) = explode(",",$show);
	} 
	else{
		//$show = "0,0,0" ;
		$b = 0;
		$e = 1;
		$r = 0;
	}
	//echo "\$b=$b,\$e=$e,\$r=$r<br>";
?>

<html>
<head>
	<title></title>	
	<link rel="stylesheet" href="css/format.css.css" type="text/css">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
<body style="margin-left:11px;">
<table width="165px" class="BorderGreen" style="background-color: #F0F0F0;" cellspacing="0">
	<a href="left_ev_maintenance.php?s=<? echo !$b.",".$e.",".$r ;?>&id=<?=$evn_id ;?>">
	<tr style="background-color: #339900; color: White;">
		<td width="16" align="center">
		<img src="images/dot.gif" width="12" height="12" border="0"></td>
		<td style="margin: 0 0 0 0; font-weight:bold;"><div align="center">
		<a href="left_ev_maintenance.php?s=<?=!$b.",".$e.",".$r ;?>&id=<?=$evn_id ;?>">
		Booking
		</a>
		</div></td>
	</tr></a>
	<?
	if($b){
	$menub = array();
	if(empty($menub)) $menub = getMenu($_SESSION["sec_view"],"B");
	foreach($menub as $menu=>$link) {
		if ($color == "#F0F0F0")
			$color = "#FFFFFF" ;
		else
			$color = "#F0F0F0" ;	
		$ctrl_link = "fra_booking.php?id=".$link;
	?>
	<tr bgcolor="<?=$color ?>">
		<td width="16" style="padding: 3px;">&nbsp;</td>
		<td class="HeaderWhiteSmall">
			<a href="<?=$ctrl_link ?>" target="main_Frame">
			<?=$menu ?></a>
		</td>
	</tr>	
	<?
	} //foreach($menu as $menu=>$link) {
	}
	?>	
</table>

<?
 	 //$evn_id = $_REQUEST["id"];
	 if($evn_id){
?>

<table width="165px" class="BorderGreen" style="background-color: #F0F0F0;" cellspacing="0">
<a href="left_ev_maintenance.php?s=<? echo $b.",".!$e.",".$r ;?>&id=<?=$evn_id ;?>">
  <tr style="background-color: #339900; color: White;">
    <td width="16" align="center">
	<img src="images/dot.gif" width="12" height="12" border="0"></td>
    <td style="margin: 0 0 0 0; font-weight:bold;"><div align="center">
	<a href="left_ev_maintenance.php?s=<?=$b.",".!$e.",".$r ;?>&id=<?=$evn_id ;?>">
	Event Maintenance
	</a>
	</div></td>
  </tr></a>
  <?
  if($e){
	$menue = array();
	if(empty($menue)) $menue = getMenu($_SESSION["sec_view"],"E");
	foreach($menue as $menu=>$link) {
		if ($color == "#F0F0F0")
			$color = "#FFFFFF" ;
		else
			$color = "#F0F0F0" ;	
			
		$ctrl_link = $link."?id=".$evn_id;
	?>
  <tr bgcolor="<?=$color ?>">
    <td width="16" style="padding: 3px;">&nbsp;</td>
    <td class="HeaderWhiteSmall"> <a href="<?=$ctrl_link ?>" target="frame_details">
      <?=$menu ?>
    </a> </td>
  </tr>
  <?
	} //foreach($menu as $menu=>$link) {
	}
	?>
</table>

<table width="165px" class="BorderGreen" style="background-color: #F0F0F0;" cellspacing="0">
<a href="left_ev_maintenance.php?s=<? echo $b.",".$e.",".!$r ;?>&id=<?=$evn_id ;?>">
  <tr style="background-color: #339900; color: White;">
    <td width="16" align="center">
	<img src="images/dot.gif" width="12" height="12" border="0"></td>
    <td style="margin: 0 0 0 0; font-weight:bold;"><div align="center">
	<a href="left_ev_maintenance.php?s=<?=$b.",".$e.",".!$r ;?>&id=<?=$evn_id ;?>">
	Report
	</a>
	</div></td>
  </tr></a>
  <?
    if($r){
	$menur = array();
	if(empty($menur)) $menur = getMenu($_SESSION["sec_view"],"R");
	foreach($menur as $menu=>$link) {
		if ($color == "#F0F0F0")
			$color = "#FFFFFF" ;
		else
			$color = "#F0F0F0" ;	
			
		$ctrl_link = $link."?id=".$evn_id;
	?>
  <tr bgcolor="<?=$color ?>">
    <td width="16" style="padding: 3px;">&nbsp;</td>
    <td class="HeaderWhiteSmall"> <a href="<?=$ctrl_link ?>" target="_blank">
      <?=$menu ?>
    </a> </td>
  </tr>
  <?
	} //foreach($menu as $menu=>$link) {
	}
	?>
</table>

<?
 	}
?>
</body>
</html>