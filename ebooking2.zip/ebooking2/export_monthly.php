<?php
	ob_start();
	session_start();
	$arrMonthly=$_SESSION["arrData"];

	header("Content-Type: application/vnd.ms-excel");
	header('Content-Disposition: attachment; filename="monthly_report.xls"');#ชื่อไฟล์	
?>
<html xmlns:o="urn:schemas-microsoft-com:office:office"
xmlns:x="urn:schemas-microsoft-com:office:excel"
xmlns="http://www.w3.org/TR/REC-html40">
<HTML>
<HEAD>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</HEAD><BODY>

<?=print_r($arrMonthly);?>
</BODY>
</HTML>