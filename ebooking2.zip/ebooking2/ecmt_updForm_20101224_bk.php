<?	
	ob_start();
	session_start();
	include_once("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	define("updSave","ecmt_updForm.php");
	
   	$evn_id =  $_REQUEST["id"];
	$ecmt_item =  $_REQUEST["id2"];
	if ($ecmt_item == "") $ecmt_item = "0 - Event Comment";
	//echo "\$evn_id =$evn_id<br>\$ecmt_item = $ecmt_item<br>";	

	//======================Begin prepare standard data======================================
	if(!empty($evn_id)){
		$sql = "SELECT * FROM eventname WHERE evn_id = '$evn_id'  ";
		$result = getData($sql);
		$row = mysql_fetch_array($result);
		$disabled = "";
		//if($row[3] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;
		if($row["evn_used"] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;
		$evn_name = $row["evn_shortname"];
	} //if(!empty($ev_id)){	
	
		$comment = "Comment";
		$sql = "SELECT  * FROM miscode ";
		$sql.=" WHERE mis_type = '$comment'";
		$sql.=" AND mis_used not in ('N','n')";
		$sql.="	ORDER BY mis_type ASC,  mis_code ASC ";
		//echo "$sql<br>";
		//xit();
		$result = getData($sql);
		$arrcomment = array();
					
		while( $row = mysql_fetch_array($result)){
			if ($row["mis_type"] == $comment ){
				$arrcomment[] = $row["mis_code"]." - ".$row["mis_name"];
				$arrComType[] = $row["mis_name"];
			} //if ($row["mis_type"]=="$event "){
		} //while( $row = mysql_fetch_array($result)){
	//======================End prepare stand data========================================

	//======================Begin select data from ev_comment===============================
	if (!empty($evn_id)){
		if(empty($ecmt_item)){
			$ecmt_item ="$arrcomment[0]";
		} //if(empty($ecmt_item)){
		
		$sql = "SELECT * FROM ev_comment WHERE evn_id = '$evn_id' 
					AND ecmt_item like '$ecmt_item' 
					";
		//echo "$sql<br>";
		//exit();
		$result = getData($sql);
		$numrow = mysql_num_rows($result);
		$rs_ecmt= mysql_fetch_array($result);	
	} //if (!empty($evn_id)){
	
	?>
<html>
<script language="javascript">	
	function validate() 	
	{
		var chkdesc = frm.ecmt_desc.value;
		if(trimAll(chkdesc)=="" )
		{
			alert('Please input data in Description');
			frm.ecmt_desc.focus();
			return false;
		}			
	}
	
	function trimAll( strValue ) {
	 var objRegExp = /^(\s*)$/;
		//check for all spaces
		if(objRegExp.test(strValue)) {
		   strValue = strValue.replace(objRegExp, '');
		   if( strValue.length == 0)
			  return strValue;
		}
	
	   //check for leading & trailing spaces
	   objRegExp = /^(\s*)([\W\w]*)(\b\s*$)/;
	   if(objRegExp.test(strValue)) {
		   //remove leading and trailing whitespace characters
		   strValue = strValue.replace(objRegExp, '$2');
		}
	  return strValue;
	}
	
//-->
</script>


<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">

</head>
	
<body >
<form action="<?=updSave ?>?id=<?=$evn_id?>" method="post" name="frm"  id="frm"  onSubmit="return validate() ;" >
  <table border="0" class="BorderGreen">
    <tr class="BorderSilver">
      <td colspan="2" style="background-color:#339900;font-weight:bold;color:White;">
	  	<div align="center"><strong >Comment - <?=$evn_id." - " .$evn_name ?></strong></div>
	  </td>
    </tr>
	<tr>
	  <td height="16" colspan="2"><div align="center">
        </div></td>
    </tr>		
		<tr>
		  <td height="28" ><div align="center">
			
			<?
			$showButton="";
			$updSave=updSave;
			for($i=0;$i<count($arrcomment);$i++){
				$btnID="Button$i";
			?>
            <input name="<?=$btnID;?>" type="button" class="Button" id="<?=$btnID;?>"  value="<?=$arrcomment[$i] ;?>"  
			onClick="window.open('<?=updSave ;?>?id=<?=$evn_id ;?>&id2=<?=$arrcomment[$i] ;?>','frame_details')" >				
			<?		
			}//for($i=0;$i<=count($arrcomment);$i++){		
			echo "$showButton";	
			?>
			
			
			
			
								
	        <input name="hd_ecmt_item" type="hidden" id="hd_ecmt_item" value="<?=$ecmt_item ;?>">						
		  </div></td>
    </tr>
		<tr>
		<?
			$sql = "SELECT ecmt_item , ecmt_desc FROM ev_comment
					WHERE evn_id = '$evn_id'  ";
			$result = getData($sql);
			$arrdesc=array();
			 while ($row = mysql_fetch_array($result)){
			 	$arrdesc[$row["ecmt_item"]]=$row["ecmt_desc"];				
			 }
			 $showVal = 	$rs_ecmt["ecmt_desc"];
			 //echo "\$showVal=$showVal<br>";
			 //echo "\$ecmt_item=$ecmt_item<br>";
			 !$showVal ? $defDesc =  "\n".$arrComType[substr($ecmt_item,0,1)]." : " : $defDesc = $showVal ;		 
			?>
			 
		  <td height="150" >
            <div align="center">			
              <textarea name="ecmt_desc" cols="98" rows="15" wrap="OFF" id="ecmt_desc" value="<?=$showVal;?>">
			  <?=$defDesc;?>
		  </textarea>
			  <br>
              <br>
            </div>			
			</td>
    </tr>
    <tr align="center" >
      <td height="39">        
        <div align="center">
			<input name="Submit2" type="button" class="Button" value="&lt;= Back " onClick="window.location = 'efsv_viewForm.php?id=<?=$evn_id ;?>'" >
			<input name="Submit" type="submit" class="Button" value="   OK   "<?=$disabled ;?>  >        
			<input name="Button" type="button" class="Button" id="Button"  onClick="history.go(-1)" value="Cancel" >
			<input name="Submit22" type="button" class="Button" value="Next =&gt;" onClick="window.location = 'eckl_viewForm.php?id=<?=$evn_id?>'" >		  
	  </div></td>
    </tr>
  </table>
</form>
<?

	//======================Begin Save Data==============================================
	//request data into varible
	$Submit = $_REQUEST["Submit"];
	if(!empty($Submit)){
		$a_ecmt_item = $_REQUEST["hd_ecmt_item"];
		$a_ecmt_desc = $_REQUEST["ecmt_desc"];
		$a_ecmt_desc = htmlspecialchars($a_ecmt_desc);
		/*
		echo "
		submit = $Submit<br>
		evn_id =  $evn_id<br>
		a_ecmt_item = $a_ecmt_item<br> 
		a_ecmt_desc = $a_ecmt_desc<br>
		";  
		*/
		//check duplicate data in table ev_comment
		$sql = "SELECT * FROM ev_comment WHERE evn_id = '$evn_id' AND ecmt_item = '$a_ecmt_item'  ";
		//echo "$sql<br>";
		//exit();
		$result = getData($sql);
		$numrow = mysql_num_rows($result);
		$row = mysql_fetch_array($result);
		//echo "numrow = $numrow<br>";
		if ($numrow == 0 ){
				$action = "add";}
			else{
				$action = "edit";
		}
		//echo "action=$action<br>";
		//exit();
		
		function  checklist($value,$label,$field){
			global $resData;
			$resData[$field] = $value;
		} //function checklist($var,$name){
		
		checklist($a_ecmt_desc,"","ecmt_desc");
		
			if($action=="add"){
				$resData["ecmt_id"]="";
				$resData["ecmt_item"]="$a_ecmt_item";
				$resData["evn_id"] = $evn_id;
			
				$resData["usr_cre"] = $_SESSION["usr_name"];
				$resData["date_cre"] = date("Y/m/d  H:i:s");		
				
				$query = create_insert_query("ev_comment",$resData);	
				//echo "$query<br>";
				//exit();
				mysql_query($query) or die("Insert error");	
				//$SaveLog=updLog($_SESSION['username'], updSave, "$query");					
				//Show alert by javascript
				echo "<script>
						alert ('Insert complete');
						window.location = 'ecmt_updForm.php?id=$evn_id&id2=$a_ecmt_item';
					  </script>";
				exit();
			}
			
			if($action=="edit"){
				$resData["usr_upd"] = $_SESSION["usr_name"];
				$resData["date_upd"] = date("Y/m/d  H:i:s");		
				
				$query = create_update_query("ev_comment", $resData, $evn_id, "evn_id");				
				$query .= " AND ecmt_item = '$a_ecmt_item' " ;
				//echo "$query<br>";
				mysql_query($query) or die("Update error");		
				//$SaveLog=updLog($_SESSION['username'], updSave, "$query");
				//Show alert by javascript
				echo "<script>
						alert ('Update complete');
						window.location = 'ecmt_updForm.php?id=$evn_id&id2=$a_ecmt_item' ;
					  </script>";
				exit();
			}
		

	} //if(!empty($Submit)){
	
	//======================End Save Data==============================================
?>