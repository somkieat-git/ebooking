BODY {
	FONT-SIZE: x-small;  COLOR: #000000; BACKGROUND-REPEAT: repeat-y; FONT-FAMILY: sans-serif; BACKGROUND-COLOR: #f5f5f5
}
PRE {
	FONT-SIZE: x-small
}
TT {
	FONT-SIZE: x-small
}
TH {
	FONT-WEIGHT: bold; FONT-SIZE: x-small; COLOR: #000000; FONT-FAMILY: sans-serif; BACKGROUND-COLOR: #d3dce3
}
TD {
	FONT-SIZE: x-small; FONT-FAMILY: sans-serif
}
FORM {
	PADDING-RIGHT: 0px; PADDING-LEFT: 0px; FONT-SIZE: x-small; PADDING-BOTTOM: 0px; MARGIN: 0px; PADDING-TOP: 0px; FONT-FAMILY: sans-serif
}
INPUT {
	FONT-SIZE: x-small; FONT-FAMILY: sans-serif
}
INPUT.textfield {
	FONT-SIZE: x-small; COLOR: #000000; FONT-FAMILY: sans-serif; BACKGROUND-COLOR: #ffffff
}
SELECT {
	FONT-SIZE: x-small; COLOR: #000000; FONT-FAMILY: sans-serif; BACKGROUND-COLOR: #ffffff
}
TEXTAREA {
	FONT-SIZE: x-small; COLOR: #000000; FONT-FAMILY: sans-serif; BACKGROUND-COLOR: #ffffff
}
H1 {
	FONT-WEIGHT: bold; FONT-SIZE: large; FONT-FAMILY: sans-serif
}
H2 {
	FONT-WEIGHT: bold; FONT-SIZE: medium; FONT-FAMILY: sans-serif
}
H3 {
	FONT-WEIGHT: bold; FONT-SIZE: x-small; FONT-FAMILY: sans-serif
}
A:link {
	FONT-SIZE: x-small; COLOR: #0000ff; FONT-FAMILY: sans-serif; TEXT-DECORATION: none
}
A:visited {
	FONT-SIZE: x-small; COLOR: #0000ff; FONT-FAMILY: sans-serif; TEXT-DECORATION: none
}
A:hover {
	FONT-SIZE: x-small; COLOR: #ff0000; FONT-FAMILY: sans-serif; TEXT-DECORATION: underline
}
A.nav:link {
	COLOR: #000000; FONT-FAMILY: sans-serif
}
A.nav:visited {
	COLOR: #000000; FONT-FAMILY: sans-serif
}
A.nav:hover {
	COLOR: #ff0000; FONT-FAMILY: sans-serif
}
A.h1:link {
	FONT-WEIGHT: bold; FONT-SIZE: large; COLOR: #000000; FONT-FAMILY: sans-serif
}
A.h1:active {
	FONT-WEIGHT: bold; FONT-SIZE: large; COLOR: #000000; FONT-FAMILY: sans-serif
}
A.h1:visited {
	FONT-WEIGHT: bold; FONT-SIZE: large; COLOR: #000000; FONT-FAMILY: sans-serif
}
A.h1:hover {
	FONT-WEIGHT: bold; FONT-SIZE: large; COLOR: #ff0000; FONT-FAMILY: sans-serif
}
A.h2:link {
	FONT-WEIGHT: bold; FONT-SIZE: medium; COLOR: #000000; FONT-FAMILY: sans-serif
}
A.h2:active {
	FONT-WEIGHT: bold; FONT-SIZE: medium; COLOR: #000000; FONT-FAMILY: sans-serif
}
A.h2:visited {
	FONT-WEIGHT: bold; FONT-SIZE: medium; COLOR: #000000; FONT-FAMILY: sans-serif
}
A.h2:hover {
	FONT-WEIGHT: bold; FONT-SIZE: medium; COLOR: #ff0000; FONT-FAMILY: sans-serif
}
A.drop:link {
	COLOR: #ff0000; FONT-FAMILY: sans-serif
}
A.drop:visited {
	COLOR: #ff0000; FONT-FAMILY: sans-serif
}
A.drop:hover {
	COLOR: #ffffff; FONT-FAMILY: sans-serif; BACKGROUND-COLOR: #ff0000; TEXT-DECORATION: none
}
DFN {
	FONT-STYLE: normal
}
DFN:hover {
	CURSOR: help; FONT-STYLE: normal
}
.nav {
	COLOR: #000000; FONT-FAMILY: sans-serif
}
.warning {
	FONT-WEIGHT: bold; FONT-SIZE: x-small; COLOR: #ff0000; FONT-FAMILY: sans-serif
}
.tblcomment {
	FONT-WEIGHT: normal; FONT-SIZE: 7pt; COLOR: #000099; FONT-FAMILY: sans-serif
}
TD.topline {
	FONT-SIZE: 1px
}
TD.tab {
	BORDER-RIGHT: #666 1px solid; BORDER-TOP: #999 1px solid; BORDER-LEFT: #999 1px solid; BORDER-BOTTOM-STYLE: none; border-radius: 2px; moz-border-radius: 2px
}
DIV.tabs {
	CLEAR: both
}
TABLE.tabs {
	BORDER-TOP-STYLE: none; BORDER-BOTTOM: #666 1px solid; BORDER-RIGHT-STYLE: none; BORDER-LEFT-STYLE: none
}
FIELDSET {
	BORDER-RIGHT: #686868 1px solid; PADDING-RIGHT: 0.5em; BORDER-TOP: #686868 1px solid; PADDING-LEFT: 0.5em; PADDING-BOTTOM: 0.5em; BORDER-LEFT: #686868 1px solid; PADDING-TOP: 0.5em; BORDER-BOTTOM: #686868 1px solid
}
FIELDSET FIELDSET {
	MARGIN: 0.8em
}
BUTTON.mult_submit {
	BORDER-TOP-STYLE: none; BORDER-RIGHT-STYLE: none; BORDER-LEFT-STYLE: none; BACKGROUND-COLOR: transparent; BORDER-BOTTOM-STYLE: none
}
.pdflayout {
	BORDER-RIGHT: #000000 1px solid; BORDER-TOP: #000000 1px solid; DISPLAY: none; OVERFLOW: hidden; BORDER-LEFT: #000000 1px solid; BORDER-BOTTOM: #000000 1px solid; POSITION: relative; BACKGROUND-COLOR: #ffffff
}
.pdflayout_table {
	BORDER-RIGHT: #000000 1px dashed; BORDER-TOP: #000000 1px dashed; DISPLAY: inline; FONT-SIZE: 90%; Z-INDEX: 2; BACKGROUND: #d3dce3; VISIBILITY: inherit; OVERFLOW: hidden; BORDER-LEFT: #000000 1px dashed; CURSOR: move; COLOR: #000000; BORDER-BOTTOM: #000000 1px dashed; POSITION: absolute
}
.print {
	FONT-SIZE: 8pt; FONT-FAMILY: arial
}
.syntax {
	FONT-SIZE: 90%; FONT-FAMILY: sans-serif
}
.syntax_comment {
	PADDING-RIGHT: 4pt; PADDING-LEFT: 4pt
}
.syntax_digit {
	
}
.syntax_digit_hex {
	
}
.syntax_digit_integer {
	
}
.syntax_digit_float {
	
}
.syntax_punct {
	
}
.syntax_alpha {
	
}
.syntax_alpha_columnType {
	TEXT-TRANSFORM: uppercase
}
.syntax_alpha_columnAttrib {
	TEXT-TRANSFORM: uppercase
}
.syntax_alpha_reservedWord {
	FONT-WEIGHT: bold; TEXT-TRANSFORM: uppercase
}
.syntax_alpha_functionName {
	TEXT-TRANSFORM: uppercase
}
.syntax_alpha_identifier {
	
}
.syntax_alpha_charset {
	
}
.syntax_alpha_variable {
	
}
.syntax_quote {
	WHITE-SPACE: pre
}
.syntax_quote_backtick {
	
}
HR {
	BORDER-TOP-WIDTH: 0px; BORDER-LEFT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; COLOR: #666666; HEIGHT: 1px; BACKGROUND-COLOR: #666666; BORDER-RIGHT-WIDTH: 0px
}
.nav {
	COLOR: #000000; BORDER-TOP-STYLE: none; BORDER-BOTTOM: #666 1px solid; FONT-FAMILY: sans-serif; BORDER-RIGHT-STYLE: none; BORDER-LEFT-STYLE: none
}
.navSpacer {
	WIDTH: 5px; HEIGHT: 16px
}
.navNormal {
	BORDER-RIGHT: #666 1px solid; PADDING-RIGHT: 5px; BORDER-TOP: #999 1px solid; PADDING-LEFT: 5px; FONT-WEIGHT: bold; FONT-SIZE: x-small; PADDING-BOTTOM: 2px; BORDER-LEFT: #999 1px solid; PADDING-TOP: 2px; FONT-FAMILY: sans-serif; BORDER-BOTTOM-STYLE: none; border-radius: 2px; moz-border-radius: 2px
}
.navDrop {
	BORDER-RIGHT: #666 0px solid; PADDING-RIGHT: 0px; BORDER-TOP: #999 0px solid; PADDING-LEFT: 0px; FONT-WEIGHT: bold; FONT-SIZE: x-small; PADDING-BOTTOM: 0px; BORDER-LEFT: #999 0px solid; PADDING-TOP: 0px; FONT-FAMILY: sans-serif; BORDER-BOTTOM-STYLE: none; border-radius: 0px; moz-border-radius: 0px
}
.navActive {
	BORDER-RIGHT: #666 1px solid; PADDING-RIGHT: 5px; BORDER-TOP: #999 1px solid; PADDING-LEFT: 5px; FONT-WEIGHT: bold; FONT-SIZE: x-small; PADDING-BOTTOM: 2px; BORDER-LEFT: #999 1px solid; PADDING-TOP: 2px; FONT-FAMILY: sans-serif; BORDER-BOTTOM-STYLE: none; border-radius: 2px; moz-border-radius: 2px
}
.navNormal {
	COLOR: #000000; BACKGROUND-COLOR: #e5e5e5
}
.navActive {
	FONT-WEIGHT: bold; FONT-SIZE: x-small; COLOR: #000000; FONT-FAMILY: sans-serif; BACKGROUND-COLOR: #cccccc
}
.navDrop {
	COLOR: #000000; BACKGROUND-COLOR: #e5e5e5
}
.navNormal A:link {
	COLOR: #0000ff
}
.navNormal A:active {
	COLOR: #0000ff
}
.navNormal A:visited {
	COLOR: #0000ff
}
.navActive A:link {
	COLOR: #0000ff
}
.navActive A:active {
	COLOR: #0000ff
}
.navActive A:visited {
	COLOR: #0000ff
}
.navDrop A:link {
	COLOR: #ff0000
}
.navDrop A:active {
	COLOR: #ff0000
}
.navDrop A:visited {
	COLOR: #ff0000
}
.navDrop A:hover {
	COLOR: #ffffff; BACKGROUND-COLOR: #ff0000
}
.navNormal A:hover {
	COLOR: #ff0000
}
.navActive A:hover {
	COLOR: #ff0000
}
DIV.errorhead {
	FONT-WEIGHT: bold; MARGIN: 0px; COLOR: #ffffff; TEXT-ALIGN: left
}
.tblError {
	BORDER-RIGHT: #ff0000 1px solid; BORDER-TOP: #ff0000 1px solid; BORDER-LEFT: #ff0000 1px solid; BORDER-BOTTOM: #ff0000 1px solid; BACKGROUND-COLOR: #ffffcc
}
.tblWarn {
	BORDER-RIGHT: #ff0000 1px solid; BORDER-TOP: #ff0000 1px solid; BORDER-LEFT: #ff0000 1px solid; BORDER-BOTTOM: #ff0000 1px solid; BACKGROUND-COLOR: #ffffff
}
DIV.tblWarn {
	BORDER-RIGHT: #ff0000 1px solid; BORDER-TOP: #ff0000 1px solid; BORDER-LEFT: #ff0000 1px solid; BORDER-BOTTOM: #ff0000 1px solid; BACKGROUND-COLOR: #ffffff
}
DIV.tblWarn {
	PADDING-RIGHT: 5px; PADDING-LEFT: 5px; PADDING-BOTTOM: 5px; MARGIN: 0px 0px 5px; WIDTH: 100%; PADDING-TOP: 5px
}
.tblHeaders {
	FONT-WEIGHT: bold; COLOR: #000000; BACKGROUND-COLOR: #d0dce0
}
.tblFooters {
	FONT-WEIGHT: normal; COLOR: #000000; BACKGROUND-COLOR: #d0dce0
}
.tblHeaders A:link {
	COLOR: #0000ff
}
.tblHeaders A:active {
	COLOR: #0000ff
}
.tblHeaders A:visited {
	COLOR: #0000ff
}
.tblFooters A:link {
	COLOR: #0000ff
}
.tblFooters A:active {
	COLOR: #0000ff
}
.tblFooters A:visited {
	COLOR: #0000ff
}
.tblHeaders A:hover {
	COLOR: #ff0000
}
.tblFooters A:hover {
	COLOR: #ff0000
}
.tblHeadError {
	FONT-WEIGHT: bold; COLOR: #ffffff; BACKGROUND-COLOR: #ff0000
}
.tblHeadWarn {
	FONT-WEIGHT: bold; COLOR: #000000; BACKGROUND-COLOR: #ffcc00
}
.noPrivileges {
	FONT-WEIGHT: bold; COLOR: #ff0000
}
.serverinfo {
	PADDING-RIGHT: 0px; PADDING-LEFT: 0px; FONT-WEIGHT: normal; FONT-SIZE: x-small; PADDING-BOTTOM: 10px; VERTICAL-ALIGN: middle; PADDING-TOP: 0px; FONT-FAMILY: sans-serif; WHITE-SPACE: nowrap
}
IMG {
	VERTICAL-ALIGN: middle
}
INPUT {
	VERTICAL-ALIGN: middle
}
SELECT {
	VERTICAL-ALIGN: middle
}
BUTTON {
	VERTICAL-ALIGN: middle
}
.syntax_comment {
	COLOR: #808000
}
.syntax_comment_mysql {
	
}
.syntax_comment_ansi {
	
}
.syntax_comment_c {
	
}
.syntax_digit {
	
}
.syntax_digit_hex {
	COLOR: teal
}
.syntax_digit_integer {
	COLOR: teal
}
.syntax_digit_float {
	COLOR: aqua
}
.syntax_punct {
	COLOR: fuchsia
}
.syntax_alpha {
	
}
.syntax_alpha_columnType {
	COLOR: #ff9900
}
.syntax_alpha_columnAttrib {
	COLOR: #0000ff
}
.syntax_alpha_reservedWord {
	COLOR: #990099
}
.syntax_alpha_functionName {
	COLOR: #ff0000
}
.syntax_alpha_identifier {
	COLOR: black
}
.syntax_alpha_charset {
	COLOR: #6495ed
}
.syntax_alpha_variable {
	COLOR: #800000
}
.syntax_quote {
	COLOR: #008000
}
.syntax_quote_double {
	
}
.syntax_quote_single {
	
}
.syntax_quote_backtick {
	
}
.syntax_indent0 {
	MARGIN-LEFT: 0em
}
.syntax_indent1 {
	MARGIN-LEFT: 1em
}
.syntax_indent2 {
	MARGIN-LEFT: 2em
}
.syntax_indent3 {
	MARGIN-LEFT: 3em
}
.syntax_indent4 {
	MARGIN-LEFT: 4em
}
.syntax_indent5 {
	MARGIN-LEFT: 5em
}
.syntax_indent6 {
	MARGIN-LEFT: 6em
}
.syntax_indent7 {
	MARGIN-LEFT: 7em
}
TABLE.calendar {
	WIDTH: 100%
}
TABLE.calendar TD {
	TEXT-ALIGN: center
}
TABLE.calendar TD A {
	DISPLAY: block
}
TABLE.calendar TD A:hover {
	BACKGROUND-COLOR: #ccffcc
}
TABLE.calendar TH {
	BACKGROUND-COLOR: #d3dce3
}
TABLE.calendar TD.selected {
	BACKGROUND-COLOR: #ffcc99
}
IMG.calendar {
	BORDER-TOP-STYLE: none; BORDER-RIGHT-STYLE: none; BORDER-LEFT-STYLE: none; BORDER-BOTTOM-STYLE: none
}
FORM.clock {
	TEXT-ALIGN: center
}
.nowrap {
	WHITE-SPACE: nowrap
}
DIV.nowrap {
	PADDING-RIGHT: 0px; PADDING-LEFT: 0px; PADDING-BOTTOM: 0px; MARGIN: 0px; PADDING-TOP: 0px
}
LI {
	PADDING-BOTTOM: 1em
}
LI FORM {
	DISPLAY: inline
}
UL.main {
	PADDING-RIGHT: 2em; PADDING-LEFT: 2em; MARGIN: 0px
}
BUTTON {
	DISPLAY: inline
}
.tab {
	FONT-WEIGHT: bolder; WHITE-SPACE: nowrap
}
TD.tab {
	WIDTH: 64px; BACKGROUND-COLOR: #dfdfdf; TEXT-ALIGN: center
}
TD.tab A {
	DISPLAY: block
}
DIV.tab {
	
}
TD.activetab {
	BACKGROUND-COLOR: silver
}
TEXTAREA {
	OVERFLOW: auto
}
.nospace {
	PADDING-RIGHT: 0px; PADDING-LEFT: 0px; PADDING-BOTTOM: 0px; MARGIN: 0px; PADDING-TOP: 0px
}
