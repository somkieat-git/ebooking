<?	
	ob_start();
	session_start();
	//include("db/chksession.db.php");
	include_once("db/connect.db.php");
	include_once("func/sql.func.php");
	//define("updSave","eesv_updFormE.php");
	$updSave = "eesv_updFormE.php";
	$status = "E";
	$action = $_REQUEST["a"];
	$evn_id = $_REQUEST["id"];
	$eesv_id =  $_REQUEST["id2"];	
	$Submit = $_REQUEST["Submit"];
	$btn_show = $_REQUEST["btn_show"];
	//echo "action=$action<br>evn_id= $evn_id<br>eesv_id= $eesv_id<br>submit = $Submit<br>btn_show = $btn_show<hr>";
	//======================Begin prepare standard data======================================
	if(!empty($evn_id)){
		$sql = "SELECT * FROM eventname WHERE evn_id = '$evn_id'  ";
		$result = getData($sql);
		$row = mysql_fetch_array($result);
		$disabled = "";
		//if($row[3] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;
		if($row["evn_used"] == "c" && empty($_SESSION["admin"]) ) $disabled = "disabled" ;
		$evn_name = $row[2];
	} //if(!empty($ev_id)){	
	
	$sql = " SELECT eloc.eloc_id, loc.loc_id, loc.loc_shortname, eloc.eloc_in_date, ";
	$sql .= " eloc.eloc_end_date, eloc.eloc_in_time, eloc.eloc_end_time";
	$sql .= " FROM location loc, ev_location eloc ";
	$sql .= " WHERE loc.loc_id = eloc.loc_id ";
	$sql .= " AND eloc.evn_id = '$evn_id' ";
	$sql .= " ORDER BY loc.loc_shortname, eloc.eloc_in_date, eloc.eloc_end_date, eloc.eloc_in_time, eloc.eloc_end_time ";
//	echo "1.=<br>$sql<hr>";
	$rstEloc = getData($sql);					
	$arrEloc = array();
	while ($rsEloc = mysql_fetch_array($rstEloc)){
		$elocID = $rsEloc["eloc_id"];
		$locID = $rsEloc["loc_id"];
		$shortName = $rsEloc["loc_shortname"];
		$inDate = chgDate($rsEloc["eloc_in_date"]);
		$endDate = chgDate($rsEloc["eloc_end_date"]);
		$inTime = chgTime($rsEloc["eloc_in_time"]);
		$endTime = chgTime($rsEloc["eloc_end_time"]);				
		$arrEloc[] = array($elocID,$locID,$shortName,$inDate,$endDate,$inTime,$endTime);
	} // while ($rsEesv = mysql_fetch_array($rstEloc)){
	
	$sql = " SELECT esv_id, esv_name, esv_amt, esv_include_vat ";
	$sql .= " FROM equip_serv ";
	$sql .= " WHERE esv_status = '$status' ";
	$sql .= " ORDER BY esv_name  ";
	//echo "2.$sql<hr>";
	$rstEsv = getData($sql);					
	$arrEsv = array();
	while ($rsEsv = mysql_fetch_array($rstEsv)){
		$esvID = $rsEsv["esv_id"];
		$esvName = $rsEsv["esv_name"];
		$esvAmt = $rsEsv["esv_amt"];
		$esvVat = $rsEsv["esv_include_vat"];
		$arrEsv[] = array($esvID,$esvName,$esvAmt,$esvVat);
	} // while ($rsEsv = mysql_fetch_array($rstEsv)){
	#Control Button
	if ($action == "a"){
		$button = "Insert Value";		
	}	
	if ($action == "e"){
		$button = "Update Value";
	}
	if ($action == "d"){
		$button = "Confirm Delete";
	}
		
	//======================End prepare stand data========================================

	//======================Begin select data from ev_dateblock===============================
	$action == "a"  ? $eesv_qty = 1 : 0 ;
	if($action != "a") {
			#Show ev_dateblock
			$sql = "SELECT eesv.eloc_id, eesv.loc_id, esv.esv_id, 
						eesv.eesv_beg_date, eesv.eesv_beg_time, eesv.eesv_end_date, eesv.eesv_end_time,
						eesv.eesv_day, eesv.eesv_amt, eesv.eesv_qty, eesv.eesv_total, eesv.eesv_adj, 
						eesv.eesv_net, eesv.eesv_chk_vat, eesv.eesv_before_vat, eesv.eesv_vat, eesv.eesv_include_vat
						FROM equip_serv esv, ev_equip_serv eesv						
						WHERE esv.esv_id = eesv.esv_id  						
						AND eesv_id  = $eesv_id 
						";
			//echo "3.$sql<hr>";
			$result = getData($sql);
			$rstEesv = mysql_fetch_array($result);				
			
			$eloc_id = $rstEesv["eloc_id"];
			$loc_id =  $rstEesv["loc_id"]; 
			$esv_id =  $rstEesv["esv_id"];
			$beg_date =  chgDate($rstEesv["eesv_beg_date"]);
			$beg_time =  chgTime($rstEesv["eesv_beg_time"]);
			$end_date =  chgDate($rstEesv["eesv_end_date"]);
			$end_time =  chgTime($rstEesv["eesv_end_time"]);
			$eesv_day =  chgNumber($rstEesv["eesv_day"]);
			$eesv_amt =  chgNumber($rstEesv["eesv_amt"]);
			$eesv_qty =  chgNumber($rstEesv["eesv_qty"]);
			$eesv_total =  chgNumber($rstEesv["eesv_total"]);
			$eesv_adj =  chgNumber($rstEesv["eesv_adj"]);
			$eesv_net =  chgNumber($rstEesv["eesv_net"]);			
			$eesv_chk_vat =  $rstEesv["eesv_chk_vat"];
			$eesv_before_vat =  chgNumber($rstEesv["eesv_before_vat"]);
			$eesv_vat =  chgNumber($rstEesv["eesv_vat"]);
			$eesv_include_vat =  chgNumber($rstEesv["eesv_include_vat"]);			
		}
?>
<html>
<head>
<title></title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link href="css/format.css.css" rel="stylesheet" type="text/css">
<!--<script language="javascript" type="text/javascript" src="datetimepicker.js"></script>-->
<script language="javascript" type="text/javascript" src="js/jsDate.js"></script>
<script language="javascript">
	function validate() 
	{
		if(frm.beg_date.value=="")
		{
			alert('Please input data in Begin Date');
			frm.beg_date.focus()
			return false;
		}
		
		if(frm.beg_time.value=="")
		{
			alert('Please input data in Begin Time');
			frm.beg_time.focus()
			return false;
		}
		if(frm.end_date.value=="")
		{
			alert('Please input data in End Date');
			frm.end_date.focus()
			return false;
		}
		if(frm.end_time.value=="")
		{
			alert('Please input data in End Time');
			frm.end_time.focus()
			return false;
		}
		if(frm.eesv_qty.value=="")
		{
			alert('Please input data in Quantity');
			frm.eesv_qty.focus()
			return false;
		}
		if(frm.eesv_amt.value=="")
		{
			alert('Please input data in Amount');
			frm.eesv_amt.focus()
			return false;
		}
	}
	
	function calcDays(date1,date2){
	  date1 = date1.split("/");
	  sDD = date1[0]; sMM =date1[1]; sYY =date1[2];	  
	  date2 = date2.split("/");
	  eDD = date2[0]; eMM =date2[1]; eYY =date2[2];	  
	  var sDate = new Date(sMM+"/"+sDD+"/"+sYY);
	  var eDate = new Date(eMM+"/"+eDD+"/"+eYY);
	  var daysApart = Math.abs(Math.round((sDate-eDate)/86400000));
	  return daysApart +1;
	} // end function calcDays
	
	function CDate(){
		begDate = document.frm.beg_date.value;
		endDate = document.frm.end_date.value;
		eesvDay = calcDays(begDate,endDate);		
		document.frm.eesv_day.value = eesvDay ;
	} //function onChange(){	
	
	function clickEloc(){
		x1 = document.frm.selLoc_id.selectedIndex ;
		x2 = document.frm.hddEloc[x1].value;		
		//alert(x2);
		arrEloc  =  x2.split("|");
		elocID = arrEloc[0];
		locID = arrEloc[1];
		inDate = arrEloc[3];
		endDate = arrEloc[4];
		inTime = arrEloc[5];
		endTime = arrEloc[6];		
		eesvDay = calcDays(inDate,endDate);				
		document.frm.eloc_id.value = elocID ;
		document.frm.loc_id.value = locID ;
		document.frm.beg_date.value = inDate ;
		document.frm.end_date.value = endDate ;
		document.frm.beg_time.value = inTime ;
		document.frm.end_time.value = endTime ;
		document.frm.eesv_day.value = eesvDay ;
		LostFocus();
	} //function clickEloc(){

	function clickEsv(){
		x1 = document.frm.selEsv_id.selectedIndex ;
		x2 = document.frm.hddEsv[x1-1].value;		
		//alert(x2);
		arrEsv  =  x2.split("|");
		esv_id = arrEsv[0];
		amtRate = arrEsv[2];
		incVat = arrEsv[3];
		document.frm.esv_id.value = esv_id ;
		document.frm.eesv_amt.value = amtRate ;
		if (incVat == "Y"){
			document.frm.eesv_chk_vat[0].checked = true;
		}
		else{
			document.frm.eesv_chk_vat[1].checked = true;
		}
		LostFocus();
	} //function clickEsv(){
	
	function LostFocus() {	
		CDate();
		var day=0, qty=0, amt=0, total=0, adj=0, net=0, chkvat=0, b4vat=0, vat=0, incvat=0 
		var svat, sb4vat, sincvat
		day = Number(document.frm.eesv_day.value.replace(",",""));
		qty = Number(document.frm.eesv_qty.value.replace(",","")) ;
		amt = Number(document.frm.eesv_amt.value.replace(",","")) ;
		adj = Number(document.frm.eesv_adj.value.replace(",","")) ;
		total = day * qty * amt ;
		net = Number(total) + adj ;
		//amt = document.frm.eesv_amt.value.replace(",","");
		//alert( amt );
		if (document.frm.eesv_chk_vat[0].checked == true ){
			//alert(document.frm.eesv_chk_vat[0].value);
			vat = Number(net * 7 / 107) ;
			svat = Number(net * 7 / 107).toFixed(2) ;
			b4vat = Number(net - vat) ;
			sb4vat = Number(net - vat).toFixed(2) ;
		}		
		if (document.frm.eesv_chk_vat[1].checked == true ){
			//alert(document.frm.eesv_chk_vat[1].value);
			vat = Number(net * 7 / 100) ;
			svat = Number(net * 7 / 100).toFixed(2) ;
			b4vat = Number(net) ;
			sb4vat = Number(net).toFixed(2) ;
		}		
		incvat = Number(b4vat + vat,2) ;
		sincvat = Number(b4vat + vat,2).toFixed(2) ;
			
		document.frm.eesv_total.value = total ;
		document.frm.eesv_net.value = net ;
		document.frm.eesv_before_vat.value = sb4vat ;
		document.frm.eesv_vat.value = svat ;
		document.frm.eesv_include_vat.value = sincvat ;
	}	
</script>


<!--------------  jQuery Datepick (Popup Calendra)  ---------------------->
	
	<link href="./css/jquery.datepick.css" type="text/css" rel="stylesheet" />
	<script type="text/javascript" src="lib/jquery.min.js"></script>	
	<script type="text/javascript" src="js/jquery.datepick.js"></script>
	<script type="text/javascript">
	$(function() {
		jQuery('#beg_date').datepick({showOnFocus: false,  yearRange: 'c-10:c+10' , showTrigger: '#calImg'});
		jQuery('#end_date').datepick({showOnFocus: false,  yearRange: 'c-10:c+10' , showTrigger: '#calImg'});
	});
	</script>


</head>
	
<body >
<form action="<?=$updSave?>?a=<?=$action ?>&id=<?=$evn_id?>&id2=<?=$eesv_id?>" method="post" name="frm"  id="frm" onSubmit="return validate();" >
  <table border="0" class="BorderGreen" >
    <tr class="BorderSilver">
      <td colspan="4"  style="background-color:#339900;font-weight:bold;color:White;">
	  	<div align="center"><strong >Equipments / Services   - <?=$evn_id." - " .$evn_name ?></strong></div>
	  </td>
    </tr>
	<tr>
	  <td height="16" colspan="4" ><input name="hd_evn_id" type="hidden" id="hd_evn_id" value="<?=$evn_id ;?>">
      <input name="eesv_id" type="hidden" id="eesv_id" value="<?=$eesv_id ;?>">      </td>
    </tr>
	<tr>
	  <td ><div align="right">Location : </div></td>
      <td colspan="3" >
	  <?php //echo "\$eloc_id= $eloc_id"; ?>
	  <select name="selLoc_id" id="selLoc_id" onChange="clickEloc();">
	  	<option value="">- - - Select Location - - -</option>
	  	<?
			foreach($arrEloc as $key => $val ){
				$eloc_id == $val[0] ? $selected = "selected" : $selected = "" ;
				echo "<option value = ".$val[0].' '.$selected.">".$val[2] ."  [ ".$val[3]." - " .$val[4] ." : ". $val[5]." - ". $val[6]." ]</option>";
			}
		?>
      </select>	  
	  <?
	  	reset($arrEloc);
		echo '<input name="hddEloc" type="hidden" id="hddEloc" value="0">';	
	  	foreach($arrEloc as $key => $val ){
			$show = $val[0]."|".$val[1]."|".$val[2] ."|".$val[3]."|".$val[4]."|".$val[5] ."|".$val[6];
			echo '<input name="hddEloc" type="hidden" id="hddEloc" value="'.$show .'">';	
		}		
	  ?>
	  <input name="eloc_id" type="hidden" id="eloc_id" value="<?=$eloc_id;?>">
      <input name="loc_id" type="hidden" id="loc_id" value="<?=$loc_id;?>">
</td>
    </tr>
	<tr>
	  <td ><div align="right">Begin Date : </div></td>
	  <td >
	  <input type="text" name="beg_date" id="beg_date" value="<?=$beg_date?>" onFocus="return LostFocus()" />
	  <div style="display: none;"> 
		<img id="calImg" src="images/calendar.gif" alt="Pick a date" class="trigger"> 
	  </div>
	  </td>
	  <td ><div align="right">Begin Time : </div></td>
	  <td ><input name="beg_time" type="text" id="beg_time" value="<?=$beg_time ;?>"></td>
    </tr>
	<tr>
	  <td height="18" ><div align="right">End Date : </div></td>
	  <td >
	  <input type="text" name="end_date" id="end_date" value="<?=$end_date?>" onBlur="return LostFocus()" />
	  <div style="display: none;"> 
		<img id="calImg" src="images/calendar.gif" alt="Pick a date" class="trigger"> 
	  </div>
	  </td>
	  <td ><div align="right">End Time : </div></td>
	  <td ><input name="end_time" type="text" id="end_time" value="<?=$end_time ;?>"></td>
    </tr>
	<tr>
	  <td height="18" colspan="4" >&nbsp;</td>
    </tr>
	<tr>
	  <td height="18" ><div align="right">Equipment : </div></td>
      <td height="18" colspan="3" >
<select name="selEsv_id" id="selEsv_id" onChange="clickEsv();">
	<option value="">- - - Select Equipment - - -</option>
  <? 
				foreach($arrEsv as $key => $val){
					$esv_id == $val[0] ? $selected = "selected":$selected = "";
					echo "<option value = ".$val[0].' '.$selected.">".$val[1] ." </option>";
				}
			?>
</select>		  
<?
				foreach($arrEsv as $key => $val){
					$show = $val[0]."|".$val[1]."|".$val[2]."|".$val[3]  ;
					echo '<input name="hddEsv" type="hidden" id="hddEsv" value="'.$show .'">';	
				}
		  ?>
<input name="esv_id" type="hidden" id="esv_id" value="<?=$esv_id ;?>">
</td>
    </tr>
	<tr>
	  <td height="18" ><div align="right">Rate :</div></td>
	  <td height="18" ><input name="eesv_amt" type="text" id="eesv_amt" value="<?=$eesv_amt ;?>" onBlur="return LostFocus()" readonly></td>
	  <td ><div align="right">Total : </div></td>
	  <td ><input name="eesv_total" type="text" id="eesv_adj22" value="<?=$eesv_total ;?>" onBlur="return LostFocus()" readonly></td>
	</tr>
	<tr>
	  <td height="18" ><div align="right">Day : </div></td>
      <td height="18" ><input name="eesv_day" type="text" id="eesv_day" value="<?=$eesv_day ;?>" size="10" maxlength="10" onBlur="return LostFocus()" readonly></td>
      <td height="18" ><div align="right">Rate Adjust :</div></td>
      <td height="18" ><input name="eesv_adj" type="text" id="eesv_adj3" value="<?=$eesv_adj ;?>" onBlur="return LostFocus()"></td>
	</tr>
	<tr>
	  <td height="18" ><div align="right">Quantity : </div></td>
	  <td ><input name="eesv_qty" type="text" id="eesv_qty" value="<?=$eesv_qty ;?>" size="10" maxlength="10" onBlur="return LostFocus()">
	  <a href="javascript:NewCal('txt_out_date','ddmmyyyy',false,12)">	  </a>
	  </td>
	  <td height="18" ><div align="right">Net :</div></td>
	  <td height="18" ><input name="eesv_net" type="text" id="eesv_net2" value="<?=$eesv_net ;?>" onBlur="return LostFocus()" readonly></td>
	</tr>
	<tr>
	  <td height="18" colspan="4" ><hr width="100%" noshade  color="#339900"></td>
    </tr>
	<tr>
	  <td height="18" colspan="2" ><div align="center">
	    <input name="eesv_chk_vat" type="radio" value="Y" 
		<? if($eesv_chk_vat == "Y") echo 'checked'?> onClick="return LostFocus()"
		>
	  Include Vat </div></td>
      <td height="18" colspan="2" ><div align="center">
        <input name="eesv_chk_vat" type="radio" value="N" 
		<? if($eesv_chk_vat == "N") echo 'checked'?> onClick="return LostFocus()"
		>
      Exclude Vat </div></td>
    </tr>
	<tr>
	  <td height="18" colspan="3" ><div align="right"></div>	    <div align="right">Amt Before Vat : </div></td>
	  <td height="18" ><input name="eesv_before_vat" type="text" id="eesv_net3" value="<?=$eesv_before_vat ;?>" readonly ></td>
    </tr>
	<tr>
	  <td height="18" colspan="3" ><div align="right">Vat : </div></td>
	  <td height="18" ><input name="eesv_vat" type="text" id="eesv_net4" value="<?=$eesv_vat ;?>" readonly ></td>
    </tr>
	<tr>
	  <td height="18" colspan="3" ><div align="right">Amt Include Vat : </div></td>
	  <td height="18" ><input name="eesv_include_vat" type="text" id="eesv_net5" value="<?=$eesv_include_vat ;?>" readonly ></td>
    </tr>
	<tr>
	  <td height="18" colspan="4" >&nbsp;</td>
    </tr>
	<tr>
	  <td height="18" colspan="4" ><div align="center">
			<input name="Submit2" type="button" class="Button" value="&lt;= Back " onClick="window.location = 'eloc_viewForm.php?id=<?=$evn_id?>'" >
			<!--<input name="Submit" type="submit" class="Button" value="<?$button ;?>" <?$disabled ;?> onClick="return validate();" />-->
			<input name="Submit" type="submit" class="Button" value="<?=$button ;?>" <?=$disabled ;?> />
			<input name="btn_show" type="submit" id="btn_show" class="Button" value="Show" />
			<input name="btnCancel" type="button" class="Button" id="btnCancel"  onClick="window.location = 'eesv_viewForm.php?id=<?=$evn_id?>'" value="Cancel" >
			<input name="Submit22" type="button" class="Button" value="Next =&gt;" onClick="window.location = 'efsv_viewForm.php?id=<?=$evn_id?>'" >		  
	  </div></td>
    </tr>	
  </table>
</form>
</html>
<?

	//======================Begin Save Data==============================================
	//request data into varible
	
	
	if(!empty($Submit) || !empty($btn_show)){	
	
				
		$evn_id =  $_REQUEST["hd_evn_id"];
		$eesv_id = $_REQUEST["eesv_id"];
		$eloc_id = $_REQUEST["eloc_id"];
		$loc_id = $_REQUEST["loc_id"];
		$esv_id = $_REQUEST["esv_id"];
		$beg_date =  chgDateToDb($_REQUEST["beg_date"]);
		$beg_time =  chgTimeToDb($_REQUEST["beg_time"]);
		$end_date =  chgDateToDb($_REQUEST["end_date"]);
		$end_time =  chgTimeToDb($_REQUEST["end_time"]);
		$eesv_day =  chgNumberToDb($_REQUEST["eesv_day"]);
		$eesv_amt =  chgNumberToDb($_REQUEST["eesv_amt"]);
		$eesv_qty =  chgNumberToDb($_REQUEST["eesv_qty"]);
		$eesv_total =  chgNumberToDb($_REQUEST["eesv_total"]);
		$eesv_adj = chgNumberToDb($_REQUEST["eesv_adj"]);
		$eesv_net =  chgNumberToDb($_REQUEST["eesv_net"]);
		$eesv_chk_vat =  chgNumberToDb($_REQUEST["eesv_chk_vat"]);
		$eesv_before_vat =  chgNumberToDb($_REQUEST["eesv_before_vat"]);
		$eesv_vat = chgNumberToDb($_REQUEST["eesv_vat"]);
		$eesv_include_vat =  chgNumberToDb($_REQUEST["eesv_include_vat"]);
		
		function  checklist($value,$label,$field){
			global $resData;
			$resData[$field] = $value;
		}				
		checklist($eloc_id,"","eloc_id");
		checklist($loc_id,"","loc_id");
		checklist($esv_id,"","esv_id");
		checklist($beg_date,"","eesv_beg_date");
		checklist($beg_time,"","eesv_beg_time");
		checklist($end_date,"","eesv_end_date");
		checklist($end_time,"","eesv_end_time");
		checklist($eesv_day,"","eesv_day");
		checklist($eesv_amt,"","eesv_amt");
		checklist($eesv_qty,"","eesv_qty");
		checklist($eesv_total,"","eesv_total");
		checklist($eesv_adj,"","eesv_adj");
		checklist($eesv_net,"","eesv_net");		
		checklist($eesv_chk_vat,"","eesv_chk_vat");
		checklist($eesv_before_vat,"","eesv_before_vat");
		checklist($eesv_vat,"","eesv_vat");
		checklist($eesv_include_vat,"","eesv_include_vat");		

		
		if($btn_show){
			$action = "s";
		}
		
		//echo "#2 : action=$action<br>evn_id= $evn_id<br>eesv_id= $eesv_id<br>submit = $Submit<br>btn_show = $btn_show<hr>";
		
			if($action=="a"){				
				$resData["evn_id"] = $evn_id ;
				$resData["usr_cre"] = $_SESSION["usr_name"];
				$resData["date_cre"] = date("Y/m/d  H:i:s");						
				$query = create_insert_query("ev_equip_serv",$resData);	
				//echo "$query<br>";exit();
				mysql_query($query) or die("Insert error");	
				$eesv_id = mysql_insert_id();
				$SaveLog=updLog($_SESSION['username'], $updSave, "$query");					
				$updRev = updRevenue("a","ev_equip_serv","eesv_id",$eesv_id);				
				//Show alert by javascript
				echo "<script>
						alert ('Insert complete');
						window.location = 'eesv_updFormE.php?a=e&id=$evn_id&id2=$eesv_id&eesv_id=$eesv_id&btn_show=y' ;
					  </script>";
				exit();
			} //if($action=="a"){				
			
			if($action=="e"){
				$_SESSION["eesv_showRev"] = "";				
				$resData["usr_upd"] = $_SESSION["usr_name"];
				$resData["date_upd"] = date("Y/m/d  H:i:s");		
				
				$query = create_update_query("ev_equip_serv", $resData, $eesv_id, "eesv_id");				
				//echo "$query<br>";exit();
				mysql_query($query) or die("Update ev_equip_serv error");
				$SaveLog=updLog($_SESSION['username'], $updSave, "$query");		
				//$delRev = delRevenue($rev_type,$eesv_id);
				$updRev = updRevenue("e","ev_equip_serv","eesv_id",$eesv_id);
				$eesv_showRev = updRevenue("s","ev_equip_serv","eesv_id",$eesv_id);
				$_SESSION["eesv_showRev"] = $eesv_showRev ;
				//Show alert by javascript
				echo "<script type='text/javascript'>
						alert ('Update complete');
						window.location = 'eesv_updFormE.php?a=e&id=$evn_id&id2=$eesv_id&eesv_id=$eesv_id&btn_show=y' ;
					  </script>";
				exit();
			} //if($action=="e"){
			
			if($action=="d"){			
				#delete value in ev_equip_serv			
				$sql = "DELETE  FROM ev_equip_serv  
							WHERE eesv_id = $eesv_id
							 ";
				//echo "$sql<br>";
				mysql_query($sql) or die("Delete error");	
				$SaveLog=updLog($_SESSION['username'], $updSave, "$sql");			
				$updRev = delRevenue("equip",$eesv_id);
				//Show alert by javascript
				echo "<script>
						alert ('Delete complete');
						window.location = 'eesv_viewForm.php?id=$evn_id' ;
					  </script>";
				exit();				
			} //if($action=="d"){	
			
			if($action == "s"){
				//$_SESSION["eesv_showRev"] = "";	
				$resData["usr_upd"] = $_SESSION["usr_name"];
				$resData["date_upd"] = date("Y/m/d  H:i:s");		
				
				$eesv_showRev = updRevenue("s","ev_equip_serv","eesv_id",$eesv_id);
				$_SESSION["eesv_showRev"] = $eesv_showRev ;
				//echo "\$updRev= <pre>"; print_r($updRev); echo "<hr>";
			}// if($action == "show"){
					
		} //if(!empty($Submit) && $action != "d"){			
			

	
	//======================End Save Data==============================================
	
	
	if($btn_show){	
		include_once("eesv_showDetail.php");				
	}		
	
	
include("db/disconnect.db.php");	
?>
