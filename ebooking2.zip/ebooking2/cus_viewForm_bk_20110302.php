<?
	ob_start(); 
	session_start();
	define("tableName","nameinfo");
	define("viewForm","cus_viewForm.php");
	define("updForm","cus_updForm.php");
	define("field_id","pro_id");
	define("beg_id",2);	
	define("end_id",19);	
	$sql = "SELECT *
				FROM profile
				";
	//echo "$sql";
	//exit();
	define("query","$sql");
	
	$cap_name = array();
	$cap_name = array("#", "Code", "Main Address", "MailAd",
            "Title(Th)", "Title(En)", "*First Name(Th)", "*First Name(En)",
            "*Last Name(Th)", "*Last Name(En)", "Pro Tnname", "Pro Enname",
            "Pro Prefix Com.Name(Th)", "Prefix Com.Name(En)", "Company Name(Th)", "Company Name(En)",
            "Pro Suffix Com.Name(Th)", "Suffix Com.Name(Th)", "Com Regis", "Department(Th)",
            "Department(En)", "Position(Th)", "Position(En)", "Address1(Th)",
            "Address1(En)", "Address2(Th)", "Address2(En)", "Soi.(Th)",
            "Soi.(En)", "Road.(Th)", "Road.(En)", "Tambol(Th)", "Tambol(En)",
            "District(Th)", "District(En)", "Province(Th)", "Province(En)",
            "Country(Th)", "Country(En)", "Postcode(Th)", "Postcode(En)",
            "Telephone(Th)", "Telephone(En)", "Fax.(Th)", "Fax.(En)", "Mobile",
            "Website", "E-mail1", "E-mail2", "Birthdate",
            "Sex", "National", "Marital", "Occupation",
            "OccupatCm", "Industry", "IndustryCm", "Education",
            "Source", "Reject", "Remark", "Lang", "Seq",
            "Show", "User Create", "Date Create", "User Update", "Date Update");
	
	
	$key = array_keys($_SESSION["sec_add"], viewForm); 
	//print_r(array_keys($_SESSION["sec_add"], viewForm));
	if($key[0])
		define("insert",1);		
	else
		define("insert",0);			
	//echo "insert = ".insert."<br>";
		
	$key = array_keys($_SESSION["sec_edit"], viewForm); 
	//print_r(array_keys($_SESSION["sec_edit"], viewForm));
	if($key[0])
		define("edit",1);		
	else
		define("edit",0);			
	//echo "edit = ".edit."<br>";
	
	$key = array_keys($_SESSION["sec_del"], viewForm); 
	//print_r(array_keys($_SESSION["sec_del"], viewForm));
	if($key[0])
		define("del",1);		
	else
		define("del",0);			
	//echo "del = ".del."<hr>";
	
	include("func/viewForm.func.php");
?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
</body>
</html>
